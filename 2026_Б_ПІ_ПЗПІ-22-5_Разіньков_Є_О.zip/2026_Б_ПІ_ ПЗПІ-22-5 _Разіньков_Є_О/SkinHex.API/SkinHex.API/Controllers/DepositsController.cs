using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using SkinHex.Core.Entities;
using SkinHex.Core.Interfaces.Services;
using SkinHex.Core.Models;
using SkinHex.Core.Options;
using SkinHex.Infrastructure;

namespace SkinHex.API.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class DepositsController : ControllerBase
{
    private readonly SkinHexDbContext _dbContext;
    private readonly INowPaymentsService _nowPaymentsService;
    private readonly NowPaymentsOptions _options;
    private readonly ILogger<DepositsController> _logger;

    public DepositsController(
        SkinHexDbContext dbContext,
        INowPaymentsService nowPaymentsService,
        IOptions<NowPaymentsOptions> options,
        ILogger<DepositsController> logger)
    {
        _dbContext = dbContext;
        _nowPaymentsService = nowPaymentsService;
        _options = options.Value;
        _logger = logger;
    }

    public record CreateDepositRequest(decimal AmountUsd, string? PayCurrency);

    /// <summary>Curated list of coins the user can deposit with (rendered in the currency picker).</summary>
    [AllowAnonymous]
    [HttpGet("currencies")]
    public IActionResult GetCurrencies()
    {
        return Ok(new
        {
            platformMinUsd = _options.MinDepositUsd,
            depositFeePercent = _options.DepositFeePercent,
            currencies = SupportedDepositCurrencies.All
        });
    }

    /// <summary>
    /// Effective minimum deposit for a coin: the greater of the platform minimum ($3) and the
    /// NOWPayments per-coin minimum (which depends on our custody/outcome currency).
    /// </summary>
    [AllowAnonymous]
    [HttpGet("min-amount")]
    public async Task<IActionResult> GetMinAmount([FromQuery] string payCurrency, CancellationToken ct)
    {
        if (!SupportedDepositCurrencies.IsSupported(payCurrency))
            return BadRequest("Unsupported currency.");

        decimal? coinMinCrypto = null;
        decimal? coinMinUsd = null;

        try
        {
            var min = await _nowPaymentsService.GetMinAmountAsync(payCurrency, _options.OutcomeCurrency, ct);
            coinMinCrypto = min.MinAmount;
            coinMinUsd = min.FiatEquivalentUsd;
        }
        catch (Exception ex)
        {
            // Don't fail the whole form if NOWPayments is briefly unavailable; fall back to the platform minimum.
            _logger.LogWarning(ex, "Failed to fetch NOWPayments min-amount for {PayCurrency}", payCurrency);
        }

        var effectiveMinUsd = Math.Max(_options.MinDepositUsd, coinMinUsd ?? 0m);

        return Ok(new
        {
            payCurrency,
            coinMinCrypto,
            coinMinUsd,
            platformMinUsd = _options.MinDepositUsd,
            minUsd = decimal.Round(effectiveMinUsd, 2, MidpointRounding.ToPositiveInfinity)
        });
    }

    /// <summary>Estimates how much crypto a USD amount converts to, for the live USD ⇆ crypto fields.</summary>
    [AllowAnonymous]
    [HttpGet("estimate")]
    public async Task<IActionResult> GetEstimate([FromQuery] decimal amountUsd, [FromQuery] string payCurrency, CancellationToken ct)
    {
        if (!SupportedDepositCurrencies.IsSupported(payCurrency))
            return BadRequest("Unsupported currency.");
        if (amountUsd <= 0)
            return BadRequest("Amount must be greater than zero.");

        try
        {
            var estimatedCrypto = await _nowPaymentsService.GetEstimatedPriceAsync(amountUsd, "usd", payCurrency, ct);
            return Ok(new { payCurrency, amountUsd, estimatedCrypto });
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to fetch NOWPayments estimate for {PayCurrency}", payCurrency);
            return StatusCode(StatusCodes.Status502BadGateway, "Could not fetch conversion rate. Please try again.");
        }
    }

    [HttpPost]
    public async Task<IActionResult> CreateDeposit([FromBody] CreateDepositRequest request, CancellationToken ct)
    {
        var userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

        if (request.AmountUsd <= 0) return BadRequest("Amount must be greater than zero.");

        var payCurrency = string.IsNullOrWhiteSpace(request.PayCurrency) ? null : request.PayCurrency.Trim();
        if (payCurrency is not null && !SupportedDepositCurrencies.IsSupported(payCurrency))
            return BadRequest("Unsupported currency.");

        // Enforce the effective minimum server-side so the client can't bypass it.
        var effectiveMinUsd = _options.MinDepositUsd;
        if (payCurrency is not null)
        {
            try
            {
                var min = await _nowPaymentsService.GetMinAmountAsync(payCurrency, _options.OutcomeCurrency, ct);
                if (min.FiatEquivalentUsd is { } coinMinUsd)
                    effectiveMinUsd = Math.Max(effectiveMinUsd, coinMinUsd);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to fetch NOWPayments min-amount during deposit for {PayCurrency}", payCurrency);
            }
        }

        // request.AmountUsd is the NET amount credited to the balance (what the user asked to deposit).
        if (request.AmountUsd < effectiveMinUsd)
            return BadRequest($"Minimum deposit for this currency is ${decimal.Round(effectiveMinUsd, 2, MidpointRounding.ToPositiveInfinity)}.");

        // Gross-up: the user pays net × (1 + fee) so that, after the NOWPayments service fee,
        // the full requested (net) amount lands on their balance. Round up so the fee is never undercharged.
        var netUsd = request.AmountUsd;
        var grossUsd = decimal.Round(netUsd * (1 + _options.DepositFeePercent), 2, MidpointRounding.ToPositiveInfinity);

        // Create transaction and deposit in DB
        var financialTransaction = new FinancialTransaction
        {
            Id = Guid.NewGuid(),
            UserId = userId,
            Amount = netUsd,
            Type = FinancialTransactionType.Deposit,
            Status = FinancialTransactionStatus.Pending,
            CreatedAt = DateTime.UtcNow
        };

        var depositId = Guid.NewGuid();

        var deposit = new Deposit
        {
            Id = depositId,
            UserId = userId,
            FiatAmount = netUsd,
            PayCurrency = payCurrency ?? string.Empty,
            NowPaymentsPaymentId = depositId.ToString(),
            Status = DepositStatus.Waiting,
            TransactionId = financialTransaction.Id,
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        };

        financialTransaction.ReferenceId = deposit.Id;

        _dbContext.FinancialTransactions.Add(financialTransaction);
        _dbContext.Deposits.Add(deposit);

        // We save to DB first to have an order_id, although typically you could call API first
        // If API fails, transaction rolls back
        await using var dbTransaction = await _dbContext.Database.BeginTransactionAsync(ct);
        try
        {
            await _dbContext.SaveChangesAsync(ct);

            // Invoice is billed the grossed-up amount; balance is credited the net amount on webhook.
            var invoiceResult = await _nowPaymentsService.CreateInvoiceAsync(grossUsd, deposit.Id.ToString(), payCurrency, ct);

            deposit.NowPaymentsPaymentId = invoiceResult.InvoiceId;
            await _dbContext.SaveChangesAsync(ct);
            await dbTransaction.CommitAsync(ct);

            return Ok(new
            {
                depositId = deposit.Id,
                invoiceUrl = invoiceResult.InvoiceUrl,
                netUsd,
                grossUsd,
                feeUsd = grossUsd - netUsd
            });
        }
        catch
        {
            await dbTransaction.RollbackAsync(ct);
            throw;
        }
    }

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> GetDepositStatus(Guid id)
    {
        var userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        var deposit = await _dbContext.Deposits.FindAsync(id);

        if (deposit == null) return NotFound();
        if (deposit.UserId != userId) return Forbid();

        return Ok(new { status = deposit.Status.ToString(), fiatAmount = deposit.FiatAmount });
    }
}
