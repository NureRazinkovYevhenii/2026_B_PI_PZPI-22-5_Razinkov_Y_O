import { useState, useRef, useEffect } from 'react';
import { ShoppingCart, Wallet, Plus, Minus } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import type { AuthState, PageKey } from '../types';
import { UserDropdown } from './UserDropdown';
import { HeaderSearch } from './HeaderSearch';
import { LanguageSwitcher } from './LanguageSwitcher';
import { useCart } from '../utils/CartContext';
import { CartDrawer } from './CartDrawer';
import { NotificationsDropdown } from './NotificationsDropdown';
import { FrozenBalancePill } from './FrozenBalancePill';

type AppHeaderProps = {
  activePage: PageKey;
  auth: AuthState | null;
  isUnverified: boolean;
  onLogin: () => void;
  onLogout: () => void;
  onNavigate: (page: PageKey) => void;
  onDepositClick: () => void;
  onWithdrawClick: () => void;
  isAdmin?: boolean;
};

export function AppHeader({ activePage, auth, onLogin, onLogout, onNavigate, onDepositClick, onWithdrawClick, isAdmin = false }: AppHeaderProps) {
  const { t } = useTranslation();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const { cart } = useCart();

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <>
      <header className="glass-panel" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 28px', position: 'sticky', top: 0, zIndex: 50, borderRadius: '0 0 16px 16px', margin: '-28px -28px 28px -28px', borderTop: 'none', borderLeft: 'none', borderRight: 'none' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '32px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }} onClick={() => onNavigate('home')}>
          <img src="/logo.png" alt="SkinHex Logo" style={{ width: '32px', height: '32px', objectFit: 'contain' }} />
          <span style={{ fontSize: '20px', fontWeight: 800, color: 'var(--text-h)' }}>SkinHex</span>
        </div>
        <nav style={{ display: 'flex', gap: '4px' }}>
          <button className="nav-button" aria-current={activePage === 'catalog' ? 'page' : undefined} onClick={() => onNavigate('catalog')}>{t('header.market')}</button>
        </nav>
      </div>

      <HeaderSearch />

      <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
        <LanguageSwitcher />
        {auth ? (
          <>
            <div className="glass-panel" style={{ display: 'flex', alignItems: 'center', height: '36px', borderRadius: '8px', padding: '2px', background: 'var(--surface)', border: '1px solid var(--border)' }}>
              <div style={{ display: 'flex', alignItems: 'center', padding: '0 10px 0 12px', gap: '8px', borderRight: '1px solid var(--border)' }}>
                <Wallet size={16} color="var(--accent)" />
                <span style={{ fontWeight: 700, color: 'var(--accent)' }}>${auth.balance?.toFixed(2) ?? '0.00'}</span>
                <FrozenBalancePill amount={auth.frozenBalance ?? 0} />
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '2px', padding: '0 4px' }}>
                <button 
                  title="Deposit" 
                  onClick={onDepositClick}
                  style={{ width: '28px', height: '28px', borderRadius: '6px', background: 'rgba(16, 185, 129, 0.1)', border: '1px solid rgba(16, 185, 129, 0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: 'var(--accent)' }}
                >
                  <Plus size={16} />
                </button>
                <button title="Withdraw" onClick={onWithdrawClick} style={{ width: '28px', height: '28px', borderRadius: '6px', background: 'transparent', border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: 'var(--text-muted)' }}>
                  <Minus size={16} />
                </button>
              </div>
            </div>

            <button 
              className="icon-button" 
              style={{ border: 'none', background: 'transparent', borderRadius: '50%', position: 'relative' }}
              onClick={() => setCartOpen(true)}
            >
              <ShoppingCart size={20} color="var(--text-h)" />
              {cart.length > 0 && (
                <div style={{ position: 'absolute', top: '-4px', right: '-4px', background: 'var(--brand)', color: 'white', fontSize: '10px', fontWeight: 800, width: '16px', height: '16px', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  {cart.length}
                </div>
              )}
            </button>
            <NotificationsDropdown />

            <div ref={dropdownRef} style={{ position: 'relative' }}>
              <button 
                style={{ background: 'transparent', border: '2px solid var(--border)', borderRadius: '50%', padding: 0, cursor: 'pointer', overflow: 'hidden', width: '40px', height: '40px', display: 'block' }}
                onClick={() => setDropdownOpen(!dropdownOpen)}
              >
                {auth.avatarUrl ? (
                  <img src={auth.avatarUrl} alt="Avatar" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                ) : (
                  <div style={{ width: '100%', height: '100%', background: 'var(--surface-hover)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-h)' }}>
                    {auth.name?.charAt(0) ?? 'U'}
                  </div>
                )}
              </button>
              <UserDropdown
                isOpen={dropdownOpen}
                onClose={() => setDropdownOpen(false)}
                onNavigate={onNavigate}
                onLogout={onLogout}
                isAdmin={isAdmin}
              />
            </div>
          </>
        ) : (
          <button className="primary-button" style={{ background: 'var(--brand)', color: '#fff', border: 'none', borderRadius: '8px' }} onClick={onLogin}>
            {t('header.signIn')}
          </button>
        )}
      </div>
    </header>
    <CartDrawer isOpen={cartOpen} onClose={() => setCartOpen(false)} onNavigate={onNavigate} />
    </>
  );
}
