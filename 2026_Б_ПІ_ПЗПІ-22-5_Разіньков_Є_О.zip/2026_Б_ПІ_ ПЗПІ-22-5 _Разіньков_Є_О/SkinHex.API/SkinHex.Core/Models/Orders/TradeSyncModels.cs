using SkinHex.Core.Entities;

namespace SkinHex.Core.Models.Orders;

public enum TradeSyncActorRole
{
    Seller = 0,
    Buyer = 1,
}

public record PendingTradeSyncItemDto(
    Guid OrderId,
    string TradeOfferId,
    string? TradeId,
    SteamOfferState OfferState,
    SteamTradeStatus? TradeStatus,
    long? TimeUpdated,
    // Lets the buyer's extension find the incoming offer and verify its contents:
    // the listing's asset id and the counterparty's SteamId64.
    long? ExpectedAssetId = null,
    string? PartnerSteamId = null,
    // The caller's side of this order: "buyer" or "seller" (unified role-less sync).
    string? Role = null,
    // When set and in the past, the seller's completion proof is due (auto-TLSN trigger).
    long? EscrowEndsAtUnix = null,
    // Last buyer-corroborated offer state, so the buyer's extension can skip unchanged reports.
    SteamOfferState? BuyerReportedOfferState = null);

public record PendingTradeSyncResponse(
    string ActorRole,
    IReadOnlyCollection<PendingTradeSyncItemDto> Trades);

public class BatchTradeSyncUpdateRequest
{
    public string? ActorRole { get; set; }
    public List<BatchTradeSyncUpdateItem> Updates { get; set; } = [];
}

public class BatchTradeSyncUpdateItem
{
    public Guid OrderId { get; set; }
    public string TradeOfferId { get; set; } = string.Empty;
    public SteamOfferState OfferState { get; set; }
    public string? TradeId { get; set; }
    public SteamTradeStatus? TradeStatus { get; set; }
    public long? TimeUpdated { get; set; }

    /// <summary>Buyer role only: asset ids the buyer saw inside the incoming offer (items_to_receive).</summary>
    public List<string>? AssetIds { get; set; }
}

public record BatchTradeSyncUpdateItemResult(
    Guid OrderId,
    string TradeOfferId,
    bool Success,
    string? ErrorCode,
    string? Message,
    SteamTradeDto? Trade);

public record BatchTradeSyncUpdateResponse(
    string ActorRole,
    int Received,
    int Updated,
    int Failed,
    IReadOnlyCollection<BatchTradeSyncUpdateItemResult> Results);
