namespace SkinHex.Core.Models.Screenshots;

// Відповідь провайдера скріншотів на запит рендера (render_mode=sides).
public sealed class InspectScreenshotResult
{
    public bool IsReady { get; init; }        // status == "done" і є обидва посилання
    public string? Status { get; init; }
    public string? ExternalGuid { get; init; }
    public string? FrontUrl { get; init; }    // відносний URL у провайдера
    public string? BackUrl { get; init; }
}
