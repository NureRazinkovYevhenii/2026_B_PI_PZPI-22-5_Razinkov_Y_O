using Hangfire;
using Microsoft.Extensions.Logging;
using SkinHex.Core.Entities;
using SkinHex.Core.Interfaces.Repositories;
using SkinHex.Core.Interfaces.Screenshots;
using SkinHex.Core.Interfaces.Services;
using SkinHex.Core.Models.Steam;

namespace SkinHex.Core.Services;

public class ScreenshotJobs(
    IItemScreenshotRepository screenshotRepository,
    IInspectScreenshotClient screenshotClient,
    IScreenshotStorage screenshotStorage,
    IBackgroundJobClient backgroundJobClient,
    IUnitOfWork unitOfWork,
    ILogger<ScreenshotJobs> logger) : IScreenshotJobs
{
    // Провайдер рендерить асинхронно: якщо статус ще не "done",
    // перепитуємо із затримкою, а не валимо джобу в ретрай Hangfire.
    private const int MaxAttempts = 10;
    private static readonly TimeSpan PollDelay = TimeSpan.FromSeconds(30);

    public async Task CaptureAsync(Guid screenshotId, CancellationToken ct)
    {
        var screenshot = await screenshotRepository.GetByIdAsync(screenshotId, ct);
        if (screenshot is null)
        {
            logger.LogWarning("Screenshot {ScreenshotId} not found. Skipping capture.", screenshotId);
            return;
        }
        if (screenshot.Status == ScreenshotStatus.Ready)
            return;

        screenshot.Attempts++;
        var inspectLink = CsgoInspectLink.FromHex(screenshot.InspectHex);

        try
        {
            var result = await screenshotClient.RequestSidesAsync(inspectLink, ct);
            screenshot.ExternalGuid ??= result.ExternalGuid;

            if (!result.IsReady)
            {
                if (screenshot.Attempts >= MaxAttempts)
                {
                    screenshot.Status = ScreenshotStatus.Failed;
                    screenshot.LastError = $"Render was not ready after {screenshot.Attempts} attempts (last status: {result.Status}).";
                    logger.LogWarning(
                        "Screenshot {ScreenshotId} failed: render not ready after {Attempts} attempts.",
                        screenshotId, screenshot.Attempts);
                }
                else
                {
                    backgroundJobClient.Schedule<IScreenshotJobs>(
                        jobs => jobs.CaptureAsync(screenshotId, CancellationToken.None),
                        PollDelay);
                }

                await unitOfWork.SaveChangesAsync(ct);
                return;
            }

            var frontBytes = await screenshotClient.DownloadImageAsync(result.FrontUrl!, ct);
            var backBytes = await screenshotClient.DownloadImageAsync(result.BackUrl!, ct);

            screenshot.FrontImagePath = await screenshotStorage.SaveAsync($"{screenshot.Id}/front.png", frontBytes, ct);
            screenshot.BackImagePath = await screenshotStorage.SaveAsync($"{screenshot.Id}/back.png", backBytes, ct);
            screenshot.Status = ScreenshotStatus.Ready;
            screenshot.CompletedAt = DateTimeOffset.UtcNow;
            screenshot.LastError = null;

            await unitOfWork.SaveChangesAsync(ct);
            logger.LogInformation("Screenshot {ScreenshotId} captured and stored.", screenshotId);
        }
        catch (Exception exception) when (exception is not OperationCanceledException)
        {
            screenshot.LastError = Truncate(exception.Message, 1000);
            await unitOfWork.SaveChangesAsync(CancellationToken.None);

            // Прокидаємо далі — мережеві/провайдерські збої ретраїть Hangfire.
            throw;
        }
    }

    private static string Truncate(string value, int maxLength)
        => value.Length <= maxLength ? value : value[..maxLength];
}
