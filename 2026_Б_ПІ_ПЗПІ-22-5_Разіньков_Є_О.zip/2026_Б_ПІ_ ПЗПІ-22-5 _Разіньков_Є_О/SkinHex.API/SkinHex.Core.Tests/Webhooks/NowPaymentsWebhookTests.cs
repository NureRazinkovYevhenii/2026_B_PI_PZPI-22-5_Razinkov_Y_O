using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Moq;
using SkinHex.Core.Interfaces.Services;
using SkinHex.Infrastructure;
using SkinHex.API.Controllers;
using SkinHex.Core.Entities;
using Xunit;

namespace SkinHex.Core.Tests.Webhooks;

public class NowPaymentsWebhookTests
{
    private readonly WebhooksController _controller;
    private readonly Mock<INowPaymentsService> _nowPaymentsServiceMock;
    private readonly SkinHexDbContext _dbContext;

    public NowPaymentsWebhookTests()
    {
        var options = new DbContextOptionsBuilder<SkinHexDbContext>()
            .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
            .Options;
        _dbContext = new SkinHexDbContext(options);
        
        _nowPaymentsServiceMock = new Mock<INowPaymentsService>();
        var loggerMock = new Mock<ILogger<WebhooksController>>();

        _controller = new WebhooksController(_dbContext, _nowPaymentsServiceMock.Object, Mock.Of<INotificationService>(), loggerMock.Object);
        _controller.ControllerContext = new ControllerContext
        {
            HttpContext = new DefaultHttpContext()
        };
    }

    [Fact]
    public async Task HandleIpn_ValidSignatureAndFinished_UpdatesBalance()
    {
        var user = new User { Id = Guid.NewGuid(), Balance = 100 };
        var deposit = new Deposit 
        { 
            Id = Guid.NewGuid(), 
            UserId = user.Id, 
            FiatAmount = 50, 
            Status = DepositStatus.Waiting,
            Transaction = new FinancialTransaction { Id = Guid.NewGuid(), Status = FinancialTransactionStatus.Pending }
        };
        _dbContext.Users.Add(user);
        _dbContext.Deposits.Add(deposit);
        await _dbContext.SaveChangesAsync();

        var payload = new { order_id = deposit.Id.ToString(), payment_status = "finished" };
        var jsonPayload = JsonSerializer.Serialize(payload);
        
        _controller.Request.Headers["x-nowpayments-sig"] = "valid_sig";
        _controller.Request.Body = new MemoryStream(Encoding.UTF8.GetBytes(jsonPayload));

        _nowPaymentsServiceMock.Setup(s => s.VerifyIpnSignature(jsonPayload, "valid_sig")).Returns(true);

        var result = await _controller.HandleIpn();

        Assert.IsType<OkResult>(result);
        Assert.Equal(DepositStatus.Finished, deposit.Status);
        Assert.Equal(FinancialTransactionStatus.Completed, deposit.Transaction.Status);
        Assert.Equal(150, user.Balance);
    }

    [Fact]
    public async Task HandleIpn_PayinHashInPayload_StoresHashWithoutCallingDetailsApi()
    {
        var user = new User { Id = Guid.NewGuid(), Balance = 100 };
        var deposit = new Deposit
        {
            Id = Guid.NewGuid(),
            UserId = user.Id,
            FiatAmount = 50,
            NowPaymentsPaymentId = "invoice-1",
            Status = DepositStatus.Waiting,
            Transaction = new FinancialTransaction { Id = Guid.NewGuid(), Status = FinancialTransactionStatus.Pending }
        };
        _dbContext.Users.Add(user);
        _dbContext.Deposits.Add(deposit);
        await _dbContext.SaveChangesAsync();

        var payload = new
        {
            order_id = deposit.Id.ToString(),
            payment_status = "finished",
            payment_id = "555444333",
            pay_amount = 2.998818,
            payin_hash = "0xabc123"
        };
        var jsonPayload = JsonSerializer.Serialize(payload);

        _controller.Request.Headers["x-nowpayments-sig"] = "valid_sig";
        _controller.Request.Body = new MemoryStream(Encoding.UTF8.GetBytes(jsonPayload));
        _nowPaymentsServiceMock.Setup(s => s.VerifyIpnSignature(jsonPayload, "valid_sig")).Returns(true);

        var result = await _controller.HandleIpn();

        Assert.IsType<OkResult>(result);
        Assert.Equal("0xabc123", deposit.PayinHash);
        Assert.Equal("555444333", deposit.NowPaymentsPaymentId);
        Assert.Equal(2.998818m, deposit.PayAmount);
        _nowPaymentsServiceMock.Verify(
            s => s.GetPaymentDetailsAsync(It.IsAny<string>(), It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task HandleIpn_FinishedWithoutHashInPayload_FallsBackToPaymentDetailsApi()
    {
        var user = new User { Id = Guid.NewGuid(), Balance = 100 };
        var deposit = new Deposit
        {
            Id = Guid.NewGuid(),
            UserId = user.Id,
            FiatAmount = 50,
            NowPaymentsPaymentId = "555444333",
            Status = DepositStatus.Confirming,
            Transaction = new FinancialTransaction { Id = Guid.NewGuid(), Status = FinancialTransactionStatus.Pending }
        };
        _dbContext.Users.Add(user);
        _dbContext.Deposits.Add(deposit);
        await _dbContext.SaveChangesAsync();

        var payload = new { order_id = deposit.Id.ToString(), payment_status = "finished" };
        var jsonPayload = JsonSerializer.Serialize(payload);

        _controller.Request.Headers["x-nowpayments-sig"] = "valid_sig";
        _controller.Request.Body = new MemoryStream(Encoding.UTF8.GetBytes(jsonPayload));
        _nowPaymentsServiceMock.Setup(s => s.VerifyIpnSignature(jsonPayload, "valid_sig")).Returns(true);
        _nowPaymentsServiceMock
            .Setup(s => s.GetPaymentDetailsAsync("555444333", It.IsAny<CancellationToken>()))
            .ReturnsAsync(new NowPaymentsPaymentDetails(2.998818m, "0xfallbackhash", "finished"));

        var result = await _controller.HandleIpn();

        Assert.IsType<OkResult>(result);
        Assert.Equal("0xfallbackhash", deposit.PayinHash);
        Assert.Equal(2.998818m, deposit.PayAmount);
        Assert.Equal(150, user.Balance);
    }

    [Fact]
    public async Task HandleIpn_InvalidSignature_ReturnsUnauthorized()
    {
        _controller.Request.Headers["x-nowpayments-sig"] = "invalid_sig";
        _controller.Request.Body = new MemoryStream(Encoding.UTF8.GetBytes("{}"));

        _nowPaymentsServiceMock.Setup(s => s.VerifyIpnSignature(It.IsAny<string>(), It.IsAny<string>())).Returns(false);

        var result = await _controller.HandleIpn();

        Assert.IsType<UnauthorizedResult>(result);
    }

    [Fact]
    public async Task HandleIpn_DuplicateFinished_Idempotent()
    {
        var user = new User { Id = Guid.NewGuid(), Balance = 100 };
        var deposit = new Deposit 
        { 
            Id = Guid.NewGuid(), 
            UserId = user.Id, 
            FiatAmount = 50, 
            Status = DepositStatus.Finished, // Already finished
            Transaction = new FinancialTransaction { Id = Guid.NewGuid(), Status = FinancialTransactionStatus.Completed }
        };
        _dbContext.Users.Add(user);
        _dbContext.Deposits.Add(deposit);
        await _dbContext.SaveChangesAsync();

        var payload = new { order_id = deposit.Id.ToString(), payment_status = "finished" };
        var jsonPayload = JsonSerializer.Serialize(payload);
        
        _controller.Request.Headers["x-nowpayments-sig"] = "valid_sig";
        _controller.Request.Body = new MemoryStream(Encoding.UTF8.GetBytes(jsonPayload));

        _nowPaymentsServiceMock.Setup(s => s.VerifyIpnSignature(jsonPayload, "valid_sig")).Returns(true);

        var result = await _controller.HandleIpn();

        Assert.IsType<OkResult>(result);
        Assert.Equal(100, user.Balance); // Should not add 50 again
    }
}
