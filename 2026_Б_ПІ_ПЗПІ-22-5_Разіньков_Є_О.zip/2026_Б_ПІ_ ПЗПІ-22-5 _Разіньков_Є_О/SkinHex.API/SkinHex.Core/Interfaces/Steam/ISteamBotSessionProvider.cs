using SkinHex.Core.Models.Steam;

namespace SkinHex.Core.Interfaces.Steam;

public interface ISteamBotSessionProvider
{
    Task<SteamBotSession> GetAnyReadySessionAsync(CancellationToken cancellationToken = default);
    Task<SteamBotSession> GetSessionByBotAsync(string username, CancellationToken cancellationToken = default);
}

public interface ISteamBotSessionStore : ISteamBotSessionProvider
{
    Task StoreAsync(SteamBotSession session, CancellationToken cancellationToken = default);
}
