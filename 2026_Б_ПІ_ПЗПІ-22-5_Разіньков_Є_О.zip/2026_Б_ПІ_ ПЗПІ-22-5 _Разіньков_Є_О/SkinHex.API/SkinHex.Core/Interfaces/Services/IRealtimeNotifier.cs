namespace SkinHex.Core.Interfaces.Services;

/// <summary>
/// Transport-agnostic realtime push. Implemented in the API layer over SignalR so that
/// Core services can broadcast without referencing ASP.NET Core.
/// </summary>
public interface IRealtimeNotifier
{
    Task SendToUserAsync(Guid userId, string eventName, object payload, CancellationToken ct = default);
    Task SendToUsersAsync(IReadOnlyCollection<Guid> userIds, string eventName, object payload, CancellationToken ct = default);
}
