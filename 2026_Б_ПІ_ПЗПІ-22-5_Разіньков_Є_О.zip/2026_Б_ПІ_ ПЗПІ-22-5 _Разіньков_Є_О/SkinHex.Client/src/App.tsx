import { useCallback, useEffect, useState } from 'react';
import './App.css';
import { AppHeader } from './components/AppHeader';
import { VerificationBanner } from './components/VerificationBanner';
import { OnboardingModal } from './components/OnboardingModal';
import { API_BASE_URL, LOGIN_URL } from './config';
import { CatalogPage } from './pages/CatalogPage';
import { HomePage } from './pages/HomePage';
import { InventoryPage } from './pages/InventoryPage';
import { MyListingsPage } from './pages/MyListingsPage';
import { OrdersPage } from './pages/OrdersPage';
import { ProfilePage } from './pages/ProfilePage';
import { SkinPage } from './pages/SkinPage';
import { SupportPage } from './pages/SupportPage';
import { AdminPage } from './pages/AdminPage';
import { DepositPendingPage } from './pages/DepositPendingPage';
import { DepositModal } from './components/DepositModal';
import { WithdrawModal } from './components/WithdrawModal';
import type { AuthState, PageKey } from './types';
import { CartProvider } from './utils/CartContext';
import { NotificationsProvider } from './utils/NotificationsContext';
import type { BalanceChangedPayload } from './api/notificationsApi';
import { syncPendingTradesViaExtension } from './utils/extensionBridge';
import {
  PROMPT_SEEN_KEY,
  buildAuthState,
  cleanAuthParamsFromUrl,
  clearPersistedAuth,
  extractTokenPair,
  isAdmin,
  isUnverified,
  persistAuth,
  readInitialAuth,
} from './utils/auth';

const AUTO_TRADE_SYNC_INTERVAL_MS = 10 * 60 * 1000;
const TRADE_SYNC_LAST_RUN_AT_KEY = 'skinhex_trade_sync_last_run_at';
const TRADE_SYNC_NEXT_RUN_AT_KEY = 'skinhex_trade_sync_next_run_at';

const initialAuthSnapshot = readInitialAuth();
const pages: PageKey[] = ['home', 'profile', 'inventory', 'catalog', 'orders', 'my-listings', 'deposit-pending', 'admin', 'support'];

type Route = { page: PageKey; skinItemName: string | null };

/**
 * Parses the location hash into a route.
 * The skin page carries its target as `#skin/<url-encoded market hash name>`,
 * e.g. `#skin/AK-47%20%7C%20Nightwish%20(Field-Tested)` — one page per exterior/variant.
 */
function getRouteFromHash(): Route {
  const raw = window.location.hash.replace(/^#/, '');
  const separatorIndex = raw.indexOf('/');
  const head = separatorIndex === -1 ? raw : raw.slice(0, separatorIndex);

  if (head === 'skin') {
    const rest = separatorIndex === -1 ? '' : raw.slice(separatorIndex + 1);
    return { page: 'skin', skinItemName: rest ? decodeURIComponent(rest) : null };
  }

  return { page: pages.includes(head as PageKey) ? (head as PageKey) : 'home', skinItemName: null };
}

function App() {
  const initialRoute = getRouteFromHash();
  const [activePage, setActivePage] = useState<PageKey>(() => initialRoute.page);
  const [skinItemName, setSkinItemName] = useState<string | null>(() => initialRoute.skinItemName);
  const [auth, setAuth] = useState<AuthState | null>(() => initialAuthSnapshot.auth);
  const [isOnboardingOpen, setOnboardingOpen] = useState(() => {
    const initAuth = initialAuthSnapshot.auth;
    return !!(initAuth && (isUnverified(initAuth) || !initAuth.tradeUrl) && !sessionStorage.getItem(PROMPT_SEEN_KEY));
  });
  const [isDepositModalOpen, setDepositModalOpen] = useState(false);
  const [isWithdrawModalOpen, setWithdrawModalOpen] = useState(false);
  const unverified = isUnverified(auth);
  const admin = isAdmin(auth);

  const saveAuth = useCallback((nextAuth: AuthState) => {
    persistAuth(nextAuth);
    setAuth(nextAuth);
  }, []);

  const refreshAuth = useCallback(
    async (refreshToken: string) => {
      const response = await fetch(`${API_BASE_URL}/auth/refresh`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refreshToken }),
      });

      if (!response.ok) {
        clearPersistedAuth();
        setAuth(null);
        return null;
      }

      const tokenPair = extractTokenPair(await response.json());

      if (!tokenPair) {
        clearPersistedAuth();
        setAuth(null);
        return null;
      }

      const nextAuth = buildAuthState(
        tokenPair.accessToken,
        tokenPair.refreshToken,
        auth?.tradeUrl ?? null,
      );
      saveAuth(nextAuth);

      return nextAuth;
    },
    [auth?.tradeUrl, saveAuth],
  );

  const authorizedFetch = useCallback(
    async (path: string, init: RequestInit = {}) => {
      if (!auth?.accessToken) {
        throw new Error('Authentication is required.');
      }

      const send = (accessToken: string) =>
        fetch(`${API_BASE_URL}${path}`, {
          ...init,
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${accessToken}`,
            ...init.headers,
          },
        });

      let response = await send(auth.accessToken);

      if (response.status === 401 && auth.refreshToken) {
        const refreshedAuth = await refreshAuth(auth.refreshToken);

        if (refreshedAuth) {
          response = await send(refreshedAuth.accessToken);
        }
      }

      return response;
    },
    [auth?.accessToken, auth?.refreshToken, refreshAuth],
  );

  useEffect(() => {
    cleanAuthParamsFromUrl();
    if (initialAuthSnapshot.fromUrl) {
      window.location.hash = 'catalog';
      setActivePage('catalog');
    }
  }, []);

  useEffect(() => {
    if (auth?.accessToken) {
      authorizedFetch('/user/me')
        .then((res) => {
          if (!res.ok) throw new Error('Failed to fetch user profile');
          return res.json();
        })
        .then((data) => {
          setAuth((prev) => {
            if (!prev) return prev;
            const updated = {
              ...prev,
              balance: data.balance ?? prev.balance,
              frozenBalance: data.frozenBalance ?? prev.frozenBalance,
              avatarUrl: data.avatarUrl ?? prev.avatarUrl,
              name: data.username ?? prev.name,
              userId: data.steamId ?? prev.userId,
            };
            persistAuth(updated);
            return updated;
          });
        })
        .catch(console.error);
    }
  }, [auth?.accessToken, authorizedFetch]);

  useEffect(() => {
    const handleHashChange = () => {
      const route = getRouteFromHash();
      setActivePage(route.page);
      setSkinItemName(route.skinItemName);
    };

    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  useEffect(() => {
    if (isOnboardingOpen) {
      sessionStorage.setItem(PROMPT_SEEN_KEY, '1');
    }
  }, [isOnboardingOpen]);

  useEffect(() => {
    if (!auth?.refreshToken || !auth.expiresAt) {
      return;
    }

    const msUntilRefresh = auth.expiresAt - Date.now() - 60_000;
    const timerId = window.setTimeout(() => {
      if (auth.refreshToken) {
        void refreshAuth(auth.refreshToken);
      }
    }, Math.max(msUntilRefresh, 0));

    return () => window.clearTimeout(timerId);
  }, [auth?.expiresAt, auth?.refreshToken, refreshAuth]);

  useEffect(() => {
    if (!auth?.accessToken) {
      return;
    }

    let stopped = false;
    let timeoutId: number | undefined;

    const emitSchedule = (nextAutoRunAt: number) => {
      localStorage.setItem(TRADE_SYNC_NEXT_RUN_AT_KEY, String(nextAutoRunAt));
      window.dispatchEvent(new CustomEvent('skinhex:trade-sync-scheduled', {
        detail: { nextAutoRunAt },
      }));
    };

    const runTradeSync = async () => {
      try {
        // Unified sync: covers the user's purchases and sales in one pass.
        const result = await syncPendingTradesViaExtension(API_BASE_URL, { force: false });

        if (!stopped) {
          const lastRunAt = Date.now();
          localStorage.setItem(TRADE_SYNC_LAST_RUN_AT_KEY, String(lastRunAt));
          window.dispatchEvent(new CustomEvent('skinhex:trade-sync-completed', {
            detail: {
              ...result,
              lastRunAt,
              nextAutoRunAt: lastRunAt + AUTO_TRADE_SYNC_INTERVAL_MS,
            },
          }));
        }
      } catch {
        // Silent on purpose: extension may be missing or unavailable.
      }
    };

    const scheduleNextRun = (delayMs: number) => {
      const normalizedDelay = Math.max(0, delayMs);
      const nextAutoRunAt = Date.now() + normalizedDelay;
      emitSchedule(nextAutoRunAt);

      timeoutId = window.setTimeout(async () => {
        if (stopped) {
          return;
        }

        await runTradeSync();
        scheduleNextRun(AUTO_TRADE_SYNC_INTERVAL_MS);
      }, normalizedDelay);
    };

    const now = Date.now();
    const nextRunRaw = localStorage.getItem(TRADE_SYNC_NEXT_RUN_AT_KEY);
    const nextRunAt = nextRunRaw ? Number(nextRunRaw) : NaN;

    if (Number.isFinite(nextRunAt) && nextRunAt > now) {
      scheduleNextRun(nextRunAt - now);
    } else {
      const lastRunRaw = localStorage.getItem(TRADE_SYNC_LAST_RUN_AT_KEY);
      const lastRunAt = lastRunRaw ? Number(lastRunRaw) : NaN;
      const hasValidLastRun = Number.isFinite(lastRunAt) && lastRunAt > 0;

      if (!hasValidLastRun) {
        scheduleNextRun(0);
      } else {
        const elapsedMs = now - lastRunAt;
        const delayMs = AUTO_TRADE_SYNC_INTERVAL_MS - elapsedMs;
        scheduleNextRun(delayMs);
      }
    }

    return () => {
      stopped = true;
      if (timeoutId !== undefined) {
        window.clearTimeout(timeoutId);
      }
    };
  }, [auth?.accessToken]);

  const handleBalanceUpdate = useCallback((payload: BalanceChangedPayload) => {
    setAuth((prev) => {
      if (!prev) return prev;
      const updated = { ...prev, balance: payload.balance, frozenBalance: payload.frozenBalance };
      persistAuth(updated);
      return updated;
    });
  }, []);

  const navigate = (page: PageKey) => {
    window.location.hash = page;
    setActivePage(page);
    setSkinItemName(null);
  };

  const openOnboarding = () => {
    setOnboardingOpen(true);
  };

  const closeOnboarding = () => {
    sessionStorage.setItem(PROMPT_SEEN_KEY, '1');
    setOnboardingOpen(false);
  };

  const handleLogin = () => {
    window.location.href = LOGIN_URL;
  };

  const handleLogout = () => {
    clearPersistedAuth();
    setAuth(null);
    setOnboardingOpen(false);
  };

  return (
    <CartProvider authorizedFetch={authorizedFetch} isAuthenticated={!!auth?.accessToken}>
      <NotificationsProvider
        authorizedFetch={authorizedFetch}
        isAuthenticated={!!auth?.accessToken}
        onBalanceUpdate={handleBalanceUpdate}
      >
      <main className="app-shell">
        <AppHeader
          activePage={activePage}
          auth={auth}
          isUnverified={unverified}
          onLogin={handleLogin}
          onLogout={handleLogout}
          onNavigate={navigate}
          onDepositClick={() => setDepositModalOpen(true)}
          onWithdrawClick={() => setWithdrawModalOpen(true)}
          isAdmin={admin}
        />

        {auth && (unverified || !auth.tradeUrl) ? <VerificationBanner isUnverified={unverified} onVerify={openOnboarding} /> : null}

        {activePage === 'home' ? <HomePage auth={auth} isUnverified={unverified} onNavigate={navigate} /> : null}
        {activePage === 'inventory' ? (
          <InventoryPage 
            auth={auth} 
            authorizedFetch={authorizedFetch} 
            onAuthUpdate={saveAuth} 
            onRequireLogin={handleLogin}
            onRequireVerification={openOnboarding}
          />
        ) : null}
        {activePage === 'catalog' ? (
          <CatalogPage auth={auth} authorizedFetch={authorizedFetch} onRequireLogin={handleLogin} />
        ) : null}
        {activePage === 'orders' ? (
          <OrdersPage auth={auth} authorizedFetch={authorizedFetch} onRequireLogin={handleLogin} />
        ) : null}
        {activePage === 'my-listings' ? (
          <MyListingsPage auth={auth} authorizedFetch={authorizedFetch} onRequireLogin={handleLogin} />
        ) : null}
        {activePage === 'profile' ? (
          <ProfilePage
            auth={auth}
            authorizedFetch={authorizedFetch}
            isUnverified={unverified}
            onAuthUpdate={saveAuth}
            onLogin={handleLogin}
            onOpenVerification={openOnboarding}
          />
        ) : null}
        {activePage === 'deposit-pending' ? (
          <DepositPendingPage />
        ) : null}
        {activePage === 'support' ? (
          <SupportPage auth={auth} authorizedFetch={authorizedFetch} onRequireLogin={handleLogin} />
        ) : null}
        {activePage === 'admin' ? (
          admin ? (
            <AdminPage auth={auth} authorizedFetch={authorizedFetch} />
          ) : (
            <HomePage auth={auth} isUnverified={unverified} onNavigate={navigate} />
          )
        ) : null}
        {activePage === 'skin' ? (
          <SkinPage
            itemName={skinItemName}
            auth={auth}
            authorizedFetch={authorizedFetch}
            onRequireLogin={handleLogin}
            onBack={() => navigate('catalog')}
          />
        ) : null}

        <DepositModal
          isOpen={isDepositModalOpen}
          onClose={() => setDepositModalOpen(false)}
        />

        <WithdrawModal
          isOpen={isWithdrawModalOpen}
          onClose={() => setWithdrawModalOpen(false)}
          balance={auth?.balance}
        />

        {isOnboardingOpen && auth ? (
          <OnboardingModal
            auth={auth}
            authorizedFetch={authorizedFetch}
            onAuthUpdate={saveAuth}
            onClose={closeOnboarding}
          />
        ) : null}

      </main>
      </NotificationsProvider>
    </CartProvider>
  );
}

export default App;
