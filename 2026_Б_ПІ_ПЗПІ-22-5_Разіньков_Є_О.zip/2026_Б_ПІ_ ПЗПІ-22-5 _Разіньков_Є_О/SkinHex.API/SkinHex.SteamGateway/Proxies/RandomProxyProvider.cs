using System.Collections.Concurrent;
using System.Net;
using Microsoft.Extensions.Options;
using SkinHex.SteamGateway.Options;

namespace SkinHex.SteamGateway.Proxies;

public sealed class RandomProxyProvider : IWebProxy
{
    private readonly ConcurrentDictionary<string, DateTimeOffset> _quarantinedUntil = new(StringComparer.OrdinalIgnoreCase);
    private readonly AsyncLocal<ProxyEndpoint?> _currentProxy = new();
    private readonly ProxyEndpoint[] _proxies;
    private readonly TimeSpan _quarantineDuration;
    private readonly TimeProvider _timeProvider;
    private readonly ILogger<RandomProxyProvider> _logger;
    private ICredentials? _credentials;

    public RandomProxyProvider(
        IOptions<ProxyOptions> options,
        TimeProvider timeProvider,
        ILogger<RandomProxyProvider> logger)
    {
        _timeProvider = timeProvider;
        _logger = logger;
        _quarantineDuration = TimeSpan.FromMinutes(options.Value.QuarantineMinutes);
        _proxies = options.Value.Endpoints
            .Select(ProxyEndpoint.Parse)
            .ToArray();
        _credentials = new ProxyCredentialMap(_proxies);
    }

    public ICredentials? Credentials
    {
        get => _credentials;
        set => _credentials = value;
    }

    public Uri GetProxy(Uri destination)
    {
        var proxy = PickProxy()
            ?? throw new InvalidOperationException("No healthy Steam proxy is available.");

        _currentProxy.Value = proxy;
        return proxy.Uri;
    }

    public bool IsBypassed(Uri host) => false;

    public void PenalizeCurrentProxy(string reason)
    {
        var proxy = _currentProxy.Value;
        if (proxy is null)
        {
            return;
        }

        var until = _timeProvider.GetUtcNow().Add(_quarantineDuration);
        _quarantinedUntil[proxy.Key] = until;
        _currentProxy.Value = null;

        _logger.LogWarning(
            "Steam proxy {Proxy} was quarantined until {QuarantinedUntil:u}. Reason: {Reason}",
            proxy.SanitizedUri,
            until,
            reason);
    }

    private ProxyEndpoint? PickProxy()
    {
        var now = _timeProvider.GetUtcNow();
        foreach (var (key, until) in _quarantinedUntil)
        {
            if (until <= now)
            {
                _quarantinedUntil.TryRemove(key, out _);
            }
        }

        var healthy = _proxies
            .Where(proxy => !_quarantinedUntil.ContainsKey(proxy.Key))
            .ToArray();

        return healthy.Length == 0
            ? null
            : healthy[Random.Shared.Next(healthy.Length)];
    }

    private sealed record ProxyEndpoint(Uri Uri, Uri SanitizedUri, NetworkCredential? Credential)
    {
        public string Key => SanitizedUri.Authority;

        public static ProxyEndpoint Parse(string value)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(value);

            var normalized = value.Contains("://", StringComparison.Ordinal)
                ? value
                : $"http://{value}";

            if (!Uri.TryCreate(normalized, UriKind.Absolute, out var uri))
            {
                throw new InvalidOperationException($"Proxy endpoint '{value}' is not a valid absolute URI.");
            }

            var credential = CreateCredential(uri);
            var sanitized = new UriBuilder(uri)
            {
                UserName = string.Empty,
                Password = string.Empty
            }.Uri;

            return new ProxyEndpoint(sanitized, sanitized, credential);
        }

        private static NetworkCredential? CreateCredential(Uri uri)
        {
            if (string.IsNullOrWhiteSpace(uri.UserInfo))
            {
                return null;
            }

            var parts = uri.UserInfo.Split(':', 2);
            var username = Uri.UnescapeDataString(parts[0]);
            var password = parts.Length == 2
                ? Uri.UnescapeDataString(parts[1])
                : string.Empty;

            return new NetworkCredential(username, password);
        }
    }

    private sealed class ProxyCredentialMap(IEnumerable<ProxyEndpoint> endpoints) : ICredentials
    {
        private readonly IReadOnlyDictionary<string, NetworkCredential> _credentials = endpoints
            .Where(endpoint => endpoint.Credential is not null)
            .ToDictionary(
                endpoint => endpoint.Key,
                endpoint => endpoint.Credential!,
                StringComparer.OrdinalIgnoreCase);

        public NetworkCredential? GetCredential(Uri uri, string authType)
        {
            return _credentials.TryGetValue(uri.Authority, out var credential)
                ? credential
                : null;
        }
    }
}
