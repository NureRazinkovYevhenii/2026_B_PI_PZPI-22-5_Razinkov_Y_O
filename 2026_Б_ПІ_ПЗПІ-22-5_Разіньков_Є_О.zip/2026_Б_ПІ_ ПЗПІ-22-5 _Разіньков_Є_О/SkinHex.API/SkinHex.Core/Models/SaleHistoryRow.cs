using SkinHex.Core.Entities;

namespace SkinHex.Core.Models;

/// <summary>
/// Raw projection row returned by the repository for sale history queries.
/// The service layer maps this to <see cref="SaleHistoryItemDto"/>.
/// </summary>
public sealed class SaleHistoryRow
{
    public Listing Listing { get; set; } = null!;
    public DateTime SoldAt { get; set; }
}
