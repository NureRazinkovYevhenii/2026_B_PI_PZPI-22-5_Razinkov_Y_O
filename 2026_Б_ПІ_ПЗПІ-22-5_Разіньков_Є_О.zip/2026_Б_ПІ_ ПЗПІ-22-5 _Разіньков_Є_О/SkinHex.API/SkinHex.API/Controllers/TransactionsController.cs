using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SkinHex.Core.Entities;
using SkinHex.Core.Models;
using SkinHex.Core.Models.Transactions;
using SkinHex.Infrastructure;

namespace SkinHex.API.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public sealed class TransactionsController : ControllerBase
{
    private const int MaxPageSize = 50;

    private readonly SkinHexDbContext _dbContext;

    public TransactionsController(SkinHexDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    [HttpGet]
    public async Task<IActionResult> GetMyTransactions([FromQuery] int page = 1, [FromQuery] int pageSize = 20, CancellationToken ct = default)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
            return Unauthorized();

        page = page < 1 ? 1 : page;
        pageSize = pageSize < 1 ? 20 : Math.Min(pageSize, MaxPageSize);

        var query = _dbContext.FinancialTransactions.AsNoTracking().Where(t => t.UserId == userId);
        var totalCount = await query.CountAsync(ct);

        var page_ = await query
            .OrderByDescending(t => t.CreatedAt)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .Select(t => new { t.Id, t.Amount, t.Type, t.Status, t.ReferenceId, t.CreatedAt })
            .ToListAsync(ct);

        // Batch-load the related records for enrichment.
        var depositTxIds = page_.Where(t => t.Type == FinancialTransactionType.Deposit).Select(t => t.Id).ToList();
        var withdrawalTxIds = page_.Where(t => t.Type == FinancialTransactionType.Withdrawal).Select(t => t.Id).ToList();
        var orderIds = page_
            .Where(t => t.Type is FinancialTransactionType.Purchase
                                 or FinancialTransactionType.Sale
                                 or FinancialTransactionType.Refund
                                 or FinancialTransactionType.Penalty
                        && t.ReferenceId != null)
            .Select(t => t.ReferenceId!.Value)
            .ToList();

        var deposits = depositTxIds.Count == 0
            ? new Dictionary<Guid, (string PayCurrency, decimal? PayAmount, string PaymentId, string? PayinHash)>()
            : await _dbContext.Deposits.AsNoTracking()
                .Where(d => depositTxIds.Contains(d.TransactionId))
                .Select(d => new { d.TransactionId, d.PayCurrency, d.PayAmount, d.NowPaymentsPaymentId, d.PayinHash })
                .ToDictionaryAsync(
                    d => d.TransactionId,
                    d => (PayCurrency: d.PayCurrency, PayAmount: d.PayAmount, PaymentId: d.NowPaymentsPaymentId, PayinHash: d.PayinHash),
                    ct);

        var withdrawals = withdrawalTxIds.Count == 0
            ? new Dictionary<Guid, (string PayCurrency, decimal Amount, string Address, string? PayoutId, string? TxHash)>()
            : await _dbContext.Withdrawals.AsNoTracking()
                .Where(w => withdrawalTxIds.Contains(w.TransactionId))
                .Select(w => new { w.TransactionId, w.PayCurrency, w.PayoutAmountUsd, w.PayoutAddress, w.NowPaymentsPayoutId, w.PayoutTxHash })
                .ToDictionaryAsync(
                    w => w.TransactionId,
                    w => (PayCurrency: w.PayCurrency, Amount: w.PayoutAmountUsd, Address: w.PayoutAddress, PayoutId: w.NowPaymentsPayoutId, TxHash: w.PayoutTxHash),
                    ct);

        var orders = orderIds.Count == 0
            ? new Dictionary<Guid, OrderInfo>()
            : await _dbContext.Orders.AsNoTracking()
                .Where(o => orderIds.Contains(o.Id))
                .Select(o => new OrderInfo(
                    o.Id,
                    o.BuyerId,
                    o.SellerId,
                    o.Buyer.Username,
                    o.Seller.Username,
                    o.Listing.Item.MarketHashName,
                    o.Listing.Item.Wear,
                    o.Listing.FloatValue))
                .ToDictionaryAsync(o => o.OrderId, o => o, ct);

        var items = page_.Select(t =>
        {
            TransactionCryptoDto? crypto = null;
            TransactionSkinDto? skin = null;

            if (t.Type == FinancialTransactionType.Deposit && deposits.TryGetValue(t.Id, out var d))
            {
                crypto = new TransactionCryptoDto(
                    d.PayCurrency, NetworkOf(d.PayCurrency), d.PayAmount, null, d.PaymentId,
                    d.PayinHash, BlockchainExplorer.BuildTxUrl(d.PayCurrency, d.PayinHash));
            }
            else if (t.Type == FinancialTransactionType.Withdrawal && withdrawals.TryGetValue(t.Id, out var w))
            {
                crypto = new TransactionCryptoDto(
                    w.PayCurrency, NetworkOf(w.PayCurrency), w.Amount, w.Address, w.PayoutId,
                    w.TxHash, BlockchainExplorer.BuildTxUrl(w.PayCurrency, w.TxHash));
            }
            else if (t.ReferenceId is { } orderId && orders.TryGetValue(orderId, out var o))
            {
                // All rows belong to the current user, so their counterparty is the other side of the order.
                var partner = userId == o.BuyerId ? o.SellerUsername : o.BuyerUsername;
                skin = new TransactionSkinDto(o.MarketHashName, o.Wear, o.Float, partner, t.Type.ToString());
            }

            return new TransactionDto(t.Id, t.Amount, t.Type.ToString(), t.Status.ToString(), t.CreatedAt, crypto, skin);
        }).ToList();

        return Ok(new PagedResult<TransactionDto>
        {
            Items = items,
            TotalCount = totalCount,
            Page = page,
            PageSize = pageSize
        });
    }

    private static string? NetworkOf(string payCurrency) =>
        SupportedDepositCurrencies.All
            .FirstOrDefault(c => string.Equals(c.Code, payCurrency, StringComparison.OrdinalIgnoreCase))?.Network;

    private Guid? GetCurrentUserId()
    {
        var value = User.FindFirstValue(ClaimTypes.NameIdentifier);
        return Guid.TryParse(value, out var id) ? id : null;
    }

    private sealed record OrderInfo(
        Guid OrderId,
        Guid BuyerId,
        Guid SellerId,
        string BuyerUsername,
        string SellerUsername,
        string MarketHashName,
        string? Wear,
        double? Float);
}
