import { useEffect, useMemo, useRef, useState, type CSSProperties } from 'react';
import { createPortal } from 'react-dom';
import { ShoppingCart } from 'lucide-react';
import type { AuthState, AuthorizedFetch, ItemDictionaryEntry, ListingCatalogItem } from '../types';
import { parseInventoryName } from '../utils/inventory';
import { getItemImageUrl } from '../utils/itemDictionary';
import { formatTimeAgo } from '../utils/catalogHelpers';
import { readApiError } from '../utils/api';
import { FloatBar } from './FloatBar';
import { useCart } from '../utils/CartContext';
import { createOrder } from '../utils/orders';

type CatalogMarketCardProps = {
  auth: AuthState | null;
  authorizedFetch: AuthorizedFetch;
  item: ListingCatalogItem;
  itemStatic: ItemDictionaryEntry | null;
  isOwnListing: boolean;
  onPurchaseCreated: () => void;
  onRequireLogin: () => void;
  onOpenDetails: () => void;
};

export function CatalogMarketCard({
  auth,
  authorizedFetch,
  item,
  itemStatic,
  isOwnListing,
  onPurchaseCreated,
  onRequireLogin,
  onOpenDetails,
}: CatalogMarketCardProps) {
  const cardRef = useRef<HTMLElement | null>(null);
  const popupRef = useRef<HTMLDivElement | null>(null);

  const parsedName = parseInventoryName(item.marketHashName);
  const accentColor = itemStatic?.color ? `#${itemStatic.color}` : '#3b82f6';
  const imageUrl = getItemImageUrl(itemStatic);
  const hasFloat = item.floatValue != null && item.floatValue > 0;
  const timeAgo = item.createdAt ? formatTimeAgo(item.createdAt) : null;

  const { addToCart, cart } = useCart();
  const inCart = cart.some(c => c.listingId === item.id);
  const [activeConfirmAction, setActiveConfirmAction] = useState<'buy' | 'remove' | null>(null);
  const [popupStyle, setPopupStyle] = useState<{ top: number; left: number; width: number } | null>(null);
  const [isEditingPrice, setIsEditingPrice] = useState(false);
  const [newPrice, setNewPrice] = useState(item.price.toFixed(2));
  const [ownActionError, setOwnActionError] = useState<string | null>(null);
  const [isBuying, setIsBuying] = useState(false);
  const [isRemovingListing, setIsRemovingListing] = useState(false);
  const [isUpdatingPrice, setIsUpdatingPrice] = useState(false);

  const hasInsufficientFunds = !!auth && item.price > auth.balance;

  const isActionPending = isBuying || isRemovingListing || isUpdatingPrice;

  const openConfirmation = (action: 'buy' | 'remove') => {
    setOwnActionError(null);
    setIsEditingPrice(false);
    setActiveConfirmAction(action);
  };

  const closeConfirmation = () => {
    if (isActionPending) {
      return;
    }

    setActiveConfirmAction(null);
    setOwnActionError(null);
  };

  useEffect(() => {
    if (!activeConfirmAction) {
      setPopupStyle(null);
      return;
    }

    const updatePosition = () => {
      const card = cardRef.current;
      if (!card) {
        return;
      }

      const rect = card.getBoundingClientRect();
      const viewportWidth = window.innerWidth;
      const preferredWidth = Math.min(340, Math.max(280, rect.width));
      const left = Math.min(
        Math.max(12, rect.left),
        Math.max(12, viewportWidth - preferredWidth - 12),
      );

      setPopupStyle({
        top: rect.bottom + 8,
        left,
        width: preferredWidth,
      });
    };

    updatePosition();
    window.addEventListener('resize', updatePosition);
    window.addEventListener('scroll', updatePosition, true);

    return () => {
      window.removeEventListener('resize', updatePosition);
      window.removeEventListener('scroll', updatePosition, true);
    };
  }, [activeConfirmAction]);

  useEffect(() => {
    if (!activeConfirmAction) {
      return;
    }

    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        closeConfirmation();
      }
    };

    document.addEventListener('keydown', handleEscape);
    return () => {
      document.removeEventListener('keydown', handleEscape);
    };
  }, [activeConfirmAction, isActionPending]);

  useEffect(() => {
    if (!activeConfirmAction) {
      return;
    }

    const timeoutId = window.setTimeout(() => {
      const focusable = popupRef.current?.querySelector<HTMLElement>('button, input');
      focusable?.focus();
    }, 0);

    return () => window.clearTimeout(timeoutId);
  }, [activeConfirmAction]);

  const handleAddToCart = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!auth) {
      onRequireLogin();
      return;
    }
    if (!inCart) {
      await addToCart(item.id);
    }
  };

  const handlePurchase = async () => {
    if (!auth?.userId) {
      onRequireLogin();
      return;
    }

    if (isBuying) {
      return;
    }

    setIsBuying(true);
    setOwnActionError(null);

    try {
      const order = await createOrder(authorizedFetch, item.id);
      setActiveConfirmAction(null);
      onPurchaseCreated();
      window.location.hash = 'orders';
      void order;
    } catch (error) {
      setOwnActionError(error instanceof Error ? error.message : 'Purchase failed.');
    } finally {
      setIsBuying(false);
    }
  };

  const handleRemoveListing = async () => {
    if (!auth) {
      onRequireLogin();
      return;
    }

    if (isRemovingListing) {
      return;
    }

    setIsRemovingListing(true);
    setOwnActionError(null);
    try {
      const response = await authorizedFetch(`/market/listings/${item.id}`, {
        method: 'DELETE',
      });

      if (!response.ok) {
        throw new Error(await readApiError(response));
      }

      setIsEditingPrice(false);
      setActiveConfirmAction(null);
      onPurchaseCreated();
    } catch (error) {
      setOwnActionError(error instanceof Error ? error.message : 'Failed to remove listing.');
    } finally {
      setIsRemovingListing(false);
    }
  };

  const handleUpdatePrice = async () => {
    if (!auth) {
      onRequireLogin();
      return;
    }

    if (isUpdatingPrice) {
      return;
    }

    const parsedPrice = Number(newPrice.replace(',', '.'));
    if (!Number.isFinite(parsedPrice) || parsedPrice <= 0) {
      setOwnActionError('Enter a valid price greater than 0.');
      return;
    }

    setIsUpdatingPrice(true);
    setOwnActionError(null);
    try {
      const response = await authorizedFetch(`/market/listings/${item.id}`, {
        method: 'PATCH',
        body: JSON.stringify({ price: parsedPrice }),
      });

      if (!response.ok) {
        throw new Error(await readApiError(response));
      }

      setActiveConfirmAction(null);
      onPurchaseCreated();
    } catch (error) {
      setOwnActionError(error instanceof Error ? error.message : 'Failed to update price.');
    } finally {
      setIsUpdatingPrice(false);
    }
  };

  const popupContent = useMemo(() => {
    if (!activeConfirmAction) {
      return null;
    }

    if (activeConfirmAction === 'buy') {
      return (
        <>
          <p className="cat-confirm-title">Are You Sure?</p>
          <p className="cat-confirm-description">
            You are about to buy this listing for ${item.price.toFixed(2)}.
          </p>
          <div className="cat-confirm-actions">
            <button className="primary-button" type="button" onClick={(e) => { e.stopPropagation(); handlePurchase(); }} disabled={isBuying || hasInsufficientFunds}>
              {isBuying ? 'Buying...' : 'Yes'}
            </button>
            <button className="secondary-button" type="button" onClick={(e) => { e.stopPropagation(); closeConfirmation(); }} disabled={isBuying}>
              No
            </button>
          </div>
        </>
      );
    }

    if (activeConfirmAction === 'remove') {
      return (
        <>
          <p className="cat-confirm-title">Are You Sure?</p>
          <p className="cat-confirm-description">
            Remove this listing from market right now?
          </p>
          <div className="cat-confirm-actions">
            <button className="primary-button" type="button" onClick={(e) => { e.stopPropagation(); handleRemoveListing(); }} disabled={isRemovingListing}>
              {isRemovingListing ? 'Removing...' : 'Yes'}
            </button>
            <button className="secondary-button" type="button" onClick={(e) => { e.stopPropagation(); closeConfirmation(); }} disabled={isRemovingListing}>
              No
            </button>
          </div>
        </>
      );
    }
  }, [
    activeConfirmAction,
    closeConfirmation,
    handlePurchase,
    handleRemoveListing,
    isBuying,
    isRemovingListing,
    item.price,
  ]);

  return (
    <article
      ref={cardRef}
      className="cat-card clickable"
      style={{ '--item-accent': accentColor } as CSSProperties}
      onClick={onOpenDetails}
    >
      {/* Rarity accent bar */}
      <div className="cat-card-accent" />

      {/* Time ago badge */}
      {timeAgo && (
        <span className="cat-card-time">{timeAgo}</span>
      )}

      {/* Header */}
      <div className="cat-card-header">
        <h3 className="cat-card-name" title={parsedName.title}>
          {parsedName.title}
        </h3>
        <span className="cat-card-exterior">
          {parsedName.exterior ?? itemStatic?.category ?? 'Item'}
        </span>
      </div>

      {/* Image */}
      <div className="cat-card-image">
        {imageUrl && <img alt={item.marketHashName} loading="lazy" src={imageUrl} />}
      </div>

      {/* Price + Seed row */}
      <div className="cat-card-footer">
        <span className="cat-card-price">${item.price.toFixed(2)}</span>
        {item.paintSeed != null && item.paintSeed > 0 && !hasFloat && (
          <span className="cat-card-seed">#{item.paintSeed}</span>
        )}
      </div>

      {/* Float bar */}
      {hasFloat && (
        <div className="cat-card-float">
          <FloatBar
            floatValue={item.floatValue!}
            minFloat={itemStatic?.minF}
            maxFloat={itemStatic?.maxF}
            paintSeed={item.paintSeed}
            size="compact"
          />
        </div>
      )}

      {/* Buy overlay on hover */}
      <div className="cat-card-actions">
        {isOwnListing ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', width: '100%' }}>
            <button
              className="primary-button"
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setOwnActionError(null);
                setActiveConfirmAction(null);
                setNewPrice(item.price.toFixed(2));
                setIsEditingPrice((prev) => !prev);
              }}
            >
              Edit Price
            </button>
            {isEditingPrice ? (
              <div style={{ marginTop: '2px', padding: '10px', borderRadius: '10px', border: '1px solid rgba(255, 255, 255, 0.12)', background: 'rgba(17, 24, 39, 0.75)' }} onClick={(e) => e.stopPropagation()}>
                <p style={{ margin: 0, marginBottom: '8px', fontSize: '13px', color: 'var(--text-muted)' }}>Are you sure?</p>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  value={newPrice}
                  onChange={(e) => setNewPrice(e.target.value)}
                  placeholder="New price"
                  style={{ width: '100%', marginBottom: '8px', padding: '8px 10px', borderRadius: '8px', border: '1px solid rgba(255, 255, 255, 0.2)', background: 'rgba(3, 7, 18, 0.6)', color: 'var(--text)' }}
                />
                <div style={{ display: 'flex', gap: '8px' }}>
                  <button className="primary-button" type="button" onClick={handleUpdatePrice} disabled={isUpdatingPrice} style={{ flex: 1 }}>
                    {isUpdatingPrice ? 'Saving...' : 'Yes'}
                  </button>
                  <button
                    className="secondary-button"
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      if (isUpdatingPrice) return;
                      setIsEditingPrice(false);
                    }}
                    disabled={isUpdatingPrice}
                    style={{ flex: 1 }}
                  >
                    No
                  </button>
                </div>
              </div>
            ) : null}
            <button
              className="secondary-button"
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                openConfirmation('remove');
              }}
              disabled={isRemovingListing}
              style={{ color: 'var(--danger)', borderColor: 'rgba(239, 68, 68, 0.2)' }}
            >
              {isRemovingListing ? 'Removing...' : 'Remove Listing'}
            </button>
            {ownActionError && isEditingPrice ? (
              <p className="purchase-message" style={{ marginTop: '2px' }}>{ownActionError}</p>
            ) : null}
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', width: '100%' }}>
            <button
              className="primary-button"
              type="button"
              disabled={isBuying || hasInsufficientFunds}
              onClick={(e) => {
                e.stopPropagation();
                openConfirmation('buy');
              }}
              title={hasInsufficientFunds ? 'Insufficient funds' : undefined}
            >
              {isBuying ? 'Buying...' : 'Buy'}
            </button>
            <button
              className={inCart ? "secondary-button" : "primary-button"}
              type="button"
              onClick={handleAddToCart}
              disabled={inCart}
              style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', width: '100%', background: inCart ? 'var(--surface-hover)' : 'var(--accent)', color: inCart ? 'var(--text-muted)' : '#fff', border: 'none' }}
            >
              <ShoppingCart size={16} />
              {inCart ? 'In Cart' : 'Add to Cart'}
            </button>
          </div>
        )}
      </div>

      {activeConfirmAction && popupStyle
        ? createPortal(
          <>
            <div className="cat-confirm-backdrop" onMouseDown={closeConfirmation} />
            <div
              ref={popupRef}
              className="cat-confirm-popover"
              style={{ top: popupStyle.top, left: popupStyle.left, width: popupStyle.width }}
              onMouseDown={(event) => event.stopPropagation()}
              onClick={(event) => event.stopPropagation()}
              role="dialog"
              aria-modal="true"
            >
              {popupContent}
              {ownActionError ? <p className="purchase-message">{ownActionError}</p> : null}
            </div>
          </>,
          document.body,
        )
        : null}
    </article>
  );
}
