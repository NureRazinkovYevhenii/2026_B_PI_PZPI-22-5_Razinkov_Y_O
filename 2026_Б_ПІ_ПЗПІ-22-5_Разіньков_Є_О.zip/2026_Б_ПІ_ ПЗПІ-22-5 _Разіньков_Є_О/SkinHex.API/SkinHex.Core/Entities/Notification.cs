namespace SkinHex.Core.Entities;

public enum NotificationType
{
    System = 0,

    // Seller-side
    ItemSold = 1,
    SaleCompleted = 2,

    // Buyer-side order lifecycle
    OrderStatusChanged = 10,
    OrderCancelled = 11,
    TradeOfferSent = 12,
    TradeOfferAccepted = 13,

    // Finance
    DepositCompleted = 20,
    WithdrawalStatusChanged = 21,

    // Disputes
    DisputeOpened = 30,
    DisputeResolved = 31
}

public class Notification
{
    public Guid Id { get; set; }
    public Guid UserId { get; set; }

    public NotificationType Type { get; set; }

    /// <summary>Type-specific JSON payload (stored as jsonb). Shape is defined by the payload records in Models/Notifications.</summary>
    public string Payload { get; set; } = "{}";

    public bool IsRead { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? ReadAt { get; set; }

    public User User { get; set; } = null!;
}
