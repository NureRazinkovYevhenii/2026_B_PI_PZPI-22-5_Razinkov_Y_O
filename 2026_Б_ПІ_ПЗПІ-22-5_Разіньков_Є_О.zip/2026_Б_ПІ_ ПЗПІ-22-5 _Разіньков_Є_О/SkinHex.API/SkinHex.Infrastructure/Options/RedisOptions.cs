namespace SkinHex.Infrastructure.Options;

public sealed class RedisOptions
{
    public const string SectionName = "Redis";

    public string ConnectionString { get; set; } = "localhost:6379";
    public string SteamSessionsKey { get; set; } = "skinhex:steam:sessions";
    public int SessionTtlMinutes { get; set; } = 90;
}
