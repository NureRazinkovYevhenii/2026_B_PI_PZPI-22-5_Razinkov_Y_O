using SkinHex.SteamBotAuthService;
using SkinHex.Infrastructure;

var builder = Host.CreateApplicationBuilder(args);

builder.Services.AddOptions<List<SteamBotOptions>>()
    .Bind(builder.Configuration.GetSection("SteamBots"))
    .Validate(bots => bots.Count > 0, "At least one Steam bot must be configured.")
    .Validate(
        bots => bots.All(bot =>
            !string.IsNullOrWhiteSpace(bot.Username) &&
            !string.IsNullOrWhiteSpace(bot.Password) &&
            !string.IsNullOrWhiteSpace(bot.SharedSecret) &&
            !string.IsNullOrWhiteSpace(bot.SteamId)),
        "Every Steam bot requires Username, Password, SharedSecret and SteamId.")
    .ValidateOnStart();
builder.Services.AddOptions<SteamAuthenticationOptions>()
    .Bind(builder.Configuration.GetSection(SteamAuthenticationOptions.SectionName))
    .Validate(options => options.RefreshIntervalMinutes > 0, "RefreshIntervalMinutes must be positive.")
    .Validate(options => options.ConnectionTimeoutSeconds > 0, "ConnectionTimeoutSeconds must be positive.")
    .ValidateOnStart();

builder.Services.AddSteamSessionRedis(builder.Configuration);
builder.Services.AddHostedService<Worker>();

var host = builder.Build();
host.Run();
