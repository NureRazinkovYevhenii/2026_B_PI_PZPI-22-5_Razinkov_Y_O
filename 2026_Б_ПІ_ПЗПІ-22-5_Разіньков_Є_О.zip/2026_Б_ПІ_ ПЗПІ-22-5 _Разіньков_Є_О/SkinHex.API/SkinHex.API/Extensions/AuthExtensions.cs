using AspNet.Security.OpenId;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using SkinHex.Infrastructure.Options;
using System.Security.Claims;
using System.Text;
using System.Text.Json;

namespace SkinHex.API.Extensions;

public static class AuthExtensions
{
    public static IServiceCollection AddSkinHexAuthentication(this IServiceCollection services, IConfiguration configuration)
    {
        var jwtOptions = configuration.GetSection("Jwt").Get<JwtOptions>()
            ?? throw new InvalidOperationException("JWT settings are not configured.");

        services.AddAuthentication(options =>
        {
            options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
            options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            options.DefaultSignInScheme = "External";
        })
        .AddCookie("External", options =>
        {
            options.Cookie.Name = "SkinHex.ExternalAuth";
            options.Cookie.HttpOnly = true;
            options.Cookie.SameSite = SameSiteMode.Lax;
            options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
            options.ExpireTimeSpan = TimeSpan.FromMinutes(10);
        })
        .AddJwtBearer(options =>
        {
            options.TokenValidationParameters = new TokenValidationParameters
            {
                ValidateIssuer = true,
                ValidateAudience = true,
                ValidateLifetime = true,
                ValidateIssuerSigningKey = true,
                ValidIssuer = jwtOptions.Issuer,
                ValidAudience = jwtOptions.Audience,
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtOptions.SecretKey)),
                ClockSkew = TimeSpan.FromMinutes(1)
            };

            // Browsers cannot send an Authorization header on WebSocket handshakes,
            // so the SignalR JS client passes the JWT as ?access_token=... for hub routes.
            options.Events = new JwtBearerEvents
            {
                OnMessageReceived = context =>
                {
                    var accessToken = context.Request.Query["access_token"];
                    if (!string.IsNullOrEmpty(accessToken) &&
                        context.HttpContext.Request.Path.StartsWithSegments("/hubs"))
                    {
                        context.Token = accessToken;
                    }
                    return Task.CompletedTask;
                }
            };
        })
        .AddSteam(options =>
        {
            options.SignInScheme = "External";
            options.ApplicationKey = configuration["Steam:ApiKey"];

            options.Events = new OpenIdAuthenticationEvents
            {
                OnAuthenticated = context =>
                {
                    var payload = context.UserPayload;

                    if (payload?.RootElement.ValueKind == JsonValueKind.Object)
                    {
                        try
                        {
                            var player = payload.RootElement.GetProperty("response").GetProperty("players")[0];

                            var avatarFull = player.GetProperty("avatarfull").GetString();

                            if (!string.IsNullOrEmpty(avatarFull))
                                context.Identity?.AddClaim(new Claim("urn:steam:avatarfull", avatarFull));
                        }
                        catch (Exception ex)
                        {
                            var logger = context.HttpContext.RequestServices
                                .GetRequiredService<ILoggerFactory>()
                                .CreateLogger("SteamAuthentication");

                            logger.LogWarning(ex, "Error retrieving Steam profile data.");
                        }
                    }
                    return Task.CompletedTask;
                }
            };
        });

        return services;
    }

    public static IServiceCollection AddSkinHexCors(this IServiceCollection services, IConfiguration configuration)
    {
        // Allowed browser origins come from config so a containerized/nginx-served client on any
        // host or port works without a code change (Cors:AllowedOrigins in appsettings / env).
        // Falls back to the local Vite dev origin. Chrome extension origins are always allowed.
        var allowedOrigins = configuration.GetSection("Cors:AllowedOrigins").Get<string[]>();
        if (allowedOrigins is null || allowedOrigins.Length == 0)
            allowedOrigins = ["http://localhost:5173"];

        services.AddCors(options =>
        {
            options.AddPolicy("FrontendPolicy", policy =>
            {
                policy.SetIsOriginAllowed(origin =>
                          allowedOrigins.Contains(origin) ||
                          origin.StartsWith("chrome-extension://"))
                      .AllowAnyHeader()
                      .AllowAnyMethod()
                      .AllowCredentials();
            });
        });

        return services;
    }
}
