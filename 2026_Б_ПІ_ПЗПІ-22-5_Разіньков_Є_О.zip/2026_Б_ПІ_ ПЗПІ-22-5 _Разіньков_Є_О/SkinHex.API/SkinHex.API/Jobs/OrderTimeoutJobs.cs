using Hangfire;
using Microsoft.Extensions.Logging;
using SkinHex.Core.Entities;
using SkinHex.Core.Interfaces.Repositories;
using SkinHex.Core.Interfaces.Services;

namespace SkinHex.API.Jobs;

public class OrderTimeoutJobs : IOrderTimeoutJobs
{
    private readonly IOrderRepository _orderRepo;
    private readonly IOrderService _orderService;
    private readonly IDisputeRepository _disputeRepo;
    private readonly IDisputeService _disputeService;
    private readonly INotificationService _notificationService;
    private readonly ILogger<OrderTimeoutJobs> _logger;

    public OrderTimeoutJobs(
        IOrderRepository orderRepo,
        IOrderService orderService,
        IDisputeRepository disputeRepo,
        IDisputeService disputeService,
        INotificationService notificationService,
        ILogger<OrderTimeoutJobs> logger)
    {
        _orderRepo = orderRepo;
        _orderService = orderService;
        _disputeRepo = disputeRepo;
        _disputeService = disputeService;
        _notificationService = notificationService;
        _logger = logger;
    }

    public async Task ExecuteTimeoutCheckAsync(Guid orderId, CancellationToken ct)
    {
        _logger.LogInformation("Executing Hangfire timeout check for order {OrderId}", orderId);

        var order = await _orderRepo.GetByIdWithTradesAsync(orderId, ct);
        if (order == null)
        {
            _logger.LogWarning("Order {OrderId} not found during timeout check.", orderId);
            return;
        }

        // An open dispute freezes automation; support resolution re-arms this job when needed.
        if (await _disputeRepo.HasOpenDisputeAsync(orderId, ct))
        {
            _logger.LogInformation("Order {OrderId} has an open dispute — timeout check skipped.", orderId);
            return;
        }

        var now = DateTime.UtcNow;

        if (order.Status == OrderStatus.Pending)
        {
            if (now >= order.ConfirmDeadline)
            {
                _logger.LogInformation("Order {OrderId} pending timeout expired. Cancelling.", orderId);
                await _orderService.CancelOrderAsync(orderId, null, "Seller did not confirm within time limit", CancelledBy.System, ct);
            }
            else
            {
                _logger.LogInformation("Order {OrderId} pending timeout has not expired yet. (Deadline extended?)", orderId);
            }
        }
        else if (order.Status == OrderStatus.Confirmed && order.ConfirmedAt.HasValue)
        {
            var sendTradeDeadline = order.ConfirmedAt.Value.AddHours(2);
            var activeTrade = order.SteamTrades.OrderByDescending(t => t.CreatedAt).FirstOrDefault();

            if (activeTrade?.OfferState == SteamOfferState.CreatedNeedsConfirmation)
            {
                var mobileDeadline = activeTrade.CreatedAt.AddHours(1);
                if (mobileDeadline > sendTradeDeadline)
                {
                    sendTradeDeadline = mobileDeadline;
                }
            }

            if (now >= sendTradeDeadline)
            {
                _logger.LogInformation("Order {OrderId} send trade timeout expired. Cancelling.", orderId);
                await _orderService.CancelOrderAsync(orderId, null, "Seller did not send trade offer within time limit", CancelledBy.System, ct);
            }
            else
            {
                var remaining = sendTradeDeadline - now;
                _logger.LogInformation("Order {OrderId} send trade timeout extended. Rescheduling in {Minutes}m.", orderId, remaining.TotalMinutes);
                BackgroundJob.Schedule<IOrderTimeoutJobs>(x => x.ExecuteTimeoutCheckAsync(orderId, CancellationToken.None), remaining);
            }
        }
        else
        {
            _logger.LogInformation("Order {OrderId} is in status {Status}. No timeout action required.", orderId, order.Status);
        }
    }

    public async Task ExecuteEscrowStuckCheckAsync(Guid orderId, CancellationToken ct)
    {
        var order = await _orderRepo.GetByIdAsync(orderId, ct);
        if (order is null || order.Status != OrderStatus.InEscrow)
            return;

        _logger.LogWarning("Order {OrderId} is still InEscrow after the escrow hold + grace period.", orderId);

        var dispute = await _disputeService.OpenSystemDisputeAsync(
            orderId,
            DisputeReason.StuckEscrow,
            "Escrow hold elapsed but no TLSN completion proof was received. " +
            "The seller must run the completion proof, or support can complete the order manually.",
            ct: ct);

        // Nudge the seller regardless of whether a dispute already existed: running the proof
        // is one click in the extension and auto-resolves the stuck case.
        await _notificationService.NotifyAsync(order.SellerId, NotificationType.System, new
        {
            orderId,
            kind = "escrow_stuck",
            message = "The escrow hold for the order has ended, but no completion proof was received. Run the confirmation in the extension to receive your payout."
        }, ct);

        if (dispute is not null)
            _logger.LogInformation("StuckEscrow dispute {DisputeId} opened for order {OrderId}.", dispute.Id, orderId);
    }
}
