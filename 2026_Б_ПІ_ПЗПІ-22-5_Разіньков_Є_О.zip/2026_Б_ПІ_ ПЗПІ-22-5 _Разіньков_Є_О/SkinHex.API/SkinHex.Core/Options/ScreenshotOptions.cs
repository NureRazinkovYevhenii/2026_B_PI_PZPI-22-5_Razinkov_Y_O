namespace SkinHex.Core.Options;

public sealed class ScreenshotOptions
{
    public const string SectionName = "Screenshots";

    public string BaseAddress { get; set; } = "https://csmarketcap.com";

    // Рендер може займати десятки секунд, тому таймаут більший за звичайний.
    public int TimeoutSeconds { get; set; } = 100;

    // Відносний шлях резолвиться від робочої директорії застосунку.
    public string StorageRootPath { get; set; } = "storage/screenshots";

    // URL-префікс, за яким API роздає збережені файли.
    public string PublicBasePath { get; set; } = "/media/screenshots";
}
