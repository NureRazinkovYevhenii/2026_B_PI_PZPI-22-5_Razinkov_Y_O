using SkinHex.Core.Entities;

namespace SkinHex.Core.Models.Notifications;

public record ItemSoldPayload(
    Guid OrderId,
    Guid ListingId,
    string MarketHashName,
    string? Wear,
    decimal Price,
    Guid BuyerId,
    string BuyerUsername,
    DateTime? ConfirmDeadline);

public record OrderStatusChangedPayload(
    Guid OrderId,
    Guid ListingId,
    OrderStatus Status,
    string Role,
    string? MarketHashName,
    string? CancelledBy,
    string? CancelReason);

public record BalanceChangedPayload(
    decimal Balance,
    decimal FrozenBalance,
    decimal Delta,
    string Reason);

public record CartItemUnavailablePayload(Guid ListingId);

public record DepositCompletedPayload(
    Guid DepositId,
    decimal Amount,
    string? PayCurrency);

public record WithdrawalStatusPayload(
    Guid WithdrawalId,
    string Status,
    decimal Amount,
    string? PayCurrency,
    string? RejectionReason);

/// <summary><paramref name="OpenedBy"/> is "buyer", "seller" or "system".</summary>
public record DisputeOpenedPayload(
    Guid DisputeId,
    Guid OrderId,
    string Reason,
    string OpenedBy);

public record DisputeResolvedPayload(
    Guid DisputeId,
    Guid OrderId,
    string Resolution,
    string? Note);

/// <summary>Warning pushed to the buyer when the incoming offer does not contain the purchased item.</summary>
public record TradeOfferMismatchPayload(
    Guid OrderId,
    string TradeOfferId,
    long ExpectedAssetId);
