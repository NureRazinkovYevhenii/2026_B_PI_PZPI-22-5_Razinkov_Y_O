using SkinHex.Core.Entities;
using SkinHex.Core.Models.Orders;

namespace SkinHex.Core.Interfaces.Repositories;

public interface IOrderRepository
{
    Task<Order?> GetByIdAsync(Guid id, CancellationToken ct = default);
    Task<Order?> GetByIdWithDetailsAsync(Guid id, CancellationToken ct = default);

    /// <summary>Untracked order graph (buyer, seller, listing + item) for read-only notification dispatch.</summary>
    Task<Order?> GetByIdForNotificationAsync(Guid id, CancellationToken ct = default);
    Task<IEnumerable<Order>> GetOrdersByUserIdAsync(Guid userId, CancellationToken ct = default);
    Task AddAsync(Order order, CancellationToken ct = default);
    Task UpdateAsync(Order order, CancellationToken ct = default);
    
    Task<int> ExecuteConfirmAsync(Guid orderId, DateTime confirmedAt, CancellationToken ct = default);
    Task<int> ExecuteCancelAsync(Guid orderId, CancelledBy cancelledBy, string? reason, DateTime cancelledAt, CancellationToken ct = default);
    Task<int> ExecuteTradeLifecycleUpdateAsync(
        Guid orderId,
        OrderStatus status,
        DateTime? tradeSentAt,
        DateTime? tradeAcceptDeadline,
        DateTime? acceptedAt,
        CancellationToken ct = default);
    Task<int> ExecuteSteamTradeUpdateAsync(Guid tradeId, SteamOfferState offerState, DateTime updatedAt, CancellationToken ct = default);
    Task<int> ExecuteSteamTradeInsertAsync(SteamTrade trade, CancellationToken ct = default);
    Task<SteamTrade?> GetSteamTradeByOfferIdAsync(string tradeOfferId, CancellationToken ct = default);
    Task<Order?> GetBySteamTradeIdWithDetailsAsync(string steamTradeId, CancellationToken ct = default);
    /// <summary>Active (TradeSent/InEscrow) orders the user participates in, with the latest trade
    /// attempt per order. <paramref name="actorRole"/> null returns both sides with per-item role.</summary>
    Task<IReadOnlyCollection<PendingTradeSyncItemDto>> GetPendingTradeSyncItemsAsync(Guid userId, TradeSyncActorRole? actorRole, CancellationToken ct = default);
    Task<List<Order>> GetExpiredPendingOrdersAsync(DateTime now, CancellationToken ct = default);
    Task<List<Order>> GetConfirmedOrdersWithTradesAsync(CancellationToken ct = default);
    Task<Order?> GetByIdWithTradesAsync(Guid orderId, CancellationToken ct = default);
}
