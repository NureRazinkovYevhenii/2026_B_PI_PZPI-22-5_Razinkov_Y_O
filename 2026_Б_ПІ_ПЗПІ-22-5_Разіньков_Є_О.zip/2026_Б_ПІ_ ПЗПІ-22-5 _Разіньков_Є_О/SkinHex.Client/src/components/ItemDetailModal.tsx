import { useEffect, useRef, useState, type CSSProperties } from 'react';
import { Camera, Crosshair, ExternalLink, ShoppingCart, X } from 'lucide-react';
import { FloatBar } from './FloatBar';
import { ScreenshotViewer } from './ScreenshotViewer';
import { API_ORIGIN } from '../config';
import type {
  AuthState,
  AuthorizedFetch,
  InventoryItem,
  ItemDictionaryEntry,
  ListingCatalogItem,
} from '../types';
import { readApiError } from '../utils/api';
import { useCart } from '../utils/CartContext';
import { parseInventoryName } from '../utils/inventory';
import { getItemImageUrl } from '../utils/itemDictionary';
import { createOrder } from '../utils/orders';
import { useTranslation } from 'react-i18next';

/** The modal serves two contexts: a market listing (with screenshots) or a raw inventory item. */
export type ItemDetailSource =
  | { kind: 'listing'; listing: ListingCatalogItem }
  | { kind: 'inventory'; item: InventoryItem };

/** Market actions (buy / cart / manage own listing) — only meaningful for the listing context. */
export type ItemDetailMarket = {
  auth: AuthState | null;
  authorizedFetch: AuthorizedFetch;
  isOwnListing: boolean;
  /** Called after a successful buy / remove / price update so the parent can refetch. */
  onChanged: () => void;
  onRequireLogin: () => void;
};

type ItemDetailModalProps = {
  source: ItemDetailSource;
  itemStatic: ItemDictionaryEntry | null;
  onClose: () => void;
  market?: ItemDetailMarket;
  /** Inventory context only: toggle the item in the sale panel. */
  onSell?: () => void;
  isInSalePanel?: boolean;
};

function buildInspectLink(inspectHex: string) {
  return `steam://run/730//+csgo_econ_action_preview%20${inspectHex}`;
}

export function ItemDetailModal({
  source,
  itemStatic,
  onClose,
  market,
  onSell,
  isInSalePanel,
}: ItemDetailModalProps) {
  const { t } = useTranslation();
  const overlayRef = useRef<HTMLDivElement>(null);
  const { addToCart, cart } = useCart();

  const isListing = source.kind === 'listing';
  const listing = isListing ? source.listing : null;
  const marketHashName = isListing ? source.listing.marketHashName : source.item.marketHashName;
  const floatValue = isListing ? source.listing.floatValue : source.item.floatValue;
  const paintSeed = isListing ? source.listing.paintSeed : source.item.paintSeed;
  const paintIndex = isListing ? null : source.item.paintIndex;
  const inspectHex = isListing ? source.listing.inspectHex : source.item.metadataHex;
  const price = isListing ? source.listing.price : null;

  const screenshotFront = listing?.screenshotFrontUrl
    ? `${API_ORIGIN}${listing.screenshotFrontUrl}`
    : null;
  const screenshotBack = listing?.screenshotBackUrl
    ? `${API_ORIGIN}${listing.screenshotBackUrl}`
    : null;

  const parsedName = parseInventoryName(marketHashName);
  const accentColor = itemStatic?.color ? `#${itemStatic.color}` : '#3b82f6';
  const imageUrl = getItemImageUrl(itemStatic);
  const hasFloat = floatValue != null && floatValue > 0;

  // ── Market action state (listing context) ──
  const inCart = Boolean(listing && cart.some((c) => c.listingId === listing.id));
  const [confirmAction, setConfirmAction] = useState<'buy' | 'remove' | null>(null);
  const [isEditingPrice, setIsEditingPrice] = useState(false);
  const [newPrice, setNewPrice] = useState('');
  const [actionError, setActionError] = useState<string | null>(null);
  const [isBusy, setIsBusy] = useState(false);

  const hasInsufficientFunds = market?.auth && source.kind === 'listing' ? source.listing.price > market.auth.balance : false;

  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', handleEsc);
    return () => document.removeEventListener('keydown', handleEsc);
  }, [onClose]);

  const handleOverlayClick = (e: React.MouseEvent) => {
    if (e.target === overlayRef.current) onClose();
  };

  const goToSkinPage = () => {
    window.location.hash = `skin/${encodeURIComponent(marketHashName)}`;
    onClose();
  };

  const requireAuth = () => {
    if (market?.auth) return true;
    market?.onRequireLogin();
    return false;
  };

  const handleAddToCart = async () => {
    if (!market || !listing || !requireAuth() || inCart) return;
    await addToCart(listing.id);
  };

  const handleBuy = async () => {
    if (!market || !listing || isBusy) return;
    setIsBusy(true);
    setActionError(null);
    try {
      await createOrder(market.authorizedFetch, listing.id);
      market.onChanged();
      onClose();
      window.location.hash = 'orders';
    } catch (error) {
      setActionError(error instanceof Error ? error.message : 'Purchase failed.');
    } finally {
      setIsBusy(false);
    }
  };

  const handleRemoveListing = async () => {
    if (!market || !listing || isBusy) return;
    setIsBusy(true);
    setActionError(null);
    try {
      const response = await market.authorizedFetch(`/market/listings/${listing.id}`, {
        method: 'DELETE',
      });
      if (!response.ok) throw new Error(await readApiError(response));
      market.onChanged();
      onClose();
    } catch (error) {
      setActionError(error instanceof Error ? error.message : 'Failed to remove listing.');
    } finally {
      setIsBusy(false);
    }
  };

  const handleUpdatePrice = async () => {
    if (!market || !listing || isBusy) return;
    const parsedPrice = Number(newPrice.replace(',', '.'));
    if (!Number.isFinite(parsedPrice) || parsedPrice <= 0) {
      setActionError('Enter a valid price greater than 0.');
      return;
    }
    setIsBusy(true);
    setActionError(null);
    try {
      const response = await market.authorizedFetch(`/market/listings/${listing.id}`, {
        method: 'PATCH',
        body: JSON.stringify({ price: parsedPrice }),
      });
      if (!response.ok) throw new Error(await readApiError(response));
      market.onChanged();
      onClose();
    } catch (error) {
      setActionError(error instanceof Error ? error.message : 'Failed to update price.');
    } finally {
      setIsBusy(false);
    }
  };

  const renderMarketActions = () => {
    if (!market || !listing) return null;

    if (market.isOwnListing) {
      return (
        <div className="item-modal-market">
          {isEditingPrice ? (
            <div className="item-modal-confirm">
              <p className="item-modal-confirm-title">{t('itemDetail.newPrice', 'New price')}</p>
              <input
                className="item-modal-price-input"
                type="number"
                step="0.01"
                min="0.01"
                value={newPrice}
                onChange={(e) => setNewPrice(e.target.value)}
                placeholder="New price"
              />
              <div className="item-modal-confirm-actions">
                <button className="primary-button" type="button" onClick={handleUpdatePrice} disabled={isBusy}>
                  {isBusy ? 'Saving...' : 'Save'}
                </button>
                <button
                  className="secondary-button"
                  type="button"
                  onClick={() => { if (!isBusy) setIsEditingPrice(false); }}
                  disabled={isBusy}
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : confirmAction === 'remove' ? (
            <div className="item-modal-confirm">
              <p className="item-modal-confirm-title">Remove this listing from market right now?</p>
              <div className="item-modal-confirm-actions">
                <button className="primary-button" type="button" onClick={handleRemoveListing} disabled={isBusy}>
                  {isBusy ? 'Removing...' : 'Yes'}
                </button>
                <button
                  className="secondary-button"
                  type="button"
                  onClick={() => { if (!isBusy) setConfirmAction(null); }}
                  disabled={isBusy}
                >
                  No
                </button>
              </div>
            </div>
          ) : (
            <>
              <button
                className="primary-button item-modal-market-btn"
                type="button"
                onClick={() => {
                  setActionError(null);
                  setNewPrice(listing.price.toFixed(2));
                  setIsEditingPrice(true);
                }}
              >
                Edit Price
              </button>
              <button
                className="secondary-button item-modal-market-btn danger"
                type="button"
                onClick={() => { setActionError(null); setConfirmAction('remove'); }}
              >
                Remove Listing
              </button>
            </>
          )}
          {actionError && <p className="purchase-message">{actionError}</p>}
        </div>
      );
    }

    return (
      <div className="item-modal-market">
        {confirmAction === 'buy' ? (
          <div className="item-modal-confirm">
            <p className="item-modal-confirm-title">
              You are about to buy this listing for ${listing.price.toFixed(2)}.
            </p>
            <div className="item-modal-confirm-actions">
              <button className="primary-button" type="button" onClick={handleBuy} disabled={isBusy || hasInsufficientFunds}>
                {isBusy ? 'Buying...' : 'Yes'}
              </button>
              <button
                className="secondary-button"
                type="button"
                onClick={() => { if (!isBusy) setConfirmAction(null); }}
                disabled={isBusy}
              >
                No
              </button>
            </div>
          </div>
        ) : (
          <>
            <button
              className="primary-button item-modal-market-btn"
              type="button"
              disabled={isBusy || hasInsufficientFunds}
              title={hasInsufficientFunds ? 'Insufficient funds' : undefined}
              onClick={() => {
                if (!requireAuth()) return;
                setActionError(null);
                setConfirmAction('buy');
              }}
            >
              Buy for ${listing.price.toFixed(2)}
            </button>
            <button
              className="secondary-button item-modal-market-btn"
              type="button"
              disabled={inCart}
              onClick={handleAddToCart}
            >
              <ShoppingCart size={16} />
              {inCart ? 'In Cart' : 'Add to Cart'}
            </button>
          </>
        )}
        {actionError && <p className="purchase-message">{actionError}</p>}
      </div>
    );
  };

  return (
    <div className="item-modal-backdrop" ref={overlayRef} onClick={handleOverlayClick}>
      <div
        className="item-modal large"
        style={{ '--item-accent': accentColor } as CSSProperties}
        role="dialog"
        aria-modal="true"
      >
        <button className="item-modal-close" onClick={onClose} title={t('salePanel.cancel')}>
          <X size={20} />
        </button>

        {/* ── Media column: in-game screenshots for listings, static render otherwise ── */}
        <div className="item-modal-media">
          {screenshotFront ? (
            <ScreenshotViewer
              frontUrl={screenshotFront}
              backUrl={screenshotBack}
              alt={marketHashName}
            />
          ) : (
            <div className="item-modal-image-area">
              {imageUrl && (
                <img src={imageUrl} alt={marketHashName} className="item-modal-img" />
              )}
              {isListing && (
                <span className="item-modal-screenshot-pending">
                  <Camera size={13} />
                  {t('itemDetail.screenshotPending', 'In-game screenshots are being prepared…')}
                </span>
              )}
            </div>
          )}
        </div>

        {/* ── Info column ── */}
        <div className="item-modal-body">
          <h2 className="item-modal-title">{parsedName.title}</h2>
          {parsedName.exterior && (
            <span className="item-modal-exterior">{parsedName.exterior}</span>
          )}

          {price != null && (
            <div className="item-modal-price">${price.toFixed(2)}</div>
          )}

          {hasFloat && (
            <div className="item-modal-float-section">
              <FloatBar
                floatValue={floatValue!}
                minFloat={itemStatic?.minF}
                maxFloat={itemStatic?.maxF}
                paintSeed={paintSeed}
                size="large"
              />
            </div>
          )}

          <div className="item-modal-properties">
            {itemStatic?.rarity && (
              <div className="item-modal-prop">
                <span className="prop-label">{t('itemDetail.rarity', 'Rarity')}</span>
                <span className="prop-value" style={{ color: accentColor }}>{itemStatic.rarity}</span>
              </div>
            )}
            {itemStatic?.category && (
              <div className="item-modal-prop">
                <span className="prop-label">{t('itemDetail.category', 'Category')}</span>
                <span className="prop-value">{itemStatic.category}</span>
              </div>
            )}
            {itemStatic?.weapon && (
              <div className="item-modal-prop">
                <span className="prop-label">{t('itemDetail.weapon', 'Weapon')}</span>
                <span className="prop-value">{itemStatic.weapon}</span>
              </div>
            )}
            {!hasFloat && paintSeed != null && paintSeed > 0 && (
              <div className="item-modal-prop">
                <span className="prop-label">{t('itemDetail.paintSeed', 'Paint Seed')}</span>
                <span className="prop-value">#{paintSeed}</span>
              </div>
            )}
            {paintIndex != null && paintIndex > 0 && (
              <div className="item-modal-prop">
                <span className="prop-label">{t('itemDetail.paintIndex', 'Paint Index')}</span>
                <span className="prop-value">{paintIndex}</span>
              </div>
            )}
          </div>

          {renderMarketActions()}

          <div className="item-modal-actions">
            <button className="item-modal-action-btn" type="button" onClick={goToSkinPage}>
              <ExternalLink size={16} />
              {t('itemDetail.skinPage', 'Skin page')}
            </button>

            {inspectHex && (
              <a
                className="item-modal-action-btn"
                href={buildInspectLink(inspectHex)}
                title={t('itemDetail.inspectHint', 'Opens CS2 and previews this exact item')}
              >
                <Crosshair size={16} />
                {t('itemDetail.inspect', 'Inspect in game')}
              </a>
            )}

            {onSell && (
              <button
                className={`item-modal-sell-btn ${isInSalePanel ? 'in-panel' : ''}`}
                onClick={onSell}
                type="button"
              >
                {isInSalePanel
                  ? t('inventory.removeFromSale', 'Remove from Sale')
                  : t('inventory.addToSale', 'Add to Sale')
                }
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
