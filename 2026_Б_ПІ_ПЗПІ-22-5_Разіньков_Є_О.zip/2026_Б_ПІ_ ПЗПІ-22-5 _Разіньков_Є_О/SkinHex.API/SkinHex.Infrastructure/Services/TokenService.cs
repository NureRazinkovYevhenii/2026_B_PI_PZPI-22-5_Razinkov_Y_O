using FluentResults;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using SkinHex.Core.Entities;
using SkinHex.Core.Interfaces;
using SkinHex.Core.Models.Auth;
using SkinHex.Infrastructure.Options;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace SkinHex.Infrastructure.Services;

public sealed class TokenService(IOptions<JwtOptions> jwtOptions) : ITokenService
{
    private readonly JwtOptions _jwtOptions = jwtOptions.Value;

    public Result<TokenResult> GenerateTokens(User user)
    {
        var accessTokenResult = GenerateAccessToken(user);
        if (accessTokenResult.IsFailed)
        {
            return Result.Fail<TokenResult>(accessTokenResult.Errors);
        }

        return Result.Ok(new TokenResult
        {
            AccessToken = accessTokenResult.Value,
            RefreshToken = GenerateRefreshToken()
        });
    }

    public Result<string> GenerateAccessToken(User user)
    {
        if (string.IsNullOrWhiteSpace(_jwtOptions.SecretKey))
        {
            return Result.Fail<string>("JWT SecretKey is not configured.");
        }

        var claims = new[]
        {
            new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new Claim(ClaimTypes.Name, user.Username),
            new Claim(ClaimTypes.Role, user.Role.ToString()),
            new Claim("steam_id", user.SteamId)
        };

        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtOptions.SecretKey));
        var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        var token = new JwtSecurityToken(
            issuer: _jwtOptions.Issuer,
            audience: _jwtOptions.Audience,
            claims: claims,
            expires: DateTime.UtcNow.AddMinutes(30),
            signingCredentials: credentials);

        return Result.Ok(new JwtSecurityTokenHandler().WriteToken(token));
    }

    private static string GenerateRefreshToken()
    {
        var randomNumber = new byte[32];
        using var rng = RandomNumberGenerator.Create();
        rng.GetBytes(randomNumber);

        return Convert.ToBase64String(randomNumber);
    }
}
