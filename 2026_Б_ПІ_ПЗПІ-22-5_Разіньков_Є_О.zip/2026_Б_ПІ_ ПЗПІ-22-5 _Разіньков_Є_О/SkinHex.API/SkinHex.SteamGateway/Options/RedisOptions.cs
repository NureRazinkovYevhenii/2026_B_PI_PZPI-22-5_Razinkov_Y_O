namespace SkinHex.SteamGateway.Options;

public sealed class RedisOptions
{
    public const string SectionName = "Redis";

    public string ConnectionString { get; init; } = "localhost:6379";
    public string SteamSessionsKey { get; init; } = "skinhex:steam:sessions";
    public int SessionTtlMinutes { get; init; } = 90;
}
