import { useTranslation } from 'react-i18next';
import { Trash2, X, ShoppingCart } from 'lucide-react';
import type { SaleItem, AuthorizedFetch } from '../types';
import { formatFloat, parseInventoryName } from '../utils/inventory';
import { getItemImageUrl } from '../utils/itemDictionary';
import { readApiError } from '../utils/api';
import { QuantityStepper } from './QuantityStepper';
import type { CSSProperties } from 'react';

type SalePanelProps = {
  authorizedFetch: AuthorizedFetch;
  saleItems: SaleItem[];
  onUpdateItem: (index: number, updates: Partial<Pick<SaleItem, 'price' | 'quantity'>>) => void;
  onRemoveItem: (index: number) => void;
  onClearAll: () => void;
  onSuccess: () => void;
  isCreating: boolean;
  onSetCreating: (v: boolean) => void;
  error: string | null;
  onSetError: (e: string | null) => void;
};

export function SalePanel({
  authorizedFetch,
  saleItems,
  onUpdateItem,
  onRemoveItem,
  onClearAll,
  onSuccess,
  isCreating,
  onSetCreating,
  error,
  onSetError,
}: SalePanelProps) {
  const { t } = useTranslation();

  if (saleItems.length === 0) {
    return (
      <aside className="sale-panel-wrap empty">
        <div className="sale-panel-empty">
          <div className="sale-panel-empty-icon">
            <ShoppingCart size={40} strokeWidth={1.5} />
          </div>
          <h3>{t('salePanel.emptyTitle')}</h3>
          <p>{t('salePanel.emptyDesc')}</p>
        </div>
      </aside>
    );
  }

  const totalItems = saleItems.reduce((sum, si) => sum + si.quantity, 0);
  const subtotal = saleItems.reduce((sum, si) => {
    const p = parseFloat(si.price);
    return sum + (isNaN(p) ? 0 : p * si.quantity);
  }, 0);
  const fee = subtotal * 0.01;
  const earnings = subtotal - fee;
  const allPricesValid = saleItems.every(si => {
    const p = parseFloat(si.price);
    return !isNaN(p) && p > 0;
  });

  const handleSubmit = async () => {
    if (!allPricesValid) {
      onSetError(t('salePanel.invalidPrice', 'Please enter valid prices for all items.'));
      return;
    }

    onSetCreating(true);
    onSetError(null);

    try {
      const itemsToSell = saleItems.flatMap(si => {
        const price = parseFloat(si.price);
        return si.group.items.slice(0, si.quantity).map(item => ({
          assetId: item.assetId,
          price,
        }));
      });

      const response = await authorizedFetch('/market/list/bulk', {
        method: 'POST',
        body: JSON.stringify({ items: itemsToSell }),
      });

      if (!response.ok) {
        throw new Error(await readApiError(response));
      }

      onSuccess();
    } catch (err) {
      onSetError(err instanceof Error ? err.message : t('salePanel.failed', 'Failed to list items.'));
    } finally {
      onSetCreating(false);
    }
  };

  return (
    <aside className="sale-panel-wrap">
      {/* Header */}
      <div className="sale-panel-head">
        <h3>
          {t('salePanel.itemsForSale', { count: totalItems, defaultValue: `${totalItems} item(s) for sale` })}
        </h3>
        <button onClick={onClearAll} className="sale-panel-clear" title={t('salePanel.clearAll', 'Clear all')}>
          <Trash2 size={16} />
        </button>
      </div>

      {/* Item list */}
      <div className="sale-panel-items">
        {saleItems.map((si, index) => {
          const item = si.group.items[0];
          const parsed = parseInventoryName(item.marketHashName);
          const accentColor = si.itemStatic?.color ? `#${si.itemStatic.color}` : '#3b82f6';
          const imageUrl = getItemImageUrl(si.itemStatic);
          const hasFloat = item.floatValue != null && item.floatValue > 0;

          return (
            <div
              className="sale-item-row"
              key={item.assetId}
              style={{ '--item-accent': accentColor } as CSSProperties}
            >
              <div className="sale-item-top">
                <div className="sale-item-thumb">
                  {imageUrl && <img src={imageUrl} alt={item.marketHashName} />}
                </div>
                <div className="sale-item-info">
                  <span className="sale-item-name" title={parsed.title}>{parsed.title}</span>
                  <span className="sale-item-meta">
                    {parsed.exterior ?? si.itemStatic?.category ?? 'Item'}
                    {hasFloat && <> · {formatFloat(item.floatValue)}</>}
                  </span>
                </div>
                <button
                  className="sale-item-remove"
                  onClick={() => onRemoveItem(index)}
                  title={t('salePanel.removeItem', 'Remove')}
                >
                  <X size={14} />
                </button>
              </div>

              <div className="sale-item-bottom">
                <div className="sale-item-price-wrap">
                  <span className="sale-item-currency">$</span>
                  <input
                    type="number"
                    step="0.01"
                    min="0.01"
                    value={si.price}
                    onChange={e => onUpdateItem(index, { price: e.target.value })}
                    placeholder="0.00"
                    className="sale-item-price-input"
                  />
                </div>
                {si.group.count > 1 && (
                  <QuantityStepper
                    value={si.quantity}
                    min={1}
                    max={si.group.count}
                    onChange={val => onUpdateItem(index, { quantity: val })}
                  />
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Summary */}
      <div className="sale-panel-summary">
        <div className="sale-summary-row">
          <span>{t('salePanel.subtotal')}</span>
          <span>${subtotal.toFixed(2)}</span>
        </div>
        <div className="sale-summary-row fee">
          <span>{t('salePanel.saleFee')}</span>
          <span>-${fee.toFixed(2)}</span>
        </div>
        <div className="sale-summary-divider" />
        <div className="sale-summary-row total">
          <span>{t('salePanel.totalEarnings')}</span>
          <span>${earnings.toFixed(2)}</span>
        </div>

        {error && <p className="sale-panel-error">{error}</p>}

        <button
          className="sale-panel-submit"
          onClick={handleSubmit}
          disabled={isCreating || !allPricesValid}
        >
          {isCreating ? t('salePanel.selling') : t('salePanel.sellItems')}
        </button>
      </div>
    </aside>
  );
}
