using FluentResults;
using SkinHex.Core.Models;

namespace SkinHex.Core.Interfaces;

public interface IUserService
{
    Task<Result<CurrentUserDto>> GetCurrentUserAsync(Guid userId, CancellationToken ct);
    Task<Result<UserBalanceDto>> GetBalanceAsync(Guid userId, CancellationToken ct);
    Task<Result<IReadOnlyList<InventoryItemDto>>> GetInventoryAsync(Guid userId, bool forceReload, CancellationToken ct);
    Task<Result> SaveTradeUrlAsync(Guid userId, string tradeUrl, CancellationToken ct);
    Task<Result> BanUserAsync(Guid userId, CancellationToken ct);
    Task<Result> UnbanUserAsync(Guid userId, CancellationToken ct);
}
