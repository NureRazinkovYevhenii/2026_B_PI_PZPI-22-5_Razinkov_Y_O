namespace SkinHex.Core.Models;

public enum SortOption
{
    PriceAsc = 0,   // Дешеві
    PriceDesc = 1,  // Дорогі
    Newest = 2,     // Нові
    FloatAsc = 3,
    FloatDesc = 4
}

public class GetListingsRequest
{
    // Пагінація
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 24; // 24 зручно ділиться на сітку 2, 3, 4 і 6 колонок на фронті

    public Guid? SellerId { get; set; }

    // Exact selection filters. Use search tips first, then pass one of these values to catalog.
    public int? ItemId { get; set; }        // Exact wear variant
    public string? BaseName { get; set; }   // "AK-47 | Bloodsport" - all wear variants for this weapon/skin
    public string? SkinName { get; set; }   // "Bloodsport" - all weapons/wears with this paint name
    public string? SearchTerm { get; set; } // Free text search for Enter-submit catalog searches
    public string? Category { get; set; }   // "Rifle", "Sniper Rifle"
    public string? Weapon { get; set; }     // "AK-47"
    public string? Wear { get; set; }       // "Field-Tested"

    // Варіант предмета. null = не фільтрувати (звичайний + StatTrak + Souvenir разом).
    public bool? IsStatTrak { get; set; }
    public bool? IsSouvenir { get; set; }

    public decimal? MinPrice { get; set; }
    public decimal? MaxPrice { get; set; }
    public double? MinFloat { get; set; }
    public double? MaxFloat { get; set; }
    public int? PaintSeed { get; set; }

    // Сортування
    public SortOption SortBy { get; set; } = SortOption.PriceAsc;
}
