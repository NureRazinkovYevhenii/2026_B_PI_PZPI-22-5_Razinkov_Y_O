import type { ParsedInventoryName } from '../types';

export function parseInventoryName(marketHashName: string): ParsedInventoryName {
  const parts: string[] = [];
  let title = marketHashName;
  let match = title.match(/\s*\(([^)]+)\)\s*$/);

  while (match) {
    parts.unshift(match[1]);
    title = title.slice(0, match.index).trim();
    match = title.match(/\s*\(([^)]+)\)\s*$/);
  }

  const exterior = parts.length > 0 ? parts.join(' / ') : null;

  return { title, exterior };
}

export function formatFloat(floatValue: number | null | undefined) {
  return typeof floatValue === 'number' ? floatValue.toFixed(10).replace(/0+$/, '').replace(/\.$/, '') : 'N/A';
}

// CS2 standard wear tier breakpoints
const WEAR_BREAKPOINTS = [0, 0.07, 0.15, 0.38, 0.45, 1.0];
const WEAR_NAMES = ['Factory New', 'Minimal Wear', 'Field-Tested', 'Well-Worn', 'Battle-Scarred'];
const WEAR_SHORT = ['FN', 'MW', 'FT', 'WW', 'BS'];
const WEAR_COLORS = ['#15803d', '#84cc16', '#ca8a04', '#ea580c', '#b91c1c'];

export function getWearName(floatValue: number): string {
  for (let i = 0; i < WEAR_BREAKPOINTS.length - 1; i++) {
    if (floatValue >= WEAR_BREAKPOINTS[i] && floatValue < WEAR_BREAKPOINTS[i + 1]) {
      return WEAR_NAMES[i];
    }
  }
  return WEAR_NAMES[WEAR_NAMES.length - 1];
}

export function getWearShort(floatValue: number): string {
  for (let i = 0; i < WEAR_BREAKPOINTS.length - 1; i++) {
    if (floatValue >= WEAR_BREAKPOINTS[i] && floatValue < WEAR_BREAKPOINTS[i + 1]) {
      return WEAR_SHORT[i];
    }
  }
  return WEAR_SHORT[WEAR_SHORT.length - 1];
}

export type FloatBarSegment = {
  color: string;
  widthPercent: number;
  label: string;
};

export function getFloatBarSegments(minF: number, maxF: number): FloatBarSegment[] {
  const segments: FloatBarSegment[] = [];

  if (minF > 0) {
    segments.push({
      color: 'transparent',
      widthPercent: minF * 100,
      label: '',
    });
  }

  for (let i = 0; i < WEAR_BREAKPOINTS.length - 1; i++) {
    const tierStart = WEAR_BREAKPOINTS[i];
    const tierEnd = WEAR_BREAKPOINTS[i + 1];

    const visibleStart = Math.max(tierStart, minF);
    const visibleEnd = Math.min(tierEnd, maxF);

    if (visibleStart >= visibleEnd) continue;

    const widthPercent = (visibleEnd - visibleStart) * 100;
    segments.push({
      color: WEAR_COLORS[i],
      widthPercent,
      label: WEAR_SHORT[i],
    });
  }

  if (maxF < 1) {
    segments.push({
      color: 'transparent',
      widthPercent: (1 - maxF) * 100,
      label: '',
    });
  }

  return segments;
}

export function getFloatPosition(floatValue: number): number {
  return Math.max(0, Math.min(100, floatValue * 100));
}

/** CS2 float bounds [min, max) for a wear-tier name, e.g. "Field-Tested" → [0.15, 0.38]. */
export function getWearTierRange(wearName: string): [number, number] {
  const index = WEAR_NAMES.indexOf(wearName);
  if (index < 0) return [0, 1];
  return [WEAR_BREAKPOINTS[index], WEAR_BREAKPOINTS[index + 1]];
}

const RARITY_ORDER: Record<string, number> = {
  'Contraband': 0,
  'Covert': 1,
  'Extraordinary': 1,
  'Classified': 2,
  'Exotic': 2,
  'Restricted': 3,
  'Remarkable': 3,
  'Mil-Spec Grade': 4,
  'High Grade': 4,
  'Industrial Grade': 5,
  'Consumer Grade': 6,
  'Base Grade': 7,
};

export function getRarityOrder(rarity: string): number {
  return RARITY_ORDER[rarity] ?? 99;
}
