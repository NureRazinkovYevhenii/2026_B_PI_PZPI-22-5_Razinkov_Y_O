using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using SkinHex.Core.Interfaces.Screenshots;
using SkinHex.Core.Models.Screenshots;

namespace SkinHex.Infrastructure.Services;

public sealed class CsMarketCapScreenshotClient(HttpClient httpClient) : IInspectScreenshotClient
{
    public async Task<InspectScreenshotResult> RequestSidesAsync(string inspectLink, CancellationToken ct = default)
    {
        using var response = await httpClient.PostAsJsonAsync(
            "api/screenshot/sides",
            new { inspect_link = inspectLink },
            ct);

        var body = await response.Content.ReadAsStringAsync(ct);
        if (!response.IsSuccessStatusCode)
        {
            throw new HttpRequestException(
                $"Screenshot provider returned {(int)response.StatusCode}: {Truncate(body, 500)}");
        }

        SidesResponse? payload;
        try
        {
            payload = JsonSerializer.Deserialize<SidesResponse>(body);
        }
        catch (JsonException)
        {
            throw new HttpRequestException($"Screenshot provider returned malformed payload: {Truncate(body, 500)}");
        }

        var isDone = string.Equals(payload?.Status, "done", StringComparison.OrdinalIgnoreCase);
        return new InspectScreenshotResult
        {
            IsReady = isDone && payload?.Urls?.Front is not null && payload.Urls.Back is not null,
            Status = payload?.Status,
            ExternalGuid = payload?.Guid,
            FrontUrl = payload?.Urls?.Front,
            BackUrl = payload?.Urls?.Back
        };
    }

    public async Task<byte[]> DownloadImageAsync(string imageUrl, CancellationToken ct = default)
    {
        // Провайдер віддає відносні шляхи ("/api/cs2x/screenshots/..."),
        // резолвимо їх від BaseAddress клієнта.
        using var response = await httpClient.GetAsync(imageUrl.TrimStart('/'), ct);
        if (!response.IsSuccessStatusCode)
        {
            throw new HttpRequestException(
                $"Screenshot download failed with {(int)response.StatusCode} for {imageUrl}.");
        }

        return await response.Content.ReadAsByteArrayAsync(ct);
    }

    private static string Truncate(string value, int maxLength)
        => value.Length <= maxLength ? value : value[..maxLength];

    private sealed class SidesResponse
    {
        [JsonPropertyName("status")] public string? Status { get; set; }
        [JsonPropertyName("guid")] public string? Guid { get; set; }
        [JsonPropertyName("urls")] public SidesUrls? Urls { get; set; }
    }

    private sealed class SidesUrls
    {
        [JsonPropertyName("front")] public string? Front { get; set; }
        [JsonPropertyName("back")] public string? Back { get; set; }
    }
}
