using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SkinHex.Core.Entities;
using SkinHex.Core.Errors;
using SkinHex.Core.Interfaces;
using SkinHex.Core.Interfaces.Repositories;
using SkinHex.Core.Interfaces.Services;
using SkinHex.Core.Interfaces.Steam;
using SkinHex.Core.Models.Notifications;
using SkinHex.Core.Models.Orders;
using SkinHex.Core.Models.Steam;
using SkinHex.Core.Options;

using Hangfire;

namespace SkinHex.Core.Services;

public class OrderService(
    IOrderRepository orderRepository,
    IListingRepository listingRepository,
    IUserRepository userRepository,
    IUnitOfWork unitOfWork,
    IOptions<OrderOptions> options,
    ISteamGatewayClient steamGatewayClient,
    IUserService userService,
    IBackgroundJobClient backgroundJobClient,
    IFinancialTransactionRepository financialTransactionRepository,
    INotificationService notificationService,
    IDisputeRepository disputeRepository,
    ILogger<OrderService> logger) : IOrderService
{
    private static readonly HashSet<SteamOfferState> RecoverableOfferStates =
    [
        SteamOfferState.Countered,
        SteamOfferState.Expired,
        SteamOfferState.Canceled,
        SteamOfferState.Declined,
        SteamOfferState.InvalidItems,
        SteamOfferState.CanceledBySecondFactor,
    ];

    private const string ReasonSellerCanceledEarly = "Seller canceled trade early in Steam";
    private const string ReasonBuyerDeclinedTrade = "Buyer declined trade in Steam";
    private const string ReasonBuyerDidNotAcceptTrade = "Buyer did not accept trade within 24h";
    private const string ReasonTradeRollbackByBuyer = "Trade rolled back by buyer in Steam";
    private const string ReasonTradeRollbackBySeller = "Trade rolled back by seller in Steam";
    private const string ReasonTradeRollbackUnknown = "Trade rolled back in Steam (initiator unknown)";

    private static readonly TimeSpan SettlementSafetyBuffer = TimeSpan.FromMinutes(60);

    private readonly OrderOptions _options = options.Value;

    public async Task<CreateOrderResponse> CreateOrderAsync(Guid listingId, Guid buyerId, CancellationToken ct = default)
    {
        var listing = await listingRepository.GetByIdWithItemAsync(listingId, ct)
            ?? throw new BusinessException(BusinessErrorCodes.ListingNotFound, "Listing not found.", 404);

        if (listing.Status != ListingStatus.Active)
            throw new BusinessException(BusinessErrorCodes.ListingUnavailable, "Listing is not available for purchase.", 409);

        if (listing.SellerId == buyerId)
            throw new BusinessException(BusinessErrorCodes.CannotBuyOwnListing, "You cannot buy your own listing.", 400);

        var buyer = await userRepository.GetByIdAsync(buyerId, ct)
            ?? throw new KeyNotFoundException("Buyer not found.");

        if (buyer.Role == UserRole.Banned)
            throw new BusinessException(BusinessErrorCodes.Forbidden, "You are banned and cannot purchase items.", 403);

        if (buyer.Balance < listing.Price)
            throw new BusinessException(BusinessErrorCodes.InsufficientBalance, "Insufficient balance.", 400);

        var seller = await userRepository.GetByIdAsync(listing.SellerId, ct)
            ?? throw new KeyNotFoundException("Seller not found.");

        var now = DateTime.UtcNow;
        // Lock the commission at purchase time so a later config change can't desync the
        // frozen (net) hold from the settlement/refund math.
        var commission = CalculateSaleCommission(listing.Price);

        listing.Status = ListingStatus.TradePending;
        // Buyer is charged the full price; the seller's escrow only holds the net they'll receive.
        // The commission (price − net) is the platform's pending cut, released to no one until settlement.
        buyer.Balance -= listing.Price;
        seller.FrozenBalance += listing.Price - commission;

        var order = new Order
        {
            Id = Guid.NewGuid(),
            ListingId = listing.Id,
            BuyerId = buyerId,
            SellerId = listing.SellerId,
            Status = OrderStatus.Pending,
            LockPrice = listing.Price,
            CommissionAmount = commission,
            CreatedAt = now,
            UpdatedAt = now,
            ConfirmDeadline = now.AddHours(_options.SellerConfirmWindowHours)
        };

        await orderRepository.AddAsync(order, ct);

        // Ledger: the buyer's balance was debited right now, so the purchase is recorded here
        // (not at settlement). A later cancellation posts an offsetting Refund entry.
        AddOrderTransaction(buyerId, listing.Price, FinancialTransactionType.Purchase, order.Id, now);

        try
        {
            await unitOfWork.SaveChangesAsync(ct);
        }
        catch (DbUpdateConcurrencyException)
        {
            throw new BusinessException(BusinessErrorCodes.ListingUnavailable, "Listing was already purchased by another buyer.", 409);
        }

        // Schedule timeout job for Pending confirmation
        var delay = order.ConfirmDeadline!.Value - now;
        backgroundJobClient.Schedule<IOrderTimeoutJobs>(
            x => x.ExecuteTimeoutCheckAsync(order.Id, CancellationToken.None),
            delay);

        // Realtime fan-out after the purchase is committed:
        // seller learns about the sale, both wallets sync (buyer spent, seller's funds froze),
        // and everyone else holding this listing in their cart sees it go unavailable.
        await notificationService.NotifyItemSoldAsync(order, listing, buyer, ct);
        await notificationService.PushBalanceUpdateAsync(buyer, -listing.Price, "purchase_hold", ct);
        // Seller's escrow only holds the net (price − commission); reflect that in the realtime delta.
        await notificationService.PushBalanceUpdateAsync(seller, listing.Price - commission, "sale_hold", ct);
        await notificationService.InvalidateCartListingAsync(listing.Id, excludeUserId: buyerId, ct);

        return new CreateOrderResponse(
            Id: order.Id,
            ListingId: order.ListingId,
            Status: order.Status,
            LockPrice: order.LockPrice,
            CreatedAt: order.CreatedAt,
            ConfirmDeadline: order.ConfirmDeadline!.Value,
            Buyer: new OrderParticipantDto(buyer.Id, buyer.Username, buyer.AvatarUrl),
            Seller: new OrderParticipantDto(seller.Id, seller.Username, seller.AvatarUrl));
    }

    public async Task<IEnumerable<OrderDto>> GetUserOrdersAsync(Guid userId, string? roleFilter = null, CancellationToken ct = default)
    {
        var normalizedRole = roleFilter?.Trim().ToLowerInvariant();
        if (normalizedRole is not null and not ("buyer" or "seller"))
            throw new ArgumentException("Role filter must be either 'buyer' or 'seller'.", nameof(roleFilter));

        var orders = await orderRepository.GetOrdersByUserIdAsync(userId, ct);

        return orders
            .Where(order => normalizedRole switch
            {
                "buyer" => order.BuyerId == userId,
                "seller" => order.SellerId == userId,
                _ => true
            })
            .Select(order => MapToOrderDto(order, userId, _options))
            .ToList();
    }

    public async Task<TradeInfoDto> GetTradeInfoAsync(Guid orderId, Guid sellerId, CancellationToken ct = default)
    {
        var order = await orderRepository.GetByIdWithDetailsAsync(orderId, ct)
            ?? throw new BusinessException(BusinessErrorCodes.OrderNotFound, "Order not found.", 404);

        if (order.SellerId != sellerId)
            throw new BusinessException(BusinessErrorCodes.Forbidden, "Insufficient permissions.", 403);

        if (order.Status != OrderStatus.Confirmed)
            throw new BusinessException(BusinessErrorCodes.InvalidOrderStatus, "Order must be in Confirmed status to get trade info.", 409);

        var buyer = order.Buyer;
        if (!SteamTradeLink.TryParse(buyer.TradeUrl, out var buyerTradeLink, out _))
            throw new BusinessException(BusinessErrorCodes.RequireTradeUrl, "Buyer has not set a valid Trade URL.", 409);

        return new TradeInfoDto(
            BuyerSteamId: buyer.SteamId,
            BuyerTradeToken: buyerTradeLink!.Token,
            BuyerPartnerId: buyerTradeLink.PartnerAccountId.ToString(),
            AssetId: order.Listing.SteamAssetId
        );
    }

    public async Task<PendingTradeSyncResponse> GetPendingTradeSyncAsync(Guid userId, string? actorRole, CancellationToken ct = default)
    {
        if (!TryParseActorRole(actorRole, out var parsedActorRole))
            throw new BusinessException("INVALID_ACTOR_ROLE", "actorRole must be 'seller', 'buyer' or 'all'.", 400);

        var trades = await orderRepository.GetPendingTradeSyncItemsAsync(userId, parsedActorRole, ct);
        return new PendingTradeSyncResponse(ActorRoleToString(parsedActorRole), trades);
    }

    private static string ActorRoleToString(TradeSyncActorRole? actorRole) =>
        actorRole?.ToString().ToLowerInvariant() ?? "all";

    public async Task<BatchTradeSyncUpdateResponse> BatchSyncTradeAttemptsAsync(Guid userId, BatchTradeSyncUpdateRequest request, CancellationToken ct = default)
    {
        if (!TryParseActorRole(request.ActorRole, out var parsedActorRole))
            throw new BusinessException("INVALID_ACTOR_ROLE", "actorRole must be 'seller', 'buyer' or 'all'.", 400);

        if (request.Updates.Count == 0)
        {
            return new BatchTradeSyncUpdateResponse(
                ActorRoleToString(parsedActorRole),
                0,
                0,
                0,
                []);
        }

        var results = new List<BatchTradeSyncUpdateItemResult>(request.Updates.Count);
        var updated = 0;

        foreach (var update in request.Updates)
        {
            if (update.OrderId == Guid.Empty || string.IsNullOrWhiteSpace(update.TradeOfferId))
            {
                results.Add(new BatchTradeSyncUpdateItemResult(
                    update.OrderId,
                    update.TradeOfferId,
                    false,
                    "INVALID_INPUT",
                    "OrderId and TradeOfferId are required.",
                    null));
                continue;
            }

            try
            {
                // Unified batch: without an explicit role, each item is routed by the caller's
                // actual side of that order. Seller reports drive the order lifecycle fully;
                // buyer reports are corroboration plus the safe subset of transitions.
                var itemRole = parsedActorRole ?? await ResolveActorRoleAsync(update.OrderId, userId, ct);

                var trade = itemRole == TradeSyncActorRole.Buyer
                    ? await ReportBuyerTradeObservationAsync(
                        update.OrderId,
                        userId,
                        update.TradeOfferId,
                        update.OfferState,
                        update.AssetIds,
                        update.TimeUpdated,
                        ct)
                    : await UpdateTradeAttemptAsync(
                        update.OrderId,
                        userId,
                        update.TradeOfferId,
                        update.OfferState,
                        update.TradeId,
                        update.TradeStatus,
                        update.TimeUpdated,
                        ct);

                updated++;
                results.Add(new BatchTradeSyncUpdateItemResult(
                    update.OrderId,
                    update.TradeOfferId,
                    true,
                    null,
                    null,
                    trade));
            }
            catch (BusinessException businessException)
            {
                results.Add(new BatchTradeSyncUpdateItemResult(
                    update.OrderId,
                    update.TradeOfferId,
                    false,
                    businessException.ErrorCode,
                    businessException.Message,
                    null));
            }
        }

        return new BatchTradeSyncUpdateResponse(
            ActorRoleToString(parsedActorRole),
            request.Updates.Count,
            updated,
            request.Updates.Count - updated,
            results);
    }

    private async Task<TradeSyncActorRole> ResolveActorRoleAsync(Guid orderId, Guid userId, CancellationToken ct)
    {
        var order = await orderRepository.GetByIdAsync(orderId, ct)
            ?? throw new BusinessException(BusinessErrorCodes.OrderNotFound, "Order not found.", 404);

        if (order.SellerId == userId)
            return TradeSyncActorRole.Seller;
        if (order.BuyerId == userId)
            return TradeSyncActorRole.Buyer;

        throw new BusinessException(BusinessErrorCodes.Forbidden, "You are not a participant of this order.", 403);
    }

    public async Task<OrderDto> ConfirmOrderAsync(Guid orderId, Guid sellerId, CancellationToken ct = default)
    {
        var order = await orderRepository.GetByIdAsync(orderId, ct)
            ?? throw new BusinessException(BusinessErrorCodes.OrderNotFound, "Order not found.", 404);

        if (order.SellerId != sellerId)
            throw new BusinessException(BusinessErrorCodes.Forbidden, "Insufficient permissions.", 403);

        if (order.Status != OrderStatus.Pending)
            throw new BusinessException(BusinessErrorCodes.OrderNotPending, "Order is not in Pending status.", 409);

        var now = DateTime.UtcNow;

        if (order.ConfirmDeadline < now)
        {
            // Auto cancel immediately if we're late
            return await CancelOrderAsync(orderId, null, "Seller did not confirm within time limit", CancelledBy.System, ct, true);
        }

        var rows = await orderRepository.ExecuteConfirmAsync(orderId, now, ct);
        if (rows == 0)
            throw new BusinessException(BusinessErrorCodes.OrderNotPending, "Order is already in a different status.", 409);

        // Update in-memory object for mapping response
        order.Status = OrderStatus.Confirmed;
        order.ConfirmedAt = now;

        // Schedule timeout job for Sending Trade
        backgroundJobClient.Schedule<IOrderTimeoutJobs>(
            x => x.ExecuteTimeoutCheckAsync(orderId, CancellationToken.None),
            TimeSpan.FromHours(2));

        // Buyer waits on the seller's confirmation — let them know it happened.
        EnqueueOrderNotification(orderId, OrderStatus.Confirmed);

        return MapToOrderDto(order, sellerId, _options);
    }

    private void EnqueueOrderNotification(Guid orderId, OrderStatus status)
        => backgroundJobClient.Enqueue<INotificationJobs>(x => x.NotifyOrderTransitionAsync(orderId, status, CancellationToken.None));

    /// <summary>Grace period after the escrow hold before a missing completion proof becomes a support case.</summary>
    private static readonly TimeSpan EscrowStuckGracePeriod = TimeSpan.FromDays(3);

    /// <summary>
    /// When an order enters escrow, schedules a check for the "seller never ran the completion proof"
    /// scenario: escrow hold + grace period later the order should not still be InEscrow.
    /// </summary>
    private void ScheduleEscrowStuckCheckIfEntered(Guid orderId, TradeLifecycleUpdate update)
    {
        if (update.Status != OrderStatus.InEscrow || !update.AcceptedAt.HasValue)
            return;

        var checkAt = CalculateEscrowEndsAt(update.AcceptedAt.Value).Add(EscrowStuckGracePeriod);
        var delay = checkAt - DateTime.UtcNow;
        if (delay < TimeSpan.Zero)
            delay = TimeSpan.Zero;

        backgroundJobClient.Schedule<IOrderTimeoutJobs>(
            x => x.ExecuteEscrowStuckCheckAsync(orderId, CancellationToken.None),
            delay);
    }

    /// <summary>
    /// Adds a ledger entry for a balance movement tied to an order. Amount is signed for Penalty
    /// (negative = charged, positive = compensation received); other types store a positive
    /// magnitude and let their type convey direction. Persisted by the caller's SaveChanges.
    /// </summary>
    private void AddOrderTransaction(Guid userId, decimal amount, FinancialTransactionType type, Guid orderId, DateTime at)
    {
        financialTransactionRepository.Add(new FinancialTransaction
        {
            Id = Guid.NewGuid(),
            UserId = userId,
            Amount = amount,
            Type = type,
            Status = FinancialTransactionStatus.Completed,
            ReferenceId = orderId,
            CreatedAt = at
        });
    }

    public async Task<OrderDto> CancelOrderAsync(Guid orderId, Guid? initiatorId, string? reason, CancelledBy? cancelledBy = null, CancellationToken ct = default)
    {
        return await CancelOrderAsync(orderId, initiatorId, reason, cancelledBy, ct, false);
    }

    private async Task<OrderDto> CancelOrderAsync(Guid orderId, Guid? initiatorId, string? reason, CancelledBy? cancelledBy, CancellationToken ct, bool isLateConfirmation)
    {
        // An open dispute freezes the normal cancel pipeline (user cancels and timeout jobs alike);
        // only support resolution or a ground-truth Steam event may move the order forward.
        if (await disputeRepository.HasOpenDisputeAsync(orderId, ct))
            throw new BusinessException(BusinessErrorCodes.OrderDisputed, "The order has an open dispute — cancellation is blocked until support resolves it.", 409);

        var order = await orderRepository.GetByIdAsync(orderId, ct)
            ?? throw new BusinessException(BusinessErrorCodes.OrderNotFound, "Order not found.", 404);

        if (cancelledBy == null)
        {
            if (initiatorId == order.BuyerId) cancelledBy = CancelledBy.Buyer;
            else if (initiatorId == order.SellerId) cancelledBy = CancelledBy.Seller;
            else cancelledBy = CancelledBy.System;
        }

        if (cancelledBy == CancelledBy.Buyer && initiatorId != order.BuyerId)
            throw new BusinessException(BusinessErrorCodes.Forbidden, "Insufficient permissions.", 403);

        if (cancelledBy == CancelledBy.Seller && initiatorId != order.SellerId)
            throw new BusinessException(BusinessErrorCodes.Forbidden, "Insufficient permissions.", 403);

        var now = DateTime.UtcNow;

        if (cancelledBy == CancelledBy.Buyer)
        {
            var cancelDto = MapToOrderDto(order, initiatorId ?? Guid.Empty, _options);
            if (cancelDto.BuyerCancelableAt.HasValue && now < cancelDto.BuyerCancelableAt.Value)
            {
                var remainingSeconds = (int)(cancelDto.BuyerCancelableAt.Value - now).TotalSeconds;
                var exception = new BusinessException(BusinessErrorCodes.TooEarlyToCancel, "Too early for the buyer to cancel.", 409);
                exception.Data["remainingSeconds"] = remainingSeconds;
                throw exception;
            }
        }

        using var transaction = await unitOfWork.BeginTransactionAsync(ct);
        var resultDto = await CancelOrderInternalAsync(orderId, initiatorId, reason, cancelledBy.Value, transaction, ct, isLateConfirmation);
        await transaction.CommitAsync(ct);

        EnqueueOrderNotification(orderId, OrderStatus.Cancelled);

        return resultDto;
    }

    private async Task<OrderDto> CancelOrderInternalAsync(Guid orderId, Guid? initiatorId, string? reason, CancelledBy cancelledBy, Microsoft.EntityFrameworkCore.Storage.IDbContextTransaction transaction, CancellationToken ct, bool isLateConfirmation, DateTime? eventTime = null)
    {
        var order = await orderRepository.GetByIdAsync(orderId, ct)
            ?? throw new BusinessException(BusinessErrorCodes.OrderNotFound, "Order not found.", 404);

        var statusBeforeCancel = order.Status;
        var now = eventTime ?? DateTime.UtcNow;

        var rows = await orderRepository.ExecuteCancelAsync(orderId, cancelledBy, reason, now, ct);
        if (rows == 0)
        {
            throw new BusinessException(BusinessErrorCodes.OrderNotPending, "Order is already in a different status.", 409);
        }

        order.Status = OrderStatus.Cancelled;
        order.CancelledAtStatus = statusBeforeCancel;
        order.CancelledBy = cancelledBy;
        order.CancelReason = reason;
        order.CancelledAt = now;

        var buyer = await userRepository.GetByIdAsync(order.BuyerId, ct);
        var seller = await userRepository.GetByIdAsync(order.SellerId, ct);
        var listing = await listingRepository.GetByIdAsync(order.ListingId, ct);

        bool isSellerFault = false;
        if (buyer != null && seller != null)
        {
            isSellerFault = ApplyPenalties(order, buyer, seller, cancelledBy, statusBeforeCancel, reason, now);
        }

        if (listing != null && !isSellerFault)
        {
            listing.Status = ListingStatus.Active;
        }

        await unitOfWork.SaveChangesAsync(ct);
        // Do not commit here, allow the caller to commit
        // await transaction.CommitAsync(ct);

        var dto = MapToOrderDto(order, initiatorId ?? Guid.Empty, _options);
        
        if (isLateConfirmation)
        {
            var exception = new BusinessException(BusinessErrorCodes.ConfirmDeadlineExceeded, "Confirmation time has expired.", 409);
            exception.Data["order"] = dto;
            throw exception;
        }

        return dto;
    }

    private bool ApplyPenalties(Order order, User buyer, User seller, CancelledBy cancelledBy, OrderStatus statusBeforeCancel, string? cancelReason, DateTime at)
    {
        // Повернення заморозки продавця. На заморозку впав тільки нетто (LockPrice − комісія),
        // тому саме стільки й знімаємо. Покупцеві повертається повна LockPrice (комісія анулюється),
        // а різниця — це відкладена комісія платформи, яка теж скасовується разом із замовленням.
        // Покупцеві під час створення замовлення нічого не заморожується (Balance списується одразу),
        // тому його FrozenBalance тут не чіпаємо.
        seller.FrozenBalance -= order.LockPrice - order.CommissionAmount;

        // A Pending order was never confirmed by the seller — nothing was committed on either side,
        // so cancelling it (buyer backs out, seller ignores it, or the confirm-timeout fires) carries
        // NO penalty. Just refund the buyer in full. Penalties only make sense after commitment
        // (the seller confirmed / a trade was sent).
        if (statusBeforeCancel == OrderStatus.Pending)
        {
            buyer.Balance += order.LockPrice;
            AddOrderTransaction(buyer.Id, order.LockPrice, FinancialTransactionType.Refund, order.Id, at);
            return false;
        }

        var penaltyAmount = CalculateStandardPenalty(order.LockPrice);
        bool isSellerFaultAfterStart = false;

        // Obtain the latest known trade attempt to determine fault reliably based on Steam status
        var latestTrade = order.SteamTrades?.OrderByDescending(t => t.UpdatedAt).FirstOrDefault();

        var faultParty = DetermineFault(
            latestTrade,
            order.TradeSentAt,
            order.TradeAcceptDeadline,
            DateTime.UtcNow, // Use current time for cancellation evaluation
            cancelReason
        );

        if (faultParty == FaultParty.Buyer)
        {
            if (cancelReason == ReasonTradeRollbackByBuyer)
            {
                penaltyAmount = CalculateRollbackPenalty(order.LockPrice);
            }

            // Buyer-fault penalties are applied immediately, trusting the reported Steam state.
            // If a report was false — e.g. a fraudulent seller staged a "declined" / 24h-timeout
            // the buyer never caused — the buyer's recourse is a PenaltyAppeal dispute, which
            // support reverses (ReverseBuyerPenalty). Keeping the money moving avoids dragging the
            // admin into every uncorroborated cancel; the appeal is the safety net for false ones.
            ApplyPenaltyForBuyerNotAcceptingTrade(buyer, seller, order, penaltyAmount, at);
        }
        else if (faultParty == FaultParty.Seller)
        {
            // Seller canceled, rolled back, or failed to send trade on time.
            ApplyPenaltyForSellerCancelingEarly(buyer, seller, order, penaltyAmount, at);

            if (cancelReason == ReasonTradeRollbackBySeller)
            {
                // Trigger background job to execute ban asynchronously, or execute it inline.
                // Using fire-and-forget job avoids slowing down the webhook processing
                // and avoids complex transaction scopes nesting.
                backgroundJobClient.Enqueue(() => userService.BanUserAsync(seller.Id, CancellationToken.None));
            }
            isSellerFaultAfterStart = statusBeforeCancel == OrderStatus.TradeSent;
        }
        else
        {
            // FaultParty.None - Refund buyer completely.
            buyer.Balance += order.LockPrice;
            AddOrderTransaction(buyer.Id, order.LockPrice, FinancialTransactionType.Refund, order.Id, at);
        }

        return isSellerFaultAfterStart;
    }

    public FaultParty DetermineFault(
        SteamTrade? latestTrade,
        DateTime? tradeSentAt,
        DateTime? tradeAcceptDeadline,
        DateTime cancelledAt,
        string? rollbackCancelReason)
    {
        // 1. If a trade was never created, it means the seller missed the Confirmation deadline.
        if (latestTrade == null)
        {
            return FaultParty.Seller;
        }

        // 2. If the reason explicitly points to a rollback, use the already detected initiator.
        if (rollbackCancelReason == ReasonTradeRollbackByBuyer)
        {
            return FaultParty.Buyer;
        }
        if (rollbackCancelReason == ReasonTradeRollbackBySeller)
        {
            return FaultParty.Seller;
        }

        // 2b. Cancel reasons that already encode fault authoritatively. The caller
        // (UpdateTradeAttemptAsync) determined these from the real Steam event — an early
        // seller cancel is the seller's fault, a buyer decline / 24h no-accept is the buyer's.
        // Trust them instead of re-deriving from the time-based heuristic below, which uses
        // the processing time and can misattribute (this caused seller-early-cancel to be
        // wrongly blamed on the buyer).
        if (rollbackCancelReason == ReasonSellerCanceledEarly)
        {
            return FaultParty.Seller;
        }
        if (rollbackCancelReason == ReasonBuyerDeclinedTrade || rollbackCancelReason == ReasonBuyerDidNotAcceptTrade)
        {
            return FaultParty.Buyer;
        }

        // 3. Fallback rollback detection via SteamTradeStatus (handles desync if reason wasn't explicitly set).
        if (latestTrade.TradeStatus == SteamTradeStatus.TradeProtectionRollback || 
            latestTrade.TradeStatus == SteamTradeStatus.EscrowRollback || 
            latestTrade.TradeStatus == SteamTradeStatus.FullSupportRollback)
        {
            logger.LogWarning("Trade {TradeId} for Order {OrderId} was rolled back but rollback cancel reason was not provided. Defaulting to None for manual review.", latestTrade.TradeId, latestTrade.OrderId);
            return FaultParty.None;
        }

        // 4. Offer explicitly declined by the buyer.
        if (latestTrade.OfferState == SteamOfferState.Declined)
        {
            return FaultParty.Buyer;
        }

        // 5. Offer canceled, invalid, or expired.
        if (latestTrade.OfferState == SteamOfferState.Canceled ||
            latestTrade.OfferState == SteamOfferState.InvalidItems ||
            latestTrade.OfferState == SteamOfferState.Expired ||
            latestTrade.OfferState == SteamOfferState.CanceledBySecondFactor)
        {
            // Check if the buyer had the full window to accept.
            if (tradeSentAt.HasValue && tradeAcceptDeadline.HasValue)
            {
                // If it was canceled AFTER the accept deadline expired, it's the buyer's fault (timeout).
                var acceptWindow = tradeAcceptDeadline.Value - tradeSentAt.Value;
                if ((cancelledAt - tradeSentAt.Value) >= acceptWindow)
                {
                    return FaultParty.Buyer;
                }
                
                // If canceled PREMATURELY (before the window expired), it's the seller's fault.
                return FaultParty.Seller;
            }
        }

        // 6. Unknown / Edge Cases. Log heavily to enable manual support intervention.
        logger.LogWarning("DetermineFault encountered an unhandled combination for Order {OrderId}. OfferState: {OfferState}, TradeStatus: {TradeStatus}, SentAt: {SentAt}, AcceptDeadline: {Deadline}, CancelledAt: {CancelledAt}. Defaulting to None.",
            latestTrade.OrderId, latestTrade.OfferState, latestTrade.TradeStatus, tradeSentAt, tradeAcceptDeadline, cancelledAt);

        return FaultParty.None;
    }

    /// <summary>
    /// Platform commission on a completed sale, deducted from the seller's proceeds.
    /// Rounded to cents (down, in the platform's favour) and clamped to the sale price.
    /// </summary>
    private decimal CalculateSaleCommission(decimal lockPrice)
    {
        if (_options.SaleCommissionPercent <= 0m || lockPrice <= 0m)
            return 0m;

        var commission = decimal.Round(lockPrice * _options.SaleCommissionPercent, 2, MidpointRounding.ToZero);
        return Math.Min(commission, lockPrice);
    }

    private static decimal CalculateStandardPenalty(decimal lockPrice)
    {
        var penalty = Math.Max(lockPrice * 0.02m, 0.05m);
        if (lockPrice < penalty) penalty = lockPrice;
        return penalty;
    }

    private static decimal CalculateRollbackPenalty(decimal lockPrice)
    {
        var penalty = Math.Max(lockPrice * 0.10m, 0.05m);
        if (lockPrice < penalty) penalty = lockPrice;
        return penalty;
    }

    private void ApplyPenaltyForBuyerNotAcceptingTrade(User buyer, User seller, Order order, decimal penaltyAmount, DateTime at)
    {
        // Штраф вираховується з суми, що повертається
        buyer.Balance += (order.LockPrice - penaltyAmount);
        seller.Balance += penaltyAmount;

        // Ledger: full refund to the buyer, minus a penalty they pay; the seller receives it as compensation.
        AddOrderTransaction(buyer.Id, order.LockPrice, FinancialTransactionType.Refund, order.Id, at);
        AddOrderTransaction(buyer.Id, -penaltyAmount, FinancialTransactionType.Penalty, order.Id, at);
        AddOrderTransaction(seller.Id, penaltyAmount, FinancialTransactionType.Penalty, order.Id, at);
    }

    private void ApplyPenaltyForSellerCancelingEarly(User buyer, User seller, Order order, decimal penaltyAmount, DateTime at)
    {
        buyer.Balance += order.LockPrice;

        // Заводимо в мінус
        seller.Balance -= penaltyAmount;
        buyer.Balance += penaltyAmount;

        // Ledger: buyer gets a full refund plus the penalty as compensation; the seller is charged it.
        AddOrderTransaction(buyer.Id, order.LockPrice, FinancialTransactionType.Refund, order.Id, at);
        AddOrderTransaction(buyer.Id, penaltyAmount, FinancialTransactionType.Penalty, order.Id, at);
        AddOrderTransaction(seller.Id, -penaltyAmount, FinancialTransactionType.Penalty, order.Id, at);
    }

    public async Task<SteamTradeDto> CreateTradeAttemptAsync(Guid orderId, Guid sellerId, string tradeOfferId, SteamOfferState offerState, CancellationToken ct = default)
    {
        using var transaction = await unitOfWork.BeginTransactionAsync(ct);

        var order = await orderRepository.GetByIdAsync(orderId, ct);
        if (order == null)
            throw new BusinessException(BusinessErrorCodes.OrderNotFound, "Order not found.", 404);

        if (order.SellerId != sellerId)
            throw new BusinessException(BusinessErrorCodes.Forbidden, "You are not the seller of this order.", 403);

        if (order.Status is not (OrderStatus.Confirmed or OrderStatus.TradeSent))
            throw new BusinessException(BusinessErrorCodes.InvalidOrderStatus, "Order must be in Confirmed or TradeSent status.", 409);

        var previousStatus = order.Status;

        var trade = order.SteamTrades.FirstOrDefault(t => t.TradeOfferId == tradeOfferId);
        if (trade != null)
        {
            if (trade.OfferState == offerState)
            {
                return new SteamTradeDto(trade.Id, trade.TradeOfferId, trade.TradeId, trade.OfferState, trade.TradeStatus, trade.CreatedAt, trade.UpdatedAt);
            }
            await orderRepository.ExecuteSteamTradeUpdateAsync(trade.Id, offerState, DateTime.UtcNow, ct);
        }
        else
        {
            trade = new SteamTrade
            {
                Id = Guid.NewGuid(),
                OrderId = orderId,
                TradeOfferId = tradeOfferId,
                OfferState = offerState,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            int inserted = await orderRepository.ExecuteSteamTradeInsertAsync(trade, ct);
            if (inserted == 0)
            {
                // Trade was inserted by a concurrent request. Fetch it and update it.
                trade = await orderRepository.GetSteamTradeByOfferIdAsync(tradeOfferId, ct)
                    ?? throw new BusinessException(BusinessErrorCodes.TradeNotFound, "Trade not found after insert conflict.", 500);

                await orderRepository.ExecuteSteamTradeUpdateAsync(trade.Id, offerState, DateTime.UtcNow, ct);
            }
        }

        var lifecycleUpdate = BuildTradeLifecycleUpdate(order, offerState, DateTime.UtcNow);

        await orderRepository.ExecuteTradeLifecycleUpdateAsync(
            orderId,
            lifecycleUpdate.Status,
            lifecycleUpdate.TradeSentAt,
            lifecycleUpdate.TradeAcceptDeadline,
            lifecycleUpdate.AcceptedAt,
            ct);

        await transaction.CommitAsync(ct);

        // e.g. Confirmed → TradeSent (notify buyer) or TradeSent → InEscrow (notify seller).
        if (lifecycleUpdate.Status != previousStatus)
        {
            EnqueueOrderNotification(orderId, lifecycleUpdate.Status);
            ScheduleEscrowStuckCheckIfEntered(orderId, lifecycleUpdate);
        }

        var finalOfferState = trade.Id != Guid.Empty && trade.OfferState != offerState ? offerState : trade.OfferState;
        var finalUpdatedAt = trade.Id != Guid.Empty && trade.OfferState != offerState ? DateTime.UtcNow : trade.UpdatedAt;
        return new SteamTradeDto(trade.Id, trade.TradeOfferId, trade.TradeId, finalOfferState, trade.TradeStatus, trade.CreatedAt, finalUpdatedAt);
    }

    /// <summary>
    /// Buyer-side report for an incoming offer. Trust model:
    /// - Corroboration fields are always recorded — they gate buyer penalties and power
    ///   the "wrong item in the offer" warning before the buyer accepts.
    /// - A safe subset of states may drive the lifecycle: Accepted/InEscrow advances the order
    ///   (starting the escrow clock only helps the seller — lying gains the buyer nothing) and
    ///   Declined cancels it (self-incriminating: the buyer's own penalty follows).
    /// - Seller-fault claims (Canceled, InvalidItems, …) are stored but never acted on:
    ///   a malicious buyer could stage them to get the seller penalized.
    /// </summary>
    private async Task<SteamTradeDto> ReportBuyerTradeObservationAsync(
        Guid orderId,
        Guid buyerId,
        string tradeOfferId,
        SteamOfferState offerState,
        IReadOnlyCollection<string>? seenAssetIds,
        long? timeUpdated,
        CancellationToken ct)
    {
        using var transaction = await unitOfWork.BeginTransactionAsync(ct);

        var order = await orderRepository.GetByIdWithDetailsAsync(orderId, ct)
            ?? throw new BusinessException(BusinessErrorCodes.OrderNotFound, "Order not found.", 404);

        if (order.BuyerId != buyerId)
            throw new BusinessException(BusinessErrorCodes.Forbidden, "You are not the buyer of this order.", 403);

        var trade = order.SteamTrades.FirstOrDefault(t => t.TradeOfferId == tradeOfferId)
            ?? throw new BusinessException(BusinessErrorCodes.TradeNotFound, "Trade offer not found.", 404);

        var wasMismatch = trade.BuyerAssetMatchesListing == false;
        var previousStatus = order.Status;
        var eventTime = timeUpdated.HasValue
            ? DateTimeOffset.FromUnixTimeSeconds(timeUpdated.Value).UtcDateTime
            : DateTime.UtcNow;

        trade.BuyerReportedOfferState = offerState;
        trade.BuyerReportedAt = eventTime;

        if (seenAssetIds is { Count: > 0 })
        {
            trade.BuyerSeenAssetIds = string.Join(",", seenAssetIds);
            trade.BuyerAssetMatchesListing = seenAssetIds
                .Any(a => long.TryParse(a, out var id) && id == order.Listing.SteamAssetId);
        }

        // While a dispute is open, buyer reports still record corroboration (evidence for the
        // admin) but must not drive the order forward — admin resolution is the only authority.
        var frozenByDispute = await disputeRepository.HasOpenDisputeAsync(orderId, ct);

        if (!frozenByDispute && order.Status == OrderStatus.TradeSent && IsAcceptedOrEscrowOfferState(offerState))
        {
            // Buyer accepted the offer — advance to InEscrow without waiting for the seller's sync.
            trade.OfferState = offerState;
            trade.UpdatedAt = DateTime.UtcNow;

            var lifecycleUpdate = BuildTradeLifecycleUpdate(order, offerState, eventTime);
            await unitOfWork.SaveChangesAsync(ct);
            await orderRepository.ExecuteTradeLifecycleUpdateAsync(
                orderId,
                lifecycleUpdate.Status,
                lifecycleUpdate.TradeSentAt,
                lifecycleUpdate.TradeAcceptDeadline,
                lifecycleUpdate.AcceptedAt,
                ct);
            await transaction.CommitAsync(ct);

            if (lifecycleUpdate.Status != previousStatus)
            {
                EnqueueOrderNotification(orderId, lifecycleUpdate.Status);
                ScheduleEscrowStuckCheckIfEntered(orderId, lifecycleUpdate);
            }
        }
        else if (!frozenByDispute && order.Status == OrderStatus.TradeSent && offerState == SteamOfferState.Declined)
        {
            // Self-incriminating: the buyer reports their own decline.
            trade.OfferState = SteamOfferState.Declined;
            trade.UpdatedAt = DateTime.UtcNow;

            await CancelOrderInternalAsync(orderId, order.BuyerId, ReasonBuyerDeclinedTrade, CancelledBy.Buyer, transaction, ct, false, eventTime);
            await transaction.CommitAsync(ct);
            EnqueueOrderNotification(orderId, OrderStatus.Cancelled);
        }
        else
        {
            await unitOfWork.SaveChangesAsync(ct);
            await transaction.CommitAsync(ct);
        }

        // Warn the buyer once when the incoming offer does not contain the purchased item.
        if (!wasMismatch && trade.BuyerAssetMatchesListing == false)
        {
            await notificationService.NotifyAsync(buyerId, NotificationType.System,
                new TradeOfferMismatchPayload(orderId, tradeOfferId, order.Listing.SteamAssetId), ct);
        }

        return new SteamTradeDto(trade.Id, trade.TradeOfferId, trade.TradeId, trade.OfferState, trade.TradeStatus, trade.CreatedAt, trade.UpdatedAt);
    }

    public async Task<SteamTradeDto> UpdateTradeAttemptAsync(
        Guid orderId,
        Guid sellerId,
        string tradeOfferId,
        SteamOfferState offerState,
        string? tradeId,
        SteamTradeStatus? tradeStatus,
        long? timeUpdated = null,
        CancellationToken ct = default)
    {
        using var transaction = await unitOfWork.BeginTransactionAsync(ct);

        var order = await orderRepository.GetByIdWithDetailsAsync(orderId, ct);
        if (order == null)
            throw new BusinessException(BusinessErrorCodes.OrderNotFound, "Order not found.", 404);

        if (order.SellerId != sellerId)
            throw new BusinessException(BusinessErrorCodes.Forbidden, "You are not the seller of this order.", 403);

        var previousStatus = order.Status;

        var trade = order.SteamTrades.FirstOrDefault(t => t.TradeOfferId == tradeOfferId);
        if (trade == null)
            throw new BusinessException(BusinessErrorCodes.TradeNotFound, "Trade offer not found.", 404);

        if (trade.OfferState == offerState &&
            (string.IsNullOrWhiteSpace(tradeId) || trade.TradeId == tradeId) && 
            (tradeStatus == null || trade.TradeStatus == tradeStatus))
        {
            return new SteamTradeDto(trade.Id, trade.TradeOfferId, trade.TradeId, trade.OfferState, trade.TradeStatus, trade.CreatedAt, trade.UpdatedAt);
        }

        trade.OfferState = offerState;
        if (!string.IsNullOrWhiteSpace(tradeId))
            trade.TradeId = tradeId;

        trade.TradeStatus = tradeStatus ?? trade.TradeStatus;
        trade.UpdatedAt = DateTime.UtcNow;
        trade.SteamUpdatedAt = timeUpdated.HasValue ? DateTimeOffset.FromUnixTimeSeconds(timeUpdated.Value).UtcDateTime : trade.SteamUpdatedAt;

        // An open dispute freezes ALL order transitions, including Steam-event-driven ones
        // (seller cancels the offer, buyer declines, rollback). We still record the new trade
        // state as evidence, but the order status and any penalties are the admin's call —
        // otherwise a party could cancel in Steam and force a default penalty outcome that
        // silently overrides the pending support resolution.
        if (await disputeRepository.HasOpenDisputeAsync(orderId, ct))
        {
            await unitOfWork.SaveChangesAsync(ct);
            await transaction.CommitAsync(ct);
            return new SteamTradeDto(trade.Id, trade.TradeOfferId, trade.TradeId, trade.OfferState, trade.TradeStatus, trade.CreatedAt, trade.UpdatedAt);
        }

        var rollbackEventTime = timeUpdated.HasValue ? DateTimeOffset.FromUnixTimeSeconds(timeUpdated.Value).UtcDateTime : (DateTime?)null;
        if (await TryProcessTradeProtectionRollbackAsync(order, tradeStatus, transaction, ct, rollbackEventTime))
        {
            return new SteamTradeDto(trade.Id, trade.TradeOfferId, trade.TradeId, trade.OfferState, trade.TradeStatus, trade.CreatedAt, trade.UpdatedAt);
        }

        if (order.Status == OrderStatus.TradeSent && order.TradeSentAt.HasValue)
        {
            if (offerState == SteamOfferState.Declined) // Declined/withdrawn by buyer-side flow
            {
                var eventTime = timeUpdated.HasValue ? DateTimeOffset.FromUnixTimeSeconds(timeUpdated.Value).UtcDateTime : (DateTime?)null;
                await CancelOrderInternalAsync(orderId, order.BuyerId, ReasonBuyerDeclinedTrade, CancelledBy.Buyer, transaction, ct, false, eventTime);
                await transaction.CommitAsync(ct);
                EnqueueOrderNotification(orderId, OrderStatus.Cancelled);
                return new SteamTradeDto(trade.Id, trade.TradeOfferId, trade.TradeId, trade.OfferState, trade.TradeStatus, trade.CreatedAt, trade.UpdatedAt);
            }
            else if (offerState == SteamOfferState.Canceled && timeUpdated.HasValue) // Canceled by seller
            {
                var timeUpdatedUtc = DateTimeOffset.FromUnixTimeSeconds(timeUpdated.Value).UtcDateTime;
                if (timeUpdatedUtc < order.TradeSentAt.Value.AddHours(24))
                {
                    // Seller canceled early
                    await CancelOrderInternalAsync(orderId, null, ReasonSellerCanceledEarly, CancelledBy.System, transaction, ct, false, timeUpdatedUtc);
                }
                else
                {
                    // Seller canceled after 24h (buyer didn't accept)
                    await CancelOrderInternalAsync(orderId, sellerId, ReasonBuyerDidNotAcceptTrade, CancelledBy.Seller, transaction, ct, false, timeUpdatedUtc);
                }
                await transaction.CommitAsync(ct);
                EnqueueOrderNotification(orderId, OrderStatus.Cancelled);
                return new SteamTradeDto(trade.Id, trade.TradeOfferId, trade.TradeId, trade.OfferState, trade.TradeStatus, trade.CreatedAt, trade.UpdatedAt);
            }
        }

        var eventTimeForUpdate = timeUpdated.HasValue ? DateTimeOffset.FromUnixTimeSeconds(timeUpdated.Value).UtcDateTime : DateTime.UtcNow;
        var lifecycleUpdate = BuildTradeLifecycleUpdate(order, offerState, eventTimeForUpdate);

        try
        {
            await unitOfWork.SaveChangesAsync(ct);
            await orderRepository.ExecuteTradeLifecycleUpdateAsync(
                orderId,
                lifecycleUpdate.Status,
                lifecycleUpdate.TradeSentAt,
                lifecycleUpdate.TradeAcceptDeadline,
                lifecycleUpdate.AcceptedAt,
                ct);
            await transaction.CommitAsync(ct);

            // e.g. TradeSent → InEscrow (buyer accepted → notify seller).
            if (lifecycleUpdate.Status != previousStatus)
            {
                EnqueueOrderNotification(orderId, lifecycleUpdate.Status);
                ScheduleEscrowStuckCheckIfEntered(orderId, lifecycleUpdate);
            }
        }
        catch (Microsoft.EntityFrameworkCore.DbUpdateException)
        {
            // If two requests try to create the same trade attempt simultaneously,
            // the second one will hit a unique constraint violation on TradeOfferId.
            // We can safely ignore the insert failure and just fetch the inserted one.
            await transaction.RollbackAsync(ct);
            unitOfWork.ClearChangeTracker();
            
            trade = await orderRepository.GetByIdAsync(orderId, ct).ContinueWith(t => t.Result?.SteamTrades.FirstOrDefault(x => x.TradeOfferId == tradeOfferId));
            if (trade == null) throw; // Should not happen if it was a duplicate insert
        }

        return new SteamTradeDto(trade.Id, trade.TradeOfferId, trade.TradeId, trade.OfferState, trade.TradeStatus, trade.CreatedAt, trade.UpdatedAt);
    }

    private async Task<CancelledBy?> DetectRollbackInitiatorAsync(Order order, CancellationToken ct)
    {
        var sellerBlocked = await IsTradeUrlBlockedAsync(order.Seller?.TradeUrl, ct);
        var buyerBlocked = await IsTradeUrlBlockedAsync(order.Buyer?.TradeUrl, ct);

        if (sellerBlocked && !buyerBlocked)
            return CancelledBy.Seller;

        if (buyerBlocked && !sellerBlocked)
            return CancelledBy.Buyer;

        return null;
    }

    private async Task<bool> IsTradeUrlBlockedAsync(string? tradeUrl, CancellationToken ct)
    {
        if (!SteamTradeLink.TryParse(tradeUrl, out var parsedTradeLink, out _))
            return false;

        try
        {
            await steamGatewayClient.ValidateTradeLinkAsync(parsedTradeLink!, ct);
            return false;
        }
        catch (SteamGatewayException ex) when (ex.IsTradePartnerUnavailable)
        {
            return true;
        }
        catch (SteamGatewayException)
        {
            return false;
        }
    }

    private static bool IsAcceptedOrEscrowOfferState(SteamOfferState offerState)
        => offerState is SteamOfferState.Accepted or SteamOfferState.InEscrow;

    private static bool TryParseActorRole(string? raw, out TradeSyncActorRole? actorRole)
    {
        // No role (or "all") means the unified sync: the user may have purchases and sales
        // at the same time, so one request covers both sides and the role is derived per order.
        if (string.IsNullOrWhiteSpace(raw) || raw.Equals("all", StringComparison.OrdinalIgnoreCase))
        {
            actorRole = null;
            return true;
        }

        if (raw.Equals("seller", StringComparison.OrdinalIgnoreCase))
        {
            actorRole = TradeSyncActorRole.Seller;
            return true;
        }

        if (raw.Equals("buyer", StringComparison.OrdinalIgnoreCase))
        {
            actorRole = TradeSyncActorRole.Buyer;
            return true;
        }

        actorRole = null;
        return false;
    }

    private static TradeLifecycleUpdate BuildTradeLifecycleUpdate(Order order, SteamOfferState offerState, DateTime eventTime)
    {
        var status = order.Status;
        var tradeSentAt = order.TradeSentAt;
        var tradeAcceptDeadline = order.TradeAcceptDeadline;
        var acceptedAt = order.AcceptedAt;
        var now = eventTime;

        if (status is OrderStatus.Completed or OrderStatus.Cancelled)
        {
            return new TradeLifecycleUpdate(status, tradeSentAt, tradeAcceptDeadline, acceptedAt);
        }

        if (offerState == SteamOfferState.Active)
        {
            status = OrderStatus.TradeSent;
            tradeSentAt ??= now;
            tradeAcceptDeadline ??= now.AddHours(24);
            return new TradeLifecycleUpdate(status, tradeSentAt, tradeAcceptDeadline, acceptedAt);
        }

        if (IsAcceptedOrEscrowOfferState(offerState))
        {
            status = OrderStatus.InEscrow;
            acceptedAt ??= now;
            tradeAcceptDeadline = null;
            return new TradeLifecycleUpdate(status, tradeSentAt, tradeAcceptDeadline, acceptedAt);
        }

        if (RecoverableOfferStates.Contains(offerState) || offerState == SteamOfferState.CreatedNeedsConfirmation)
        {
            status = OrderStatus.Confirmed;
            tradeAcceptDeadline = null;
            return new TradeLifecycleUpdate(status, tradeSentAt, tradeAcceptDeadline, acceptedAt);
        }

        if (status == OrderStatus.TradeSent)
        {
            status = OrderStatus.Confirmed;
            tradeAcceptDeadline = null;
        }

        return new TradeLifecycleUpdate(status, tradeSentAt, tradeAcceptDeadline, acceptedAt);
    }

    private readonly record struct TradeLifecycleUpdate(
        OrderStatus Status,
        DateTime? TradeSentAt,
        DateTime? TradeAcceptDeadline,
        DateTime? AcceptedAt);

    public async Task ProcessTlsnTradeStatusProofAsync(
        string steamTradeId,
        SteamTradeStatus tradeStatus,
        string? steamIdOther,
        IReadOnlyCollection<string> transferredAssetIds,
        long? timeSettlementUnix,
        DateTimeOffset proofObservedAtUtc,
        CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(steamTradeId))
            throw new ArgumentException("Steam trade id is required.", nameof(steamTradeId));

        var order = await orderRepository.GetBySteamTradeIdWithDetailsAsync(steamTradeId, ct)
            ?? throw new BusinessException(BusinessErrorCodes.OrderNotFound, "Order for provided Steam trade was not found.", 404);

        if (tradeStatus != SteamTradeStatus.Complete)
        {
            await HandleNonFinalTlsnStatusAsync(order, steamTradeId, tradeStatus, ct);
            return;
        }

        if (string.IsNullOrWhiteSpace(steamIdOther) ||
            !string.Equals(order.Buyer.SteamId, steamIdOther, StringComparison.Ordinal))
        {
            throw new BusinessException(BusinessErrorCodes.TlsnSteamIdMismatch, "TLSN buyer steam id mismatch.", 403);
        }

        if (!HasMatchingListingAsset(order.Listing.SteamAssetId, transferredAssetIds))
        {
            throw new BusinessException(BusinessErrorCodes.TlsnAssetMismatch, "TLSN assets do not match listing asset.", 403);
        }

        // ── Ingestion vs. business logic ─────────────────────────────────────────
        // The proof already cleared the fraud checks above (right buyer, right asset), so it is
        // authentic EVIDENCE and the webhook caller records it as Accepted. From here we only
        // decide whether it also SETTLES the order (credits the seller). Anything that means
        // "valid, but don't settle right now" is a soft return — NOT a rejection — so a proof
        // run during a dispute still lands as evidence the admin can act on immediately, instead
        // of being thrown away with "settlement window not elapsed".

        if (order.Status == OrderStatus.Completed)
            return; // already settled — idempotent for repeated webhook callbacks

        if (order.Status != OrderStatus.InEscrow || !order.AcceptedAt.HasValue)
        {
            logger.LogInformation("TLSN proof for order {OrderId} recorded as evidence; order not in a settleable state ({Status}).", order.Id, order.Status);
            return;
        }

        if (!timeSettlementUnix.HasValue)
        {
            logger.LogInformation("TLSN proof for order {OrderId} recorded as evidence; settlement time missing, cannot auto-settle.", order.Id);
            return;
        }

        var settlementAtUtc = DateTimeOffset.FromUnixTimeSeconds(timeSettlementUnix.Value);
        var settlementReadyAtUtc = settlementAtUtc.Add(SettlementSafetyBuffer);
        var escrowEndsAt = CalculateEscrowEndsAt(order.AcceptedAt.Value);

        // Funds are not released until the settlement buffer AND the 7-day trade-protection hold
        // pass — that hold is what protects against a later rollback. Before then the proof is
        // still recorded as evidence; during a dispute the admin resolves it manually.
        if (proofObservedAtUtc < settlementReadyAtUtc || DateTime.UtcNow < escrowEndsAt)
        {
            logger.LogInformation("TLSN proof for order {OrderId} recorded as evidence; hold window not elapsed yet, not auto-settling.", order.Id);
            return;
        }

        using var transaction = await unitOfWork.BeginTransactionAsync(ct);

        order.Status = OrderStatus.Completed;
        order.HoldEndsAt = escrowEndsAt;

        if (order.Listing is not null)
            order.Listing.Status = ListingStatus.Sold;

        // The seller's escrow only ever held the net (price − commission), so release exactly that
        // and hand it to the seller. The commission stayed off the seller's books the whole time;
        // it's the platform's cut, now realized.
        var commission = order.CommissionAmount;
        var sellerProceeds = order.LockPrice - commission;

        if (order.Seller is not null)
        {
            order.Seller.FrozenBalance -= sellerProceeds;
            order.Seller.Balance += sellerProceeds;
        }

        // Record the seller's sale — their frozen funds just became spendable. The buyer's
        // Purchase entry was already posted at purchase time, so only the Sale (gross) plus the
        // platform Commission (the deducted fee) are added here. Both are shown to the seller so
        // the net (Sale − Commission) matches their actual balance delta.
        // Guarded by the idempotent "already Completed" check above, so this runs exactly once.
        var completedAt = DateTime.UtcNow;
        AddOrderTransaction(order.SellerId, order.LockPrice, FinancialTransactionType.Sale, order.Id, completedAt);
        if (commission > 0m)
            AddOrderTransaction(order.SellerId, commission, FinancialTransactionType.Commission, order.Id, completedAt);

        // A valid completion proof is cryptographic ground truth that the deal succeeded exactly
        // as listed (the proof already verified buyer SteamID + asset == listing + hold elapsed).
        // So it auto-resolves ANY open dispute on this order, not just StuckEscrow: if the buyer
        // had claimed "wrong item" or "not received", a passing proof contradicts that — and a
        // genuinely wrong item would have failed proof validation and never reached this point.
        var openDispute = await disputeRepository.GetOpenByOrderIdAsync(order.Id, ct);
        if (openDispute is not null)
        {
            openDispute.Status = DisputeStatus.Resolved;
            openDispute.Resolution = DisputeResolution.CompleteOrder;
            openDispute.ResolutionNote = "Auto-resolved: valid TLSN completion proof received — the trade settled as listed.";
            openDispute.ResolvedAt = completedAt;
            openDispute.UpdatedAt = completedAt;
        }

        var trade = order.SteamTrades
            .OrderByDescending(t => t.UpdatedAt)
            .FirstOrDefault(t => t.TradeId == steamTradeId);
        if (trade is not null)
        {
            trade.TradeStatus = tradeStatus;
            trade.UpdatedAt = DateTime.UtcNow;
        }

        await unitOfWork.SaveChangesAsync(ct);
        await transaction.CommitAsync(ct);

        // Escrow settled → deal closed. Notify both parties.
        EnqueueOrderNotification(order.Id, OrderStatus.Completed);
    }

    private async Task HandleNonFinalTlsnStatusAsync(Order order, string steamTradeId, SteamTradeStatus tradeStatus, CancellationToken ct)
    {
        using var transaction = await unitOfWork.BeginTransactionAsync(ct);

        var trade = order.SteamTrades
            .OrderByDescending(t => t.UpdatedAt)
            .FirstOrDefault(t => t.TradeId == steamTradeId)
            ?? order.SteamTrades.OrderByDescending(t => t.UpdatedAt).FirstOrDefault();

        if (trade is not null)
        {
            trade.TradeStatus = tradeStatus;
            trade.UpdatedAt = DateTime.UtcNow;

            if (await TryProcessTradeProtectionRollbackAsync(order, tradeStatus, transaction, ct))
                return;
        }

        await unitOfWork.SaveChangesAsync(ct);
        await transaction.CommitAsync(ct);
    }

    private async Task<bool> TryProcessTradeProtectionRollbackAsync(
        Order order,
        SteamTradeStatus? tradeStatus,
        Microsoft.EntityFrameworkCore.Storage.IDbContextTransaction transaction,
        CancellationToken ct,
        DateTime? eventTime = null)
    {
        if (tradeStatus != SteamTradeStatus.TradeProtectionRollback ||
            order.Status is not (OrderStatus.TradeSent or OrderStatus.InEscrow))
        {
            return false;
        }

        var rollbackInitiator = await DetectRollbackInitiatorAsync(order, ct);
        var rollbackReason = rollbackInitiator switch
        {
            CancelledBy.Seller => ReasonTradeRollbackBySeller,
            CancelledBy.Buyer => ReasonTradeRollbackByBuyer,
            _ => ReasonTradeRollbackUnknown,
        };
        var rollbackCancelledBy = rollbackInitiator switch
        {
            CancelledBy.Seller => CancelledBy.Seller,
            CancelledBy.Buyer => CancelledBy.Buyer,
            _ => CancelledBy.System,
        };

        await CancelOrderInternalAsync(order.Id, null, rollbackReason, rollbackCancelledBy, transaction, ct, false, eventTime);

        // Unknown initiator means nobody was penalized and nobody reviewed the case —
        // open a system dispute so support attributes the rollback manually.
        Guid? rollbackDisputeId = null;
        if (rollbackInitiator is null && !await disputeRepository.HasOpenDisputeAsync(order.Id, ct))
        {
            var dispute = new OrderDispute
            {
                Id = Guid.NewGuid(),
                OrderId = order.Id,
                OpenedByUserId = null,
                Reason = DisputeReason.RollbackFraud,
                Status = DisputeStatus.Open,
                Description = "Trade protection rollback detected, but the initiator could not be determined " +
                              "from trade-ban heuristics. Manual attribution required.",
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };
            disputeRepository.Add(dispute);
            await unitOfWork.SaveChangesAsync(ct);
            rollbackDisputeId = dispute.Id;
        }

        await transaction.CommitAsync(ct);
        EnqueueOrderNotification(order.Id, OrderStatus.Cancelled);
        if (rollbackDisputeId.HasValue)
            backgroundJobClient.Enqueue<INotificationJobs>(x => x.NotifyDisputeOpenedAsync(rollbackDisputeId.Value, CancellationToken.None));
        return true;
    }

    private static bool HasMatchingListingAsset(long listingSteamAssetId, IReadOnlyCollection<string> transferredAssetIds)
    {
        foreach (var assetId in transferredAssetIds)
        {
            if (long.TryParse(assetId, out var parsedAssetId) && parsedAssetId == listingSteamAssetId)
                return true;
        }

        return false;
    }

    public static DateTime CalculateEscrowEndsAt(DateTime acceptedAt)
    {
        var end = acceptedAt.AddDays(7);
        if (end.Minute > 0 || end.Second > 0 || end.Millisecond > 0)
        {
            end = end.Date.AddHours(end.Hour + 1);
        }

        end = end.Add(SettlementSafetyBuffer);

        return end;
    }

    internal static OrderDto MapToOrderDto(Order order, Guid currentUserId, OrderOptions options)
    {
        var isBuyer = order.BuyerId == currentUserId;

        var itemDto = new OrderItemDto(
            MarketHashName: order.Listing?.Item?.MarketHashName ?? string.Empty,
            Wear: order.Listing?.Item?.Wear,
            Float: order.Listing?.FloatValue);

        var partner = isBuyer ? order.Seller : order.Buyer;
        var partnerDto = new OrderParticipantDto(partner?.Id ?? Guid.Empty, partner?.Username ?? string.Empty, partner?.AvatarUrl);

        SteamTradeDto? activeTradeDto = null;
        if (order.SteamTrades?.Any() == true)
        {
            var latestTrade = order.SteamTrades.OrderByDescending(t => t.CreatedAt).First();
            activeTradeDto = new SteamTradeDto(
                TradeId: latestTrade.Id,
                TradeOfferId: latestTrade.TradeOfferId,
                SteamTradeId: latestTrade.TradeId,
                OfferState: latestTrade.OfferState,
                TradeStatus: latestTrade.TradeStatus,
                CreatedAt: latestTrade.CreatedAt,
                UpdatedAt: latestTrade.UpdatedAt);
        }

        DateTime? sendTradeDeadline = null;
        if (order.Status == OrderStatus.Confirmed && order.ConfirmedAt.HasValue)
        {
            sendTradeDeadline = order.ConfirmedAt.Value.AddHours(2);
            if (activeTradeDto?.OfferState == SteamOfferState.CreatedNeedsConfirmation)
            {
                var mobileDeadline = activeTradeDto.CreatedAt.AddHours(1);
                if (mobileDeadline > sendTradeDeadline)
                {
                    sendTradeDeadline = mobileDeadline;
                }
            }
        }

        DateTime? escrowEndsAt = null;
        if (order.AcceptedAt.HasValue)
        {
            escrowEndsAt = CalculateEscrowEndsAt(order.AcceptedAt.Value);
        }

        return new OrderDto(
            OrderId: order.Id,
            ListingId: order.ListingId,
            Role: isBuyer ? "Buyer" : "Seller",
            Status: order.Status,
            Price: order.LockPrice,
            CreatedAt: order.CreatedAt,
            ConfirmDeadline: order.ConfirmDeadline,
            SendTradeDeadline: sendTradeDeadline,
            TradeAcceptDeadline: order.TradeAcceptDeadline,
            EscrowEndsAt: escrowEndsAt,
            BuyerCancelableAt: sendTradeDeadline ?? order.CreatedAt.AddMinutes(options.BuyerCancelWindowMinutes),
            CancelledAtStatus: order.CancelledAtStatus,
            CancelledBy: order.CancelledBy?.ToString(),
            CancelReason: order.CancelReason,
            Partner: partnerDto,
            Item: itemDto,
            ActiveTrade: activeTradeDto);
    }
}
