import { LogOut, User, Package, ListOrdered, Tags, Shield, LifeBuoy } from 'lucide-react';
import type { PageKey } from '../types';
import { useTranslation } from 'react-i18next';

type UserDropdownProps = {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (page: PageKey) => void;
  onLogout: () => void;
  isAdmin?: boolean;
};

export function UserDropdown({ isOpen, onClose, onNavigate, onLogout, isAdmin = false }: UserDropdownProps) {
  const { t } = useTranslation();

  const handleNavigate = (page: PageKey) => {
    onNavigate(page);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="dropdown-menu glass-panel animate-fade-in">
      <button className="dropdown-item" onClick={() => handleNavigate('profile')}>
        <User size={16} /> {t('userDropdown.profile')}
      </button>
      <button className="dropdown-item" onClick={() => handleNavigate('inventory')}>
        <Package size={16} /> {t('userDropdown.inventory')}
      </button>
      <button className="dropdown-item" onClick={() => handleNavigate('my-listings')}>
        <Tags size={16} /> {t('userDropdown.myListings')}
      </button>
      <button className="dropdown-item" onClick={() => handleNavigate('orders')}>
        <ListOrdered size={16} /> {t('userDropdown.trades')}
      </button>
      <button className="dropdown-item" onClick={() => handleNavigate('support')}>
        <LifeBuoy size={16} /> {t('userDropdown.support')}
      </button>
      {isAdmin && (
        <>
          <div className="dropdown-divider" />
          <button className="dropdown-item" onClick={() => handleNavigate('admin')}>
            <Shield size={16} /> {t('userDropdown.admin')}
          </button>
        </>
      )}
      <div className="dropdown-divider" />
      <button className="dropdown-item danger" onClick={() => { onLogout(); onClose(); }}>
        <LogOut size={16} /> {t('userDropdown.signOut')}
      </button>
    </div>
  );
}
