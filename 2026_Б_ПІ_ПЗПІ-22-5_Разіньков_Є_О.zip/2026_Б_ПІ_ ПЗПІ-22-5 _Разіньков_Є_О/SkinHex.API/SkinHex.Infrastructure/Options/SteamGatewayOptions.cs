namespace SkinHex.Infrastructure.Options;

public sealed class SteamGatewayOptions
{
    public const string SectionName = "SteamGateway";

    public string BaseAddress { get; set; } = "http://localhost:5100";
    public int TimeoutSeconds { get; set; } = 20;
}
