﻿using System.Text.Json.Serialization;

namespace SkinHex.Infrastructure.Seed;

public class ByMykelCollection
{
    [JsonPropertyName("id")] public string Id { get; set; } = null!;
    [JsonPropertyName("name")] public string Name { get; set; } = null!;
    [JsonPropertyName("image")] public string? Image { get; set; }
}

public class ByMykelSkinNotGrouped
{
    [JsonPropertyName("id")] public string Id { get; set; } = null!;
    [JsonPropertyName("name")] public string Name { get; set; } = null!;
    [JsonPropertyName("market_hash_name")] public string MarketHashName { get; set; } = null!;

    [JsonPropertyName("weapon")] public ByMykelPropertyObj? Weapon { get; set; }
    [JsonPropertyName("category")] public ByMykelPropertyObj? Category { get; set; }
    [JsonPropertyName("wear")] public ByMykelPropertyObj? Wear { get; set; }
    [JsonPropertyName("rarity")] public ByMykelRarity? Rarity { get; set; }

    [JsonPropertyName("stattrak")] public bool StatTrak { get; set; }
    [JsonPropertyName("souvenir")] public bool Souvenir { get; set; }
    [JsonPropertyName("image")] public string? Image { get; set; }

    // Якщо колекції є у відповіді (іноді вони можуть бути приховані в цьому ендпоінті)
    [JsonPropertyName("collections")] public List<ByMykelPropertyObj>? Collections { get; set; }
}

// Універсальний клас для вкладених об'єктів типу { "id": "...", "name": "..." }
public class ByMykelPropertyObj
{
    [JsonPropertyName("name")] public string Name { get; set; } = null!;
}

public class ByMykelRarity
{
    [JsonPropertyName("name")] public string Name { get; set; } = null!;
    [JsonPropertyName("color")] public string Color { get; set; } = null!;
}
public class ByMykelWear
{
    [JsonPropertyName("name")] public string Name { get; set; } = null!; // "Field-Tested"
}

public class ByMykelCollectionRef
{
    [JsonPropertyName("name")] public string Name { get; set; } = null!;
}
