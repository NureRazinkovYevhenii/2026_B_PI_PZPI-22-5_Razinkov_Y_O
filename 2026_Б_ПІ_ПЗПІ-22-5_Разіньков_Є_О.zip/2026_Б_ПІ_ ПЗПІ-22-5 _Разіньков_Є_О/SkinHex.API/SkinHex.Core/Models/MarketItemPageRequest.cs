namespace SkinHex.Core.Models;

public sealed class MarketItemPageRequest
{
    /// <summary>Exact market hash name — identifies one specific exterior/variant, e.g. "StatTrak™ AK-47 | Nightwish (Field-Tested)".</summary>
    public string MarketHashName { get; set; } = string.Empty;

    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 24;

    public decimal? MinPrice { get; set; }
    public decimal? MaxPrice { get; set; }
    public double? MinFloat { get; set; }
    public double? MaxFloat { get; set; }
    public int? PaintSeed { get; set; }

    public SortOption SortBy { get; set; } = SortOption.PriceAsc;
}
