namespace SkinHex.Core.Interfaces.Services;

public record CreateInvoiceResult(string InvoiceId, string InvoiceUrl);

/// <summary>Minimum payable amount for a coin, relative to the custody (outcome) currency.</summary>
/// <param name="CurrencyFrom">The coin the user pays with (e.g. "usdttrc20").</param>
/// <param name="CurrencyTo">The custody/outcome currency (e.g. "usdtbsc").</param>
/// <param name="MinAmount">Minimum amount expressed in <paramref name="CurrencyFrom"/> units.</param>
/// <param name="FiatEquivalentUsd">Minimum amount expressed in USD, when NOWPayments returns it.</param>
public record NowPaymentsMinAmount(string CurrencyFrom, string CurrencyTo, decimal MinAmount, decimal? FiatEquivalentUsd);

/// <summary>Extended payment details fetched from GET /v1/payment/{id}, used to backfill the blockchain payin hash.</summary>
public record NowPaymentsPaymentDetails(decimal? PayAmount, string? PayinHash, string? PaymentStatus);

public interface INowPaymentsService
{
    Task<CreateInvoiceResult> CreateInvoiceAsync(decimal amountUsd, string orderId, string? payCurrency = null, CancellationToken ct = default);

    /// <summary>Fetches the minimum payment amount for <paramref name="currencyFrom"/> relative to <paramref name="currencyTo"/>.</summary>
    Task<NowPaymentsMinAmount> GetMinAmountAsync(string currencyFrom, string currencyTo, CancellationToken ct = default);

    /// <summary>Estimates how much <paramref name="currencyTo"/> a given <paramref name="amount"/> of <paramref name="currencyFrom"/> converts to.</summary>
    Task<decimal> GetEstimatedPriceAsync(decimal amount, string currencyFrom, string currencyTo, CancellationToken ct = default);

    /// <summary>Fetches the extended payment record (GET /v1/payment/{id}), including the blockchain payin hash.</summary>
    Task<NowPaymentsPaymentDetails> GetPaymentDetailsAsync(string paymentId, CancellationToken ct = default);

    bool VerifyIpnSignature(string rawBody, string signature);
}
