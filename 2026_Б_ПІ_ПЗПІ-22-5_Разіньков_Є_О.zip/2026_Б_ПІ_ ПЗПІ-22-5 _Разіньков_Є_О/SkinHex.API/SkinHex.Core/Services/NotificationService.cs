using System.Text.Json;
using Microsoft.Extensions.Logging;
using SkinHex.Core.Entities;
using SkinHex.Core.Interfaces.Repositories;
using SkinHex.Core.Interfaces.Services;
using SkinHex.Core.Models.Notifications;

namespace SkinHex.Core.Services;

public class NotificationService(
    INotificationRepository notificationRepository,
    IUnitOfWork unitOfWork,
    IRealtimeNotifier realtimeNotifier,
    ILogger<NotificationService> logger) : INotificationService
{
    private const int MaxPageSize = 100;

    // Matches ASP.NET Core / SignalR default wire format (camelCase) so the payload
    // shape is identical whether the client reads it from the hub or from the REST history.
    private static readonly JsonSerializerOptions PayloadJsonOptions = new(JsonSerializerDefaults.Web);

    public async Task<NotificationDto> NotifyAsync(Guid userId, NotificationType type, object payload, CancellationToken ct = default)
    {
        var notification = new Notification
        {
            Id = Guid.NewGuid(),
            UserId = userId,
            Type = type,
            Payload = JsonSerializer.Serialize(payload, payload.GetType(), PayloadJsonOptions),
            IsRead = false,
            CreatedAt = DateTime.UtcNow
        };

        await notificationRepository.AddAsync(notification, ct);
        await unitOfWork.SaveChangesAsync(ct);

        var dto = MapToDto(notification);
        await PushSafeAsync([userId], RealtimeEvents.Notification, dto, ct);
        return dto;
    }

    public Task<NotificationDto> NotifyItemSoldAsync(Order order, Listing listing, User buyer, CancellationToken ct = default)
    {
        var payload = new ItemSoldPayload(
            OrderId: order.Id,
            ListingId: listing.Id,
            MarketHashName: listing.Item?.MarketHashName ?? string.Empty,
            Wear: listing.Item?.Wear,
            Price: order.LockPrice,
            BuyerId: buyer.Id,
            BuyerUsername: buyer.Username,
            ConfirmDeadline: order.ConfirmDeadline);

        return NotifyAsync(order.SellerId, NotificationType.ItemSold, payload, ct);
    }

    public async Task<NotificationDto> NotifyOrderStatusChangedAsync(Guid recipientId, Order order, OrderStatus status, CancellationToken ct = default)
    {
        var role = recipientId == order.SellerId ? "seller" : "buyer";

        var payload = new OrderStatusChangedPayload(
            OrderId: order.Id,
            ListingId: order.ListingId,
            Status: status,
            Role: role,
            MarketHashName: order.Listing?.Item?.MarketHashName,
            CancelledBy: order.CancelledBy?.ToString(),
            CancelReason: order.CancelReason);

        var type = status switch
        {
            OrderStatus.Cancelled => NotificationType.OrderCancelled,
            OrderStatus.TradeSent => NotificationType.TradeOfferSent,
            OrderStatus.InEscrow => NotificationType.TradeOfferAccepted,
            OrderStatus.Completed => role == "seller" ? NotificationType.SaleCompleted : NotificationType.OrderStatusChanged,
            _ => NotificationType.OrderStatusChanged
        };

        var dto = await NotifyAsync(recipientId, type, payload, ct);
        await PushSafeAsync([recipientId], RealtimeEvents.OrderUpdated, payload, ct);
        return dto;
    }

    public Task<NotificationDto> NotifyDepositCompletedAsync(Guid userId, Guid depositId, decimal amount, string? payCurrency, CancellationToken ct = default)
    {
        var payload = new DepositCompletedPayload(depositId, amount, payCurrency);
        return NotifyAsync(userId, NotificationType.DepositCompleted, payload, ct);
    }

    public Task<NotificationDto> NotifyWithdrawalStatusAsync(Guid userId, Withdrawal withdrawal, CancellationToken ct = default)
    {
        var payload = new WithdrawalStatusPayload(
            WithdrawalId: withdrawal.Id,
            Status: withdrawal.Status.ToString(),
            Amount: withdrawal.AmountUsd,
            PayCurrency: withdrawal.PayCurrency,
            RejectionReason: withdrawal.RejectionReason);

        return NotifyAsync(userId, NotificationType.WithdrawalStatusChanged, payload, ct);
    }

    public Task PushBalanceUpdateAsync(User user, decimal delta, string reason, CancellationToken ct = default)
    {
        var payload = new BalanceChangedPayload(user.Balance, user.FrozenBalance, delta, reason);
        return PushSafeAsync([user.Id], RealtimeEvents.BalanceUpdated, payload, ct);
    }

    public async Task InvalidateCartListingAsync(Guid listingId, Guid? excludeUserId = null, CancellationToken ct = default)
    {
        var userIds = await notificationRepository.GetUserIdsWithListingInCartAsync(listingId, excludeUserId, ct);
        if (userIds.Count == 0)
            return;

        await PushSafeAsync(userIds, RealtimeEvents.CartItemUnavailable, new CartItemUnavailablePayload(listingId), ct);
    }

    public async Task<NotificationsPageResponse> GetNotificationsAsync(Guid userId, int limit, DateTime? before, CancellationToken ct = default)
    {
        limit = Math.Clamp(limit, 1, MaxPageSize);

        // Fetch one extra row to detect whether an older page exists.
        var rows = await notificationRepository.GetLatestAsync(userId, limit + 1, before, ct);
        var hasMore = rows.Count > limit;

        var items = rows
            .Take(limit)
            .Select(MapToDto)
            .ToList();

        var unreadCount = await notificationRepository.GetUnreadCountAsync(userId, ct);

        return new NotificationsPageResponse(items, unreadCount, hasMore);
    }

    public Task<int> GetUnreadCountAsync(Guid userId, CancellationToken ct = default)
        => notificationRepository.GetUnreadCountAsync(userId, ct);

    public Task<int> MarkReadAsync(Guid userId, IReadOnlyCollection<Guid> ids, CancellationToken ct = default)
        => ids.Count == 0
            ? Task.FromResult(0)
            : notificationRepository.MarkReadAsync(userId, ids, DateTime.UtcNow, ct);

    public Task<int> MarkAllReadAsync(Guid userId, CancellationToken ct = default)
        => notificationRepository.MarkAllReadAsync(userId, DateTime.UtcNow, ct);

    private async Task PushSafeAsync(IReadOnlyCollection<Guid> userIds, string eventName, object payload, CancellationToken ct)
    {
        try
        {
            await realtimeNotifier.SendToUsersAsync(userIds, eventName, payload, ct);
        }
        catch (Exception ex)
        {
            // Realtime delivery is best-effort: the notification is already persisted,
            // so the user will still see it via the REST history endpoint.
            logger.LogWarning(ex, "Failed to push realtime event {EventName} to {UserCount} user(s).", eventName, userIds.Count);
        }
    }

    private static NotificationDto MapToDto(Notification notification)
    {
        using var document = JsonDocument.Parse(notification.Payload);
        return new NotificationDto(
            Id: notification.Id,
            Type: notification.Type.ToString(),
            Payload: document.RootElement.Clone(),
            IsRead: notification.IsRead,
            CreatedAt: notification.CreatedAt,
            ReadAt: notification.ReadAt);
    }
}
