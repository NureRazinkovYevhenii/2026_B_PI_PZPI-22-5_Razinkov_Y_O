using System.Collections.Concurrent;
using System.Text.Json;
using Microsoft.Extensions.Options;
using SkinHex.Core.Models.Steam;
using SkinHex.SteamGateway.Options;
using StackExchange.Redis;

namespace SkinHex.SteamGateway.Steam;

public sealed class RedisSteamBotSessionProvider : ISteamBotSessionProvider
{
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

    private readonly ConcurrentDictionary<string, DateTimeOffset> _quarantinedUntil = new(StringComparer.OrdinalIgnoreCase);
    private readonly IDatabase _database;
    private readonly RedisOptions _options;
    private readonly RedisKey _sessionIndexKey;
    private readonly TimeSpan _quarantineDuration;
    private readonly TimeProvider _timeProvider;
    private readonly ILogger<RedisSteamBotSessionProvider> _logger;

    public RedisSteamBotSessionProvider(
        IConnectionMultiplexer connectionMultiplexer,
        IOptions<RedisOptions> options,
        IOptions<SteamGatewayOptions> gatewayOptions,
        TimeProvider timeProvider,
        ILogger<RedisSteamBotSessionProvider> logger)
    {
        _database = connectionMultiplexer.GetDatabase();
        _options = options.Value;
        _sessionIndexKey = $"{_options.SteamSessionsKey}:bots";
        _quarantineDuration = TimeSpan.FromMinutes(gatewayOptions.Value.BotQuarantineMinutes);
        _timeProvider = timeProvider;
        _logger = logger;
    }

    public async Task<SteamBotSession> GetAnyReadySessionAsync(
        CancellationToken cancellationToken = default)
    {
        var usernames = await _database.SetMembersAsync(_sessionIndexKey)
            .WaitAsync(cancellationToken);

        if (usernames.Length == 0)
        {
            throw new InvalidOperationException("Redis does not contain active Steam bot sessions.");
        }

        Random.Shared.Shuffle(usernames);

        var allQuarantined = true;
        foreach (var usernameValue in usernames)
        {
            var username = usernameValue.ToString();
            if (IsQuarantined(username))
            {
                continue;
            }

            allQuarantined = false;
            var session = await TryGetAsync(username, cancellationToken);
            if (session is not null)
            {
                return session;
            }

            await _database.SetRemoveAsync(_sessionIndexKey, usernameValue)
                .WaitAsync(cancellationToken);
        }

        throw new InvalidOperationException(
            allQuarantined
                ? "All Steam bot sessions are quarantined after Steam rate-limited/banned them."
                : "All Steam bot sessions in Redis are expired.");
    }

    public void Quarantine(string username, string reason)
    {
        if (string.IsNullOrWhiteSpace(username))
        {
            return;
        }

        var until = _timeProvider.GetUtcNow().Add(_quarantineDuration);
        _quarantinedUntil[username] = until;

        _logger.LogWarning(
            "Steam bot {Bot} was quarantined until {QuarantinedUntil:u}. Reason: {Reason}",
            username,
            until,
            reason);
    }

    private bool IsQuarantined(string username)
    {
        if (!_quarantinedUntil.TryGetValue(username, out var until))
        {
            return false;
        }

        if (until <= _timeProvider.GetUtcNow())
        {
            _quarantinedUntil.TryRemove(username, out _);
            return false;
        }

        return true;
    }

    private async Task<SteamBotSession?> TryGetAsync(
        string username,
        CancellationToken cancellationToken)
    {
        var value = await _database.StringGetAsync(GetSessionKey(username))
            .WaitAsync(cancellationToken);

        return value.IsNullOrEmpty
            ? null
            : JsonSerializer.Deserialize<SteamBotSession>(value.ToString(), JsonOptions);
    }

    private RedisKey GetSessionKey(string username) => $"{_options.SteamSessionsKey}:bot:{username}";
}
