using SkinHex.Core.Entities;

namespace SkinHex.Core.Interfaces.Services;

/// <summary>
/// Background dispatch for order notifications. Enqueued (not awaited) by OrderService after a
/// state transition commits, so notification persistence runs in its own scope/DbContext and can
/// never roll back or interfere with the order transaction.
/// </summary>
public interface INotificationJobs
{
    Task NotifyOrderTransitionAsync(Guid orderId, OrderStatus announcedStatus, CancellationToken ct);

    /// <summary>Notifies both order participants that a dispute was opened. Throws (and lets Hangfire
    /// retry) when the dispute row is not visible yet — it may be enqueued just before the commit.</summary>
    Task NotifyDisputeOpenedAsync(Guid disputeId, CancellationToken ct);
}
