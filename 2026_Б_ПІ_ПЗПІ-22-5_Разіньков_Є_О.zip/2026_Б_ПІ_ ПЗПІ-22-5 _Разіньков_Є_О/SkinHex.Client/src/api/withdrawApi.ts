import { API_BASE_URL } from '../config';
import type { DepositCurrency } from './depositApi';

export interface WithdrawalCurrenciesResponse {
  minWithdrawalUsd: number;
  withdrawalFeePercent: number;
  currencies: DepositCurrency[];
}

export interface WithdrawalEstimate {
  amountUsd: number;
  platformFeePercent: number;
  platformFeeUsd: number;
  estNetworkFeeUsd: number | null;
  estimatedReceiveUsd: number;
  payCurrency: string;
}

export interface WithdrawalDto {
  id: string;
  amountUsd: number;
  platformFeeUsd: number;
  payoutAmountUsd: number;
  payCurrency: string;
  payoutAddress: string;
  status: string;
  rejectionReason: string | null;
  createdAt: string;
  processedAt: string | null;
}

export interface CreateWithdrawalRequest {
  amountUsd: number;
  payCurrency: string;
  address: string;
  extraId?: string | null;
}

const authHeaders = (): Record<string, string> => {
  const token = localStorage.getItem('jwt_token');
  return {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
};

async function readError(response: Response, fallback: string): Promise<string> {
  try {
    const text = await response.text();
    if (!text) return fallback;
    try {
      const json = JSON.parse(text);
      return json.detail ?? json.message ?? json.title ?? text;
    } catch {
      return text;
    }
  } catch {
    return fallback;
  }
}

export const getWithdrawalCurrencies = async (): Promise<WithdrawalCurrenciesResponse> => {
  const response = await fetch(`${API_BASE_URL}/withdrawals/currencies`, { headers: authHeaders() });
  if (!response.ok) throw new Error(await readError(response, 'Failed to load currencies'));
  return response.json();
};

export const getWithdrawalEstimate = async (
  amountUsd: number,
  payCurrency: string,
  signal?: AbortSignal,
): Promise<WithdrawalEstimate> => {
  const params = new URLSearchParams({ amountUsd: String(amountUsd), payCurrency });
  const response = await fetch(`${API_BASE_URL}/withdrawals/estimate?${params}`, { headers: authHeaders(), signal });
  if (!response.ok) throw new Error(await readError(response, 'Failed to fetch estimate'));
  return response.json();
};

export const createWithdrawal = async (request: CreateWithdrawalRequest): Promise<WithdrawalDto> => {
  const response = await fetch(`${API_BASE_URL}/withdrawals`, {
    method: 'POST',
    headers: authHeaders(),
    body: JSON.stringify(request),
  });
  if (!response.ok) throw new Error(await readError(response, 'Failed to create withdrawal'));
  return response.json();
};

export const getMyWithdrawals = async (): Promise<WithdrawalDto[]> => {
  const response = await fetch(`${API_BASE_URL}/withdrawals/my`, { headers: authHeaders() });
  if (!response.ok) throw new Error(await readError(response, 'Failed to load withdrawals'));
  return response.json();
};
