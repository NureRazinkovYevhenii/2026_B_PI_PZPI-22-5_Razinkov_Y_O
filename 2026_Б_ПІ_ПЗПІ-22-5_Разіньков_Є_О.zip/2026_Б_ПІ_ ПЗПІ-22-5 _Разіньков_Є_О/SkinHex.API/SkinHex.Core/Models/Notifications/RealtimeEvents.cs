namespace SkinHex.Core.Models.Notifications;

/// <summary>
/// Client-side SignalR event names. The frontend subscribes to these on the notifications hub.
/// "Notification" carries a persisted <see cref="NotificationDto"/> envelope; the rest are
/// ephemeral state-sync events that are not stored in the database.
/// </summary>
public static class RealtimeEvents
{
    /// <summary>Persisted notification envelope (NotificationDto).</summary>
    public const string Notification = "Notification";

    /// <summary>Ephemeral: user's balance/frozen balance changed (BalanceChangedPayload).</summary>
    public const string BalanceUpdated = "BalanceUpdated";

    /// <summary>Ephemeral: a listing in the user's cart is no longer available (CartItemUnavailablePayload).</summary>
    public const string CartItemUnavailable = "CartItemUnavailable";

    /// <summary>Ephemeral: an order the user participates in changed state (OrderStatusChangedPayload).</summary>
    public const string OrderUpdated = "OrderUpdated";
}
