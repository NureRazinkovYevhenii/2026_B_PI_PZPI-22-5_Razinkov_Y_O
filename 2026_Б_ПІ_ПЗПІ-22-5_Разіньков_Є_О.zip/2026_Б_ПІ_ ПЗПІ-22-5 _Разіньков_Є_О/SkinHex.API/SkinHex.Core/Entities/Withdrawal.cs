namespace SkinHex.Core.Entities;

public enum WithdrawalStatus
{
    Pending = 0,      // Awaiting admin approval
    Processing = 1,   // Payout created at NOWPayments, in flight
    Completed = 2,    // Payout finished
    Rejected = 3,     // Admin rejected — balance refunded
    Failed = 4        // Payout failed/expired at NOWPayments — balance refunded
}

public class Withdrawal
{
    public Guid Id { get; set; }
    public Guid UserId { get; set; }
    public Guid TransactionId { get; set; }

    /// <summary>Gross amount debited from the user's balance up front.</summary>
    public decimal AmountUsd { get; set; }

    /// <summary>Platform fee kept by us (AmountUsd * WithdrawalFeePercent).</summary>
    public decimal PlatformFeeUsd { get; set; }

    /// <summary>Amount actually sent to the payout (AmountUsd - PlatformFeeUsd). Stablecoin ≈ 1:1 USD.</summary>
    public decimal PayoutAmountUsd { get; set; }

    public string PayCurrency { get; set; } = string.Empty;
    public string PayoutAddress { get; set; } = string.Empty;

    /// <summary>Optional memo/tag for networks that need one (TON, SOL, etc.).</summary>
    public string? PayoutExtraId { get; set; }

    public WithdrawalStatus Status { get; set; } = WithdrawalStatus.Pending;

    public string? NowPaymentsPayoutId { get; set; }
    public string? NowPaymentsBatchId { get; set; }

    /// <summary>Blockchain transaction hash of the outgoing payout to the user's wallet (NOWPayments "hash").</summary>
    public string? PayoutTxHash { get; set; }

    public string? RejectionReason { get; set; }
    public Guid? ProcessedByAdminId { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? ProcessedAt { get; set; }

    public User User { get; set; } = null!;
    public FinancialTransaction Transaction { get; set; } = null!;
}
