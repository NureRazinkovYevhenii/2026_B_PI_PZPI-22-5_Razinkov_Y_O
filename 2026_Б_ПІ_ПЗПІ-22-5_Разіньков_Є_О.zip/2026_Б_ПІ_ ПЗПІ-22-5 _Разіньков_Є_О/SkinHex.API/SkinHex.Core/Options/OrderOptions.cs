namespace SkinHex.Core.Options;

public class OrderOptions
{
    public int SellerConfirmWindowHours { get; set; } = 12;
    public int BuyerCancelWindowMinutes { get; set; } = 30;
    public int AutoCancelPollIntervalSeconds { get; set; } = 60;
}
