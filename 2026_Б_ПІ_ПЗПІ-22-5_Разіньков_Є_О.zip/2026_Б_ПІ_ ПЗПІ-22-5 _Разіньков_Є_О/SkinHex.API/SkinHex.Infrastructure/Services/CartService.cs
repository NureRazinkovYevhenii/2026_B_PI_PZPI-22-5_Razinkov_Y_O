using Microsoft.EntityFrameworkCore;
using SkinHex.Core.Entities;
using SkinHex.Core.Interfaces;
using SkinHex.Core.Models.Cart;

namespace SkinHex.Infrastructure.Services;

public class CartService : ICartService
{
    private readonly SkinHexDbContext _context;

    public CartService(SkinHexDbContext context)
    {
        _context = context;
    }

    public async Task<List<CartItemDto>> GetCartAsync(Guid userId)
    {
        var cartItems = await _context.CartItems
            .Include(c => c.Listing)
                .ThenInclude(l => l.Item)
            .Where(c => c.UserId == userId)
            .OrderByDescending(c => c.AddedAt)
            .Select(c => new CartItemDto
            {
                Id = c.Id,
                ListingId = c.ListingId,
                Price = c.Listing.Price,
                MarketHashName = c.Listing.Item.MarketHashName,
                ItemImageHash = c.Listing.Item.ImageHash,
                FloatValue = c.Listing.FloatValue,
                PaintSeed = c.Listing.PaintSeed,
                IsAvailable = c.Listing.Status == ListingStatus.Active,
                AddedAt = c.AddedAt
            })
            .ToListAsync();

        return cartItems;
    }

    public async Task<CartItemDto> AddToCartAsync(Guid userId, Guid listingId)
    {
        // 1. Перевіряємо існування лота
        var listing = await _context.Listings
            .Include(l => l.Item)
            .FirstOrDefaultAsync(l => l.Id == listingId);

        if (listing == null)
            throw new Exception("Listing not found.");

        if (listing.SellerId == userId)
            throw new Exception("You cannot add your own listing to the cart.");

        // 2. Перевіряємо, чи немає вже в кошику
        var existingItem = await _context.CartItems
            .FirstOrDefaultAsync(c => c.UserId == userId && c.ListingId == listingId);

        if (existingItem != null)
            throw new Exception("Listing is already in the cart.");

        // 3. Додаємо
        var cartItem = new CartItem
        {
            Id = Guid.NewGuid(),
            UserId = userId,
            ListingId = listingId,
            AddedAt = DateTimeOffset.UtcNow
        };

        _context.CartItems.Add(cartItem);
        await _context.SaveChangesAsync();

        return new CartItemDto
        {
            Id = cartItem.Id,
            ListingId = listing.Id,
            Price = listing.Price,
            MarketHashName = listing.Item.MarketHashName,
            ItemImageHash = listing.Item.ImageHash,
            FloatValue = listing.FloatValue,
            PaintSeed = listing.PaintSeed,
            IsAvailable = listing.Status == ListingStatus.Active,
            AddedAt = cartItem.AddedAt
        };
    }

    public async Task RemoveFromCartAsync(Guid userId, Guid cartItemId)
    {
        var cartItem = await _context.CartItems
            .FirstOrDefaultAsync(c => c.Id == cartItemId && c.UserId == userId);

        if (cartItem != null)
        {
            _context.CartItems.Remove(cartItem);
            await _context.SaveChangesAsync();
        }
    }

    public async Task ClearCartAsync(Guid userId)
    {
        var cartItems = await _context.CartItems
            .Where(c => c.UserId == userId)
            .ToListAsync();

        if (cartItems.Any())
        {
            _context.CartItems.RemoveRange(cartItems);
            await _context.SaveChangesAsync();
        }
    }
}
