using Microsoft.EntityFrameworkCore;
using SkinHex.Core.Entities;
using SkinHex.Core.Interfaces;

namespace SkinHex.Infrastructure.Repositories;

public sealed class UserRepository : IUserRepository
{
    private readonly SkinHexDbContext _dbContext;

    public UserRepository(SkinHexDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public Task<User?> GetByIdAsync(Guid id, CancellationToken ct)
    {
        return _dbContext.Users.FirstOrDefaultAsync(x => x.Id == id, ct);
    }

    public Task<User?> GetBySteamIdAsync(string steamId, CancellationToken ct)
    {
        return _dbContext.Users.FirstOrDefaultAsync(x => x.SteamId == steamId, ct);
    }

    public async Task AddAsync(User user, CancellationToken ct)
    {
        await _dbContext.Users.AddAsync(user, ct);
    }

}
