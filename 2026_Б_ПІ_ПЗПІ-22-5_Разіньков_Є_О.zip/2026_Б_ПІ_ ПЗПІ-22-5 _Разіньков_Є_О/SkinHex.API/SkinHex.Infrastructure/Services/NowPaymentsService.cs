using System.Buffers;
using System.Globalization;
using System.Net.Http.Json;
using System.Security.Cryptography;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SkinHex.Core.Interfaces.Services;
using SkinHex.Core.Options;

namespace SkinHex.Infrastructure.Services;

public class NowPaymentsService : INowPaymentsService
{
    private readonly HttpClient _httpClient;
    private readonly NowPaymentsOptions _options;
    private readonly ILogger<NowPaymentsService> _logger;

    public NowPaymentsService(HttpClient httpClient, IOptions<NowPaymentsOptions> options, ILogger<NowPaymentsService> logger)
    {
        _httpClient = httpClient;
        _options = options.Value;
        _logger = logger;
        _httpClient.BaseAddress = new Uri(_options.BaseUrl);
        _httpClient.DefaultRequestHeaders.Add("x-api-key", _options.ApiKey);
    }

    public async Task<CreateInvoiceResult> CreateInvoiceAsync(decimal amountUsd, string orderId, string? payCurrency = null, CancellationToken ct = default)
    {
        var requestBody = new Dictionary<string, object?>
        {
            ["price_amount"] = amountUsd,
            ["price_currency"] = "usd",
            ["order_id"] = orderId,
            ["ipn_callback_url"] = _options.IpnCallbackUrl,
            ["success_url"] = _options.SuccessUrl
        };

        // When the user has already picked a coin on our side, lock the hosted invoice to it.
        if (!string.IsNullOrWhiteSpace(payCurrency))
        {
            requestBody["pay_currency"] = payCurrency;
        }

        var response = await _httpClient.PostAsJsonAsync("/v1/invoice", requestBody, ct);
        response.EnsureSuccessStatusCode();

        var responseString = await response.Content.ReadAsStringAsync(ct);
        using var jsonDocument = JsonDocument.Parse(responseString);
        var root = jsonDocument.RootElement;

        var id = root.GetProperty("id").GetString();
        var invoiceUrl = root.GetProperty("invoice_url").GetString();

        return new CreateInvoiceResult(id!, invoiceUrl!);
    }

    public async Task<NowPaymentsMinAmount> GetMinAmountAsync(string currencyFrom, string currencyTo, CancellationToken ct = default)
    {
        var url = $"/v1/min-amount?currency_from={Uri.EscapeDataString(currencyFrom)}"
                + $"&currency_to={Uri.EscapeDataString(currencyTo)}"
                + "&fiat_equivalent=usd";

        var response = await _httpClient.GetAsync(url, ct);
        response.EnsureSuccessStatusCode();

        var responseString = await response.Content.ReadAsStringAsync(ct);
        using var jsonDocument = JsonDocument.Parse(responseString);
        var root = jsonDocument.RootElement;

        var minAmount = ReadDecimal(root, "min_amount") ?? 0m;
        var fiatEquivalent = ReadDecimal(root, "fiat_equivalent");

        return new NowPaymentsMinAmount(currencyFrom, currencyTo, minAmount, fiatEquivalent);
    }

    public async Task<decimal> GetEstimatedPriceAsync(decimal amount, string currencyFrom, string currencyTo, CancellationToken ct = default)
    {
        var url = $"/v1/estimate?amount={amount.ToString(CultureInfo.InvariantCulture)}"
                + $"&currency_from={Uri.EscapeDataString(currencyFrom)}"
                + $"&currency_to={Uri.EscapeDataString(currencyTo)}";

        var response = await _httpClient.GetAsync(url, ct);
        response.EnsureSuccessStatusCode();

        var responseString = await response.Content.ReadAsStringAsync(ct);
        using var jsonDocument = JsonDocument.Parse(responseString);
        var root = jsonDocument.RootElement;

        return ReadDecimal(root, "estimated_amount") ?? 0m;
    }

    public async Task<NowPaymentsPaymentDetails> GetPaymentDetailsAsync(string paymentId, CancellationToken ct = default)
    {
        var response = await _httpClient.GetAsync($"/v1/payment/{Uri.EscapeDataString(paymentId)}", ct);
        response.EnsureSuccessStatusCode();

        var responseString = await response.Content.ReadAsStringAsync(ct);
        using var jsonDocument = JsonDocument.Parse(responseString);
        var root = jsonDocument.RootElement;

        var payAmount = ReadDecimal(root, "pay_amount") ?? ReadDecimal(root, "actually_paid");
        var payinHash = root.TryGetProperty("payin_hash", out var hashElement) && hashElement.ValueKind == JsonValueKind.String
            ? hashElement.GetString()
            : null;
        var paymentStatus = root.TryGetProperty("payment_status", out var statusElement)
            ? statusElement.GetString()
            : null;

        return new NowPaymentsPaymentDetails(payAmount, payinHash, paymentStatus);
    }

    public bool VerifyIpnSignature(string rawBody, string signature)
    {
        if (string.IsNullOrWhiteSpace(rawBody) || string.IsNullOrWhiteSpace(signature))
            return false;

        try
        {
            // NOWPayments signs the payload with keys sorted recursively at every level and numbers /
            // nested objects preserved as-is. Re-create that exact JSON so our HMAC matches theirs.
            using var jsonDocument = JsonDocument.Parse(rawBody);
            var sortedJson = Canonicalize(jsonDocument.RootElement);

            // Compute HMAC-SHA512
            var keyBytes = Encoding.UTF8.GetBytes(_options.IpnSecret);
            var messageBytes = Encoding.UTF8.GetBytes(sortedJson);

            using var hmac = new HMACSHA512(keyBytes);
            var hashBytes = hmac.ComputeHash(messageBytes);

            var computedSignature = BitConverter.ToString(hashBytes).Replace("-", "").ToLowerInvariant();

            var match = computedSignature == signature.ToLowerInvariant();
            if (!match)
                _logger.LogWarning("IPN signature mismatch (payload keys: {Keys})", sortedJson.Length);

            return match;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "IPN signature verification threw");
            return false;
        }
    }

    /// <summary>
    /// Rebuilds the canonical JSON NOWPayments signs: object keys sorted (ordinal) at every nesting
    /// level, arrays kept in order, numbers written verbatim (no decimal reformatting), matching the
    /// output of their recursive sort + JSON.stringify.
    /// </summary>
    private static string Canonicalize(JsonElement root)
    {
        var buffer = new ArrayBufferWriter<byte>();
        using (var writer = new Utf8JsonWriter(buffer, new JsonWriterOptions { Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping }))
        {
            WriteSorted(writer, root);
        }
        return Encoding.UTF8.GetString(buffer.WrittenSpan);
    }

    private static void WriteSorted(Utf8JsonWriter writer, JsonElement element)
    {
        switch (element.ValueKind)
        {
            case JsonValueKind.Object:
                writer.WriteStartObject();
                foreach (var property in element.EnumerateObject().OrderBy(p => p.Name, StringComparer.Ordinal))
                {
                    writer.WritePropertyName(property.Name);
                    WriteSorted(writer, property.Value);
                }
                writer.WriteEndObject();
                break;
            case JsonValueKind.Array:
                writer.WriteStartArray();
                foreach (var item in element.EnumerateArray())
                    WriteSorted(writer, item);
                writer.WriteEndArray();
                break;
            case JsonValueKind.Number:
                // Verbatim so 5.05 / 0 / big ints keep their on-wire form (== what NOWPayments signed).
                writer.WriteRawValue(element.GetRawText(), skipInputValidation: true);
                break;
            case JsonValueKind.String:
                writer.WriteStringValue(element.GetString());
                break;
            case JsonValueKind.True:
            case JsonValueKind.False:
                writer.WriteBooleanValue(element.GetBoolean());
                break;
            default:
                writer.WriteNullValue();
                break;
        }
    }

    /// <summary>Reads a decimal that NOWPayments may return either as a JSON number or a stringified number.</summary>
    private static decimal? ReadDecimal(JsonElement root, string propertyName)
    {
        if (!root.TryGetProperty(propertyName, out var element))
            return null;

        return element.ValueKind switch
        {
            JsonValueKind.Number => element.GetDecimal(),
            JsonValueKind.String when decimal.TryParse(element.GetString(), NumberStyles.Any, CultureInfo.InvariantCulture, out var parsed) => parsed,
            _ => null
        };
    }
}
