import { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import type { AuthorizedFetch } from '../../types';
import {
  fetchDispute,
  fetchDisputes,
  resolveDispute,
  takeDisputeUnderReview,
  type AdminDisputeDetail,
  type AdminDisputeListItem,
  type DisputeResolution,
} from '../../api/adminApi';
import { formatDateTime, formatMoney, IdCell, Pager, shortId, StateBlock, StatusBadge } from './adminShared';

type Props = { authorizedFetch: AuthorizedFetch };

const PAGE_SIZE = 20;
const STATUS_OPTIONS = ['', 'Open', 'UnderReview', 'Resolved', 'Rejected'];
const REASON_OPTIONS = ['', 'OfferNotReceived', 'WrongItemReceived', 'RollbackFraud', 'StuckEscrow', 'PenaltyAppeal', 'UnverifiedBuyerFault', 'Other'];

/** Money outcome per resolution, so the admin sees exactly what a click will move. */
const RESOLUTIONS: Array<{ value: DisputeResolution; hintKey: string }> = [
  { value: 'RefundBuyer', hintKey: 'admin.disputes.hints.RefundBuyer' },
  { value: 'CompleteOrder', hintKey: 'admin.disputes.hints.CompleteOrder' },
  { value: 'ApplyBuyerPenalty', hintKey: 'admin.disputes.hints.ApplyBuyerPenalty' },
  { value: 'ReverseBuyerPenalty', hintKey: 'admin.disputes.hints.ReverseBuyerPenalty' },
  { value: 'NoAction', hintKey: 'admin.disputes.hints.NoAction' },
];

export function AdminDisputes({ authorizedFetch }: Props) {
  const { t } = useTranslation();
  const [status, setStatus] = useState('Open');
  const [reason, setReason] = useState('');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [items, setItems] = useState<AdminDisputeListItem[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await fetchDisputes(authorizedFetch, { status, reason, search: search.trim(), page, pageSize: PAGE_SIZE });
      setItems(result.items);
      setTotalCount(result.totalCount);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load disputes');
    } finally {
      setLoading(false);
    }
  }, [authorizedFetch, status, reason, search, page]);

  useEffect(() => {
    void load();
  }, [load]);

  const onSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1);
    void load();
  };

  return (
    <div>
      <form className="admin-toolbar" onSubmit={onSearchSubmit}>
        <input
          className="admin-input"
          placeholder={t('admin.disputes.searchPlaceholder')}
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <select className="admin-select" value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }}>
          {STATUS_OPTIONS.map((s) => (
            <option key={s} value={s}>{s === '' ? t('admin.disputes.allStatuses') : s}</option>
          ))}
        </select>
        <select className="admin-select" value={reason} onChange={(e) => { setReason(e.target.value); setPage(1); }}>
          {REASON_OPTIONS.map((r) => (
            <option key={r} value={r}>{r === '' ? t('admin.disputes.allReasons') : r}</option>
          ))}
        </select>
        <button className="primary-button" type="submit">{t('admin.search')}</button>
      </form>

      {error ? (
        <StateBlock><strong>{t('admin.error')}</strong><p>{error}</p></StateBlock>
      ) : loading ? (
        <StateBlock><strong>{t('admin.loading')}</strong></StateBlock>
      ) : items.length === 0 ? (
        <StateBlock><strong>{t('admin.disputes.none')}</strong></StateBlock>
      ) : (
        <div className="admin-table-wrap">
          <table className="admin-table">
            <thead>
              <tr>
                <th>{t('admin.id')}</th>
                <th>{t('admin.disputes.reason')}</th>
                <th>{t('admin.disputes.openedBy')}</th>
                <th>{t('admin.disputes.order')}</th>
                <th>{t('admin.disputes.price')}</th>
                <th>{t('admin.disputes.status')}</th>
                <th>{t('admin.disputes.updated')}</th>
              </tr>
            </thead>
            <tbody>
              {items.map((dispute) => (
                <tr key={dispute.id} className="admin-row" onClick={() => setSelectedId(dispute.id)}>
                  <td><IdCell id={dispute.id} /></td>
                  <td style={{ fontWeight: 600, color: 'var(--text-h)' }}>
                    {dispute.reason}
                    {dispute.frozenPenaltyAmount != null && (
                      <span className="admin-order-tag">{formatMoney(dispute.frozenPenaltyAmount)} frozen</span>
                    )}
                  </td>
                  <td>{dispute.openedByUsername ?? t('admin.disputes.system')}</td>
                  <td>
                    <span className="admin-order-tag">#{shortId(dispute.orderId)}</span>{' '}
                    <StatusBadge status={dispute.orderStatus} />
                  </td>
                  <td>{formatMoney(dispute.orderPrice)}</td>
                  <td><StatusBadge status={dispute.status} /></td>
                  <td style={{ color: 'var(--text-muted)', fontSize: 13 }}>{formatDateTime(dispute.updatedAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Pager page={page} pageSize={PAGE_SIZE} totalCount={totalCount} onPage={setPage} />

      {selectedId && (
        <DisputeDetailModal
          authorizedFetch={authorizedFetch}
          disputeId={selectedId}
          onClose={() => setSelectedId(null)}
          onChanged={() => void load()}
        />
      )}
    </div>
  );
}

type ModalProps = {
  authorizedFetch: AuthorizedFetch;
  disputeId: string;
  onClose: () => void;
  onChanged: () => void;
};

function DisputeDetailModal({ authorizedFetch, disputeId, onClose, onChanged }: ModalProps) {
  const { t } = useTranslation();
  const [detail, setDetail] = useState<AdminDisputeDetail | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);
  const [resolution, setResolution] = useState<DisputeResolution>('RefundBuyer');
  const [note, setNote] = useState('');

  const reload = useCallback(async () => {
    try {
      setDetail(await fetchDispute(authorizedFetch, disputeId));
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load dispute');
    }
  }, [authorizedFetch, disputeId]);

  useEffect(() => {
    void reload();
  }, [reload]);

  const isOpen = detail?.dispute.status === 'Open' || detail?.dispute.status === 'UnderReview';

  const onTakeReview = async () => {
    setBusy(true);
    setActionError(null);
    try {
      await takeDisputeUnderReview(authorizedFetch, disputeId);
      await reload();
      onChanged();
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Action failed');
    } finally {
      setBusy(false);
    }
  };

  const onResolve = async () => {
    setBusy(true);
    setActionError(null);
    try {
      await resolveDispute(authorizedFetch, disputeId, resolution, note.trim());
      await reload();
      onChanged();
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Resolution failed');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="admin-modal-overlay" onClick={onClose}>
      <div className="admin-modal glass-panel" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 860 }}>
        <div className="admin-modal-head">
          <div>
            <h3>{t('admin.disputes.detailTitle')} — {detail?.dispute.reason ?? ''}</h3>
            <IdCell id={disputeId} />
          </div>
          <button className="admin-modal-close" onClick={onClose} aria-label="Close">✕</button>
        </div>

        {error ? (
          <StateBlock><strong>{error}</strong></StateBlock>
        ) : !detail ? (
          <StateBlock><strong>{t('admin.loading')}</strong></StateBlock>
        ) : (
          <div className="admin-modal-body">
            <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap', marginBottom: 12 }}>
              <StatusBadge status={detail.dispute.status} />
              <span className="admin-chip">{detail.dispute.reason}</span>
              <span className="admin-chip">order #{shortId(detail.order.orderId)} · <StatusBadge status={detail.order.status} /></span>
              <span className="admin-chip">{formatMoney(detail.order.lockPrice)}</span>
              {detail.dispute.frozenPenaltyAmount != null && (
                <span className="admin-chip" style={{ color: '#fbbf24' }}>
                  {t('admin.disputes.frozenPenalty')}: {formatMoney(detail.dispute.frozenPenaltyAmount)}
                </span>
              )}
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 16, fontSize: 13 }}>
              <div className="glass-panel" style={{ padding: 12, borderRadius: 8 }}>
                <strong>{t('admin.disputes.buyer')}</strong>: {detail.order.buyerUsername} <IdCell id={detail.order.buyerId} />
              </div>
              <div className="glass-panel" style={{ padding: 12, borderRadius: 8 }}>
                <strong>{t('admin.disputes.seller')}</strong>: {detail.order.sellerUsername} <IdCell id={detail.order.sellerId} />
              </div>
            </div>

            <div className="glass-panel" style={{ padding: 12, borderRadius: 8, marginBottom: 16, fontSize: 13 }}>
              <div style={{ color: 'var(--text-muted)', marginBottom: 4 }}>
                {t('admin.disputes.openedBy')}: {detail.dispute.openedByUserId
                  ? (detail.dispute.openedByUserId === detail.order.buyerId ? detail.order.buyerUsername : detail.order.sellerUsername)
                  : t('admin.disputes.system')} · {formatDateTime(detail.dispute.createdAt)}
              </div>
              <div style={{ whiteSpace: 'pre-wrap' }}>{detail.dispute.description}</div>
              {detail.order.marketHashName && (
                <div style={{ marginTop: 8, color: 'var(--text-muted)' }}>
                  {detail.order.marketHashName} · asset {detail.order.listingAssetId}
                  {detail.order.cancelReason && <> · {detail.order.cancelledBy}: {detail.order.cancelReason}</>}
                </div>
              )}
            </div>

            {/* Evidence: trades with buyer corroboration */}
            <h4 style={{ margin: '0 0 8px' }}>{t('admin.disputes.trades')}</h4>
            {detail.trades.length === 0 ? (
              <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>{t('admin.disputes.noTrades')}</p>
            ) : (
              <div className="admin-table-wrap" style={{ marginBottom: 16 }}>
                <table className="admin-table" style={{ fontSize: 12 }}>
                  <thead>
                    <tr>
                      <th>Offer</th>
                      <th>Trade</th>
                      <th>{t('admin.disputes.sellerState')}</th>
                      <th>{t('admin.disputes.buyerState')}</th>
                      <th>{t('admin.disputes.assetMatch')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {detail.trades.map((trade) => (
                      <tr key={trade.tradeOfferId}>
                        <td>{trade.tradeOfferId}</td>
                        <td>{trade.steamTradeId ?? '—'}</td>
                        <td>{trade.offerState}{trade.tradeStatus ? ` / ${trade.tradeStatus}` : ''}</td>
                        <td>
                          {trade.buyerReportedOfferState
                            ? `${trade.buyerReportedOfferState} · ${formatDateTime(trade.buyerReportedAt)}`
                            : t('admin.disputes.noBuyerReport')}
                        </td>
                        <td>
                          {trade.buyerAssetMatchesListing == null
                            ? '—'
                            : trade.buyerAssetMatchesListing
                              ? <span style={{ color: '#34d399' }}>✓</span>
                              : <span style={{ color: '#f87171' }}>✗ {trade.buyerSeenAssetIds}</span>}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* Evidence: TLSN proof records */}
            <h4 style={{ margin: '0 0 8px' }}>{t('admin.disputes.proofs')}</h4>
            {detail.proofs.length === 0 ? (
              <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>{t('admin.disputes.noProofs')}</p>
            ) : (
              <div className="admin-table-wrap" style={{ marginBottom: 16 }}>
                <table className="admin-table" style={{ fontSize: 12 }}>
                  <thead>
                    <tr>
                      <th>{t('admin.disputes.received')}</th>
                      <th>Trade</th>
                      <th>Status</th>
                      <th>{t('admin.disputes.outcome')}</th>
                      <th>{t('admin.disputes.failure')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {detail.proofs.map((proof) => (
                      <tr key={proof.id}>
                        <td>{formatDateTime(proof.receivedAt)}</td>
                        <td>{proof.steamTradeId ?? '—'}</td>
                        <td>{proof.tradeStatus ?? '—'}</td>
                        <td><StatusBadge status={proof.outcome} /></td>
                        <td style={{ color: 'var(--text-muted)' }}>
                          {proof.failureCode ? `${proof.failureCode}: ${proof.failureReason ?? ''}` : '—'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {actionError && <div className="admin-inline-error">{actionError}</div>}

            {isOpen ? (
              <div className="glass-panel" style={{ padding: 16, borderRadius: 8 }}>
                <h4 style={{ margin: '0 0 12px' }}>{t('admin.disputes.resolveTitle')}</h4>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                  {RESOLUTIONS.map(({ value, hintKey }) => (
                    <label key={value} style={{ display: 'flex', gap: 10, alignItems: 'flex-start', fontSize: 13, cursor: 'pointer' }}>
                      <input
                        type="radio"
                        name="dispute-resolution"
                        checked={resolution === value}
                        onChange={() => setResolution(value)}
                        style={{ marginTop: 2 }}
                      />
                      <span>
                        <strong>{value}</strong>
                        <span style={{ display: 'block', color: 'var(--text-muted)' }}>{t(hintKey)}</span>
                      </span>
                    </label>
                  ))}
                </div>

                <textarea
                  className="admin-textarea"
                  rows={2}
                  placeholder={t('admin.disputes.notePlaceholder')}
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  style={{ marginTop: 12, width: '100%' }}
                />

                <div className="admin-action-row" style={{ marginTop: 12 }}>
                  <button className="primary-button" type="button" disabled={busy} onClick={onResolve}>
                    {busy ? t('admin.loading') : t('admin.disputes.resolve')}
                  </button>
                  {detail.dispute.status === 'Open' && (
                    <button type="button" className="admin-btn-ghost" disabled={busy} onClick={onTakeReview}>
                      {t('admin.disputes.takeReview')}
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <div className="glass-panel" style={{ padding: 16, borderRadius: 8, fontSize: 13 }}>
                <strong>{detail.dispute.resolution}</strong>
                {detail.dispute.resolutionNote && <p style={{ margin: '6px 0 0', color: 'var(--text-muted)' }}>{detail.dispute.resolutionNote}</p>}
                <p style={{ margin: '6px 0 0', color: 'var(--text-muted)' }}>{formatDateTime(detail.dispute.resolvedAt)}</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
