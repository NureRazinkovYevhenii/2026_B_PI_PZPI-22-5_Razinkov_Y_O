using SkinHex.Core.Entities;

namespace SkinHex.Core.Interfaces.Repositories;

public interface ITlsnProofRecordRepository
{
    /// <summary>Stages the record; persisted by the caller's SaveChanges.</summary>
    void Add(TlsnProofRecord record);

    /// <summary>Resolves the order an incoming proof belongs to via its Steam trade id.</summary>
    Task<Guid?> GetOrderIdBySteamTradeIdAsync(string steamTradeId, CancellationToken ct = default);

    Task<List<TlsnProofRecord>> GetByOrderIdAsync(Guid orderId, CancellationToken ct = default);
}
