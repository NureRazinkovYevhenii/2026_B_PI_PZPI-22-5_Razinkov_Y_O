import { handleRequest } from "./bridge/handlers";
import { RequestType } from "./bridge/types";
import { syncPendingTrades } from "./steam/tradeSync";

// ── Зовнішні запити від сайту ─────────────────────────────────────────────────

chrome.runtime.onMessageExternal.addListener(
    (request: any, _sender: chrome.runtime.MessageSender, sendResponse: (response?: any) => void) => {

        // Захист: зовнішні сайти не повинні слати команди напряму в offscreen
        if (request.target === 'offscreen') {
            sendResponse({ success: false, error: "Direct offscreen access denied" });
            return false;
        }

        // Запам'ятовуємо адресу API: фоновий sync за будильником працює і без відкритого сайту.
        if (typeof request?.apiBaseUrl === 'string' && request.apiBaseUrl) {
            chrome.storage.local.set({ apiBaseUrl: request.apiBaseUrl }).catch(() => {});
        }

        handleRequest(request)
            .then(data => sendResponse({ success: true, data }))
            .catch(err => sendResponse({ success: false, error: err.message }));

        return true; // Важливо для асинхронного sendResponse
    }
);

// ── Фоновий sync за будильником ───────────────────────────────────────────────
// chrome.alarms будить service worker, навіть коли сайт закритий: статуси трейдів
// продовжують надходити на бекенд. TLSN-пруфи навмисно НЕ запускаються автоматично —
// completion proof завжди ініціюється користувачем (кнопкою на сайті).

const SYNC_ALARM_NAME = 'skinhex-trade-sync';
const SYNC_PERIOD_MINUTES = 10;

function ensureSyncAlarm() {
    chrome.alarms.create(SYNC_ALARM_NAME, {
        periodInMinutes: SYNC_PERIOD_MINUTES,
        delayInMinutes: 1,
    });
}

chrome.runtime.onInstalled.addListener(ensureSyncAlarm);
chrome.runtime.onStartup.addListener(ensureSyncAlarm);

chrome.alarms.onAlarm.addListener(async (alarm) => {
    if (alarm.name !== SYNC_ALARM_NAME) {
        return;
    }

    const { apiBaseUrl } = await chrome.storage.local.get('apiBaseUrl') as { apiBaseUrl?: string };
    if (!apiBaseUrl) {
        // Сайт ще жодного разу не звертався до розширення — не знаємо, куди репортити.
        return;
    }

    try {
        const result = await syncPendingTrades({
            type: RequestType.SYNC_PENDING_TRADES,
            apiBaseUrl,
        });
        if (!result.skipped) {
            console.log(`[Alarm] Trade sync: ${result.sentUpdates} updates, ${result.updated} applied.`);
        }
    } catch (e) {
        console.warn('[Alarm] Trade sync failed:', e);
    }
});
