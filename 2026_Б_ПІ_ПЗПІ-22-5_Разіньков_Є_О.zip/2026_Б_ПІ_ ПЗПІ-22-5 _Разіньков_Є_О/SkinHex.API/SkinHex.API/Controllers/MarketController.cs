using FluentResults;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SkinHex.API.Errors;
using SkinHex.Core.Interfaces.Services;
using SkinHex.Core.Models;
using System.Security.Claims;

namespace SkinHex.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class MarketController : ControllerBase
{
    private readonly IMarketService _marketService;

    public MarketController(IMarketService marketService)
    {
        _marketService = marketService;
    }

    [HttpPost("list")]
    [Authorize]
    public async Task<IActionResult> CreateListing([FromBody] CreateListingRequest request, CancellationToken ct)
    {
        var userId = GetCurrentUserId();
        if (userId is null) return Unauthorized();

        var result = await _marketService.CreateListingAsync(userId.Value, request, ct);

        if (result.IsFailed)
        {
            return this.ToProblemDetails(result.Errors);
        }

        return Ok(new { listingId = result.Value });
    }

    [HttpPost("list/bulk")]
    [Authorize]
    public async Task<IActionResult> CreateListings([FromBody] CreateListingsRequest request, CancellationToken ct)
    {
        var userId = GetCurrentUserId();
        if (userId is null) return Unauthorized();
        if (request is null)
        {
            return this.ToProblemDetails([new Error("Request body is required.")]);
        }

        var result = await _marketService.CreateListingsAsync(userId.Value, request, ct);

        if (result.IsFailed)
        {
            return this.ToProblemDetails(result.Errors);
        }

        return Ok(result.Value);
    }

    [HttpPatch("listings/{id:guid}")]
    [Authorize]
    public async Task<IActionResult> UpdateListing(Guid id, [FromBody] UpdateListingRequest request, CancellationToken ct)
    {
        var userId = GetCurrentUserId();
        if (userId is null) return Unauthorized();

        var result = await _marketService.UpdateListingAsync(userId.Value, id, request, ct);
        if (result.IsFailed)
        {
            return ToMarketProblem(result.Errors);
        }

        return NoContent();
    }

    [HttpDelete("listings/{id:guid}")]
    [Authorize]
    public async Task<IActionResult> RemoveListing(Guid id, CancellationToken ct)
    {
        var userId = GetCurrentUserId();
        if (userId is null) return Unauthorized();

        var result = await _marketService.RemoveListingAsync(userId.Value, id, ct);
        if (result.IsFailed)
        {
            return ToMarketProblem(result.Errors);
        }

        return NoContent();
    }

    [HttpGet("catalog")]
    public async Task<IActionResult> GetCatalog([FromQuery] GetListingsRequest request, CancellationToken ct)
    {
        var result = await _marketService.GetCatalogAsync(request, ct);
        return Ok(result);
    }

    [HttpGet("my")]
    [Authorize]
    public async Task<IActionResult> GetMyListings([FromQuery] GetListingsRequest request, CancellationToken ct)
    {
        var userId = GetCurrentUserId();
        if (userId is null) return Unauthorized();

        request.SellerId = userId.Value;
        var result = await _marketService.GetCatalogAsync(request, ct);
        return Ok(result);
    }

    [HttpGet("items/by-name")]
    public async Task<IActionResult> GetItemPage([FromQuery] MarketItemPageRequest request, CancellationToken ct)
    {
        var result = await _marketService.GetItemPageAsync(request, ct);
        if (result.IsFailed)
        {
            return ToMarketProblem(result.Errors);
        }

        return Ok(result.Value);
    }

    [HttpGet("search-tips")]
    public async Task<IActionResult> SearchTips([FromQuery] MarketSearchTipRequest request, CancellationToken ct)
    {
        var result = await _marketService.SearchTipsAsync(request, ct);
        if (result.IsFailed)
        {
            return this.ToProblemDetails(result.Errors);
        }

        return Ok(result.Value);
    }

    [HttpGet("item-search")]
    public async Task<IActionResult> ItemSearch([FromQuery] MarketSearchTipRequest request, CancellationToken ct)
    {
        var result = await _marketService.SearchItemsAsync(request, ct);
        if (result.IsFailed)
        {
            return this.ToProblemDetails(result.Errors);
        }

        return Ok(result.Value);
    }

    [HttpGet("items/{itemId:int}/sales")]
    public async Task<IActionResult> GetSaleHistory(
        int itemId,
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 20,
        CancellationToken ct = default)
    {
        var result = await _marketService.GetSaleHistoryAsync(itemId, page, pageSize, ct);
        return Ok(result);
    }

    private Guid? GetCurrentUserId()
    {
        var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        return Guid.TryParse(userIdClaim, out var userId) ? userId : null;
    }

    private IActionResult ToMarketProblem(IReadOnlyList<IError> errors)
    {
        var messages = errors.Select(error => error.Message).ToArray();
        var statusCode = messages switch
        {
            var m when m.Any(message => message.Contains("not found", StringComparison.OrdinalIgnoreCase)) =>
                StatusCodes.Status404NotFound,
            var m when m.Any(message => message.Contains("your own", StringComparison.OrdinalIgnoreCase)) =>
                StatusCodes.Status403Forbidden,
            var m when m.Any(message => message.Contains("active", StringComparison.OrdinalIgnoreCase)) =>
                StatusCodes.Status409Conflict,
            _ => StatusCodes.Status400BadRequest
        };

        return this.ToProblemDetails(errors, statusCode);
    }
}
