using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SkinHex.Core.Interfaces.Services;
using SkinHex.Core.Models.Notifications;

namespace SkinHex.API.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class NotificationsController : ControllerBase
{
    private readonly INotificationService _notificationService;

    public NotificationsController(INotificationService notificationService)
    {
        _notificationService = notificationService;
    }

    private Guid GetUserId()
    {
        var userIdString = User.FindFirstValue(ClaimTypes.NameIdentifier);
        return Guid.Parse(userIdString!);
    }

    /// <summary>Latest notifications, newest first. Pass <paramref name="before"/> (CreatedAt of the oldest loaded item) to page further back.</summary>
    [HttpGet]
    public async Task<ActionResult<NotificationsPageResponse>> GetNotifications(
        [FromQuery] int limit = 20,
        [FromQuery] DateTime? before = null,
        CancellationToken ct = default)
    {
        var page = await _notificationService.GetNotificationsAsync(GetUserId(), limit, before, ct);
        return Ok(page);
    }

    [HttpGet("unread-count")]
    public async Task<ActionResult<UnreadCountResponse>> GetUnreadCount(CancellationToken ct = default)
    {
        var count = await _notificationService.GetUnreadCountAsync(GetUserId(), ct);
        return Ok(new UnreadCountResponse(count));
    }

    [HttpPost("read")]
    public async Task<ActionResult<MarkNotificationsReadResponse>> MarkRead(
        [FromBody] MarkNotificationsReadRequest request,
        CancellationToken ct = default)
    {
        var updated = await _notificationService.MarkReadAsync(GetUserId(), request.Ids, ct);
        return Ok(new MarkNotificationsReadResponse(updated));
    }

    [HttpPost("read-all")]
    public async Task<ActionResult<MarkNotificationsReadResponse>> MarkAllRead(CancellationToken ct = default)
    {
        var updated = await _notificationService.MarkAllReadAsync(GetUserId(), ct);
        return Ok(new MarkNotificationsReadResponse(updated));
    }
}
