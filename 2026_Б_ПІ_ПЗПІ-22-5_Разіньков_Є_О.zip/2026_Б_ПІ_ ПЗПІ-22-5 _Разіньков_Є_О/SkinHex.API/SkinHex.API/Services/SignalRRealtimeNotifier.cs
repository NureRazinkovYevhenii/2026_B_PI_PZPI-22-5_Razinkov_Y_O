using Microsoft.AspNetCore.SignalR;
using SkinHex.API.Hubs;
using SkinHex.Core.Interfaces.Services;

namespace SkinHex.API.Services;

public sealed class SignalRRealtimeNotifier(IHubContext<NotificationsHub> hubContext) : IRealtimeNotifier
{
    public Task SendToUserAsync(Guid userId, string eventName, object payload, CancellationToken ct = default)
        => hubContext.Clients.User(userId.ToString()).SendAsync(eventName, payload, ct);

    public Task SendToUsersAsync(IReadOnlyCollection<Guid> userIds, string eventName, object payload, CancellationToken ct = default)
    {
        if (userIds.Count == 0)
            return Task.CompletedTask;

        var ids = userIds.Select(id => id.ToString()).ToList();
        return hubContext.Clients.Users(ids).SendAsync(eventName, payload, ct);
    }
}
