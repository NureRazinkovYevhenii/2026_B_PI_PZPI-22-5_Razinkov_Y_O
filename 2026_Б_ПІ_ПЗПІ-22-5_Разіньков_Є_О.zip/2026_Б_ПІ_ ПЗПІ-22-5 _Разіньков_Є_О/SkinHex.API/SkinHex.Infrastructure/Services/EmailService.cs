using FluentResults;
using MailKit.Net.Smtp;
using MailKit.Security;
using Microsoft.Extensions.Options;
using MimeKit;
using SkinHex.Core.Interfaces.Services;
using SkinHex.Infrastructure.Options;

namespace SkinHex.Infrastructure.Services;

public sealed class EmailService(IOptions<SmtpOptions> smtpOptions) : IEmailService
{
    private readonly SmtpOptions _smtpOptions = smtpOptions.Value;

    public async Task<Result> SendOtpAsync(string toEmail, int code, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(toEmail))
        {
            return Result.Fail("Recipient email is required.");
        }

        if (string.IsNullOrWhiteSpace(_smtpOptions.Host) ||
            string.IsNullOrWhiteSpace(_smtpOptions.FromEmail))
        {
            return Result.Fail("SMTP settings are not configured.");
        }

        try
        {
            var message = new MimeMessage();
            message.From.Add(new MailboxAddress(_smtpOptions.FromName, _smtpOptions.FromEmail));
            message.To.Add(MailboxAddress.Parse(toEmail));
            message.Subject = "SkinHex email verification code";
            message.Body = new TextPart("plain")
            {
                Text = $"Your SkinHex verification code is {code}."
            };

            using var client = new SmtpClient();
            await client.ConnectAsync(
                _smtpOptions.Host,
                _smtpOptions.Port,
                SecureSocketOptions.StartTls,
                cancellationToken);

            if (!string.IsNullOrWhiteSpace(_smtpOptions.User))
            {
                await client.AuthenticateAsync(
                    _smtpOptions.User,
                    _smtpOptions.Password,
                    cancellationToken);
            }

            await client.SendAsync(message, cancellationToken);
            await client.DisconnectAsync(true, cancellationToken);

            return Result.Ok();
        }
        catch (Exception ex)
        {
            return Result.Fail($"Failed to send verification email: {ex.Message}");
        }
    }
}
