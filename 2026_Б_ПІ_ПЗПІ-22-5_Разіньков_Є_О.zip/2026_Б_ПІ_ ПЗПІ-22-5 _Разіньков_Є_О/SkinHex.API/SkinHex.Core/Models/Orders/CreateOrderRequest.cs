namespace SkinHex.Core.Models.Orders;

public record CreateOrderRequest(Guid ListingId);
