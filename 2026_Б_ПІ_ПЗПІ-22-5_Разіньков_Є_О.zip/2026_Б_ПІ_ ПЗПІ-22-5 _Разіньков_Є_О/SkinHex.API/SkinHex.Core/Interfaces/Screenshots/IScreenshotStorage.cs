namespace SkinHex.Core.Interfaces.Screenshots;

public interface IScreenshotStorage
{
    // Зберігає файл і повертає нормалізований відносний шлях (з '/'),
    // який зберігається в БД і підставляється після PublicBasePath при віддачі.
    Task<string> SaveAsync(string relativePath, byte[] content, CancellationToken ct = default);
}
