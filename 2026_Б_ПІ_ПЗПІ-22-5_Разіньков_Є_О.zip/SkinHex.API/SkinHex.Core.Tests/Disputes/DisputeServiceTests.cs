using FluentAssertions;
using Hangfire;
using Microsoft.Extensions.Logging;
using Moq;
using SkinHex.Core.Entities;
using SkinHex.Core.Errors;
using SkinHex.Core.Interfaces;
using SkinHex.Core.Interfaces.Repositories;
using SkinHex.Core.Interfaces.Services;
using SkinHex.Core.Services;

namespace SkinHex.Core.Tests.Disputes;

public class DisputeServiceTests
{
    private readonly Mock<IDisputeRepository> _disputeRepoMock = new();
    private readonly Mock<IOrderRepository> _orderRepoMock = new();
    private readonly Mock<IFinancialTransactionRepository> _financialTxRepoMock = new();
    private readonly Mock<IUnitOfWork> _uowMock = new();
    private readonly Mock<INotificationService> _notificationServiceMock = new();
    private readonly Mock<IBackgroundJobClient> _backgroundJobClientMock = new();
    private readonly DisputeService _sut;

    public DisputeServiceTests()
    {
        _uowMock.Setup(u => u.BeginTransactionAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(Mock.Of<Microsoft.EntityFrameworkCore.Storage.IDbContextTransaction>());

        _sut = new DisputeService(
            _disputeRepoMock.Object,
            _orderRepoMock.Object,
            _financialTxRepoMock.Object,
            _uowMock.Object,
            _notificationServiceMock.Object,
            _backgroundJobClientMock.Object,
            Mock.Of<ILogger<DisputeService>>());
    }

    private static (Order order, User buyer, User seller) CreateOrderGraph(OrderStatus status, decimal lockPrice = 100m)
    {
        var buyer = new User { Id = Guid.NewGuid(), Username = "buyer", Balance = 0m, FrozenBalance = 0m };
        var seller = new User { Id = Guid.NewGuid(), Username = "seller", Balance = 0m, FrozenBalance = lockPrice };
        var order = new Order
        {
            Id = Guid.NewGuid(),
            BuyerId = buyer.Id,
            SellerId = seller.Id,
            Buyer = buyer,
            Seller = seller,
            Status = status,
            LockPrice = lockPrice,
            ListingId = Guid.NewGuid(),
            Listing = new Listing { Status = ListingStatus.TradePending },
            CreatedAt = DateTime.UtcNow.AddDays(-1)
        };
        return (order, buyer, seller);
    }

    private OrderDispute SetupDispute(Order order, DisputeReason reason = DisputeReason.Other, decimal? frozenPenalty = null)
    {
        var dispute = new OrderDispute
        {
            Id = Guid.NewGuid(),
            OrderId = order.Id,
            Order = order,
            Reason = reason,
            Status = DisputeStatus.Open,
            FrozenPenaltyAmount = frozenPenalty
        };
        _disputeRepoMock.Setup(r => r.GetByIdWithOrderDetailsAsync(dispute.Id, It.IsAny<CancellationToken>()))
            .ReturnsAsync(dispute);
        return dispute;
    }

    // ---------- Opening ----------

    [Fact]
    public async Task OpenDisputeAsync_OnActiveOrder_ByParticipant_CreatesDispute()
    {
        var (order, buyer, _) = CreateOrderGraph(OrderStatus.TradeSent);
        _orderRepoMock.Setup(r => r.GetByIdAsync(order.Id, It.IsAny<CancellationToken>())).ReturnsAsync(order);
        _disputeRepoMock.Setup(r => r.HasOpenDisputeAsync(order.Id, It.IsAny<CancellationToken>())).ReturnsAsync(false);

        var dto = await _sut.OpenDisputeAsync(order.Id, buyer.Id, DisputeReason.OfferNotReceived, "Offer did not arrive");

        dto.Reason.Should().Be(nameof(DisputeReason.OfferNotReceived));
        dto.Status.Should().Be(nameof(DisputeStatus.Open));
        _disputeRepoMock.Verify(r => r.Add(It.Is<OrderDispute>(d =>
            d.OrderId == order.Id && d.OpenedByUserId == buyer.Id)), Times.Once);
        _uowMock.Verify(u => u.SaveChangesAsync(It.IsAny<CancellationToken>()), Times.Once);
        // The counterparty (seller) is notified.
        _notificationServiceMock.Verify(n => n.NotifyAsync(order.SellerId, NotificationType.DisputeOpened,
            It.IsAny<object>(), It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task OpenDisputeAsync_OnOldCancelledOrder_Throws()
    {
        var (order, buyer, _) = CreateOrderGraph(OrderStatus.Cancelled);
        order.CancelledAt = DateTime.UtcNow.AddDays(-10); // appeal window is 7 days
        _orderRepoMock.Setup(r => r.GetByIdAsync(order.Id, It.IsAny<CancellationToken>())).ReturnsAsync(order);

        var act = async () => await _sut.OpenDisputeAsync(order.Id, buyer.Id, DisputeReason.PenaltyAppeal, "penalty is unfair");

        var ex = await act.Should().ThrowAsync<BusinessException>();
        ex.Which.ErrorCode.Should().Be(BusinessErrorCodes.DisputeNotAllowed);
    }

    [Fact]
    public async Task OpenDisputeAsync_WhenAlreadyOpen_Throws()
    {
        var (order, buyer, _) = CreateOrderGraph(OrderStatus.InEscrow);
        _orderRepoMock.Setup(r => r.GetByIdAsync(order.Id, It.IsAny<CancellationToken>())).ReturnsAsync(order);
        _disputeRepoMock.Setup(r => r.HasOpenDisputeAsync(order.Id, It.IsAny<CancellationToken>())).ReturnsAsync(true);

        var act = async () => await _sut.OpenDisputeAsync(order.Id, buyer.Id, DisputeReason.WrongItemReceived, "wrong item");

        var ex = await act.Should().ThrowAsync<BusinessException>();
        ex.Which.ErrorCode.Should().Be(BusinessErrorCodes.DisputeAlreadyOpen);
    }

    [Fact]
    public async Task OpenDisputeAsync_ByStranger_Throws()
    {
        var (order, _, _) = CreateOrderGraph(OrderStatus.TradeSent);
        _orderRepoMock.Setup(r => r.GetByIdAsync(order.Id, It.IsAny<CancellationToken>())).ReturnsAsync(order);

        var act = async () => await _sut.OpenDisputeAsync(order.Id, Guid.NewGuid(), DisputeReason.Other, "someone else's order");

        var ex = await act.Should().ThrowAsync<BusinessException>();
        ex.Which.ErrorCode.Should().Be(BusinessErrorCodes.Forbidden);
    }

    // ---------- Resolutions ----------

    [Fact]
    public async Task Resolve_RefundBuyer_OnTradeSent_CancelsAndRefunds()
    {
        var (order, buyer, seller) = CreateOrderGraph(OrderStatus.TradeSent);
        var dispute = SetupDispute(order, DisputeReason.OfferNotReceived);
        var adminId = Guid.NewGuid();

        var dto = await _sut.ResolveDisputeAsync(dispute.Id, adminId, DisputeResolution.RefundBuyer, "seller staged the offer");

        dto.Status.Should().Be(nameof(DisputeStatus.Resolved));
        order.Status.Should().Be(OrderStatus.Cancelled);
        order.Listing.Status.Should().Be(ListingStatus.Active); // item never left the seller
        buyer.Balance.Should().Be(100m);
        seller.FrozenBalance.Should().Be(0m);
        seller.Balance.Should().Be(0m);

        _financialTxRepoMock.Verify(r => r.Add(It.Is<FinancialTransaction>(t =>
            t.UserId == buyer.Id && t.Type == FinancialTransactionType.Refund && t.Amount == 100m && t.ReferenceId == order.Id)), Times.Once);
    }

    [Fact]
    public async Task Resolve_RefundBuyer_OnInEscrow_ListingStaysSpent()
    {
        var (order, buyer, seller) = CreateOrderGraph(OrderStatus.InEscrow);
        var dispute = SetupDispute(order, DisputeReason.WrongItemReceived);

        await _sut.ResolveDisputeAsync(dispute.Id, Guid.NewGuid(), DisputeResolution.RefundBuyer, "wrong item delivered");

        order.Status.Should().Be(OrderStatus.Cancelled);
        order.Listing.Status.Should().Be(ListingStatus.Sold); // item is already with the buyer
        buyer.Balance.Should().Be(100m);
        seller.FrozenBalance.Should().Be(0m);
    }

    [Fact]
    public async Task Resolve_CompleteOrder_OnInEscrow_ReleasesSellerFunds()
    {
        var (order, _, seller) = CreateOrderGraph(OrderStatus.InEscrow);
        var dispute = SetupDispute(order, DisputeReason.StuckEscrow);

        var dto = await _sut.ResolveDisputeAsync(dispute.Id, Guid.NewGuid(), DisputeResolution.CompleteOrder, "delivery verified manually");

        dto.Status.Should().Be(nameof(DisputeStatus.Resolved));
        order.Status.Should().Be(OrderStatus.Completed);
        order.Listing.Status.Should().Be(ListingStatus.Sold);
        seller.FrozenBalance.Should().Be(0m);
        seller.Balance.Should().Be(100m);

        _financialTxRepoMock.Verify(r => r.Add(It.Is<FinancialTransaction>(t =>
            t.UserId == seller.Id && t.Type == FinancialTransactionType.Sale && t.Amount == 100m)), Times.Once);
    }

    [Fact]
    public async Task Resolve_CompleteOrder_WithCommission_DeductsPlatformCut()
    {
        // Manual completion must mirror the TLSN settlement: the seller only froze the net,
        // so releasing it hands over net, and the platform keeps the locked commission.
        var (order, _, seller) = CreateOrderGraph(OrderStatus.InEscrow);
        order.CommissionAmount = 5m;      // 5% of 100, locked at purchase
        seller.FrozenBalance = 95m;       // only the net was ever frozen

        var dispute = SetupDispute(order, DisputeReason.StuckEscrow);

        await _sut.ResolveDisputeAsync(dispute.Id, Guid.NewGuid(), DisputeResolution.CompleteOrder, "delivery verified manually");

        order.Status.Should().Be(OrderStatus.Completed);
        seller.FrozenBalance.Should().Be(0m);   // net hold released, no dust
        seller.Balance.Should().Be(95m);        // 100 sale − 5 commission

        _financialTxRepoMock.Verify(r => r.Add(It.Is<FinancialTransaction>(t =>
            t.UserId == seller.Id && t.Type == FinancialTransactionType.Sale && t.Amount == 100m)), Times.Once);
        _financialTxRepoMock.Verify(r => r.Add(It.Is<FinancialTransaction>(t =>
            t.UserId == seller.Id && t.Type == FinancialTransactionType.Commission && t.Amount == 5m)), Times.Once);
    }

    [Fact]
    public async Task Resolve_CompleteOrder_OnNonEscrowOrder_Throws()
    {
        var (order, _, _) = CreateOrderGraph(OrderStatus.TradeSent);
        var dispute = SetupDispute(order);

        var act = async () => await _sut.ResolveDisputeAsync(dispute.Id, Guid.NewGuid(), DisputeResolution.CompleteOrder, null);

        var ex = await act.Should().ThrowAsync<BusinessException>();
        ex.Which.ErrorCode.Should().Be(BusinessErrorCodes.InvalidDisputeResolution);
    }

    [Fact]
    public async Task Resolve_ApplyBuyerPenalty_TransfersWithheldPenaltyToSeller()
    {
        var (order, buyer, seller) = CreateOrderGraph(OrderStatus.Cancelled);
        seller.FrozenBalance = 0m; // already released at cancellation
        buyer.Balance = 98m;
        buyer.FrozenBalance = 2m; // withheld penalty
        var dispute = SetupDispute(order, DisputeReason.UnverifiedBuyerFault, frozenPenalty: 2m);

        await _sut.ResolveDisputeAsync(dispute.Id, Guid.NewGuid(), DisputeResolution.ApplyBuyerPenalty, "offer confirmed via TLSN evidence");

        buyer.FrozenBalance.Should().Be(0m);
        buyer.Balance.Should().Be(98m);
        seller.Balance.Should().Be(2m);

        _financialTxRepoMock.Verify(r => r.Add(It.Is<FinancialTransaction>(t =>
            t.UserId == buyer.Id && t.Type == FinancialTransactionType.Penalty && t.Amount == -2m)), Times.Once);
        _financialTxRepoMock.Verify(r => r.Add(It.Is<FinancialTransaction>(t =>
            t.UserId == seller.Id && t.Type == FinancialTransactionType.Penalty && t.Amount == 2m)), Times.Once);
    }

    [Fact]
    public async Task Resolve_ReverseBuyerPenalty_WithheldPath_ReleasesFreezeWithoutLedger()
    {
        var (order, buyer, seller) = CreateOrderGraph(OrderStatus.Cancelled);
        seller.FrozenBalance = 0m;
        buyer.Balance = 98m;
        buyer.FrozenBalance = 2m;
        var dispute = SetupDispute(order, DisputeReason.UnverifiedBuyerFault, frozenPenalty: 2m);

        await _sut.ResolveDisputeAsync(dispute.Id, Guid.NewGuid(), DisputeResolution.ReverseBuyerPenalty, "offer never reached the buyer");

        buyer.FrozenBalance.Should().Be(0m);
        buyer.Balance.Should().Be(100m);
        seller.Balance.Should().Be(0m);

        // Full Refund was already posted at cancellation — releasing the freeze adds no ledger rows.
        _financialTxRepoMock.Verify(r => r.Add(It.IsAny<FinancialTransaction>()), Times.Never);
    }

    [Fact]
    public async Task Resolve_ReverseBuyerPenalty_AppealPath_ReversesAppliedPenalty()
    {
        var (order, buyer, seller) = CreateOrderGraph(OrderStatus.Cancelled);
        seller.FrozenBalance = 0m;
        buyer.Balance = 98m;
        seller.Balance = 2m;
        var dispute = SetupDispute(order, DisputeReason.PenaltyAppeal); // no frozen amount — penalty was applied

        _financialTxRepoMock.Setup(r => r.GetCompletedByReferenceAsync(order.Id, FinancialTransactionType.Penalty, It.IsAny<CancellationToken>()))
            .ReturnsAsync(
            [
                new FinancialTransaction { UserId = buyer.Id, Amount = -2m, Type = FinancialTransactionType.Penalty },
                new FinancialTransaction { UserId = seller.Id, Amount = 2m, Type = FinancialTransactionType.Penalty }
            ]);

        await _sut.ResolveDisputeAsync(dispute.Id, Guid.NewGuid(), DisputeResolution.ReverseBuyerPenalty, "penalty was unfair");

        buyer.Balance.Should().Be(100m);
        seller.Balance.Should().Be(0m);

        _financialTxRepoMock.Verify(r => r.Add(It.Is<FinancialTransaction>(t =>
            t.UserId == buyer.Id && t.Type == FinancialTransactionType.Penalty && t.Amount == 2m)), Times.Once);
        _financialTxRepoMock.Verify(r => r.Add(It.Is<FinancialTransaction>(t =>
            t.UserId == seller.Id && t.Type == FinancialTransactionType.Penalty && t.Amount == -2m)), Times.Once);
    }

    [Fact]
    public async Task Resolve_NoAction_WithWithheldPenalty_Throws()
    {
        var (order, _, _) = CreateOrderGraph(OrderStatus.Cancelled);
        var dispute = SetupDispute(order, DisputeReason.UnverifiedBuyerFault, frozenPenalty: 2m);

        var act = async () => await _sut.ResolveDisputeAsync(dispute.Id, Guid.NewGuid(), DisputeResolution.NoAction, null);

        var ex = await act.Should().ThrowAsync<BusinessException>();
        ex.Which.ErrorCode.Should().Be(BusinessErrorCodes.InvalidDisputeResolution);
    }

    [Fact]
    public async Task Resolve_AlreadyResolved_Throws()
    {
        var (order, _, _) = CreateOrderGraph(OrderStatus.Cancelled);
        var dispute = SetupDispute(order);
        dispute.Status = DisputeStatus.Resolved;

        var act = async () => await _sut.ResolveDisputeAsync(dispute.Id, Guid.NewGuid(), DisputeResolution.NoAction, null);

        var ex = await act.Should().ThrowAsync<BusinessException>();
        ex.Which.ErrorCode.Should().Be(BusinessErrorCodes.InvalidDisputeResolution);
    }
}
