using SkinHex.Core.Entities;
using SkinHex.Core.Interfaces.Repositories;
using SkinHex.Core.Interfaces.Services;
using SkinHex.Core.Models.Notifications;

namespace SkinHex.Core.Services;

public class NotificationJobs(
    IOrderRepository orderRepository,
    IDisputeRepository disputeRepository,
    INotificationService notificationService) : INotificationJobs
{
    public async Task NotifyDisputeOpenedAsync(Guid disputeId, CancellationToken ct)
    {
        // Enqueued right before the surrounding transaction commits — if the row is not
        // visible yet, throwing lets Hangfire retry until it is.
        var dispute = await disputeRepository.GetByIdAsync(disputeId, ct)
            ?? throw new InvalidOperationException($"Dispute {disputeId} is not visible yet.");

        var order = await orderRepository.GetByIdForNotificationAsync(dispute.OrderId, ct);
        if (order is null)
            return;

        var openedBy = dispute.OpenedByUserId == order.BuyerId ? "buyer"
            : dispute.OpenedByUserId == order.SellerId ? "seller"
            : "system";
        var payload = new DisputeOpenedPayload(dispute.Id, order.Id, dispute.Reason.ToString(), openedBy);

        await notificationService.NotifyAsync(order.BuyerId, NotificationType.DisputeOpened, payload, ct);
        await notificationService.NotifyAsync(order.SellerId, NotificationType.DisputeOpened, payload, ct);
    }

    public async Task NotifyOrderTransitionAsync(Guid orderId, OrderStatus announcedStatus, CancellationToken ct)
    {
        var order = await orderRepository.GetByIdForNotificationAsync(orderId, ct);
        if (order is null)
            return;

        switch (announcedStatus)
        {
            // Seller confirmed / sent the trade — the buyer is the one waiting on it.
            case OrderStatus.Confirmed:
            case OrderStatus.TradeSent:
                await notificationService.NotifyOrderStatusChangedAsync(order.BuyerId, order, announcedStatus, ct);
                break;

            // Buyer accepted the offer — the seller wants to know it moved to escrow.
            case OrderStatus.InEscrow:
                await notificationService.NotifyOrderStatusChangedAsync(order.SellerId, order, announcedStatus, ct);
                break;

            // Deal closed — both parties care (buyer: purchase done, seller: funds released).
            case OrderStatus.Completed:
                await notificationService.NotifyOrderStatusChangedAsync(order.BuyerId, order, announcedStatus, ct);
                await notificationService.NotifyOrderStatusChangedAsync(order.SellerId, order, announcedStatus, ct);
                break;

            // Notify whoever did NOT trigger the cancellation; a system cancel notifies both.
            case OrderStatus.Cancelled:
                if (order.CancelledBy == CancelledBy.Buyer)
                {
                    await notificationService.NotifyOrderStatusChangedAsync(order.SellerId, order, announcedStatus, ct);
                }
                else if (order.CancelledBy == CancelledBy.Seller)
                {
                    await notificationService.NotifyOrderStatusChangedAsync(order.BuyerId, order, announcedStatus, ct);
                }
                else
                {
                    await notificationService.NotifyOrderStatusChangedAsync(order.BuyerId, order, announcedStatus, ct);
                    await notificationService.NotifyOrderStatusChangedAsync(order.SellerId, order, announcedStatus, ct);
                }
                break;
        }
    }
}
