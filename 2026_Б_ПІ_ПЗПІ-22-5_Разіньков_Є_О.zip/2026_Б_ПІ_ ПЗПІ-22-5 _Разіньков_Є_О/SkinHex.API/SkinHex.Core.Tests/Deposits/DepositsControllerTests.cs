using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using SkinHex.API.Controllers;
using SkinHex.Core.Entities;
using SkinHex.Core.Interfaces.Services;
using SkinHex.Core.Options;
using SkinHex.Infrastructure;
using Xunit;

namespace SkinHex.Core.Tests.Deposits;

public class DepositsControllerTests
{
    private readonly Mock<INowPaymentsService> _nowPaymentsServiceMock = new();
    private readonly SkinHexDbContext _dbContext;
    private readonly NowPaymentsOptions _options = new()
    {
        OutcomeCurrency = "usdtbsc",
        MinDepositUsd = 3m
    };
    private readonly Guid _userId = Guid.NewGuid();

    public DepositsControllerTests()
    {
        var dbOptions = new DbContextOptionsBuilder<SkinHexDbContext>()
            .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
            // CreateDeposit opens a DB transaction; the in-memory provider warns instead of supporting it.
            .ConfigureWarnings(w => w.Ignore(InMemoryEventId.TransactionIgnoredWarning))
            .Options;
        _dbContext = new SkinHexDbContext(dbOptions);
    }

    private DepositsController CreateController()
    {
        var controller = new DepositsController(
            _dbContext,
            _nowPaymentsServiceMock.Object,
            Microsoft.Extensions.Options.Options.Create(_options),
            Mock.Of<ILogger<DepositsController>>());

        var user = new ClaimsPrincipal(new ClaimsIdentity(new[]
        {
            new Claim(ClaimTypes.NameIdentifier, _userId.ToString())
        }));

        controller.ControllerContext = new ControllerContext
        {
            HttpContext = new DefaultHttpContext { User = user }
        };
        return controller;
    }

    private void SetupCoinMin(string payCurrency, decimal? fiatEquivalentUsd, decimal minCrypto = 0m)
    {
        _nowPaymentsServiceMock
            .Setup(s => s.GetMinAmountAsync(payCurrency, _options.OutcomeCurrency, It.IsAny<CancellationToken>()))
            .ReturnsAsync(new NowPaymentsMinAmount(payCurrency, _options.OutcomeCurrency, minCrypto, fiatEquivalentUsd));
    }

    [Fact]
    public void GetCurrencies_ReturnsCuratedListAndPlatformMin()
    {
        var controller = CreateController();

        var result = controller.GetCurrencies();

        var ok = Assert.IsType<OkObjectResult>(result);
        Assert.NotNull(ok.Value);
    }

    [Fact]
    public async Task GetMinAmount_UnsupportedCurrency_ReturnsBadRequest()
    {
        var controller = CreateController();

        var result = await controller.GetMinAmount("dogecoin-fake", CancellationToken.None);

        Assert.IsType<BadRequestObjectResult>(result);
    }

    [Fact]
    public async Task GetMinAmount_CoinMinAbovePlatform_UsesCoinMin()
    {
        // USDT TRC20 famously can't be sent below ~11.2 USDT even though our platform min is $3.
        SetupCoinMin("usdttrc20", fiatEquivalentUsd: 11.2m, minCrypto: 11.2m);
        var controller = CreateController();

        var result = await controller.GetMinAmount("usdttrc20", CancellationToken.None);

        var ok = Assert.IsType<OkObjectResult>(result);
        var minUsd = (decimal)ok.Value!.GetType().GetProperty("minUsd")!.GetValue(ok.Value)!;
        Assert.Equal(11.2m, minUsd);
    }

    [Fact]
    public async Task GetMinAmount_CoinMinBelowPlatform_UsesPlatformMin()
    {
        SetupCoinMin("usdtbsc", fiatEquivalentUsd: 0.8m, minCrypto: 0.8m);
        var controller = CreateController();

        var result = await controller.GetMinAmount("usdtbsc", CancellationToken.None);

        var ok = Assert.IsType<OkObjectResult>(result);
        var minUsd = (decimal)ok.Value!.GetType().GetProperty("minUsd")!.GetValue(ok.Value)!;
        Assert.Equal(3m, minUsd);
    }

    [Fact]
    public async Task CreateDeposit_BelowCoinMinimum_ReturnsBadRequestAndNoInvoice()
    {
        SetupCoinMin("usdttrc20", fiatEquivalentUsd: 11.2m);
        var controller = CreateController();

        var result = await controller.CreateDeposit(
            new DepositsController.CreateDepositRequest(5m, "usdttrc20"), CancellationToken.None);

        Assert.IsType<BadRequestObjectResult>(result);
        _nowPaymentsServiceMock.Verify(
            s => s.CreateInvoiceAsync(It.IsAny<decimal>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()),
            Times.Never);
        Assert.Empty(_dbContext.Deposits);
    }

    [Fact]
    public async Task CreateDeposit_BelowPlatformMinimum_ReturnsBadRequest()
    {
        SetupCoinMin("usdtbsc", fiatEquivalentUsd: 0.5m);
        var controller = CreateController();

        // $2 is above the coin min but below the $3 platform floor.
        var result = await controller.CreateDeposit(
            new DepositsController.CreateDepositRequest(2m, "usdtbsc"), CancellationToken.None);

        Assert.IsType<BadRequestObjectResult>(result);
    }

    [Fact]
    public async Task CreateDeposit_MeetsMinimum_CreatesInvoiceWithSelectedCurrency()
    {
        SetupCoinMin("usdttrc20", fiatEquivalentUsd: 11.2m);
        _nowPaymentsServiceMock
            // Invoice is billed the grossed-up amount: 15 × (1 + 0.01) = 15.15.
            .Setup(s => s.CreateInvoiceAsync(15.15m, It.IsAny<string>(), "usdttrc20", It.IsAny<CancellationToken>()))
            .ReturnsAsync(new CreateInvoiceResult("invoice_123", "https://nowpayments.io/invoice/123"));

        var controller = CreateController();

        var result = await controller.CreateDeposit(
            new DepositsController.CreateDepositRequest(15m, "usdttrc20"), CancellationToken.None);

        Assert.IsType<OkObjectResult>(result);

        _nowPaymentsServiceMock.Verify(
            s => s.CreateInvoiceAsync(15.15m, It.IsAny<string>(), "usdttrc20", It.IsAny<CancellationToken>()),
            Times.Once);

        var deposit = Assert.Single(_dbContext.Deposits);
        Assert.Equal("usdttrc20", deposit.PayCurrency);
        Assert.Equal("invoice_123", deposit.NowPaymentsPaymentId);
        Assert.Equal(_userId, deposit.UserId);
        // The balance is credited the NET amount (what the user requested), not the grossed-up invoice.
        Assert.Equal(15m, deposit.FiatAmount);
    }

    [Fact]
    public async Task CreateDeposit_GrossesUpInvoiceByFeePercent()
    {
        SetupCoinMin("usdtbsc", fiatEquivalentUsd: 0.5m);
        _nowPaymentsServiceMock
            .Setup(s => s.CreateInvoiceAsync(It.IsAny<decimal>(), It.IsAny<string>(), "usdtbsc", It.IsAny<CancellationToken>()))
            .ReturnsAsync(new CreateInvoiceResult("inv", "url"));

        var controller = CreateController();

        // Net $10 → gross $10.10 (1% fee).
        await controller.CreateDeposit(
            new DepositsController.CreateDepositRequest(10m, "usdtbsc"), CancellationToken.None);

        _nowPaymentsServiceMock.Verify(
            s => s.CreateInvoiceAsync(10.10m, It.IsAny<string>(), "usdtbsc", It.IsAny<CancellationToken>()),
            Times.Once);
        Assert.Equal(10m, Assert.Single(_dbContext.Deposits).FiatAmount);
    }

    [Fact]
    public async Task CreateDeposit_UnsupportedCurrency_ReturnsBadRequest()
    {
        var controller = CreateController();

        var result = await controller.CreateDeposit(
            new DepositsController.CreateDepositRequest(20m, "not-a-real-coin"), CancellationToken.None);

        Assert.IsType<BadRequestObjectResult>(result);
    }
}
