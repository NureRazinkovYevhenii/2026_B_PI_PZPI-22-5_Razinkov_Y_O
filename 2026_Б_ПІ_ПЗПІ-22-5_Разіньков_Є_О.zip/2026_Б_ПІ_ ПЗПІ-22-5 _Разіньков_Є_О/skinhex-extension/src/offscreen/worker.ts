import * as Comlink from 'comlink';
import init, { Prover, initialize } from 'tlsn-wasm';
import { fromWebSocket } from './io-channel';
import type { TlsnRequestConfig } from '../bridge/types';

console.log("[Worker] worker.ts file started executing!");

const NOTARY_ORIGIN = 'ws://localhost:7047';
const TLSN_THREAD_COUNT = Math.max(1, Math.min(2, navigator.hardwareConcurrency || 2));
const TLSN_INIT_TIMEOUT_MS = 20_000;

type TranscriptRange = { start: number; end: number };

type RevealConfigRange = TranscriptRange & {
    handler: {
        type: 'SENT' | 'RECV';
        part: 'ALL';
        action: { kind: 'REVEAL' };
    };
};

interface NotarySession {
    sessionId: string;
    socket: WebSocket;
}

type TlsnProofInput = {
    config: TlsnRequestConfig;
    sessionData?: Record<string, unknown>;
};

// ── Inject runtime URLs so that the patched spawn.js inside tlsn-wasm
//    can find our spawner.js and worker.js by their chrome-extension:// URLs.
//    self.location.href here is e.g. chrome-extension://<id>/worker.js
(self as any).__SPAWNER_URL__ = self.location.href.replace(/\/worker\.js(\?.*)?$/, '/spawner.js');
(self as any).__WORKER_URL__ = self.location.href;
console.log('[Worker] __SPAWNER_URL__ =', (self as any).__SPAWNER_URL__);
console.log('[Worker] __WORKER_URL__ =', (self as any).__WORKER_URL__);

// ── Suppress non-fatal WASM thread-teardown traps ────────────────────────────
// wasm-bindgen's thread pool cleanup triggers `RuntimeError: operation does not
// support unaligned accesses`. This is a known wasm-bindgen bug in sub-thread
// teardown — it does NOT affect the proof result.
// Using `self.onerror + return true` is the ONLY way to suppress WASM traps
// (they bypass addEventListener('error') and try/catch).
(self as any).onerror = (
    message: string, _src: string, _line: number, _col: number, _err: unknown
) => {
    if (typeof message === 'string' &&
        (message.includes('unaligned') || message.includes('unreachable'))) {
        console.debug('[Worker] Suppressed WASM cleanup trap:', message);
        return true; // returning true prevents the error from propagating
    }
    return false;
};

// ── WASM initialisation (called via Comlink from offscreen.ts) ───────────────

function withTimeout<T>(promise: Promise<T>, timeoutMs: number, label: string): Promise<T> {
    let timeoutId: ReturnType<typeof setTimeout>;

    const timeout = new Promise<never>((_, reject) => {
        timeoutId = setTimeout(() => {
            reject(new Error(`${label} timed out after ${timeoutMs}ms`));
        }, timeoutMs);
    });

    return Promise.race([promise, timeout]).finally(() => clearTimeout(timeoutId));
}

async function initializeTlsn() {
    console.log('[Worker] crossOriginIsolated =', (self as any).crossOriginIsolated);
    console.log('[Worker] SharedArrayBuffer available =', typeof SharedArrayBuffer !== 'undefined');
    console.log('[Worker] hardwareConcurrency =', navigator.hardwareConcurrency);

    console.log('[Worker] Calling init() (loading WASM)...');
    await init();
    console.log('[Worker] init() completed!');

    console.log(`[Worker] Calling initialize() (starting spawner, threads=${TLSN_THREAD_COUNT})...`);
    await withTimeout(
        initialize(
            { level: 'Debug', crate_filters: [], span_events: [] } as any,
            TLSN_THREAD_COUNT
        ),
        TLSN_INIT_TIMEOUT_MS,
        'TLSN initialize()'
    );
    console.log('[Worker] TLSN WASM module initialized!');
}

// ── Helper: ranges for redaction ─────────────────────────────────────────────

function findAllOccurrences(secret: string, transcript: string): TranscriptRange[] {
    const ranges: TranscriptRange[] = [];
    if (!secret) return ranges;
    let pos = 0;
    while ((pos = transcript.indexOf(secret, pos)) !== -1) {
        ranges.push({ start: pos, end: pos + secret.length });
        pos += secret.length;
    }
    return ranges;
}

function subtractRanges(
    fullRange: TranscriptRange,
    secretRanges: TranscriptRange[]
): TranscriptRange[] {
    const sorted = [...secretRanges].sort((a, b) => a.start - b.start);
    const result: TranscriptRange[] = [];
    let currentPos = fullRange.start;
    for (const secret of sorted) {
        if (secret.start > currentPos) result.push({ start: currentPos, end: secret.start });
        currentPos = Math.max(currentPos, secret.end);
    }
    if (currentPos < fullRange.end) result.push({ start: currentPos, end: fullRange.end });
    return result;
}

// ── Notary session registration ───────────────────────────────────────────────

async function createNotarySession(
    maxRecvData: number,
    maxSentData: number,
    sessionData?: Record<string, unknown>
): Promise<NotarySession> {
    return new Promise((resolve, reject) => {
        const ws = new WebSocket(`${NOTARY_ORIGIN}/session`);
        let settled = false;

        ws.onopen = () => {
            ws.send(JSON.stringify({
                type: 'register',
                maxRecvData,
                maxSentData,
                sessionData: sessionData ?? {}
            }));
        };
        ws.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);
                if (data.type === 'session_registered' && data.sessionId) {
                    settled = true;
                    console.log(`[Worker] Session WebSocket registered: ${data.sessionId}`);
                    resolve({ sessionId: data.sessionId, socket: ws });
                } else if (data.type === 'error') {
                    const error = new Error('Notary error: ' + data.message);
                    if (settled) {
                        console.error('[Worker] Notary session error:', error);
                    } else {
                        settled = true;
                        reject(error);
                    }
                } else {
                    console.log('[Worker] Notary session message:', data);
                }
            } catch (e) {
                if (!settled) {
                    settled = true;
                    reject(new Error('Parse error from /session: ' + String(e)));
                }
            }
        };
        ws.onerror = () => {
            if (!settled) {
                settled = true;
                reject(new Error('WebSocket error on /session'));
            } else {
                console.error('[Worker] WebSocket error on /session after registration');
            }
        };
        ws.onclose = (event) => {
            if (!settled) {
                settled = true;
                reject(new Error(`Session WebSocket closed before registration. code=${event.code}`));
            } else {
                console.log(`[Worker] Session WebSocket closed. code=${event.code}`);
            }
        };
    });
}

function toRevealConfigRange(range: TranscriptRange, type: 'SENT' | 'RECV'): RevealConfigRange {
    return {
        ...range,
        handler: {
            type,
            part: 'ALL',
            action: { kind: 'REVEAL' },
        },
    };
}

function sendRevealConfig(
    session: NotarySession,
    sentRanges: TranscriptRange[],
    recvRanges: TranscriptRange[]
) {
    if (session.socket.readyState !== WebSocket.OPEN) {
        throw new Error(`Session WebSocket is not open, state=${session.socket.readyState}`);
    }

    const message = {
        type: 'reveal_config',
        sent: sentRanges.map((range) => toRevealConfigRange(range, 'SENT')),
        recv: recvRanges.map((range) => toRevealConfigRange(range, 'RECV')),
    };

    console.log(
        `[Worker] Sending reveal_config: sent=${message.sent.length}, recv=${message.recv.length}`
    );
    session.socket.send(JSON.stringify(message));
}

// ── Generic TLSNotary proof flow ──────────────────────────────────────────────
//
// Worker не знає, до якого API він звертається. Він отримує повністю
// сформований TlsnRequestConfig і створює криптографічний proof.

async function runTlsnProof(input: TlsnRequestConfig | TlsnProofInput) {
    const config = (input as TlsnProofInput)?.config
        ? (input as TlsnProofInput).config
        : (input as TlsnRequestConfig);
    const sessionData = (input as TlsnProofInput)?.sessionData ?? {};

    const maxRecvData = config.maxRecvData ?? 16384;
    const maxSentData = config.maxSentData ?? 2048;

    let parsedUrl: URL;
    try {
        parsedUrl = new URL(config.url);
    } catch (e) {
        console.error(`[Worker] Failed to parse URL: "${config.url}"`, e);
        throw e;
    }

    const relativeUri = parsedUrl.pathname + parsedUrl.search;
    console.log(`[Worker] Starting TLSNotary for ${config.serverName}${relativeUri}...`);

    const prover = await new Prover({
        server_name: config.serverName,
        mode: 'Mpc',
        max_recv_data: maxRecvData,
        max_sent_data: maxSentData,
        network: 'Bandwidth',
    } as any);

    let session: NotarySession | undefined;

    try {
        // 1. Реєструємо сесію в нотаріуса
        console.log('[Worker] Creating a session with the notary...');
        session = await createNotarySession(maxRecvData, maxSentData, sessionData);

        // 2. MPC-TLS handshake з нотаріусом
        console.log(`[Worker] Establishing session (${session.sessionId})...`);
        const verifierIo = await fromWebSocket(`${NOTARY_ORIGIN}/verifier?sessionId=${session.sessionId}`);
        await prover.setup(verifierIo);

        // 3. Формуємо заголовки
        const headers = new Map<string, number[]>();
        headers.set('Host', Array.from(new TextEncoder().encode(config.serverName)));
        headers.set('Connection', Array.from(new TextEncoder().encode('close')));
        headers.set('Accept-Encoding', Array.from(new TextEncoder().encode('identity')));

        // Додаткові заголовки
        if (config.headers) {
            for (const [key, value] of Object.entries(config.headers)) {
                headers.set(key, Array.from(new TextEncoder().encode(value)));
            }
        }

        // 4. Надсилаємо запит через проксі нотаріуса
        console.log('[Worker] Sending request through the proxy...');
        const proxyIo = await fromWebSocket(`${NOTARY_ORIGIN}/proxy?token=${config.serverName}`);

        await prover.send_request(proxyIo, {
            uri: relativeUri,
            method: config.method,
            headers,
            body: config.body ? Array.from(new TextEncoder().encode(config.body)) : undefined,
        } as any);

        // 5. Редакція секретів з надісланих даних
        console.log('[Worker] Response received. Starting redaction...');
        const transcript = await prover.transcript();
        const sentStr = new TextDecoder().decode(new Uint8Array(transcript.sent));

        // Збираємо всі діапазони секретів для редакції
        const allSecretRanges: TranscriptRange[] = [];
        for (const secret of config.secretsToRedact) {
            allSecretRanges.push(...findAllOccurrences(secret, sentStr));
        }

        const sentRanges = subtractRanges({ start: 0, end: transcript.sent.length }, allSecretRanges);
        const recvRanges = [{ start: 0, end: transcript.recv.length }];

        // 6. Генеруємо proof
        sendRevealConfig(session, sentRanges, recvRanges);
        const proof = await prover.reveal({
            sent: sentRanges,
            recv: recvRanges,
            server_identity: true,
        });

        console.log('[Worker] ✅ Proof generated successfully!');
        return proof;
    } finally {
        if (session?.socket.readyState === WebSocket.OPEN) {
            session.socket.close();
        }
        // Обов'язково звільняємо WASM-пам'ять, інакше при наступному запуску буде panic
        console.log('[Worker] Freeing prover memory...');
        try { prover.free(); } catch(e) {}
    }
}

// ── Expose to offscreen.ts via Comlink ───────────────────────────────────────

Comlink.expose({
    init: initializeTlsn,
    runTlsnProof,
});
