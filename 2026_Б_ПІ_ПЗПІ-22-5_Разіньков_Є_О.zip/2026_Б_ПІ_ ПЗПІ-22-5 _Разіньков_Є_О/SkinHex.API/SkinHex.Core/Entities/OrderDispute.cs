using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace SkinHex.Core.Entities;

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum DisputeReason
{
    /// <summary>Buyer claims the trade offer marked as sent never reached their Steam account.</summary>
    OfferNotReceived = 0,

    /// <summary>The item delivered (or offered) does not match the listing.</summary>
    WrongItemReceived = 1,

    /// <summary>Trade protection rollback with an initiator the system could not determine.</summary>
    RollbackFraud = 2,

    /// <summary>Escrow hold elapsed but no TLSN completion proof arrived — order stuck in InEscrow.</summary>
    StuckEscrow = 3,

    /// <summary>A party contests a penalty that was already applied on a cancelled order.</summary>
    PenaltyAppeal = 4,

    /// <summary>Buyer-fault cancellation without buyer-side confirmation that the offer existed;
    /// the penalty is withheld frozen until support confirms or reverses it.</summary>
    UnverifiedBuyerFault = 5,

    Other = 6
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum DisputeStatus
{
    Open = 0,
    UnderReview = 1,
    Resolved = 2,
    Rejected = 3
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum DisputeResolution
{
    None = 0,

    /// <summary>Cancel an active order and refund the buyer in full (no penalties).</summary>
    RefundBuyer = 1,

    /// <summary>Manually complete an InEscrow order: release frozen funds to the seller.</summary>
    CompleteOrder = 2,

    /// <summary>Confirm buyer fault: transfer the withheld penalty from the buyer to the seller.</summary>
    ApplyBuyerPenalty = 3,

    /// <summary>Buyer was not at fault: return the withheld penalty, or reverse an already-applied one.</summary>
    ReverseBuyerPenalty = 4,

    /// <summary>Close the dispute without any balance movement.</summary>
    NoAction = 5
}

public class OrderDispute
{
    [Key]
    public Guid Id { get; set; }

    public Guid OrderId { get; set; }

    /// <summary>User who opened the dispute; null when opened automatically by the system.</summary>
    public Guid? OpenedByUserId { get; set; }

    public DisputeReason Reason { get; set; }
    public DisputeStatus Status { get; set; } = DisputeStatus.Open;
    public DisputeResolution Resolution { get; set; } = DisputeResolution.None;

    [MaxLength(2000)]
    public string Description { get; set; } = string.Empty;

    [MaxLength(2000)]
    public string? ResolutionNote { get; set; }

    /// <summary>Admin who resolved the dispute; null while open and for TLSN auto-resolutions.</summary>
    public Guid? ResolvedByAdminId { get; set; }

    /// <summary>Penalty amount withheld on the buyer's FrozenBalance until support confirms
    /// (ApplyBuyerPenalty) or reverses (ReverseBuyerPenalty) it. Null for other dispute kinds.</summary>
    public decimal? FrozenPenaltyAmount { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? ResolvedAt { get; set; }

    public Order Order { get; set; } = null!;
}
