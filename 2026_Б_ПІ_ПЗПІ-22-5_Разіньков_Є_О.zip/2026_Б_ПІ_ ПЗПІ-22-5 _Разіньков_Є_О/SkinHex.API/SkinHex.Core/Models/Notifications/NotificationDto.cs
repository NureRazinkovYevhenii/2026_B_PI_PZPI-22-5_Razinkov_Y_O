using System.Text.Json;

namespace SkinHex.Core.Models.Notifications;

public record NotificationDto(
    Guid Id,
    string Type,
    JsonElement Payload,
    bool IsRead,
    DateTime CreatedAt,
    DateTime? ReadAt);

public record NotificationsPageResponse(
    IReadOnlyList<NotificationDto> Items,
    int UnreadCount,
    bool HasMore);

public record MarkNotificationsReadRequest(IReadOnlyCollection<Guid> Ids);

public record MarkNotificationsReadResponse(int Updated);

public record UnreadCountResponse(int UnreadCount);
