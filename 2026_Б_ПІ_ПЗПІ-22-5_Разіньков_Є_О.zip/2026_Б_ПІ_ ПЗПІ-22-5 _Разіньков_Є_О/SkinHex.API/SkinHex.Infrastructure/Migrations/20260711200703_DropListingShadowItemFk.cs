﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SkinHex.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class DropListingShadowItemFk : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Listings_Items_ItemId1",
                table: "Listings");

            migrationBuilder.DropIndex(
                name: "IX_Listings_ItemId1",
                table: "Listings");

            migrationBuilder.DropColumn(
                name: "ItemId1",
                table: "Listings");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "ItemId1",
                table: "Listings",
                type: "integer",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Listings_ItemId1",
                table: "Listings",
                column: "ItemId1");

            migrationBuilder.AddForeignKey(
                name: "FK_Listings_Items_ItemId1",
                table: "Listings",
                column: "ItemId1",
                principalTable: "Items",
                principalColumn: "Id");
        }
    }
}
