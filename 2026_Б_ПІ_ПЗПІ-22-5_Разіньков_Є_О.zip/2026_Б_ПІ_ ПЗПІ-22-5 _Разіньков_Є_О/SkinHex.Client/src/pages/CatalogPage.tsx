import { useCallback, useEffect, useRef, useState } from 'react';
import { Loader2 } from 'lucide-react';
import { CatalogMarketCard } from '../components/CatalogMarketCard';
import { CatalogSidebar } from '../components/CatalogSidebar';
import { CatalogSortBar } from '../components/CatalogSortBar';
import { CardSkeletonGrid } from '../components/CardSkeletonGrid';
import { ItemDetailModal } from '../components/ItemDetailModal';
import { API_BASE_URL } from '../config';
import type { AuthState, AuthorizedFetch, CatalogFilters, CatalogSortOption, ItemDictionaryEntry, ListingCatalogItem } from '../types';
import { readApiError } from '../utils/api';
import { buildCatalogParams, DEFAULT_FILTERS } from '../utils/catalogHelpers';
import { getItemStatic, loadItemDictionary } from '../utils/itemDictionary';

type CatalogPageProps = {
  auth: AuthState | null;
  authorizedFetch: AuthorizedFetch;
  onRequireLogin: () => void;
};

export function CatalogPage({ auth, authorizedFetch, onRequireLogin }: CatalogPageProps) {
  const [filters, setFilters] = useState<CatalogFilters>({ ...DEFAULT_FILTERS });
  const [items, setItems] = useState<ListingCatalogItem[]>([]);
  const [itemDictionary, setItemDictionary] = useState<Record<string, ItemDictionaryEntry>>({});
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [detailItem, setDetailItem] = useState<ListingCatalogItem | null>(null);

  // Refs for debounce & infinite scroll
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const sentinelRef = useRef<HTMLDivElement>(null);
  const filtersRef = useRef(filters);
  filtersRef.current = filters;

  // Track whether it's first load vs filter-triggered reload
  const isFirstLoad = useRef(true);

  // ── Fetch catalog data ──
  const fetchCatalog = useCallback(
    async (currentFilters: CatalogFilters, pageNum: number, append: boolean) => {
      if (append) {
        setIsLoadingMore(true);
      } else {
        setIsLoading(true);
      }
      setError(null);

      try {
        const params = buildCatalogParams(currentFilters, pageNum);
        const [response, dictionary] = await Promise.all([
          fetch(`${API_BASE_URL}/market/catalog?${params}`),
          loadItemDictionary(),
        ]);

        if (!response.ok) {
          throw new Error(await readApiError(response));
        }

        const data = (await response.json()) as {
          items: ListingCatalogItem[];
          totalPages: number;
          page: number;
        };

        setItemDictionary(dictionary);
        setTotalPages(data.totalPages || 1);

        if (append) {
          setItems((prev) => [...prev, ...data.items]);
        } else {
          setItems(data.items);
        }
        setPage(data.page || pageNum);
      } catch (loadError) {
        if (!append) setItems([]);
        setError(loadError instanceof Error ? loadError.message : 'Failed to load catalog.');
      } finally {
        setIsLoading(false);
        setIsLoadingMore(false);
      }
    },
    [],
  );

  // ── Initial load ──
  useEffect(() => {
    if (isFirstLoad.current) {
      isFirstLoad.current = false;
      void fetchCatalog(filters, 1, false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ── Debounced filter change → refetch from page 1 ──
  const handleFiltersChange = useCallback(
    (next: CatalogFilters) => {
      setFilters(next);

      if (debounceRef.current) {
        clearTimeout(debounceRef.current);
      }

      debounceRef.current = setTimeout(() => {
        setPage(1);
        void fetchCatalog(next, 1, false);
      }, 500);
    },
    [fetchCatalog],
  );

  // ── Sort change → immediate refetch ──
  const handleSortChange = useCallback(
    (sort: CatalogSortOption) => {
      const next = { ...filtersRef.current, sortBy: sort };
      setFilters(next);
      setPage(1);
      void fetchCatalog(next, 1, false);
    },
    [fetchCatalog],
  );

  // ── Reset ──
  const handleReset = useCallback(() => {
    const next = { ...DEFAULT_FILTERS };
    setFilters(next);
    setPage(1);
    void fetchCatalog(next, 1, false);
  }, [fetchCatalog]);

  // ── Load next page callback ──
  const loadNextPage = useCallback(() => {
    if (isLoading || isLoadingMore || page >= totalPages) return;
    const nextPage = page + 1;
    void fetchCatalog(filtersRef.current, nextPage, true);
  }, [isLoading, isLoadingMore, page, totalPages, fetchCatalog]);

  // ── Infinite scroll via IntersectionObserver ──
  useEffect(() => {
    const sentinel = sentinelRef.current;
    if (!sentinel) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          loadNextPage();
        }
      },
      { rootMargin: '400px' },
    );

    observer.observe(sentinel);
    return () => observer.disconnect();
  }, [loadNextPage]);

  // ── Reload catalog (after purchase etc.) ──
  const reloadCatalog = useCallback(() => {
    setPage(1);
    void fetchCatalog(filtersRef.current, 1, false);
  }, [fetchCatalog]);

  return (
    <section className="cat-page">
      <CatalogSidebar
        filters={filters}
        onChange={handleFiltersChange}
        onReset={handleReset}
        itemDictionary={itemDictionary}
      />

      <div className="cat-main">
        <CatalogSortBar sortBy={filters.sortBy} onSortChange={handleSortChange} />

        {error ? (
          <div className="inventory-state inventory-error" role="alert">
            <strong>Error</strong>
            <p>{error}</p>
          </div>
        ) : isLoading ? (
          <CardSkeletonGrid />
        ) : items.length > 0 ? (
          <>
            <div className="cat-grid">
              {items.map((item) => (
                <CatalogMarketCard
                  key={item.id}
                  auth={auth}
                  authorizedFetch={authorizedFetch}
                  item={item}
                  itemStatic={getItemStatic(itemDictionary, item.marketHashName)}
                  isOwnListing={Boolean(auth && item.sellerSteamId === auth.userId)}
                  onPurchaseCreated={reloadCatalog}
                  onRequireLogin={onRequireLogin}
                  onOpenDetails={() => setDetailItem(item)}
                />
              ))}
            </div>

            {/* Infinite scroll sentinel */}
            <div ref={sentinelRef} className="cat-sentinel">
              {isLoadingMore && (
                <div className="cat-loading-more">
                  <Loader2 size={20} className="spin-animation" />
                  <span>Loading more...</span>
                </div>
              )}
              {page >= totalPages && items.length > 0 && (
                <div className="cat-end-message">
                  No more items
                </div>
              )}
            </div>
          </>
        ) : (
          <div className="inventory-state">
            <strong>No items found</strong>
            <p>Try adjusting your filters</p>
          </div>
        )}
      </div>

      {detailItem && (
        <ItemDetailModal
          source={{ kind: 'listing', listing: detailItem }}
          itemStatic={getItemStatic(itemDictionary, detailItem.marketHashName)}
          onClose={() => setDetailItem(null)}
          market={{
            auth,
            authorizedFetch,
            isOwnListing: Boolean(auth && detailItem.sellerSteamId === auth.userId),
            onChanged: reloadCatalog,
            onRequireLogin,
          }}
        />
      )}
    </section>
  );
}
