export class SkinHexTokenManager {
    private static readonly DOMAIN = "http://localhost:5173";

    /**
     * Gets the SkinHex JWT token directly from the site's cookies.
     * Throws an error if the user is not authenticated.
     */
    public static async getJwtToken(): Promise<string> {
        const cookie = await chrome.cookies.get({
            url: this.DOMAIN,
            name: "skinhex_jwt"
        });

        if (!cookie || !cookie.value) {
            throw new Error("AUTH_EXPIRED");
        }

        return cookie.value;
    }
}
