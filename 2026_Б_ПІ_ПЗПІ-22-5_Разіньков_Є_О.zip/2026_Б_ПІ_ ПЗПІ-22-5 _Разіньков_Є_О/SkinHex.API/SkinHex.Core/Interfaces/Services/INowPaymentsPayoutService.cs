namespace SkinHex.Core.Interfaces.Services;

/// <summary>Result of creating a payout batch at NOWPayments.</summary>
public record PayoutResult(string BatchId, string PayoutId, string Status);

/// <summary>Raised when a payout call fails (misconfiguration or an error from NOWPayments).</summary>
public sealed class PayoutException : Exception
{
    public PayoutException(string message) : base(message) { }
    public PayoutException(string message, Exception inner) : base(message, inner) { }
}

public interface INowPaymentsPayoutService
{
    /// <summary>
    /// Creates a single-withdrawal payout batch. <paramref name="amountUsd"/> is sent as the payout
    /// amount in <paramref name="currencyCode"/> (stablecoins are ~1:1 with USD).
    /// </summary>
    Task<PayoutResult> CreatePayoutAsync(
        string address,
        string currencyCode,
        decimal amountUsd,
        string? extraId = null,
        CancellationToken ct = default);

    /// <summary>
    /// Confirms a created payout batch via POST /v1/payout/{batchId}/verify using a TOTP-generated
    /// 2FA code. Without this step the batch stays unconfirmed in the NOWPayments dashboard.
    /// </summary>
    Task VerifyPayoutAsync(string batchId, CancellationToken ct = default);

    /// <summary>Fetches the current status string for a payout id.</summary>
    Task<string> GetPayoutStatusAsync(string payoutId, CancellationToken ct = default);
}
