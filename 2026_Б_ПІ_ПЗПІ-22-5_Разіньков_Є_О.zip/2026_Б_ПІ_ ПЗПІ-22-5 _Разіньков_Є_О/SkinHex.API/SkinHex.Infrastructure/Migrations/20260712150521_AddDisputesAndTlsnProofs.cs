﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SkinHex.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class AddDisputesAndTlsnProofs : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "BuyerAssetMatchesListing",
                table: "SteamTrades",
                type: "boolean",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "BuyerReportedAt",
                table: "SteamTrades",
                type: "timestamp with time zone",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "BuyerReportedOfferState",
                table: "SteamTrades",
                type: "integer",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "BuyerSeenAssetIds",
                table: "SteamTrades",
                type: "character varying(2000)",
                maxLength: 2000,
                nullable: true);

            migrationBuilder.CreateTable(
                name: "OrderDisputes",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    OrderId = table.Column<Guid>(type: "uuid", nullable: false),
                    OpenedByUserId = table.Column<Guid>(type: "uuid", nullable: true),
                    Reason = table.Column<int>(type: "integer", nullable: false),
                    Status = table.Column<int>(type: "integer", nullable: false),
                    Resolution = table.Column<int>(type: "integer", nullable: false),
                    Description = table.Column<string>(type: "character varying(2000)", maxLength: 2000, nullable: false),
                    ResolutionNote = table.Column<string>(type: "character varying(2000)", maxLength: 2000, nullable: true),
                    ResolvedByAdminId = table.Column<Guid>(type: "uuid", nullable: true),
                    FrozenPenaltyAmount = table.Column<decimal>(type: "numeric(18,2)", precision: 18, scale: 2, nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    ResolvedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OrderDisputes", x => x.Id);
                    table.ForeignKey(
                        name: "FK_OrderDisputes_Orders_OrderId",
                        column: x => x.OrderId,
                        principalTable: "Orders",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "TlsnProofRecords",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    OrderId = table.Column<Guid>(type: "uuid", nullable: true),
                    SteamTradeId = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    SessionId = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    ServerName = table.Column<string>(type: "character varying(200)", maxLength: 200, nullable: false),
                    TradeStatus = table.Column<int>(type: "integer", nullable: true),
                    SteamIdOther = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: true),
                    TransferredAssetIds = table.Column<string>(type: "character varying(2000)", maxLength: 2000, nullable: true),
                    TimeSettlementUnix = table.Column<long>(type: "bigint", nullable: true),
                    Outcome = table.Column<int>(type: "integer", nullable: false),
                    FailureCode = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    FailureReason = table.Column<string>(type: "character varying(1000)", maxLength: 1000, nullable: true),
                    PayloadJson = table.Column<string>(type: "jsonb", nullable: false),
                    ReceivedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TlsnProofRecords", x => x.Id);
                    table.ForeignKey(
                        name: "FK_TlsnProofRecords_Orders_OrderId",
                        column: x => x.OrderId,
                        principalTable: "Orders",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.SetNull);
                });

            migrationBuilder.CreateIndex(
                name: "IX_OrderDisputes_OrderId_OpenUnique",
                table: "OrderDisputes",
                column: "OrderId",
                unique: true,
                filter: "\"Status\" IN (0, 1)");

            migrationBuilder.CreateIndex(
                name: "IX_OrderDisputes_Reason",
                table: "OrderDisputes",
                column: "Reason");

            migrationBuilder.CreateIndex(
                name: "IX_OrderDisputes_Status",
                table: "OrderDisputes",
                column: "Status");

            migrationBuilder.CreateIndex(
                name: "IX_TlsnProofRecords_OrderId",
                table: "TlsnProofRecords",
                column: "OrderId");

            migrationBuilder.CreateIndex(
                name: "IX_TlsnProofRecords_Outcome",
                table: "TlsnProofRecords",
                column: "Outcome");

            migrationBuilder.CreateIndex(
                name: "IX_TlsnProofRecords_SteamTradeId",
                table: "TlsnProofRecords",
                column: "SteamTradeId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "OrderDisputes");

            migrationBuilder.DropTable(
                name: "TlsnProofRecords");

            migrationBuilder.DropColumn(
                name: "BuyerAssetMatchesListing",
                table: "SteamTrades");

            migrationBuilder.DropColumn(
                name: "BuyerReportedAt",
                table: "SteamTrades");

            migrationBuilder.DropColumn(
                name: "BuyerReportedOfferState",
                table: "SteamTrades");

            migrationBuilder.DropColumn(
                name: "BuyerSeenAssetIds",
                table: "SteamTrades");
        }
    }
}
