using SkinHex.Core.Entities;
using SkinHex.Core.Models;

namespace SkinHex.Core.Interfaces.Repositories;

public interface IListingRepository
{
    Task<Listing?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default);
    Task<Listing?> GetByIdWithItemAsync(Guid id, CancellationToken cancellationToken = default);
    Task<Listing?> GetByIdForUpdateAsync(Guid id, CancellationToken cancellationToken = default);
    Task<bool> HasActiveListingAsync(long steamAssetId, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<Listing>> GetActiveBySellerAsync(Guid sellerId, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<Listing>> GetUncancelledBySellerAsync(Guid sellerId, CancellationToken cancellationToken = default);
    Task<IReadOnlySet<long>> GetActiveSteamAssetIdsAsync(
        IReadOnlyCollection<long> steamAssetIds,
        CancellationToken cancellationToken = default);
    void Add(Listing listing);
    void AddRange(IEnumerable<Listing> listings);
    Task UpdateAsync(Listing listing, CancellationToken cancellationToken = default);
    Task<(IReadOnlyList<Listing> Items, int TotalCount)> GetActivePageAsync(
        GetListingsRequest request,
        CancellationToken cancellationToken = default);

    /// <summary>Мінімальна активна ціна по кожному переданому ItemId (лише ті, де є листинги).</summary>
    Task<IReadOnlyDictionary<int, decimal>> GetMinPriceByItemIdsAsync(
        IReadOnlyCollection<int> itemIds,
        CancellationToken cancellationToken = default);

    /// <summary>Мін./середня ціна і кількість активних листингів одного предмета.</summary>
    Task<ItemPriceSummary> GetItemPriceSummaryAsync(
        int itemId,
        CancellationToken cancellationToken = default);

    /// <summary>Sold listings (or with confirmed+ orders) for a given item, newest sales first.</summary>
    Task<(IReadOnlyList<SaleHistoryRow> Items, int TotalCount)> GetSaleHistoryPageAsync(
        int itemId,
        int page,
        int pageSize,
        CancellationToken cancellationToken = default);
}
