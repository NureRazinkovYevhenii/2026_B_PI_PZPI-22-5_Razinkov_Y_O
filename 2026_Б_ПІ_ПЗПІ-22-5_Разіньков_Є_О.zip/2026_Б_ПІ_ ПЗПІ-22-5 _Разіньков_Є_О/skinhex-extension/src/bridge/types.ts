export enum RequestType {
    PING = "PING",
    FETCH_STEAM_USER = "FETCH_STEAM_USER",
    CREATE_TRADE_OFFER = "CREATE_TRADE_OFFER",
    SYNC_PENDING_TRADES = "SYNC_PENDING_TRADES",
    CANCEL_TRADE_OFFER = "CANCEL_TRADE_OFFER",
    CHECK_TRADE_OFFER_STATUS = "CHECK_TRADE_OFFER_STATUS",
    CHECK_TRADE_STATUS = "CHECK_TRADE_STATUS",
    TLSN_PROVE = "TLSN_PROVE"
}

export interface PingRequest {
    type: RequestType.PING;
}

export interface PingResponse {
    success: boolean;
    version: string;
}

export interface FetchSteamUserRequest {
    type: RequestType.FETCH_STEAM_USER;
    expectedSteamID?: string;
}

export interface FetchSteamUserResponse {
    isLoggedIn: boolean;
    steamID?: string | null;
    sessionID?: string;
    token?: string;
    error?: string;
}


export interface CreateTradeOfferRequest {
    type: RequestType.CREATE_TRADE_OFFER;
    orderId: string;
    apiBaseUrl: string;
    authToken: string;
}

export interface CreateTradeOfferResponse {
    tradeOfferId?: string;
    offerState?: number;
    needsConfirmation?: boolean;
    error?: string;
}

export interface SyncPendingTradesRequest {
    type: RequestType.SYNC_PENDING_TRADES;
    apiBaseUrl: string;
    force?: boolean;
    /** Застаріле поле: sync тепер єдиний і покриває покупки та продажі одразу. */
    actorRole?: 'seller' | 'buyer' | 'all';
}

export interface SyncPendingTradesResponse {
    actorRole: string;
    pendingCount: number;
    sentUpdates: number;
    updated: number;
    failed: number;
    skipped?: boolean;
    reason?: string;
}

export interface CancelTradeOfferRequest {
    type: RequestType.CANCEL_TRADE_OFFER;
    tradeOfferId: string;
}

export interface CancelTradeOfferResponse {
    cancelled?: boolean;
    error?: string;
}

export interface CheckTradeOfferStatusRequest {
    type: RequestType.CHECK_TRADE_OFFER_STATUS;
    tradeOfferId: string;
    apiBaseUrl: string;
    orderId: string;
}

export interface CheckTradeOfferStatusResponse {
    offerState?: number;
    tradeId?: string;
    error?: string;
}

export interface CheckTradeStatusRequest {
    type: RequestType.CHECK_TRADE_STATUS;
    tradeId: string;
}

export interface CheckTradeStatusResponse {
    tradeStatus?: number;
    error?: string;
}

// ── TLSN Generic Proof Types ────────────────────────────────────────────────

/**
 * Опис HTTP-запиту для створення TLSN proof.
 * Повністю generic — worker не знає, до якого API він звертається.
 */
export interface TlsnRequestConfig {
    /** Повний URL запиту (включно з query params) */
    url: string;
    /** TLS server name для handshake (e.g. 'api.steampowered.com') */
    serverName: string;
    /** HTTP метод */
    method: 'GET' | 'POST';
    /** Додаткові заголовки (окрім Host, Connection, Accept-Encoding) */
    headers?: Record<string, string>;
    /** Тіло запиту (для POST) */
    body?: string;
    /** Рядки, які потрібно приховати (відредагувати) з надісланих даних у proof.
     *  Наприклад, access_token. Worker знайде всі входження та замінить їх на [REDACTED]. */
    secretsToRedact: string[];
    /** Макс. розмір отримуваних даних (default: 16384) */
    maxRecvData?: number;
    /** Макс. розмір надсиланих даних (default: 2048) */
    maxSentData?: number;
}

/**
 * Запит TLSN_PROVE від сайту до розширення.
 * Сайт передає бізнес-дані, а розширення саме формує TlsnRequestConfig.
 */
export interface TLSNProveRequest {
    type: RequestType.TLSN_PROVE;
    data: {
        /** Який саме proof потрібен:
         *  - trade_status — один конкретний трейд (GetTradeStatus);
         *  - trade_history — сторінка історії, підтверджує одразу багато трейдів (GetTradeHistory). */
        proofType: 'trade_status' | 'trade_history';
        /** Trade ID (для proofType = 'trade_status') */
        tradeId?: string;
        /** Trade IDs, які користувач хоче підтвердити (для trade_history — контекст сесії) */
        tradeIds?: string[];
        /** Optional SkinHex order id to correlate webhook session metadata */
        orderId?: string;
        /** SteamID64 користувача (для перевірки акаунта) */
        targetSteamId?: string;
    }
}

export interface OffscreenProofResponse {
    data?: any; // Тут лежатиме готовий payload
    error?: string;
}
