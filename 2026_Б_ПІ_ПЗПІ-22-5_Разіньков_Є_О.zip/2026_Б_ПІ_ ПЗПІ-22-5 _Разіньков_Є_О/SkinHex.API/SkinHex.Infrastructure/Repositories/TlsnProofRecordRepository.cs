using Microsoft.EntityFrameworkCore;
using SkinHex.Core.Entities;
using SkinHex.Core.Interfaces.Repositories;

namespace SkinHex.Infrastructure.Repositories;

public sealed class TlsnProofRecordRepository(SkinHexDbContext context) : ITlsnProofRecordRepository
{
    public void Add(TlsnProofRecord record) => context.TlsnProofRecords.Add(record);

    public Task<Guid?> GetOrderIdBySteamTradeIdAsync(string steamTradeId, CancellationToken ct = default) =>
        context.SteamTrades
            .AsNoTracking()
            .Where(t => t.TradeId == steamTradeId)
            .OrderByDescending(t => t.UpdatedAt)
            .Select(t => (Guid?)t.OrderId)
            .FirstOrDefaultAsync(ct);

    public Task<List<TlsnProofRecord>> GetByOrderIdAsync(Guid orderId, CancellationToken ct = default) =>
        context.TlsnProofRecords
            .AsNoTracking()
            .Where(r => r.OrderId == orderId)
            .OrderByDescending(r => r.ReceivedAt)
            .ToListAsync(ct);
}
