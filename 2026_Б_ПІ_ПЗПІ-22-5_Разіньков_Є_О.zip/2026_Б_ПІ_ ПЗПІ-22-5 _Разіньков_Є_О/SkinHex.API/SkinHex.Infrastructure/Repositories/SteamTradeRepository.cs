using SkinHex.Core.Entities;
using SkinHex.Core.Interfaces.Repositories;

namespace SkinHex.Infrastructure.Repositories;

public class SteamTradeRepository : ISteamTradeRepository
{
    private readonly SkinHexDbContext _context;

    public SteamTradeRepository(SkinHexDbContext context)
    {
        _context = context;
    }

    public async Task AddAsync(SteamTrade steamTrade, CancellationToken ct = default)
    {
        await _context.SteamTrades.AddAsync(steamTrade, ct);
    }
}
