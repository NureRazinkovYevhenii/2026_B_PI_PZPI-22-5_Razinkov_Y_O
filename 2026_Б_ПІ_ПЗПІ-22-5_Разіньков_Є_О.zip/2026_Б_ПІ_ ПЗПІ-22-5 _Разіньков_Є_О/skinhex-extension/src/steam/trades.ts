import type {
    CancelTradeOfferRequest,
    CancelTradeOfferResponse,
    CheckTradeStatusResponse,
    CreateTradeOfferRequest,
    CheckTradeStatusRequest,
    CheckTradeOfferStatusRequest
} from "../bridge/types";
import { fetchTradeInfo, createTradeAttempt, updateTradeAttempt } from "./skinhexApi";
import { TokenManager } from "./tokenManager";
import { SkinHexTokenManager } from "./skinhexToken";
export async function createTradeOffer(req: CreateTradeOfferRequest): Promise<any> {
    console.log(`[Extension] createTradeOffer: fetching trade-info for order ${req.orderId}...`);
    
    const authToken = await SkinHexTokenManager.getJwtToken();

    // 0. Запитати дані в SkinHex API
    const tradeInfo = await fetchTradeInfo(req.apiBaseUrl, req.orderId, authToken);
    
    console.log(`[Extension] trade-info received:`, {
        buyerSteamId: tradeInfo.buyerSteamId,
        buyerPartnerId: tradeInfo.buyerPartnerId,
        assetId: tradeInfo.assetId,
    });

    // 1. РОЗУМНЕ ОТРИМАННЯ СЕСІЇ
    const sessionCookie = await chrome.cookies.get({ url: 'https://steamcommunity.com', name: 'sessionid' });
    if (!sessionCookie) {
        throw new Error("sessionid not found. User is not authenticated in Steam.");
    }
    const sessionID = sessionCookie.value;

    // 2. ФОРМАТУВАННЯ ПРЕДМЕТІВ (CS2 = appid 730, contextid 2)
    // Продавець віддає свій предмет, покупець нічого не віддає.
    const itemMapper = (assetID: string) => ({
        appid: "730",                // <-- Рядок!
        contextid: "2",              // <-- Рядок!
        amount: 1,                   // <-- Число
        assetid: String(assetID),    // <-- Рядок!
    });

    const offerData = {
        newversion: true,
        version: 2, // 1 (give) + 0 (receive) + 1 = 2
        me: {
            assets: [itemMapper(String(tradeInfo.assetId))],
            currency: [],
            ready: false,
        },
        them: {
            assets: [],
            currency: [],
            ready: false,
        },
    };

    const params = {
        trade_offer_access_token: tradeInfo.buyerTradeToken,
    };

    // 3. ПІДГОТОВКА ФОРМИ (x-www-form-urlencoded)
    const formData = new URLSearchParams({
        sessionid: sessionID,
        serverid: "1",
        partner: tradeInfo.buyerSteamId,
        tradeoffermessage: `SkinHex Trade - Order ${req.orderId}`,
        json_tradeoffer: JSON.stringify(offerData),
        captcha: '',
        trade_offer_create_params: JSON.stringify(params),
    });

    // Примусово використовуємо english, щоб легше було парсити відповідь або просто як раніше
    const url = 'https://steamcommunity.com/tradeoffer/new/send?l=english';

    // 4. ВІДПРАВКА ЗАПИТУ
    const resp = await fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            // Referer підміняється автоматично через ruleset
        },
        body: formData.toString(),
    });

    const text = await resp.text();
    let json: any = null;
    
    try {
        json = JSON.parse(text);
    } catch (e: any) {
        console.error(`Error parsing the Steam response: ${e.toString()}`);
    }

    console.log(`[Extension] Steam response (CreateTradeOffer):`, { status: resp.status, json });

    if (resp.status !== 200 || !json) {
        return {
            error: json?.strError || text || `Steam returned status ${resp.status}`,
        };
    }

    const tradeOfferId = json.tradeofferid;
    const needsConfirmation = json.needs_mobile_confirmation || json.needs_email_confirmation;
    const offerState = needsConfirmation ? 9 : 2;

    try {
        // Send directly to Backend
        return await createTradeAttempt(req.apiBaseUrl, req.orderId, tradeOfferId, offerState, authToken);
    } catch (e: any) {
        return {
            error: `Trade created in Steam but failed to report to Backend: ${e.message}`,
            tradeOfferId,
            offerState
        };
    }
}

export async function checkTradeOfferStatus(req: CheckTradeOfferStatusRequest & { apiBaseUrl: string, orderId: string }): Promise<any> {
    const tokenManager = TokenManager.getInstance();
    const token = await tokenManager.getToken();

    const offerResp = await fetch(
        `https://api.steampowered.com/IEconService/GetTradeOffer/v1/?access_token=${token}&tradeofferid=${req.tradeOfferId}&language=en`,
        { credentials: 'include' }
    );

    if (!offerResp.ok) throw new Error(`API error while checking the offer: ${offerResp.status}`);
    
    const offerData = await offerResp.json();
    const offer = offerData.response?.offer;

    if (!offer) throw new Error(`Trade with ID ${req.tradeOfferId} not found`);

    const authToken = await SkinHexTokenManager.getJwtToken();

    let resolvedTradeStatus: number | null = null;
    if ((offer.trade_offer_state === 3 || offer.trade_offer_state === 11) && offer.tradeid) {
        try {
            const statusResp = await fetch(
                `https://api.steampowered.com/IEconService/GetTradeStatus/v1/?access_token=${token}&tradeid=${offer.tradeid}&language=en`,
                { credentials: 'include' }
            );
            if (statusResp.ok) {
                const statusData = await statusResp.json();
                const trade = statusData.response?.trades?.[0];
                if (trade && typeof trade.status === 'number') {
                    resolvedTradeStatus = trade.status;
                }
            }
        } catch (e) {
            console.error("Failed to fetch trade status details:", e);
        }
    }

    try {
        return await updateTradeAttempt(
            req.apiBaseUrl, 
            req.orderId, 
            req.tradeOfferId, 
            offer.trade_offer_state, 
            offer.tradeid || null, 
            resolvedTradeStatus,
            offer.time_updated || null,
            authToken
        );
    } catch (e: any) {
        return { error: `Steam check succeeded but backend report failed: ${e.message}` };
    }
}

export async function cancelTradeOffer(req: CancelTradeOfferRequest): Promise<CancelTradeOfferResponse> {
    if (!req.tradeOfferId?.trim()) {
        return { error: "tradeOfferId is required" };
    }

    const sessionCookie = await chrome.cookies.get({
        url: 'https://steamcommunity.com',
        name: 'sessionid'
    });

    if (!sessionCookie) {
        return { error: "sessionid not found. User is not authenticated in Steam." };
    }

    const formData = new URLSearchParams({
        sessionid: sessionCookie.value
    });

    const cancelUrl = `https://steamcommunity.com/tradeoffer/${encodeURIComponent(req.tradeOfferId)}/cancel`;
    const response = await fetch(cancelUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: formData.toString()
    });

    const raw = await response.text();
    let payload: any = null;
    try {
        payload = JSON.parse(raw);
    } catch {
        // Some Steam responses may not be JSON when blocked by auth/captcha.
    }

    if (!response.ok) {
        return { error: payload?.strError || payload?.error || `Steam returned status ${response.status}` };
    }

    const success = payload?.tradeofferid != null || payload?.success === true || payload?.strError == null;
    if (!success) {
        return { error: payload?.strError || "Steam cancel request failed" };
    }

    return { cancelled: true };
}

export async function checkTradeStatus(req: CheckTradeStatusRequest): Promise<CheckTradeStatusResponse> {
    const tokenManager = TokenManager.getInstance();
    const token = await tokenManager.getToken();

    const tradeResp = await fetch(
        `https://api.steampowered.com/IEconService/GetTradeStatus/v1/?access_token=${token}&tradeid=${req.tradeId}&language=en`,
        { credentials: 'include' }
    );

    if (!tradeResp.ok) throw new Error(`API error while checking the trade: ${tradeResp.status}`);

    const tradeData = await tradeResp.json();
    const tradeStatus = tradeData.response?.trades?.[0]?.status;

    return {
        tradeStatus: tradeStatus
    };
}