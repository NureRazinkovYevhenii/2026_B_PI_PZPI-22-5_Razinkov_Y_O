using System.Text.Json;
using SkinHex.Core.Interfaces.Steam;
using SkinHex.Core.Models;
using SkinHex.Core.Models.Steam;

namespace SkinHex.Infrastructure.SteamGateway;

public sealed class SteamGatewayClient(HttpClient httpClient) : ISteamGatewayClient
{
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

    public async Task<IReadOnlyList<InventoryItemDto>> GetInventoryAsync(
        SteamTradeLink tradeLink,
        bool forceReload = false,
        CancellationToken cancellationToken = default)
    {
        var requestUri =
            $"api/inventory/{tradeLink.SteamId64}?tradeUrl={Uri.EscapeDataString(tradeLink.Uri.AbsoluteUri)}";
        if (forceReload)
        {
            requestUri += "&forceReload=true";
        }

        using var response = await httpClient.GetAsync(requestUri, cancellationToken);
        var body = await response.Content.ReadAsStringAsync(cancellationToken);

        if (!response.IsSuccessStatusCode)
        {
            var problem = SteamGatewayProblemDetails.TryParse(body);
            throw new SteamGatewayException(
                problem?.Detail ?? problem?.Title ?? "SteamGateway request failed.",
                response.StatusCode,
                problem?.ErrorCode);
        }

        return JsonSerializer.Deserialize<IReadOnlyList<InventoryItemDto>>(body, JsonOptions)
            ?? Array.Empty<InventoryItemDto>();
    }

    public async Task ValidateTradeLinkAsync(
        SteamTradeLink tradeLink,
        CancellationToken cancellationToken = default)
    {
        var requestUri =
            $"api/inventory/{tradeLink.SteamId64}/validate?tradeUrl={Uri.EscapeDataString(tradeLink.Uri.AbsoluteUri)}";

        using var response = await httpClient.GetAsync(requestUri, cancellationToken);

        if (!response.IsSuccessStatusCode)
        {
            var body = await response.Content.ReadAsStringAsync(cancellationToken);
            var problem = SteamGatewayProblemDetails.TryParse(body);
            throw new SteamGatewayException(
                problem?.Detail ?? problem?.Title ?? "SteamGateway request failed.",
                response.StatusCode,
                problem?.ErrorCode);
        }
    }

    private sealed record SteamGatewayProblemDetails(string? Title, string? Detail, string? ErrorCode)
    {
        public static SteamGatewayProblemDetails? TryParse(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return null;
            }

            try
            {
                using var document = JsonDocument.Parse(value);
                var root = document.RootElement;

                return new SteamGatewayProblemDetails(
                    GetString(root, "title"),
                    GetString(root, "detail"),
                    GetString(root, "errorCode"));
            }
            catch (JsonException)
            {
                return null;
            }
        }

        private static string? GetString(JsonElement root, string propertyName)
        {
            return root.TryGetProperty(propertyName, out var property) &&
                   property.ValueKind == JsonValueKind.String
                ? property.GetString()
                : null;
        }
    }
}
