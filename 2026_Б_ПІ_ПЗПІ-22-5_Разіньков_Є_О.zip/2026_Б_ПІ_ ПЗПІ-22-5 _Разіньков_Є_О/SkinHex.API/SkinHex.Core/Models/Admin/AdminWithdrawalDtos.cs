namespace SkinHex.Core.Models.Admin;

public record AdminWithdrawalListItemDto(
    Guid Id,
    Guid UserId,
    string Username,
    decimal AmountUsd,
    decimal PlatformFeeUsd,
    decimal PayoutAmountUsd,
    string PayCurrency,
    string PayoutAddress,
    string? PayoutExtraId,
    string Status,
    string? RejectionReason,
    string? NowPaymentsPayoutId,
    DateTime CreatedAt,
    DateTime? ProcessedAt);

public record RejectWithdrawalRequest(string Reason);
