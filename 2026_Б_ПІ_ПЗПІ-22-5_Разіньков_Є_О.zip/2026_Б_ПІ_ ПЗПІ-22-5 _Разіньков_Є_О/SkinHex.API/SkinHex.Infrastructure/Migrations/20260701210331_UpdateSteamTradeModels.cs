﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SkinHex.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class UpdateSteamTradeModels : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "SteamStatus",
                table: "SteamTrades",
                newName: "OfferState");

            migrationBuilder.AddColumn<string>(
                name: "TradeId",
                table: "SteamTrades",
                type: "character varying(100)",
                maxLength: 100,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "TradeStatus",
                table: "SteamTrades",
                type: "integer",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "TradeId",
                table: "SteamTrades");

            migrationBuilder.DropColumn(
                name: "TradeStatus",
                table: "SteamTrades");

            migrationBuilder.RenameColumn(
                name: "OfferState",
                table: "SteamTrades",
                newName: "SteamStatus");
        }
    }
}
