using SkinHex.Core.Models.Steam;

namespace SkinHex.SteamGateway.Steam;

public sealed record SteamInventoryRequest(
    ulong SteamId64,
    uint PartnerAccountId,
    Uri? Referrer,
    string? Token,
    bool ForceReload)
{
    private const ulong SteamId64Offset = 76561197960265728UL;

    public static bool TryCreate(
        string steamId,
        string? tradeUrl,
        string? token,
        bool forceReload,
        out SteamInventoryRequest? request,
        out string error)
    {
        request = null;

        if (!ulong.TryParse(steamId, out var steamId64) ||
            steamId64 <= SteamId64Offset ||
            steamId64 - SteamId64Offset > uint.MaxValue)
        {
            error = "steamId must be a valid SteamID64.";
            return false;
        }

        var partnerAccountId = (uint)(steamId64 - SteamId64Offset);

        if (!string.IsNullOrWhiteSpace(tradeUrl))
        {
            if (!SteamTradeLink.TryParse(tradeUrl, out var parsedTradeLink, out error))
            {
                return false;
            }

            if (parsedTradeLink!.SteamId64 != steamId64)
            {
                error = "tradeUrl belongs to another Steam account.";
                return false;
            }

            request = new SteamInventoryRequest(
                steamId64,
                partnerAccountId,
                parsedTradeLink.Uri,
                parsedTradeLink.Token,
                forceReload);
            error = string.Empty;
            return true;
        }

        var normalizedToken = string.IsNullOrWhiteSpace(token) ? null : token.Trim();
        var referrer = normalizedToken is null
            ? null
            : new Uri($"https://steamcommunity.com/tradeoffer/new/?partner={partnerAccountId}&token={Uri.EscapeDataString(normalizedToken)}");

        request = new SteamInventoryRequest(steamId64, partnerAccountId, referrer, normalizedToken, forceReload);
        error = string.Empty;
        return true;
    }
}
