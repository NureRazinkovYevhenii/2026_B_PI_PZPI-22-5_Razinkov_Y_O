using global::SkinHex.Core.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Text.Json;
using SkinHex.Core.Models;

namespace SkinHex.Infrastructure.Seed;

public class SkinHexDbSeeder
{
    private readonly SkinHexDbContext _context;
    private readonly HttpClient _httpClient;
    private readonly ILogger<SkinHexDbSeeder> _logger;

    public SkinHexDbSeeder(SkinHexDbContext context, ILogger<SkinHexDbSeeder> logger)
    {
        _context = context;
        _logger = logger;
        _httpClient = new HttpClient();
    }

    public async Task SeedAsync()
    {
        var skinsJson = await _httpClient.GetStringAsync("https://raw.githubusercontent.com/ByMykel/CSGO-API/main/public/api/en/skins_not_grouped.json");
        var skinDtos = JsonSerializer.Deserialize<List<ByMykelSkinNotGrouped>>(skinsJson);

        var itemsToInsert = new List<Item>();

        if (skinDtos != null)
        {
            foreach (var dto in skinDtos)
            {
                var collectionName = dto.Collections?.FirstOrDefault()?.Name;

                var color = dto.Rarity?.Color?.TrimStart('#') ?? "eb4b4b";

                var item = new Item
                {
                    MarketHashName = dto.MarketHashName ?? dto.Name,
                    BaseName = ItemNameParser.GetCleanBaseName(dto.Name),
                    Category = dto.Category?.Name ?? "Unknown",
                    Weapon = dto.Weapon?.Name,
                    Rarity = dto.Rarity?.Name ?? "Base Grade",
                    Wear = dto.Wear?.Name,
                    IsStatTrak = dto.StatTrak,
                    IsSouvenir = dto.Souvenir,
                    Color = color,
                    ImageHash = ExtractHashFromUrl(dto.Image)
                };

                itemsToInsert.Add(item);
            }
        }

        var duplicates = itemsToInsert
        .GroupBy(x => x.MarketHashName)
        .Where(g => g.Count() > 1)
        .ToList();

        if (duplicates.Any())
        {
            _logger.LogWarning("⚠️ Found {Count} duplicate MarketHashName entries. Listing them:", duplicates.Count);

            foreach (var group in duplicates)
            {
                _logger.LogInformation("Duplicate: {Name} (occurs {Count} times)", group.Key, group.Count());
            }
        }
        else
        {
            _logger.LogInformation("✅ No duplicates found, the database is clean.");
        }

        var uniqueItems = itemsToInsert
            .DistinctBy(x => x.MarketHashName)
            .ToList();

        _logger.LogInformation("🚀 Inserting {Count} unique items into the database...", uniqueItems.Count);

        var batchSize = 5000;
        for (int i = 0; i < uniqueItems.Count; i += batchSize)
        {
            var batch = uniqueItems.Skip(i).Take(batchSize);
            await _context.Set<Item>().AddRangeAsync(batch);
            await _context.SaveChangesAsync();
        }

        _context.ChangeTracker.AutoDetectChangesEnabled = true;
        _logger.LogInformation("🎉 Database seeding completed successfully!");
    }

    private string ExtractHashFromUrl(string? url)
    {
        if (string.IsNullOrEmpty(url)) return string.Empty;
        return url.Split('/').Last().Replace(".png", "");
    }
}