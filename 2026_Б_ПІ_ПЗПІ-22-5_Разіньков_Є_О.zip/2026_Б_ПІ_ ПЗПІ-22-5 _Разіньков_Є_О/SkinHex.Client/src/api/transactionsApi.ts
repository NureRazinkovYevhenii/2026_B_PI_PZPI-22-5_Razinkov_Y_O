import type { AuthorizedFetch, PagedResult } from '../types';
import { readApiError } from '../utils/api';

export interface TransactionCrypto {
  payCurrency: string;
  network: string | null;
  amount: number | null;
  address: string | null;
  paymentId: string | null;
  txHash: string | null;
  explorerUrl: string | null;
}

export interface TransactionSkin {
  marketHashName: string;
  wear: string | null;
  float: number | null;
  partnerUsername: string;
  role: string; // "Purchase" | "Sale"
}

export interface Transaction {
  id: string;
  amount: number;
  type: string; // Deposit | Withdrawal | Purchase | Sale | Commission | Penalty | AdminAdjustment
  status: string;
  createdAt: string;
  crypto: TransactionCrypto | null;
  skin: TransactionSkin | null;
}

export async function getTransactions(
  fetcher: AuthorizedFetch,
  page = 1,
  pageSize = 10,
): Promise<PagedResult<Transaction>> {
  const params = new URLSearchParams({ page: String(page), pageSize: String(pageSize) });
  const response = await fetcher(`/transactions?${params}`);
  if (!response.ok) {
    throw new Error(await readApiError(response));
  }
  return response.json() as Promise<PagedResult<Transaction>>;
}
