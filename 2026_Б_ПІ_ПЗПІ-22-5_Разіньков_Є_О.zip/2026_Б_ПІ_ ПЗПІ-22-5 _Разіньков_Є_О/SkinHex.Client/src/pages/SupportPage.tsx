import { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import type { AuthState, AuthorizedFetch } from '../types';
import {
  createTicket,
  fetchMyTicket,
  fetchMyTickets,
  replyToMyTicket,
  takeSupportPrefill,
  type SupportTicketDetail,
  type SupportTicketListItem,
  type TicketCategory,
} from '../api/supportApi';

type SupportPageProps = {
  auth: AuthState | null;
  authorizedFetch: AuthorizedFetch;
  onRequireLogin: () => void;
};

const CATEGORIES: TicketCategory[] = ['Order', 'Deposit', 'Withdrawal', 'Account', 'Other'];

function formatDateTime(value: string | null | undefined): string {
  if (!value) return '—';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? '—' : date.toLocaleString();
}

function shortId(id: string): string {
  return id.length > 8 ? `${id.slice(0, 8)}…` : id;
}

export function SupportPage({ auth, authorizedFetch, onRequireLogin }: SupportPageProps) {
  const { t } = useTranslation();
  const [tickets, setTickets] = useState<SupportTicketListItem[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [prefill] = useState(() => takeSupportPrefill());

  const loadTickets = useCallback(async () => {
    if (!auth) return;
    setIsLoading(true);
    setError(null);
    try {
      setTickets(await fetchMyTickets(authorizedFetch));
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load tickets');
    } finally {
      setIsLoading(false);
    }
  }, [auth, authorizedFetch]);

  useEffect(() => {
    void loadTickets();
  }, [loadTickets]);

  // A deep-link from an order card opens the create form immediately.
  useEffect(() => {
    if (prefill) {
      setIsCreating(true);
    }
  }, [prefill]);

  if (!auth) {
    return (
      <section className="orders-section" aria-labelledby="support-title">
        <div className="inventory-head">
          <div>
            <p className="eyebrow">{t('support.eyebrow')}</p>
            <h2 id="support-title">{t('support.title')}</h2>
          </div>
        </div>
        <div className="inventory-state">
          <strong>{t('support.signInPrompt')}</strong>
          <p>{t('support.signInDescription')}</p>
          <button className="primary-button" onClick={onRequireLogin} type="button">
            {t('common.signInSteam')}
          </button>
        </div>
      </section>
    );
  }

  return (
    <section className="orders-section" aria-labelledby="support-title">
      <div className="inventory-head">
        <div>
          <p className="eyebrow">{t('support.eyebrow')}</p>
          <h2 id="support-title">{t('support.title')}</h2>
        </div>
        {!isCreating && !selectedId && (
          <button className="primary-button" type="button" onClick={() => setIsCreating(true)}>
            {t('support.newTicket')}
          </button>
        )}
      </div>

      {isCreating ? (
        <CreateTicketForm
          authorizedFetch={authorizedFetch}
          initialOrderId={prefill?.orderId ?? null}
          initialCategory={prefill?.category}
          initialSubject={prefill?.subject}
          onCancel={() => setIsCreating(false)}
          onCreated={(detail) => {
            setIsCreating(false);
            setSelectedId(detail.id);
            void loadTickets();
          }}
        />
      ) : selectedId ? (
        <TicketThread
          authorizedFetch={authorizedFetch}
          ticketId={selectedId}
          onBack={() => {
            setSelectedId(null);
            void loadTickets();
          }}
        />
      ) : error ? (
        <div className="inventory-state inventory-error" role="alert">
          <strong>{t('support.unavailable')}</strong>
          <p>{error}</p>
        </div>
      ) : isLoading ? (
        <div className="inventory-state">
          <strong>{t('support.loading')}</strong>
        </div>
      ) : tickets.length === 0 ? (
        <div className="inventory-state">
          <strong>{t('support.noTickets')}</strong>
          <p>{t('support.noTicketsHint')}</p>
        </div>
      ) : (
        <div className="admin-table-wrap">
          <table className="admin-table">
            <thead>
              <tr>
                <th>{t('support.columns.subject')}</th>
                <th>{t('support.columns.category')}</th>
                <th>{t('support.columns.status')}</th>
                <th style={{ textAlign: 'center' }}>{t('support.columns.messages')}</th>
                <th>{t('support.columns.updated')}</th>
              </tr>
            </thead>
            <tbody>
              {tickets.map((ticket) => (
                <tr key={ticket.id} className="admin-row" onClick={() => setSelectedId(ticket.id)}>
                  <td style={{ fontWeight: 600, color: 'var(--text-h)' }}>
                    {ticket.subject}
                    {ticket.orderId && <span className="admin-order-tag">#{shortId(ticket.orderId)}</span>}
                  </td>
                  <td>{t(`support.categories.${ticket.category.toLowerCase()}`)}</td>
                  <td>
                    <span className={`trade-card__status trade-card__status--${ticket.status.toLowerCase()}`}>
                      {t(`support.statuses.${ticket.status.toLowerCase()}`)}
                    </span>
                  </td>
                  <td style={{ textAlign: 'center' }}>{ticket.messagesCount}</td>
                  <td style={{ color: 'var(--text-muted)', fontSize: 13 }}>{formatDateTime(ticket.updatedAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}

type CreateTicketFormProps = {
  authorizedFetch: AuthorizedFetch;
  initialOrderId: string | null;
  initialCategory?: TicketCategory;
  initialSubject?: string;
  onCancel: () => void;
  onCreated: (detail: SupportTicketDetail) => void;
};

function CreateTicketForm({ authorizedFetch, initialOrderId, initialCategory, initialSubject, onCancel, onCreated }: CreateTicketFormProps) {
  const { t } = useTranslation();
  const [subject, setSubject] = useState(initialSubject ?? '');
  const [category, setCategory] = useState<TicketCategory>(initialCategory ?? (initialOrderId ? 'Order' : 'Other'));
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject.trim() || !message.trim()) return;
    setBusy(true);
    setError(null);
    try {
      const detail = await createTicket(authorizedFetch, {
        subject: subject.trim(),
        category,
        message: message.trim(),
        orderId: initialOrderId,
      });
      onCreated(detail);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create ticket');
    } finally {
      setBusy(false);
    }
  };

  return (
    <form className="glass-panel" style={{ padding: 24, borderRadius: 12, display: 'flex', flexDirection: 'column', gap: 16, maxWidth: 640 }} onSubmit={onSubmit}>
      <h3 style={{ margin: 0 }}>{t('support.form.title')}</h3>

      {initialOrderId && (
        <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>
          {t('support.form.linkedOrder')}: <span className="admin-order-tag">#{shortId(initialOrderId)}</span>
        </div>
      )}

      <label style={{ display: 'flex', flexDirection: 'column', gap: 6, fontSize: 13, color: 'var(--text-muted)' }}>
        {t('support.form.category')}
        <select className="admin-select" value={category} onChange={(e) => setCategory(e.target.value as TicketCategory)}>
          {CATEGORIES.map((c) => (
            <option key={c} value={c}>{t(`support.categories.${c.toLowerCase()}`)}</option>
          ))}
        </select>
      </label>

      <label style={{ display: 'flex', flexDirection: 'column', gap: 6, fontSize: 13, color: 'var(--text-muted)' }}>
        {t('support.form.subject')}
        <input
          className="admin-input"
          maxLength={200}
          placeholder={t('support.form.subjectPlaceholder')}
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
        />
      </label>

      <label style={{ display: 'flex', flexDirection: 'column', gap: 6, fontSize: 13, color: 'var(--text-muted)' }}>
        {t('support.form.message')}
        <textarea
          className="admin-textarea"
          maxLength={4000}
          placeholder={t('support.form.messagePlaceholder')}
          rows={6}
          value={message}
          onChange={(e) => setMessage(e.target.value)}
        />
      </label>

      {error && <div className="admin-inline-error">{error}</div>}

      <div style={{ display: 'flex', gap: 8 }}>
        <button className="primary-button" type="submit" disabled={busy || !subject.trim() || !message.trim()}>
          {busy ? t('support.form.sending') : t('support.form.submit')}
        </button>
        <button className="secondary-button" type="button" onClick={onCancel} disabled={busy}>
          {t('support.form.cancel')}
        </button>
      </div>
    </form>
  );
}

type TicketThreadProps = {
  authorizedFetch: AuthorizedFetch;
  ticketId: string;
  onBack: () => void;
};

function TicketThread({ authorizedFetch, ticketId, onBack }: TicketThreadProps) {
  const { t } = useTranslation();
  const [detail, setDetail] = useState<SupportTicketDetail | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [reply, setReply] = useState('');
  const [busy, setBusy] = useState(false);

  const reload = useCallback(async () => {
    try {
      setDetail(await fetchMyTicket(authorizedFetch, ticketId));
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load ticket');
    }
  }, [authorizedFetch, ticketId]);

  useEffect(() => {
    void reload();
  }, [reload]);

  const onReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reply.trim()) return;
    setBusy(true);
    try {
      setDetail(await replyToMyTicket(authorizedFetch, ticketId, reply.trim()));
      setReply('');
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Reply failed');
    } finally {
      setBusy(false);
    }
  };

  const isClosed = detail?.status === 'Closed';

  return (
    <div className="glass-panel" style={{ padding: 24, borderRadius: 12, maxWidth: 760 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
        <button className="secondary-button" type="button" onClick={onBack}>
          ← {t('support.thread.back')}
        </button>
        <div>
          <h3 style={{ margin: 0 }}>{detail?.subject ?? t('support.loading')}</h3>
          {detail && (
            <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginTop: 4, fontSize: 13, color: 'var(--text-muted)' }}>
              <span className={`trade-card__status trade-card__status--${detail.status.toLowerCase()}`}>
                {t(`support.statuses.${detail.status.toLowerCase()}`)}
              </span>
              <span>{t(`support.categories.${detail.category.toLowerCase()}`)}</span>
              {detail.orderId && <span className="admin-order-tag">#{shortId(detail.orderId)}</span>}
            </div>
          )}
        </div>
      </div>

      {error && <div className="admin-inline-error">{error}</div>}

      {detail && (
        <>
          <div className="admin-thread">
            {detail.messages.map((m) => (
              <div key={m.id} className={`admin-msg ${m.isFromSupport ? 'admin-msg-support' : 'admin-msg-user'}`}>
                <div className="admin-msg-meta">
                  {m.isFromSupport ? t('support.thread.support') : t('support.thread.you')} · {formatDateTime(m.createdAt)}
                </div>
                <div className="admin-msg-body">{m.body}</div>
              </div>
            ))}
          </div>

          {!isClosed ? (
            <form className="admin-reply-form" onSubmit={onReply}>
              <textarea
                className="admin-textarea"
                maxLength={4000}
                placeholder={t('support.thread.replyPlaceholder')}
                rows={3}
                value={reply}
                onChange={(e) => setReply(e.target.value)}
              />
              <div style={{ marginTop: 8 }}>
                <button className="primary-button" type="submit" disabled={busy || !reply.trim()}>
                  {busy ? t('support.form.sending') : t('support.thread.send')}
                </button>
              </div>
            </form>
          ) : (
            <div style={{ marginTop: 12, fontSize: 13, color: 'var(--text-muted)' }}>{t('support.thread.closed')}</div>
          )}
        </>
      )}
    </div>
  );
}
