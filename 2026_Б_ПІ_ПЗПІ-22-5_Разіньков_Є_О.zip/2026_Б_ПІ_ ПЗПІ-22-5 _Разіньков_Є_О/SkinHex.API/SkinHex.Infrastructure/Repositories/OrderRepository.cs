using Microsoft.EntityFrameworkCore;
using SkinHex.Core.Entities;
using SkinHex.Core.Interfaces.Repositories;
using SkinHex.Core.Models.Orders;
using SkinHex.Core.Services;

namespace SkinHex.Infrastructure.Repositories;

public class OrderRepository : IOrderRepository
{
    private readonly SkinHexDbContext _context;

    public OrderRepository(SkinHexDbContext context)
    {
        _context = context;
    }

    public Task<Order?> GetByIdAsync(Guid id, CancellationToken ct = default)
    {
        return _context.Orders
            .Include(o => o.SteamTrades)
            .FirstOrDefaultAsync(o => o.Id == id, ct);
    }

    public Task<Order?> GetByIdWithDetailsAsync(Guid id, CancellationToken ct = default)
    {
        return _context.Orders
            .Include(o => o.Buyer)
            .Include(o => o.Seller)
            .Include(o => o.Listing)
            .Include(o => o.SteamTrades)
            .FirstOrDefaultAsync(o => o.Id == id, ct);
    }

    public Task<Order?> GetByIdForNotificationAsync(Guid id, CancellationToken ct = default)
    {
        return _context.Orders
            .Include(o => o.Buyer)
            .Include(o => o.Seller)
            .Include(o => o.Listing)
                .ThenInclude(l => l.Item)
            .AsNoTracking()
            .FirstOrDefaultAsync(o => o.Id == id, ct);
    }

    public async Task<IEnumerable<Order>> GetOrdersByUserIdAsync(Guid userId, CancellationToken ct = default)
    {
        return await _context.Orders
            .Include(o => o.Buyer)
            .Include(o => o.Seller)
            .Include(o => o.Listing)
                .ThenInclude(l => l.Item)
            .Include(o => o.SteamTrades)
            .Where(o => o.BuyerId == userId || o.SellerId == userId)
            .OrderByDescending(o => o.CreatedAt)
            .AsNoTracking()
            .ToListAsync(ct);
    }

    public async Task AddAsync(Order order, CancellationToken ct = default)
    {
        await _context.Orders.AddAsync(order, ct);
    }

    public Task UpdateAsync(Order order, CancellationToken ct = default)
    {
        _context.Orders.Update(order);
        return Task.CompletedTask;
    }

    public async Task<int> ExecuteConfirmAsync(Guid orderId, DateTime confirmedAt, CancellationToken ct = default)
    {
        return await _context.Orders
            .Where(o => o.Id == orderId && o.Status == OrderStatus.Pending)
            .ExecuteUpdateAsync(s => s
                .SetProperty(o => o.Status, OrderStatus.Confirmed)
                .SetProperty(o => o.ConfirmedAt, confirmedAt)
                .SetProperty(o => o.UpdatedAt, DateTime.UtcNow), ct);
    }

    public async Task<int> ExecuteCancelAsync(Guid orderId, CancelledBy cancelledBy, string? reason, DateTime cancelledAt, CancellationToken ct = default)
    {
        return await _context.Orders
            .Where(o => o.Id == orderId &&
                        (o.Status == OrderStatus.Pending ||
                         o.Status == OrderStatus.Confirmed ||
                         o.Status == OrderStatus.TradeSent ||
                         o.Status == OrderStatus.InEscrow))
            .ExecuteUpdateAsync(s => s
                .SetProperty(o => o.Status, OrderStatus.Cancelled)
                .SetProperty(o => o.CancelledBy, cancelledBy)
                .SetProperty(o => o.CancelReason, reason)
                .SetProperty(o => o.CancelledAt, cancelledAt)
                .SetProperty(o => o.UpdatedAt, DateTime.UtcNow), ct);
    }

    public async Task<int> ExecuteTradeLifecycleUpdateAsync(
        Guid orderId,
        OrderStatus status,
        DateTime? tradeSentAt,
        DateTime? tradeAcceptDeadline,
        DateTime? acceptedAt,
        CancellationToken ct = default)
    {
        return await _context.Orders
            .Where(o => o.Id == orderId)
            .ExecuteUpdateAsync(s => s
                .SetProperty(o => o.Status, status)
                .SetProperty(o => o.TradeSentAt, tradeSentAt)
                .SetProperty(o => o.TradeAcceptDeadline, tradeAcceptDeadline)
                .SetProperty(o => o.AcceptedAt, acceptedAt)
                .SetProperty(o => o.UpdatedAt, DateTime.UtcNow), ct);
    }

    public async Task<int> ExecuteSteamTradeUpdateAsync(Guid tradeId, SteamOfferState offerState, DateTime updatedAt, CancellationToken ct = default)
    {
        return await _context.SteamTrades
            .Where(t => t.Id == tradeId)
            .ExecuteUpdateAsync(s => s
                .SetProperty(t => t.OfferState, offerState)
                .SetProperty(t => t.UpdatedAt, updatedAt), ct);
    }

    public async Task<int> ExecuteSteamTradeInsertAsync(SteamTrade trade, CancellationToken ct = default)
    {
        return await _context.Database.ExecuteSqlInterpolatedAsync(
            $@"INSERT INTO ""SteamTrades"" (""Id"", ""OrderId"", ""TradeOfferId"", ""OfferState"", ""TradeStatus"", ""TradeId"", ""CreatedAt"", ""UpdatedAt"") 
              VALUES ({trade.Id}, {trade.OrderId}, {trade.TradeOfferId}, {trade.OfferState}, {trade.TradeStatus}, {trade.TradeId}, {trade.CreatedAt}, {trade.UpdatedAt}) 
              ON CONFLICT (""TradeOfferId"") DO NOTHING", ct);
    }

    public async Task<SteamTrade?> GetSteamTradeByOfferIdAsync(string tradeOfferId, CancellationToken ct = default)
    {
        return await _context.SteamTrades.AsNoTracking().FirstOrDefaultAsync(t => t.TradeOfferId == tradeOfferId, ct);
    }

    public async Task<Order?> GetBySteamTradeIdWithDetailsAsync(string steamTradeId, CancellationToken ct = default)
    {
        return await _context.Orders
            .Include(o => o.Buyer)
            .Include(o => o.Seller)
            .Include(o => o.Listing)
            .Include(o => o.SteamTrades)
            .FirstOrDefaultAsync(o => o.SteamTrades.Any(t => t.TradeId == steamTradeId), ct);
    }

    public async Task<IReadOnlyCollection<PendingTradeSyncItemDto>> GetPendingTradeSyncItemsAsync(
        Guid userId,
        TradeSyncActorRole? actorRole,
        CancellationToken ct = default)
    {
        var query = _context.Orders
            .AsNoTracking()
            .Where(o => o.Status == OrderStatus.TradeSent || o.Status == OrderStatus.InEscrow);

        query = actorRole switch
        {
            TradeSyncActorRole.Seller => query.Where(o => o.SellerId == userId),
            TradeSyncActorRole.Buyer => query.Where(o => o.BuyerId == userId),
            // Unified sync: one request covers the user's purchases and sales alike.
            _ => query.Where(o => o.SellerId == userId || o.BuyerId == userId)
        };

        var rows = await query
            .Select(o => new
            {
                o.Id,
                o.SellerId,
                o.AcceptedAt,
                ExpectedAssetId = (long?)o.Listing.SteamAssetId,
                BuyerSteamId = o.Buyer.SteamId,
                SellerSteamId = o.Seller.SteamId,
                LatestTrade = o.SteamTrades
                    .OrderByDescending(t => t.UpdatedAt)
                    .FirstOrDefault()
            })
            .Where(x => x.LatestTrade != null)
            .ToListAsync(ct);

        return rows
            .Select(x =>
            {
                var isSeller = x.SellerId == userId;
                return new PendingTradeSyncItemDto(
                    x.Id,
                    x.LatestTrade!.TradeOfferId,
                    x.LatestTrade.TradeId,
                    x.LatestTrade.OfferState,
                    x.LatestTrade.TradeStatus,
                    x.LatestTrade.SteamUpdatedAt.HasValue
                        ? new DateTimeOffset(x.LatestTrade.SteamUpdatedAt.Value).ToUnixTimeSeconds()
                        : null,
                    x.ExpectedAssetId,
                    // The counterparty from the actor's point of view.
                    isSeller ? x.BuyerSteamId : x.SellerSteamId,
                    isSeller ? "seller" : "buyer",
                    x.AcceptedAt.HasValue
                        ? new DateTimeOffset(OrderService.CalculateEscrowEndsAt(x.AcceptedAt.Value)).ToUnixTimeSeconds()
                        : null,
                    x.LatestTrade.BuyerReportedOfferState);
            })
            .ToList();
    }

    public async Task<List<Order>> GetExpiredPendingOrdersAsync(DateTime now, CancellationToken ct = default)
    {
        return await _context.Orders
            .Include(o => o.Buyer)
            .Include(o => o.Seller)
            .Include(o => o.Listing)
            .Where(o => o.Status == OrderStatus.Pending && o.ConfirmDeadline < now)
            .ToListAsync(ct);
    }

    public async Task<List<Order>> GetConfirmedOrdersWithTradesAsync(CancellationToken ct = default)
    {
        return await _context.Orders
            .Include(o => o.SteamTrades)
            .Where(o => o.Status == OrderStatus.Confirmed)
            .ToListAsync(ct);
    }

    public async Task<Order?> GetByIdWithTradesAsync(Guid orderId, CancellationToken ct = default)
    {
        return await _context.Orders
            .Include(o => o.SteamTrades)
            .FirstOrDefaultAsync(o => o.Id == orderId, ct);
    }
}
