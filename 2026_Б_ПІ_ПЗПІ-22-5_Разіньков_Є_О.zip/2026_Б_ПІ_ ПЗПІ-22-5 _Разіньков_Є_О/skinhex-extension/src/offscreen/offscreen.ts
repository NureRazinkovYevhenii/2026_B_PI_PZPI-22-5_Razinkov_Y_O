import * as Comlink from 'comlink';

console.log("SkinHex Offscreen document is starting...");

// Use chrome.runtime.getURL to load worker.js by its stable, non-hashed name.
// This works because worker.ts is compiled as a named entry in vite.config.ts.
const workerUrl = chrome.runtime.getURL('worker.js');
const worker = new Worker(workerUrl, { type: 'module' });
const { init, runTlsnProof }: any = Comlink.wrap(worker);

// 1. Init WASM inside the worker
console.log("[Offscreen] Calling init() via Comlink...");
const wasmReadyPromise = init()
    .then(() => console.log("[Offscreen] ✅ WASM loaded into memory successfully!"))
    .catch((e: any) => {
        console.error("[Offscreen] ❌ Fatal error while loading WASM:", e);
        throw e;
    });

let isProofRunning = false;

chrome.runtime.onMessage.addListener((request, _sender, sendResponse) => {
    if (request.target !== 'offscreen') return false;

    if (request.type === 'TLSN_PROVE') {
        if (isProofRunning) {
            sendResponse({ error: "Proof already running. Please wait." });
            return true;
        }
        isProofRunning = true;

        wasmReadyPromise
            .then(() => runTlsnProof(request.data))
            .then((payload: any) => {
                isProofRunning = false;
                sendResponse({ data: payload });
            })
            .catch((e: any) => {
                isProofRunning = false;
                sendResponse({ error: e.message || "Unknown error" });
            });
        return true;
    }
});
