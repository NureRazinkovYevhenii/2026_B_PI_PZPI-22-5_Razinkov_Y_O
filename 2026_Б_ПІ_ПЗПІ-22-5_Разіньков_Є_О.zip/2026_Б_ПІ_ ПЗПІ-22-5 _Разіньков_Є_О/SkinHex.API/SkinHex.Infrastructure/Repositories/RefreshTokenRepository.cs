using Microsoft.EntityFrameworkCore;
using SkinHex.Core.Entities;
using SkinHex.Core.Interfaces;

namespace SkinHex.Infrastructure.Repositories;

public sealed class RefreshTokenRepository : IRefreshTokenRepository
{
    private readonly SkinHexDbContext _dbContext;

    public RefreshTokenRepository(SkinHexDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public Task<RefreshToken?> GetByTokenWithUserAsync(
        string token,
        CancellationToken cancellationToken = default)
    {
        return _dbContext.RefreshTokens
            .Include(x => x.User)
            .FirstOrDefaultAsync(x => x.Token == token, cancellationToken);
    }

    public Task<List<RefreshToken>> GetByUserIdAsync(Guid id, CancellationToken ct)
    {
        return _dbContext.RefreshTokens
         .Where(x => x.UserId == id && !x.IsRevoked)
         .ToListAsync(ct);
    }

    public async Task AddAsync(RefreshToken refreshToken, CancellationToken cancellationToken = default)
    {
        await _dbContext.RefreshTokens.AddAsync(refreshToken, cancellationToken);
    }

}
