using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using SkinHex.Core.Options;
using SkinHex.Infrastructure.Services;
using Xunit;

namespace SkinHex.Core.Tests.Webhooks;

public class NowPaymentsSignatureTests
{
    private static NowPaymentsService CreateService(string ipnSecret)
    {
        var options = Microsoft.Extensions.Options.Options.Create(new NowPaymentsOptions
        {
            BaseUrl = "https://api.nowpayments.io",
            IpnSecret = ipnSecret
        });
        return new NowPaymentsService(new HttpClient(), options, NullLogger<NowPaymentsService>.Instance);
    }

    // Real IPN body + signature captured from NOWPayments. The payload contains a nested `fee`
    // object, which must be canonicalized as an object (with sorted keys), not an escaped string.
    private const string RealBody =
        "{\"payment_id\":4848759072,\"invoice_id\":4388832543,\"payment_status\":\"waiting\"," +
        "\"pay_address\":\"0x6B104Aac1FE05722273B4f51F291bb9Dd607c61f\",\"price_amount\":5.05," +
        "\"price_currency\":\"usd\",\"pay_amount\":5.04472159,\"actually_paid\":0," +
        "\"actually_paid_at_fiat\":0,\"pay_currency\":\"usdtbsc\"," +
        "\"order_id\":\"32476f44-f63f-4055-9bdd-27e08fe4663f\",\"order_description\":null," +
        "\"purchase_id\":\"6098551373\",\"outcome_amount\":4.986086,\"outcome_currency\":\"usdtbsc\"," +
        "\"payment_extra_ids\":null,\"parent_payment_id\":null,\"payin_extra_id\":null," +
        "\"fee\":{\"currency\":\"usdtbsc\",\"depositFee\":0,\"serviceFee\":0,\"withdrawalFee\":0}}";

    private const string RealSecret = "SxBpyeG9wX4rreoQXjsY2q/8cHAZjTIg";
    private const string RealSignature =
        "d658a9045bacff36ae3aea8ed4923e2c7c5cc34baee3a16c41a42ad2c7e68cb4" +
        "26966d8cf12ad312163fb890896ab92582c205f9500ed1999fe6915e2c03de3f";

    [Fact]
    public void VerifyIpnSignature_RealPayloadWithNestedFeeObject_Valid()
    {
        var service = CreateService(RealSecret);
        Assert.True(service.VerifyIpnSignature(RealBody, RealSignature));
    }

    [Fact]
    public void VerifyIpnSignature_WrongSecret_Invalid()
    {
        var service = CreateService("Ywlv7AJfuJv/pciRajAHP5o40uTceZad");
        Assert.False(service.VerifyIpnSignature(RealBody, RealSignature));
    }

    [Fact]
    public void VerifyIpnSignature_TamperedBody_Invalid()
    {
        var service = CreateService(RealSecret);
        var tampered = RealBody.Replace("\"actually_paid\":0", "\"actually_paid\":9999");
        Assert.False(service.VerifyIpnSignature(tampered, RealSignature));
    }
}
