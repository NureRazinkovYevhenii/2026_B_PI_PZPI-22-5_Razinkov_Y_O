/**
 * spawner.ts - compiled to dist/spawner.js
 *
 * tlsn-wasm already registers the web_spawn_* message handlers as a top-level
 * side effect of importing the package. Keep this file intentionally thin:
 * adding our own duplicate handlers races on the same WASM spawner pointer and
 * can make initialize() hang forever.
 */

import * as tlsnWasm from 'tlsn-wasm';

// Keep the import alive: tlsn-wasm registers the web_spawn_* listeners at
// module top level. Without this assignment Rollup can erase the import.
(self as any).__TLSN_WASM_SPAWNER_MODULE__ = tlsnWasm;

// Suppress WASM unaligned-access traps during thread teardown.
// Must use self.onerror + return true — addEventListener('error') doesn't catch WASM traps.
(self as any).onerror = (
    message: string, _src: string, _line: number, _col: number, _err: unknown
) => {
    if (typeof message === 'string' &&
        (message.includes('unaligned') || message.includes('unreachable'))) {
        console.debug('[Spawner] Suppressed WASM cleanup trap:', message);
        return true;
    }
    return false;
};
