using Hangfire;
using Hangfire.PostgreSql;
using Microsoft.EntityFrameworkCore;
using SkinHex.API.Errors;
using SkinHex.API.Extensions;
using SkinHex.Core.Interfaces;
using SkinHex.Core.Interfaces.Services;
using SkinHex.Core.Services;
using SkinHex.Infrastructure;
using SkinHex.Infrastructure.Seed;

namespace SkinHex.API;

public class Program
{
    public static async Task Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        builder.Services.AddInfrastructure(builder.Configuration);

        builder.Services.AddSkinHexAuthentication(builder.Configuration);
        builder.Services.AddSkinHexCors(builder.Configuration);

        builder.Services.AddControllers();
        builder.Services.AddProblemDetails();
        builder.Services.AddExceptionHandler<GlobalExceptionHandler>();

        builder.Services.AddMemoryCache();

        var connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
            ?? throw new InvalidOperationException("DefaultConnection is not configured.");

        builder.Services.AddHangfire(configuration =>
            configuration.UsePostgreSqlStorage(options => options.UseNpgsqlConnection(connectionString)));
        builder.Services.AddHangfireServer();

        builder.Services.AddEndpointsApiExplorer();
        builder.Services.AddSwaggerGen();

        builder.Services.AddScoped<IAuthService, AuthService>();
        builder.Services.AddScoped<IUserService, UserService>();
        builder.Services.AddScoped<IMarketService, MarketService>();
        builder.Services.AddScoped<IOrderService, OrderService>();
        builder.Services.AddScoped<ITradeService, TradeService>();
        builder.Services.AddScoped<ITlsnWebhookProcessor, TlsnWebhookProcessor>();
        builder.Services.AddScoped<IDisputeService, DisputeService>();

        builder.Services.AddSignalR();
        builder.Services.AddSingleton<IRealtimeNotifier, SkinHex.API.Services.SignalRRealtimeNotifier>();
        builder.Services.AddScoped<INotificationService, NotificationService>();
        builder.Services.AddScoped<INotificationJobs, NotificationJobs>();

        builder.Services.Configure<SkinHex.Core.Options.OrderOptions>(builder.Configuration.GetSection("Orders"));
        builder.Services.AddScoped<IOrderTimeoutJobs, SkinHex.API.Jobs.OrderTimeoutJobs>();
        builder.Services.AddScoped<IScreenshotJobs, ScreenshotJobs>();

        var app = builder.Build();

        // In containers Postgres starts empty; applying migrations on boot makes the API
        // self-sufficient. Opt-in via config (compose sets RunMigrationsOnStartup=true) so the
        // existing local `dotnet run` workflow against an already-migrated DB is unchanged.
        if (builder.Configuration.GetValue<bool>("RunMigrationsOnStartup"))
        {
            using var scope = app.Services.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<SkinHexDbContext>();
            await db.Database.MigrateAsync();
        }

        app.UseExceptionHandler();

        if (app.Environment.IsDevelopment())
        {
            app.UseSwagger();
            app.UseSwaggerUI();
            app.UseHangfireDashboard("/hangfire");
        }

        app.UseWhen(
            context => !context.Request.Path.StartsWithSegments("/api/tlsn/webhook"),
            appBuilder => appBuilder.UseHttpsRedirection());

        app.UseCors("FrontendPolicy");

        // Роздача збережених скріншотів предметів (front/back за inspect-посиланням).
        var screenshotOptions = app.Services
            .GetRequiredService<Microsoft.Extensions.Options.IOptions<SkinHex.Core.Options.ScreenshotOptions>>()
            .Value;
        var screenshotRoot = Path.GetFullPath(screenshotOptions.StorageRootPath);
        Directory.CreateDirectory(screenshotRoot);
        app.UseStaticFiles(new StaticFileOptions
        {
            FileProvider = new Microsoft.Extensions.FileProviders.PhysicalFileProvider(screenshotRoot),
            RequestPath = screenshotOptions.PublicBasePath
        });

        app.UseAuthentication();
        app.UseAuthorization();

        app.MapControllers();
        app.MapHub<SkinHex.API.Hubs.NotificationsHub>("/hubs/notifications");

        app.Run();
    }
}
