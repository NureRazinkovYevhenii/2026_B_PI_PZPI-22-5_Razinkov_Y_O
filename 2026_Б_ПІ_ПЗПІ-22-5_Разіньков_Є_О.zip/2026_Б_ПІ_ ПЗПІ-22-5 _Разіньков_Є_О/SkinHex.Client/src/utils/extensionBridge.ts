/**
 * Bridge for communicating with the SkinHex P2P Chrome Extension.
 * Uses chrome.runtime.sendMessage to send commands to the extension's
 * background service worker.
 */

const EXTENSION_ID = 'kbpdfpppfkhkdjcacaackddhmkcdgaba';

function getChromeRuntime(): any {
  return (globalThis as any)?.chrome?.runtime;
}

type ExtensionResponse<T = any> = {
  success: boolean;
  data?: T;
  error?: string;
};

function isChromeExtensionAvailable(): boolean {
  return !!getChromeRuntime()?.sendMessage;
}

export async function sendToExtension<T = any>(request: Record<string, any>): Promise<T> {
  if (!isChromeExtensionAvailable()) {
    throw new Error('SkinHex Extension is not available. Make sure Chrome is used and the extension is installed.');
  }

  return new Promise<T>((resolve, reject) => {
    const runtime = getChromeRuntime();
    if (!runtime?.sendMessage) {
      reject(new Error('Chrome runtime API is unavailable'));
      return;
    }

    console.log('🚀 Відправка команди в розширення:', request);

    runtime.sendMessage(
      EXTENSION_ID,
      request,
      (response: ExtensionResponse<T> | undefined) => {
        if (runtime.lastError) {
          console.error('❌ Помилка з\'єднання з розширенням:', runtime.lastError.message);
          reject(new Error(runtime.lastError.message ?? 'Extension communication failed'));
          return;
        }

        if (!response) {
          console.error('❌ Немає відповіді від розширення');
          reject(new Error('No response from extension'));
          return;
        }

        if (!response.success) {
          console.error('❌ Помилка всередині розширення:', response.error);
          reject(new Error(response.error ?? 'Extension returned an error'));
          return;
        }

        console.log('✅ Успішна відповідь від розширення:', response);
        resolve(response.data as T);
      }
    );
  });
}

export async function pingExtension(): Promise<boolean> {
  try {
    await sendToExtension({ type: 'PING' });
    return true;
  } catch {
    return false;
  }
}


export type SendTradeResult = {
  tradeOfferId?: string;
  offerState?: number;
  needsConfirmation?: boolean;
  error?: string;
};

export async function sendTradeViaExtension(
  orderId: string,
  apiBaseUrl: string
): Promise<any> {
  return sendToExtension<any>({
    type: 'CREATE_TRADE_OFFER',
    orderId,
    apiBaseUrl,
  });
}

export type FetchSteamUserResponse = {
    isLoggedIn: boolean;
    steamID?: string | null;
    sessionID?: string;
    token?: string;
    error?: string;
};

export async function checkSteamAuthViaExtension(expectedSteamID?: string): Promise<FetchSteamUserResponse> {
  return sendToExtension<FetchSteamUserResponse>({
    type: 'FETCH_STEAM_USER',
    expectedSteamID,
  });
}

export type CheckTradeOfferStatusResult = {
    offerState?: number;
    tradeId?: string;
    error?: string;
};

export async function checkTradeOfferStatusViaExtension(tradeOfferId: string, apiBaseUrl: string, orderId: string): Promise<any> {
    return sendToExtension<any>({
        type: 'CHECK_TRADE_OFFER_STATUS',
        tradeOfferId,
        apiBaseUrl,
        orderId
    });
}

export type CheckTradeStatusResult = {
    tradeStatus?: number;
    error?: string;
};

export async function checkTradeStatusViaExtension(tradeId: string): Promise<CheckTradeStatusResult> {
    return sendToExtension<CheckTradeStatusResult>({
        type: 'CHECK_TRADE_STATUS',
        tradeId
    });
}

export type CancelTradeOfferResult = {
  cancelled?: boolean;
  error?: string;
};

export async function cancelTradeOfferViaExtension(tradeOfferId: string): Promise<CancelTradeOfferResult> {
  return sendToExtension<CancelTradeOfferResult>({
    type: 'CANCEL_TRADE_OFFER',
    tradeOfferId,
  });
}

export type TlsnTradeProofResult = {
  data?: unknown;
  error?: string;
};

export type SyncPendingTradesResult = {
  actorRole: string;
  pendingCount: number;
  sentUpdates: number;
  updated: number;
  failed: number;
  skipped?: boolean;
  reason?: string;
};

/**
 * Confirms many trades in ONE TLSN session: a single GetTradeStatus proof for one trade,
 * or a GetTradeHistory proof covering the latest trades when there are several.
 */
export async function proveTradesBatchViaExtension(
  tradeIds: string[],
  orderId?: string
): Promise<TlsnTradeProofResult> {
  return sendToExtension<TlsnTradeProofResult>({
    type: 'TLSN_PROVE',
    data: tradeIds.length === 1
      ? { proofType: 'trade_status', tradeId: tradeIds[0], orderId }
      : { proofType: 'trade_history', tradeIds },
  });
}

export async function proveTradeStatusViaExtension(
  tradeId: string,
  targetSteamId: string,
  orderId?: string
): Promise<TlsnTradeProofResult> {
  return sendToExtension<TlsnTradeProofResult>({
    type: 'TLSN_PROVE',
    data: {
      proofType: 'trade_status',
      tradeId,
      targetSteamId,
      orderId,
    },
  });
}

// Sync is unified: the extension covers the user's purchases and sales in one pass.
export async function syncPendingTradesViaExtension(
  apiBaseUrl: string,
  options?: { force?: boolean }
): Promise<SyncPendingTradesResult> {
  return sendToExtension<SyncPendingTradesResult>({
    type: 'SYNC_PENDING_TRADES',
    apiBaseUrl,
    force: options?.force ?? false,
  });
}
