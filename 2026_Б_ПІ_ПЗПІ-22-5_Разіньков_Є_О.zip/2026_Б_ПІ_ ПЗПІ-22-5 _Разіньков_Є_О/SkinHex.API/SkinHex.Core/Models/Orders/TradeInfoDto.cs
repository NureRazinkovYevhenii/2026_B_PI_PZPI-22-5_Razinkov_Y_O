namespace SkinHex.Core.Models.Orders;

public record TradeInfoDto(
    string BuyerSteamId,
    string BuyerTradeToken,
    string BuyerPartnerId,
    long AssetId
);
