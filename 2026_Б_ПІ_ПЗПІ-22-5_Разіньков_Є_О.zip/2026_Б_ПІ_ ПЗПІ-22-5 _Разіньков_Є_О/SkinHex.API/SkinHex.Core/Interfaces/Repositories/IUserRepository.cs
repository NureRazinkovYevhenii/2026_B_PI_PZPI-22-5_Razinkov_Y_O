using SkinHex.Core.Entities;

namespace SkinHex.Core.Interfaces;

public interface IUserRepository
{
    Task<User?> GetByIdAsync(Guid id, CancellationToken ct);
    Task<User?> GetBySteamIdAsync(string steamId, CancellationToken ct);
    Task AddAsync(User user, CancellationToken ct);

}
