import { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { OrderCard } from '../components/OrderCard';
import type { AuthState, AuthorizedFetch, ItemDictionaryEntry, Order, OrderRoleFilter } from '../types';
import { loadItemDictionary } from '../utils/itemDictionary';
import { getUserOrders } from '../utils/orders';
import { checkSteamAuthViaExtension, proveTradesBatchViaExtension, syncPendingTradesViaExtension } from '../utils/extensionBridge';
import { API_BASE_URL } from '../config';
import { ORDER_UPDATED_EVENT } from '../utils/NotificationsContext';
import { ORDERS_TAB_EVENT, ORDERS_TAB_STORAGE_KEY } from '../api/notificationsApi';
import { fetchMyDisputes, indexDisputesByOrder, type Dispute } from '../api/disputesApi';

function readPendingOrdersTab(): OrderRoleFilter | null {
  const pending = sessionStorage.getItem(ORDERS_TAB_STORAGE_KEY);
  if (pending === 'buyer' || pending === 'seller') {
    sessionStorage.removeItem(ORDERS_TAB_STORAGE_KEY);
    return pending;
  }
  return null;
}

type OrdersPageProps = {
  auth: AuthState | null;
  authorizedFetch: AuthorizedFetch;
  onRequireLogin: () => void;
};

const tabs: Array<{ key: OrderRoleFilter; i18nKey: string }> = [
  { key: 'buyer', i18nKey: 'orders.myPurchases' },
  { key: 'seller', i18nKey: 'orders.mySales' },
];

const AUTO_PING_INTERVAL_SECONDS = 10 * 60;
const MANUAL_SYNC_COOLDOWN_SECONDS = 30;
const TRADE_SYNC_LAST_RUN_AT_KEY = 'skinhex_trade_sync_last_run_at';
const TRADE_SYNC_NEXT_RUN_AT_KEY = 'skinhex_trade_sync_next_run_at';

function formatTimer(totalSeconds: number): string {
  const seconds = Math.max(0, totalSeconds);
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
}

export function OrdersPage({ auth, authorizedFetch, onRequireLogin }: OrdersPageProps) {
  const { t } = useTranslation();
  const [activeRole, setActiveRole] = useState<OrderRoleFilter>(() => readPendingOrdersTab() ?? 'buyer');
  const [orders, setOrders] = useState<Order[]>([]);
  const [disputesByOrder, setDisputesByOrder] = useState<Record<string, Dispute>>({});
  const [itemDictionary, setItemDictionary] = useState<Record<string, ItemDictionaryEntry>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [steamExtError, setSteamExtError] = useState<string | null>(null);
  const [isSyncingTrades, setIsSyncingTrades] = useState(false);
  const [isProvingAll, setIsProvingAll] = useState(false);
  const [secondsToAutoPing, setSecondsToAutoPing] = useState(AUTO_PING_INTERVAL_SECONDS);
  const [manualCooldownLeft, setManualCooldownLeft] = useState(0);

  useEffect(() => {
    void loadItemDictionary().then(setItemDictionary);
  }, []);

  const loadOrders = useCallback(async () => {
    if (!auth) {
      setOrders([]);
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const fetchedOrders = await getUserOrders(authorizedFetch, activeRole);
      fetchedOrders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      setOrders(fetchedOrders);

      // Disputes overlay the order list: cards show the "under review" banner and
      // hide conflicting actions while a dispute is open.
      try {
        setDisputesByOrder(indexDisputesByOrder(await fetchMyDisputes(authorizedFetch)));
      } catch {
        // Non-fatal: orders still render without dispute badges.
      }
    } catch (loadError) {
      setOrders([]);
      setError(loadError instanceof Error ? loadError.message : 'Failed to load orders.');
    } finally {
      setIsLoading(false);
    }
  }, [activeRole, auth, authorizedFetch]);

  const checkSteamAuth = useCallback(async () => {
    // Both sides rely on the extension now: the seller sends trades through it, and the
    // buyer's extension corroborates incoming offers (protects them from staged penalties).
    if (!auth?.steamId) {
      setSteamExtError(null);
      return;
    }

    try {
      const res = await checkSteamAuthViaExtension(auth.steamId);
      if (!res.isLoggedIn) {
        setSteamExtError('You are not logged into Steam! Please log in on steamcommunity.com first.');
      } else if (res.error) {
        setSteamExtError(`Steam Auth Error: ${res.error}`);
      } else {
        setSteamExtError(null);
      }
    } catch (err) {
      // Extension not installed or other error
      setSteamExtError(err instanceof Error ? err.message : 'Failed to connect to SkinHex extension');
    }
  }, [auth]);

  useEffect(() => {
    void loadOrders();
    void checkSteamAuth();
  }, [loadOrders, checkSteamAuth]);

  useEffect(() => {
    const nextRunRaw = localStorage.getItem(TRADE_SYNC_NEXT_RUN_AT_KEY);
    const nextRunAt = nextRunRaw ? Number(nextRunRaw) : NaN;
    const now = Date.now();

    if (Number.isFinite(nextRunAt) && nextRunAt > now) {
      const left = Math.max(0, Math.ceil((nextRunAt - now) / 1000));
      setSecondsToAutoPing(left);
      return;
    }

    const lastRunRaw = localStorage.getItem(TRADE_SYNC_LAST_RUN_AT_KEY);
    const lastRunAt = lastRunRaw ? Number(lastRunRaw) : NaN;
    if (Number.isFinite(lastRunAt) && lastRunAt > 0) {
      const elapsedSeconds = Math.floor((now - lastRunAt) / 1000);
      const left = Math.max(0, AUTO_PING_INTERVAL_SECONDS - elapsedSeconds);
      setSecondsToAutoPing(left);
      return;
    }

    setSecondsToAutoPing(AUTO_PING_INTERVAL_SECONDS);
  }, []);

  useEffect(() => {
    const intervalId = window.setInterval(() => {
      const nextRunRaw = localStorage.getItem(TRADE_SYNC_NEXT_RUN_AT_KEY);
      const nextRunAt = nextRunRaw ? Number(nextRunRaw) : NaN;
      if (Number.isFinite(nextRunAt) && nextRunAt > 0) {
        const left = Math.max(0, Math.ceil((nextRunAt - Date.now()) / 1000));
        setSecondsToAutoPing(left);
      }

      setManualCooldownLeft((prev) => Math.max(0, prev - 1));
    }, 1000);

    return () => window.clearInterval(intervalId);
  }, []);

  useEffect(() => {
    const handleSyncScheduled = (event: Event) => {
      const customEvent = event as CustomEvent<{ nextAutoRunAt?: number }>;
      const nextAutoRunAt = customEvent.detail?.nextAutoRunAt;
      if (typeof nextAutoRunAt === 'number' && Number.isFinite(nextAutoRunAt)) {
        localStorage.setItem(TRADE_SYNC_NEXT_RUN_AT_KEY, String(nextAutoRunAt));
        const left = Math.max(0, Math.ceil((nextAutoRunAt - Date.now()) / 1000));
        setSecondsToAutoPing(left);
      }
    };

    const handleSyncCompleted = (event: Event) => {
      const customEvent = event as CustomEvent<{ lastRunAt?: number }>;
      const lastRunAt = customEvent.detail?.lastRunAt;
      if (typeof lastRunAt === 'number' && Number.isFinite(lastRunAt)) {
        localStorage.setItem(TRADE_SYNC_LAST_RUN_AT_KEY, String(lastRunAt));
      }
      void loadOrders();
    };

    window.addEventListener('skinhex:trade-sync-scheduled', handleSyncScheduled);
    window.addEventListener('skinhex:trade-sync-completed', handleSyncCompleted);
    return () => {
      window.removeEventListener('skinhex:trade-sync-scheduled', handleSyncScheduled);
      window.removeEventListener('skinhex:trade-sync-completed', handleSyncCompleted);
    };
  }, [loadOrders]);

  // Realtime: an order changed server-side (notifications hub) — re-fetch the list.
  useEffect(() => {
    const handleOrderUpdated = () => {
      void loadOrders();
    };

    window.addEventListener(ORDER_UPDATED_EVENT, handleOrderUpdated);
    return () => window.removeEventListener(ORDER_UPDATED_EVENT, handleOrderUpdated);
  }, [loadOrders]);

  // Clicking a notification while OrdersPage is already open switches to the relevant tab.
  useEffect(() => {
    const handleTabSwitch = (event: Event) => {
      const tab = (event as CustomEvent<{ tab?: OrderRoleFilter }>).detail?.tab;
      if (tab === 'buyer' || tab === 'seller') {
        setActiveRole(tab);
      }
    };

    window.addEventListener(ORDERS_TAB_EVENT, handleTabSwitch);
    return () => window.removeEventListener(ORDERS_TAB_EVENT, handleTabSwitch);
  }, []);

  // Sales whose escrow hold has fully elapsed but the completion proof was never sent:
  // exactly the trades a TLSN proof would settle right now. Drives the "confirm all" button.
  const nowMs = Date.now();
  const tradesNeedingProof = orders.filter((order) => {
    const isEscrow = order.status === 'InEscrow' || order.status === 3;
    return (
      order.role === 'Seller' &&
      isEscrow &&
      !!order.activeTrade?.steamTradeId &&
      !!order.escrowEndsAt &&
      new Date(order.escrowEndsAt).getTime() <= nowMs
    );
  });

  const handleProveAllTrades = async () => {
    if (isProvingAll || tradesNeedingProof.length === 0) {
      return;
    }

    setIsProvingAll(true);
    setError(null);

    try {
      if (auth?.steamId) {
        const steamAuth = await checkSteamAuthViaExtension(auth.steamId);
        if (!steamAuth.isLoggedIn) {
          throw new Error('You are not logged into Steam! Please log in on steamcommunity.com first.');
        }
      }

      const tradeIds = tradesNeedingProof.map((order) => order.activeTrade!.steamTradeId!);
      const result = await proveTradesBatchViaExtension(tradeIds, tradesNeedingProof[0].orderId);
      if (result.error) {
        throw new Error(result.error);
      }

      // Webhook processing is asynchronous on the backend after notary submission.
      window.setTimeout(() => {
        void loadOrders();
      }, 1500);
    } catch (proveError) {
      setError(proveError instanceof Error ? proveError.message : 'Failed to generate TLSN proof.');
    } finally {
      setIsProvingAll(false);
    }
  };

  const handleForceTradeSync = async () => {
    if (!auth) {
      return;
    }

    if (manualCooldownLeft > 0) {
      return;
    }

    setIsSyncingTrades(true);
    setManualCooldownLeft(MANUAL_SYNC_COOLDOWN_SECONDS);
    setError(null);

    try {
      await syncPendingTradesViaExtension(API_BASE_URL, { force: true });

      const lastRunAt = Date.now();
      const nextAutoRunAt = lastRunAt + AUTO_PING_INTERVAL_SECONDS * 1000;
      localStorage.setItem(TRADE_SYNC_LAST_RUN_AT_KEY, String(lastRunAt));
      localStorage.setItem(TRADE_SYNC_NEXT_RUN_AT_KEY, String(nextAutoRunAt));
      window.dispatchEvent(new CustomEvent('skinhex:trade-sync-completed', {
        detail: { lastRunAt, nextAutoRunAt, source: 'manual' },
      }));
      window.dispatchEvent(new CustomEvent('skinhex:trade-sync-scheduled', {
        detail: { nextAutoRunAt, source: 'manual' },
      }));

      await loadOrders();
    } catch (syncError) {
      setError(syncError instanceof Error ? syncError.message : 'Failed to sync pending trades.');
    } finally {
      setIsSyncingTrades(false);
    }
  };

  if (!auth) {
    return (
      <section className="orders-section" aria-labelledby="orders-title">
        <div className="inventory-head">
          <div>
            <p className="eyebrow">{t('orders.title')}</p>
            <h2 id="orders-title">{t('orders.myOrders')}</h2>
          </div>
        </div>
        <div className="inventory-state">
          <strong>{t('orders.signInPrompt')}</strong>
          <p>{t('orders.signInDescription')}</p>
          <button className="primary-button" onClick={onRequireLogin} type="button">
            {t('common.signInSteam')}
          </button>
        </div>
      </section>
    );
  }

  return (
    <section className="orders-section" aria-labelledby="orders-title">
      <div className="inventory-head">
        <div>
          <p className="eyebrow">{t('orders.title')}</p>
          <h2 id="orders-title">{t('orders.myOrders')}</h2>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '8px' }}>
          <div className="orders-sync-box" aria-live="polite">
            <span className="orders-sync-label">Auto-Ping in {formatTimer(secondsToAutoPing)}</span>
            <button
              className="orders-sync-refresh"
              onClick={handleForceTradeSync}
              type="button"
              disabled={isSyncingTrades || manualCooldownLeft > 0}
              title={manualCooldownLeft > 0 ? `Try again in ${manualCooldownLeft}s` : 'Force trade sync'}
              aria-label={manualCooldownLeft > 0 ? `Trade sync cooldown ${manualCooldownLeft} seconds` : 'Force trade sync'}
            >
              <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M21 12a9 9 0 1 1-2.64-6.36" />
                <polyline points="21 3 21 9 15 9" />
              </svg>
            </button>
          </div>
          {tradesNeedingProof.length > 0 && (
            <button
              className="primary-button"
              type="button"
              onClick={handleProveAllTrades}
              disabled={isProvingAll}
              style={{ backgroundColor: '#10b981', color: '#fff', display: 'inline-flex', alignItems: 'center', gap: '8px' }}
              title={t('orders.proveAll.hint')}
            >
              {isProvingAll && (
                <span style={{ width: '14px', height: '14px', border: '2px solid rgba(255,255,255,0.4)', borderTopColor: '#fff', borderRadius: '50%', animation: 'spin 1s linear infinite' }} />
              )}
              {isProvingAll
                ? t('orders.proveAll.running')
                : t('orders.proveAll.button', { count: tradesNeedingProof.length })}
            </button>
          )}
        </div>
      </div>

      <div className="orders-tabs" role="tablist" aria-label={t('orders.roleFilterLabel')}>
        {tabs.map((tab) => (
          <button
            aria-selected={activeRole === tab.key}
            className="orders-tab"
            key={tab.key}
            onClick={() => setActiveRole(tab.key)}
            role="tab"
            type="button"
          >
            {t(tab.i18nKey)}
          </button>
        ))}
      </div>

      {steamExtError && (
        <div style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)', border: '1px solid #ef4444', color: '#fca5a5', padding: '16px', borderRadius: '8px', marginBottom: '24px', display: 'flex', alignItems: 'flex-start', gap: '12px' }}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0, marginTop: '2px' }}>
            <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
            <line x1="12" y1="9" x2="12" y2="13"></line>
            <line x1="12" y1="17" x2="12.01" y2="17"></line>
          </svg>
          <div>
            <h4 style={{ margin: 0, fontSize: '15px', color: '#fef2f2', fontWeight: 600 }}>Extension Error</h4>
            <p style={{ margin: '4px 0 0', fontSize: '14px', lineHeight: 1.5 }}>{steamExtError}</p>
          </div>
        </div>
      )}

      {error ? (
        <div className="inventory-state inventory-error" role="alert">
          <strong>{t('orders.unavailable')}</strong>
          <p>{error}</p>
        </div>
      ) : isLoading ? (
        <div className="inventory-state">
          <strong>{t('orders.loading')}</strong>
        </div>
      ) : orders.length ? (
        <div className="orders-list">
          {orders.map((order) => (
            <OrderCard
              auth={auth}
              authorizedFetch={authorizedFetch}
              dispute={disputesByOrder[order.orderId] ?? null}
              itemStatic={itemDictionary[order.item.marketHashName] ?? null}
              key={order.orderId}
              onDisputeChanged={(dispute) =>
                setDisputesByOrder((prev) => ({ ...prev, [dispute.orderId]: dispute }))
              }
              order={order}
              onOrderUpdate={(updated) => {
                setOrders((prev) =>
                  prev.map((o) => {
                    if (o.orderId === updated.orderId) {
                      return {
                        ...updated,
                        item: {
                          ...updated.item,
                          marketHashName: updated.item?.marketHashName || o.item.marketHashName,
                          wear: updated.item?.wear || o.item.wear,
                          float: updated.item?.float ?? o.item.float
                        },
                        partner: {
                          ...updated.partner,
                          username: updated.partner?.username || o.partner.username,
                          avatarUrl: updated.partner?.avatarUrl || o.partner.avatarUrl,
                        }
                      };
                    }
                    return o;
                  })
                );
              }}
            />
          ))}
        </div>
      ) : (
        <div className="inventory-state">
          <strong>{t('orders.noOrdersYet')}</strong>
          <p>{activeRole === 'buyer' ? t('orders.noPurchases') : t('orders.noSales')}</p>
        </div>
      )}

      {/* Support entry point lives right under the trades — problems start here. */}
      <div className="glass-panel" style={{ marginTop: 24, padding: '20px 24px', borderRadius: 12, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16, flexWrap: 'wrap' }}>
        <div>
          <strong style={{ color: 'var(--text-h)' }}>{t('support.ctaTitle')}</strong>
          <p style={{ margin: '4px 0 0', fontSize: 13, color: 'var(--text-muted)' }}>{t('support.ctaDescription')}</p>
        </div>
        <button
          className="secondary-button"
          type="button"
          onClick={() => { window.location.hash = 'support'; }}
        >
          {t('support.ctaButton')}
        </button>
      </div>
    </section>
  );
}
