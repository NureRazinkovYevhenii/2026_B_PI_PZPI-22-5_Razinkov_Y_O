import type { SyncPendingTradesRequest, SyncPendingTradesResponse } from "../bridge/types";
import {
    fetchPendingTradeSyncItems,
    reportBatchTradeSync,
    type BatchTradeSyncUpdateItem,
    type PendingTradeSyncItem
} from "./skinhexApi";
import { SkinHexTokenManager } from "./skinhexToken";
import { TokenManager } from "./tokenManager";

const SYNC_COOLDOWN_MS = 10 * 60 * 1000;
const MAX_HISTORY_PAGES = 10;
const HISTORY_PAGE_SIZE = 100;

let lastSyncAt = 0;

type TradeHistoryEntry = {
    status?: number;
    timeUpdated?: number;
};

/**
 * Єдиний sync: одним запитом отримуємо всі активні трейди користувача
 * (і як продавця, і як покупця) та репортимо зміни одним батчем.
 * Роль кожного трейду приходить з бекенду в полі role.
 */
export async function syncPendingTrades(req: SyncPendingTradesRequest): Promise<SyncPendingTradesResponse> {
    const now = Date.now();

    if (!req.force && now - lastSyncAt < SYNC_COOLDOWN_MS) {
        return {
            actorRole: 'all',
            pendingCount: 0,
            sentUpdates: 0,
            updated: 0,
            failed: 0,
            skipped: true,
            reason: 'COOLDOWN',
        };
    }

    const authToken = await SkinHexTokenManager.getJwtToken();
    const pending = await fetchPendingTradeSyncItems(req.apiBaseUrl, authToken);

    if (!pending.trades.length) {
        lastSyncAt = now;
        return { actorRole: 'all', pendingCount: 0, sentUpdates: 0, updated: 0, failed: 0 };
    }

    const steamToken = await TokenManager.getInstance().getToken();

    // role відсутній у старих бекендів — вважаємо такі трейди продажами (попередня поведінка).
    const sellerItems = pending.trades.filter((t) => t.role !== 'buyer');
    const buyerItems = pending.trades.filter((t) => t.role === 'buyer');

    const updates: BatchTradeSyncUpdateItem[] = [];

    if (sellerItems.length) {
        const offersById = await fetchTradeOffersMap(steamToken, 'sent');

        const trackedTradeIds = new Set(
            sellerItems
                .map((trade) => trade.tradeId)
                .filter((tradeId): tradeId is string => !!tradeId)
        );

        const historyByTradeId = trackedTradeIds.size > 0
            ? await fetchTradeHistoryMap(steamToken, trackedTradeIds)
            : new Map<string, TradeHistoryEntry>();

        updates.push(...buildSellerUpdates(sellerItems, offersById, historyByTradeId));
    }

    if (buyerItems.length) {
        const receivedById = await fetchTradeOffersMap(steamToken, 'received');
        updates.push(...buildBuyerUpdates(buyerItems, receivedById));
    }

    if (!updates.length) {
        lastSyncAt = now;
        return { actorRole: 'all', pendingCount: pending.trades.length, sentUpdates: 0, updated: 0, failed: 0 };
    }

    const report = await reportBatchTradeSync(req.apiBaseUrl, authToken, updates);
    lastSyncAt = now;

    return {
        actorRole: 'all',
        pendingCount: pending.trades.length,
        sentUpdates: updates.length,
        updated: report.updated,
        failed: report.failed,
    };
}

function buildSellerUpdates(
    pendingTrades: PendingTradeSyncItem[],
    offersById: Map<string, any>,
    historyByTradeId: Map<string, TradeHistoryEntry>
): BatchTradeSyncUpdateItem[] {
    const updates: BatchTradeSyncUpdateItem[] = [];

    for (const pending of pendingTrades) {
        let offerState = pending.offerState;
        let tradeId = pending.tradeId ?? null;
        let tradeStatus = pending.tradeStatus ?? null;
        let timeUpdated = pending.timeUpdated ?? null;

        const offer = offersById.get(pending.tradeOfferId);

        // Offer lookup is mainly useful while tradeId is not yet known.
        if (offer) {
            if (typeof offer.trade_offer_state === 'number') {
                offerState = offer.trade_offer_state;
            }
            if (offer.tradeid) {
                tradeId = String(offer.tradeid);
            }
            if (typeof offer.time_updated === 'number') {
                timeUpdated = offer.time_updated;
            }
        }

        // Once tradeId exists, GetTradeHistory is the source of truth for final/reversed statuses.
        if (tradeId) {
            const history = historyByTradeId.get(tradeId);
            if (history) {
                if (typeof history.status === 'number') {
                    tradeStatus = history.status;
                }
                if (typeof history.timeUpdated === 'number') {
                    timeUpdated = history.timeUpdated;
                }
            }
        }

        const changed =
            offerState !== pending.offerState ||
            (tradeId ?? null) !== (pending.tradeId ?? null) ||
            (tradeStatus ?? null) !== (pending.tradeStatus ?? null) ||
            (timeUpdated ?? null) !== (pending.timeUpdated ?? null);

        if (!changed) {
            continue;
        }

        updates.push({
            orderId: pending.orderId,
            tradeOfferId: pending.tradeOfferId,
            offerState,
            tradeId,
            tradeStatus,
            timeUpdated,
        });
    }

    return updates;
}

/**
 * Покупецькі репорти — corroboration: підтверджуємо, що офер справді прийшов,
 * і передаємо asset id з items_to_receive, щоб бекенд звірив предмет з листингом
 * (і попередив покупця про підміну до прийняття).
 */
function buildBuyerUpdates(
    pendingTrades: PendingTradeSyncItem[],
    receivedById: Map<string, any>
): BatchTradeSyncUpdateItem[] {
    const updates: BatchTradeSyncUpdateItem[] = [];

    for (const pending of pendingTrades) {
        const offer = receivedById.get(pending.tradeOfferId);
        // Офер не видно покупцю — репортити нічого; відсутність підтвердження
        // бекенд трактує на користь покупця (штраф не застосовується автоматично).
        if (!offer) {
            continue;
        }

        const offerState = typeof offer.trade_offer_state === 'number'
            ? offer.trade_offer_state
            : pending.offerState;

        // Цей стан уже підтверджено раніше — не спамимо бекенд повторами.
        if ((pending.buyerReportedOfferState ?? null) === offerState) {
            continue;
        }

        const assetIds = Array.isArray(offer.items_to_receive)
            ? offer.items_to_receive
                .map((item: any) => (item?.assetid != null ? String(item.assetid) : null))
                .filter((id: string | null): id is string => !!id)
            : undefined;

        updates.push({
            orderId: pending.orderId,
            tradeOfferId: pending.tradeOfferId,
            offerState,
            tradeId: offer.tradeid ? String(offer.tradeid) : null,
            timeUpdated: typeof offer.time_updated === 'number' ? offer.time_updated : null,
            assetIds,
        });
    }

    return updates;
}

async function fetchTradeOffersMap(accessToken: string, direction: 'sent' | 'received'): Promise<Map<string, any>> {
    const getSent = direction === 'sent';
    const url = `https://api.steampowered.com/IEconService/GetTradeOffers/v1/?access_token=${encodeURIComponent(accessToken)}&get_sent_offers=${getSent}&get_received_offers=${!getSent}&active_only=0&historical_only=0&get_descriptions=false&language=en`;

    const response = await fetch(url, { credentials: 'include' });
    if (!response.ok) {
        throw new Error(`Steam GetTradeOffers failed: ${response.status}`);
    }

    const payload = await response.json();
    const key = getSent ? 'trade_offers_sent' : 'trade_offers_received';
    const offers = Array.isArray(payload?.response?.[key]) ? payload.response[key] : [];

    const byId = new Map<string, any>();
    for (const offer of offers) {
        if (!offer?.tradeofferid) {
            continue;
        }
        byId.set(String(offer.tradeofferid), offer);
    }

    return byId;
}

async function fetchTradeHistoryMap(
    accessToken: string,
    targetTradeIds: Set<string>
): Promise<Map<string, TradeHistoryEntry>> {
    const result = new Map<string, TradeHistoryEntry>();

    let startAfterTime = 0;
    let startAfterTradeId = '0';

    for (let page = 0; page < MAX_HISTORY_PAGES && result.size < targetTradeIds.size; page++) {
        const url = `https://api.steampowered.com/IEconService/GetTradeHistory/v1/?access_token=${encodeURIComponent(accessToken)}&max_trades=${HISTORY_PAGE_SIZE}&include_failed=true&navigating_back=false&start_after_time=${startAfterTime}&start_after_tradeid=${startAfterTradeId}&language=en`;

        const response = await fetch(url, { credentials: 'include' });
        if (!response.ok) {
            throw new Error(`Steam GetTradeHistory failed: ${response.status}`);
        }

        const payload = await response.json();
        const trades = Array.isArray(payload?.response?.trades) ? payload.response.trades : [];

        if (!trades.length) {
            break;
        }

        for (const trade of trades) {
            if (!trade?.tradeid) {
                continue;
            }

            const tradeId = String(trade.tradeid);
            if (!targetTradeIds.has(tradeId)) {
                continue;
            }

            result.set(tradeId, {
                status: typeof trade.status === 'number' ? trade.status : undefined,
                timeUpdated: typeof trade.time_updated === 'number' ? trade.time_updated : undefined,
            });
        }

        const lastTrade = trades[trades.length - 1];
        const nextTime = Number(lastTrade?.time_init ?? lastTrade?.time_updated ?? 0);
        const nextTradeId = String(lastTrade?.tradeid ?? startAfterTradeId);

        if (!nextTime || !nextTradeId || (nextTime === startAfterTime && nextTradeId === startAfterTradeId)) {
            break;
        }

        startAfterTime = nextTime;
        startAfterTradeId = nextTradeId;

        if (!payload?.response?.more) {
            break;
        }
    }

    return result;
}
