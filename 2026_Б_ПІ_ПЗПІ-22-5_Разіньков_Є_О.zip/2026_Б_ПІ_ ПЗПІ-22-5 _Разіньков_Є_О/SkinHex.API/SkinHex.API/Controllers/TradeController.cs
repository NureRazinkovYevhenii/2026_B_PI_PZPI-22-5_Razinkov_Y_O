using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SkinHex.Core.Interfaces.Services;
using SkinHex.Core.Models.Orders;
using System.Security.Claims;

namespace SkinHex.API.Controllers;

[ApiController]
[Route("api/orders")]
public class TradeController : ControllerBase
{
    private readonly ITradeService _tradeService;

    public TradeController(ITradeService tradeService)
    {
        _tradeService = tradeService;
    }

    /// <summary>
    /// Розширення запитує дані для відправки Steam-трейду.
    /// Доступно лише продавцю замовлення у статусі Confirmed.
    /// </summary>
    [HttpGet("{orderId}/trade-info")]
    [Authorize]
    public async Task<IActionResult> GetTradeInfo(Guid orderId, CancellationToken ct)
    {
        var userIdClaim = User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (!Guid.TryParse(userIdClaim, out var sellerId))
            return Unauthorized();

        var result = await _tradeService.GetTradeInfoAsync(orderId, sellerId, ct);
        return Ok(result);
    }

    [HttpPost("{id:guid}/trade")]
    [Authorize]
    public async Task<IActionResult> CreateTradeAttempt(Guid id, [FromBody] CreateTradeAttemptRequest request, CancellationToken ct)
    {
        var userIdClaim = User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (!Guid.TryParse(userIdClaim, out var sellerId))
            return Unauthorized();

        var result = await _tradeService.CreateTradeAttemptAsync(id, sellerId, request.TradeOfferId, request.OfferState, ct);
        return Ok(result);
    }

    [HttpPut("{id:guid}/trade")]
    [Authorize]
    public async Task<IActionResult> UpdateTradeAttempt(Guid id, [FromBody] UpdateTradeAttemptRequest request, CancellationToken ct)
    {
        var userIdClaim = User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (!Guid.TryParse(userIdClaim, out var sellerId))
            return Unauthorized();

        var result = await _tradeService.UpdateTradeAttemptAsync(
            id,
            sellerId,
            request.TradeOfferId,
            request.OfferState,
            request.TradeId,
            request.TradeStatus,
            request.TimeUpdated,
            ct);
        return Ok(result);
    }

    [HttpGet("trade-sync/pending")]
    [Authorize]
    public async Task<IActionResult> GetPendingTradeSync([FromQuery] string? actorRole, CancellationToken ct)
    {
        var userIdClaim = User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (!Guid.TryParse(userIdClaim, out var userId))
            return Unauthorized();

        var result = await _tradeService.GetPendingTradeSyncAsync(userId, actorRole, ct);
        return Ok(result);
    }

    [HttpPost("trade-sync/batch")]
    [Authorize]
    public async Task<IActionResult> BatchSyncTradeAttempts([FromBody] BatchTradeSyncUpdateRequest request, CancellationToken ct)
    {
        var userIdClaim = User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (!Guid.TryParse(userIdClaim, out var userId))
            return Unauthorized();

        var result = await _tradeService.BatchSyncTradeAttemptsAsync(userId, request, ct);
        return Ok(result);
    }
}
