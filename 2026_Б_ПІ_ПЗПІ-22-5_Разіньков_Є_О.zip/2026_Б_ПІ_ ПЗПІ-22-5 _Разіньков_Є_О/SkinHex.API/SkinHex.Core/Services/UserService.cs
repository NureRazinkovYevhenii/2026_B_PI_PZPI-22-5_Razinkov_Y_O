using FluentResults;
using Microsoft.Extensions.Caching.Memory;
using SkinHex.Core.Errors;
using SkinHex.Core.Interfaces;
using SkinHex.Core.Interfaces.Repositories;
using SkinHex.Core.Interfaces.Steam;
using SkinHex.Core.Models;
using SkinHex.Core.Models.Steam;

namespace SkinHex.Core.Services;

public sealed class UserService(
    IUserRepository userRepository,
    ISteamGatewayClient steamGatewayClient,
    IListingRepository listingRepository,
    IUnitOfWork unitOfWork,
    IMemoryCache cache) : IUserService
{
    private static readonly TimeSpan InventoryReloadCooldown = TimeSpan.FromMinutes(5);
    private static readonly TimeSpan InventoryCacheDuration = TimeSpan.FromMinutes(10);

    public async Task<Result<CurrentUserDto>> GetCurrentUserAsync(
        Guid userId,
        CancellationToken cancellationToken)
    {
        if (userId == Guid.Empty)
            return Result.Fail<CurrentUserDto>("UserId is required.");

        var user = await userRepository.GetByIdAsync(userId, cancellationToken);
        if (user is null)
            return Result.Fail<CurrentUserDto>("User was not found.");

        return Result.Ok(new CurrentUserDto(
            user.SteamId,
            user.Username,
            user.AvatarUrl,
            user.Balance,
            user.FrozenBalance));
    }

    public async Task<Result<UserBalanceDto>> GetBalanceAsync(
        Guid userId,
        CancellationToken cancellationToken)
    {
        if (userId == Guid.Empty)
            return Result.Fail<UserBalanceDto>("UserId is required.");

        var user = await userRepository.GetByIdAsync(userId, cancellationToken);
        if (user is null)
            return Result.Fail<UserBalanceDto>("User was not found.");

        return Result.Ok(new UserBalanceDto(
            user.Balance,
            user.FrozenBalance));
    }

    public async Task<Result<IReadOnlyList<InventoryItemDto>>> GetInventoryAsync(
        Guid userId,
        bool forceReload,
        CancellationToken cancellationToken)
    {
        if (userId == Guid.Empty)
            return Result.Fail<IReadOnlyList<InventoryItemDto>>("UserId is required.");

        var user = await userRepository.GetByIdAsync(userId, cancellationToken);
        if (user is null)
            return Result.Fail<IReadOnlyList<InventoryItemDto>>("User was not found.");

        if (!SteamTradeLink.TryParse(user.TradeUrl, out var tradeLink, out _))
            return Result.Fail<IReadOnlyList<InventoryItemDto>>(BusinessErrorCodes.RequireTradeUrl);

        if (forceReload &&
            cache.TryGetValue(GetInventoryReloadCooldownKey(userId), out DateTimeOffset nextAllowedAt))
        {
            var retryAfter = nextAllowedAt - DateTimeOffset.UtcNow;
            if (retryAfter > TimeSpan.Zero)
            {
                return Result.Fail<IReadOnlyList<InventoryItemDto>>(
                    CreateInventoryReloadRateLimitError(retryAfter));
            }
        }

        // Return cached inventory when not force-reloading.
        var inventoryCacheKey = GetInventoryCacheKey(userId);
        if (!forceReload &&
            cache.TryGetValue(inventoryCacheKey, out IReadOnlyList<InventoryItemDto>? cachedInventory) &&
            cachedInventory is not null)
        {
            return Result.Ok(await FilterByActiveListingsAsync(cachedInventory, userId, cancellationToken));
        }

        try
        {
            var inventory = await steamGatewayClient.GetInventoryAsync(tradeLink!, forceReload, cancellationToken);

            if (inventory.Count == 0)
            {
                // Steam's JSON endpoint returns an empty array when the user is trade banned.
                // We must fetch the HTML page to confirm if it's a ban.
                await steamGatewayClient.ValidateTradeLinkAsync(tradeLink!, cancellationToken);
            }

            // Cache the raw inventory (before listing filtering) so that
            // subsequent calls reflect listing changes without hitting Steam.
            cache.Set(inventoryCacheKey, inventory, InventoryCacheDuration);

            if (forceReload)
            {
                var reloadAllowedAt = DateTimeOffset.UtcNow.Add(InventoryReloadCooldown);
                cache.Set(GetInventoryReloadCooldownKey(userId), reloadAllowedAt, InventoryReloadCooldown);
            }

            return Result.Ok(await FilterByActiveListingsAsync(inventory, userId, cancellationToken));
        }
        catch (SteamGatewayException exception) when (exception.IsTradeUrlExpired)
        {
            user.TradeUrl = null;
            user.UpdatedAt = DateTime.UtcNow;
            await unitOfWork.SaveChangesAsync(cancellationToken);

            return Result.Fail<IReadOnlyList<InventoryItemDto>>(CreateExpiredTradeUrlError());
        }
        catch (SteamGatewayException exception) when (exception.IsTradePartnerUnavailable)
        {
            return Result.Fail<IReadOnlyList<InventoryItemDto>>(
                new Error("Your inventory is currently unavailable because you are banned from trading.")
                    .WithMetadata("errorCode", "TRADE_PARTNER_UNAVAILABLE")
            );
        }
    }

    private async Task<IReadOnlyList<InventoryItemDto>> FilterByActiveListingsAsync(
        IReadOnlyList<InventoryItemDto> inventory,
        Guid userId,
        CancellationToken cancellationToken)
    {
        var activeListings = await listingRepository.GetUncancelledBySellerAsync(userId, cancellationToken);
        var listedAssetIds = activeListings
            .Select(listing => listing.SteamAssetId.ToString())
            .ToHashSet(StringComparer.Ordinal);

        return inventory
            .Where(item => !listedAssetIds.Contains(item.AssetId))
            .ToList();
    }

    public async Task<Result> SaveTradeUrlAsync(
        Guid userId,
        string tradeUrl,
        CancellationToken cancellationToken = default)
    {
        var user = await userRepository.GetByIdAsync(userId, cancellationToken);
        if (user is null)
            return Result.Fail("User was not found.");

        if (!SteamTradeLink.TryParse(tradeUrl, out var parsedTradeLink, out var error))
            return Result.Fail(error);

        if (!ulong.TryParse(user.SteamId, out var userSteamId64) ||
            userSteamId64 != parsedTradeLink!.SteamId64)
        {
            return Result.Fail("This trade link belongs to another Steam account.");
        }

        user.TradeUrl = parsedTradeLink.Uri.AbsoluteUri;
        user.UpdatedAt = DateTime.UtcNow;
        await unitOfWork.SaveChangesAsync(cancellationToken);

        return Result.Ok();
    }

    private static Error CreateExpiredTradeUrlError()
    {
        return new Error("Your Steam trade link is no longer valid. Please attach a new trade link.")
            .WithMetadata("errorCode", BusinessErrorCodes.RequireNewTradeUrl);
    }

    private static Error CreateInventoryReloadRateLimitError(TimeSpan retryAfter)
    {
        var retryAfterSeconds = Math.Max(1, (int)Math.Ceiling(retryAfter.TotalSeconds));
        return new Error($"Inventory can be force reloaded again in {retryAfterSeconds} seconds.")
            .WithMetadata("errorCode", BusinessErrorCodes.InventoryReloadRateLimited)
            .WithMetadata("retryAfterSeconds", retryAfterSeconds);
    }

    private static string GetInventoryReloadCooldownKey(Guid userId)
    {
        return $"inventory:reload-cooldown:{userId:N}";
    }

    private static string GetInventoryCacheKey(Guid userId)
    {
        return $"inventory:data:{userId:N}";
    }

    public async Task<Result> BanUserAsync(Guid userId, CancellationToken ct)
    {
        using var transaction = await unitOfWork.BeginTransactionAsync(ct);

        var user = await userRepository.GetByIdAsync(userId, ct);
        if (user is null)
            return Result.Fail("User was not found.");

        user.Role = Entities.UserRole.Banned;
        user.UpdatedAt = DateTime.UtcNow;

        // Load active listings explicitly: GetByIdAsync does not include the navigation,
        // and lazy loading is not enabled, so user.Listings would otherwise be empty.
        var listings = await listingRepository.GetActiveBySellerAsync(userId, ct);
        foreach (var listing in listings)
        {
            listing.Status = Entities.ListingStatus.Cancelled;
        }

        await unitOfWork.SaveChangesAsync(ct);
        await transaction.CommitAsync(ct);

        return Result.Ok();
    }

    public async Task<Result> UnbanUserAsync(Guid userId, CancellationToken ct)
    {
        var user = await userRepository.GetByIdAsync(userId, ct);
        if (user is null)
            return Result.Fail("User was not found.");

        if (user.Role != Entities.UserRole.Banned)
            return Result.Fail("User is not banned.");

        // Cancelled listings are not restored: the seller re-lists if they still hold the items.
        user.Role = Entities.UserRole.User;
        user.UpdatedAt = DateTime.UtcNow;

        await unitOfWork.SaveChangesAsync(ct);

        return Result.Ok();
    }
}
