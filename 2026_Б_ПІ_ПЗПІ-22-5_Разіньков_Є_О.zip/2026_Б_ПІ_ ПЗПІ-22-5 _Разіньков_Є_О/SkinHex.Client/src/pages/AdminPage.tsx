import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { LayoutDashboard, Users, LifeBuoy, ShoppingBag, Banknote, Scale } from 'lucide-react';
import type { AuthState, AuthorizedFetch } from '../types';
import { AdminDashboard } from '../components/admin/AdminDashboard';
import { AdminUsers } from '../components/admin/AdminUsers';
import { AdminTickets } from '../components/admin/AdminTickets';
import { AdminOrders } from '../components/admin/AdminOrders';
import { AdminPayouts } from '../components/admin/AdminPayouts';
import { AdminDisputes } from '../components/admin/AdminDisputes';

type AdminTab = 'dashboard' | 'users' | 'tickets' | 'disputes' | 'orders' | 'payouts';

type AdminPageProps = {
  auth: AuthState | null;
  authorizedFetch: AuthorizedFetch;
};

const TABS: Array<{ key: AdminTab; i18nKey: string; icon: typeof Users }> = [
  { key: 'dashboard', i18nKey: 'admin.tabs.dashboard', icon: LayoutDashboard },
  { key: 'users', i18nKey: 'admin.tabs.users', icon: Users },
  { key: 'tickets', i18nKey: 'admin.tabs.tickets', icon: LifeBuoy },
  { key: 'disputes', i18nKey: 'admin.tabs.disputes', icon: Scale },
  { key: 'orders', i18nKey: 'admin.tabs.orders', icon: ShoppingBag },
  { key: 'payouts', i18nKey: 'admin.tabs.payouts', icon: Banknote },
];

export function AdminPage({ authorizedFetch }: AdminPageProps) {
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState<AdminTab>('dashboard');

  return (
    <section className="admin-section" aria-labelledby="admin-title">
      <div className="inventory-head">
        <div>
          <p className="eyebrow">{t('admin.eyebrow')}</p>
          <h2 id="admin-title">{t('admin.title')}</h2>
        </div>
      </div>

      <div className="admin-tabs" role="tablist" aria-label={t('admin.title')}>
        {TABS.map(({ key, i18nKey, icon: Icon }) => (
          <button
            key={key}
            role="tab"
            type="button"
            aria-selected={activeTab === key}
            className={`admin-tab ${activeTab === key ? 'is-active' : ''}`}
            onClick={() => setActiveTab(key)}
          >
            <Icon size={16} />
            {t(i18nKey)}
          </button>
        ))}
      </div>

      <div className="admin-content">
        {activeTab === 'dashboard' && <AdminDashboard authorizedFetch={authorizedFetch} />}
        {activeTab === 'users' && <AdminUsers authorizedFetch={authorizedFetch} />}
        {activeTab === 'tickets' && <AdminTickets authorizedFetch={authorizedFetch} />}
        {activeTab === 'disputes' && <AdminDisputes authorizedFetch={authorizedFetch} />}
        {activeTab === 'orders' && <AdminOrders authorizedFetch={authorizedFetch} />}
        {activeTab === 'payouts' && <AdminPayouts authorizedFetch={authorizedFetch} />}
      </div>
    </section>
  );
}
