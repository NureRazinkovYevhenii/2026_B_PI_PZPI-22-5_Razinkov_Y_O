import { useMemo } from 'react';
import { formatFloat, getFloatBarSegments, getFloatPosition } from '../utils/inventory';

type FloatBarProps = {
  floatValue: number;
  minFloat?: number | null;
  maxFloat?: number | null;
  paintSeed?: number | null;
  size?: 'compact' | 'large';
  /** Render the float value + paint seed row under the track. Default true. */
  showInfo?: boolean;
};

export function FloatBar({ floatValue, minFloat, maxFloat, paintSeed, size = 'compact', showInfo = true }: FloatBarProps) {
  const minF = minFloat ?? 0;
  const maxF = maxFloat ?? 1;

  const segments = useMemo(() => getFloatBarSegments(minF, maxF), [minF, maxF]);

  return (
    <div className={`float-bar-widget ${size}`}>
      <div className="float-bar-track">
        {segments.map((seg, i) => {
          const isColored = seg.color !== 'transparent';
          const isFirstColored = isColored && (i === 0 || segments[i - 1].color === 'transparent');
          const isLastColored = isColored && (i === segments.length - 1 || segments[i + 1].color === 'transparent');

          return (
            <div
              key={i}
              className={`float-bar-segment ${isFirstColored ? 'first-colored' : ''} ${isLastColored ? 'last-colored' : ''}`}
              style={{ width: `${seg.widthPercent}%`, backgroundColor: seg.color }}
              title={seg.label}
            />
          );
        })}
        {typeof floatValue === 'number' && (
          <div
            className="float-bar-pointer"
            style={{ left: `${getFloatPosition(floatValue)}%` }}
          />
        )}
      </div>
      {showInfo && (
        <div className="float-bar-info">
          <span className="float-value">{formatFloat(floatValue)}</span>
          {paintSeed != null && paintSeed > 0 && (
            <span className="paint-seed">{paintSeed}</span>
          )}
        </div>
      )}
    </div>
  );
}
