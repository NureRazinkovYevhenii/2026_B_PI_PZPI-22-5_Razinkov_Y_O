using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SkinHex.Core.Interfaces.Services;
using SkinHex.Core.Models.Orders;
using System.Security.Claims;

namespace SkinHex.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class OrdersController : ControllerBase
{
    private readonly IOrderService _orderService;

    public OrdersController(IOrderService orderService)
    {
        _orderService = orderService;
    }

    /// <summary>
    /// Покупець натиснув "Купити" — створює ордер, заморожує кошти, резервує листинг.
    /// </summary>
    [HttpPost]
    [Authorize]
    public async Task<IActionResult> CreateOrder([FromBody] CreateOrderRequest request, CancellationToken ct)
    {
        var userIdClaim = User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (!Guid.TryParse(userIdClaim, out var buyerId))
            return Unauthorized();

        var result = await _orderService.CreateOrderAsync(request.ListingId, buyerId, ct);
        return Ok(result);
    }

    [HttpGet("my")]
    [Authorize]
    public async Task<IActionResult> GetMyOrders([FromQuery] string? role, CancellationToken ct)
    {
        var userIdClaim = User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (!Guid.TryParse(userIdClaim, out var userId))
            return Unauthorized();

        try
        {
            var orders = await _orderService.GetUserOrdersAsync(userId, role, ct);
            return Ok(orders);
        }
        catch (ArgumentException ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }

    /// <summary>
    /// Продавець підтверджує готовність відправити замовлення
    /// </summary>
    [HttpPost("{orderId}/confirm")]
    [Authorize]
    public async Task<IActionResult> ConfirmOrder(Guid orderId, CancellationToken ct)
    {
        var userIdClaim = User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (!Guid.TryParse(userIdClaim, out var sellerId))
            return Unauthorized();

        var result = await _orderService.ConfirmOrderAsync(orderId, sellerId, ct);
        return Ok(result);
    }

    /// <summary>
    /// Покупець або продавець скасовує замовлення
    /// </summary>
    [HttpPost("{orderId}/cancel")]
    [Authorize]
    public async Task<IActionResult> CancelOrder(Guid orderId, [FromBody] CancelOrderRequest request, CancellationToken ct)
    {
        var userIdClaim = User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (!Guid.TryParse(userIdClaim, out var initiatorId))
            return Unauthorized();

        var result = await _orderService.CancelOrderAsync(orderId, initiatorId, request.Reason, null, ct);
        return Ok(result);
    }

}
