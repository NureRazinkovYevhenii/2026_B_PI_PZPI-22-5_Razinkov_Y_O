import type { CSSProperties } from 'react';
import type { AuthState, AuthorizedFetch, ItemDictionaryEntry, ListingCatalogItem } from '../types';
import { formatFloat, parseInventoryName } from '../utils/inventory';
import { getItemImageUrl } from '../utils/itemDictionary';
import { PurchaseButton } from './PurchaseButton';

type CatalogCardProps = {
  auth: AuthState | null;
  authorizedFetch: AuthorizedFetch;
  item: ListingCatalogItem;
  itemStatic: ItemDictionaryEntry | null;
  isOwnListing: boolean;
  onPurchaseCreated: () => void;
  onRequireLogin: () => void;
};

export function CatalogCard({
  auth,
  authorizedFetch,
  item,
  itemStatic,
  isOwnListing,
  onPurchaseCreated,
  onRequireLogin,
}: CatalogCardProps) {
  const parsedName = parseInventoryName(item.marketHashName);
  const accentColor = itemStatic?.color ? `#${itemStatic.color}` : '#b91cff';
  const imageUrl = getItemImageUrl(itemStatic);

  return (
    <article className="inventory-card catalog-card" style={{ '--item-accent': accentColor } as CSSProperties}>
      <div className="item-title-row">
        <div>
          <h3>{parsedName.title}</h3>
          <p>{parsedName.exterior ?? 'Item'}</p>
        </div>
      </div>

      <div className="item-art">
        {imageUrl && <img alt={item.marketHashName} loading="lazy" src={imageUrl} />}
      </div>

      <dl className="item-stats">
        {item.floatValue != null && item.floatValue > 0 && (
          <div>
            <dt>Float</dt>
            <dd>{formatFloat(item.floatValue)}</dd>
          </div>
        )}
        {item.paintSeed != null && item.paintSeed > 0 && (
          <div>
            <dt>Seed</dt>
            <dd>{item.paintSeed}</dd>
          </div>
        )}
        <div>
          <dt>Price</dt>
          <dd>${item.price.toFixed(2)}</dd>
        </div>
      </dl>

      <div className="catalog-card-overlay">
        {isOwnListing ? (
          <button className="secondary-button" type="button" disabled>
            Your listing
          </button>
        ) : (
          <PurchaseButton
            auth={auth}
            authorizedFetch={authorizedFetch}
            listingId={item.id}
            onCreated={onPurchaseCreated}
            onRequireLogin={onRequireLogin}
          />
        )}
      </div>
    </article>
  );
}
