namespace SkinHex.Core.Models.Auth;

public sealed record VerifyEmailRequest(string Email, int Code);
