namespace SkinHex.Core.Models;

/// <summary>Агрегати активних листингів одного предмета (конкретний ItemId).</summary>
public sealed class ItemPriceSummary
{
    public decimal? MinPrice { get; set; }
    public decimal? AvgPrice { get; set; }
    public int Count { get; set; }
}
