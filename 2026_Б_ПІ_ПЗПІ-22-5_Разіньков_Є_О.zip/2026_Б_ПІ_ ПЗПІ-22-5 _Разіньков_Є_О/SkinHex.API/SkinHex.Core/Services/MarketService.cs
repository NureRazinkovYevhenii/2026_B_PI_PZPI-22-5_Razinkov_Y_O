using FluentResults;
using Hangfire;
using Microsoft.Extensions.Options;
using SkinHex.Core.Errors;
using SkinHex.Core.Entities;
using SkinHex.Core.Interfaces;
using SkinHex.Core.Interfaces.Repositories;
using SkinHex.Core.Interfaces.Services;
using SkinHex.Core.Interfaces.Steam;
using SkinHex.Core.Models;
using SkinHex.Core.Options;
using SkinHex.Core.Models.Steam;

namespace SkinHex.Core.Services;

public sealed class MarketService(
    IUserRepository userRepository,
    IItemRepository itemRepository,
    IListingRepository listingRepository,
    IItemScreenshotRepository itemScreenshotRepository,
    ISteamGatewayClient steamGatewayClient,
    IBackgroundJobClient backgroundJobClient,
    IOptions<ScreenshotOptions> screenshotOptions,
    IUnitOfWork unitOfWork) : IMarketService
{
    private const decimal MaxListingPrice = 20000m;
    private const int MaxSearchTipLimit = 25;

    private static readonly string[] WearOrder =
    [
        "Factory New", "Minimal Wear", "Field-Tested", "Well-Worn", "Battle-Scarred"
    ];

    public async Task<Result<Guid>> CreateListingAsync(Guid sellerId, CreateListingRequest request, CancellationToken ct)
    {
        var result = await CreateListingsAsync(
            sellerId,
            new CreateListingsRequest
            {
                Items =
                [
                    new CreateListingItemRequest
                    {
                        AssetId = request.AssetId,
                        Price = request.Price
                    }
                ]
            },
            ct);

        return result.IsFailed
            ? Result.Fail<Guid>(result.Errors)
            : Result.Ok(result.Value.ListingIds[0]);
    }

    public async Task<Result<CreateListingsResponse>> CreateListingsAsync(
        Guid sellerId,
        CreateListingsRequest request,
        CancellationToken ct)
    {
        if (request.Items is null || request.Items.Count == 0)
            return Result.Fail<CreateListingsResponse>("At least one listing item is required.");
        if (request.Items.Any(item => string.IsNullOrWhiteSpace(item.AssetId)))
            return Result.Fail<CreateListingsResponse>("Steam asset ids cannot be empty.");

        foreach (var item in request.Items)
        {
            var priceValidation = ValidateListingPrice(item.Price);
            if (priceValidation.IsFailed)
                return Result.Fail<CreateListingsResponse>(priceValidation.Errors);
        }

        var normalizedItems = request.Items
            .Select(item => new CreateListingItemRequest
            {
                AssetId = item.AssetId.Trim(),
                Price = item.Price
            })
            .ToArray();
        var normalizedAssetIds = normalizedItems.Select(item => item.AssetId).ToArray();
        if (normalizedAssetIds.Distinct(StringComparer.Ordinal).Count() != normalizedAssetIds.Length)
            return Result.Fail<CreateListingsResponse>("Duplicate Steam asset ids are not allowed.");

        var user = await userRepository.GetByIdAsync(sellerId, ct);
        if (user is null)
            return Result.Fail<CreateListingsResponse>("User was not found.");
        if (user.Role == UserRole.Banned)
            return Result.Fail<CreateListingsResponse>("You are banned and cannot create listings.");
        if (!SteamTradeLink.TryParse(user.TradeUrl, out var tradeLink, out _))
            return Result.Fail<CreateListingsResponse>(BusinessErrorCodes.RequireTradeUrl);

        // Ownership validation must never use the UI inventory cache.
        IReadOnlyList<InventoryItemDto> inventory;
        try
        {
            inventory = await steamGatewayClient.GetInventoryAsync(tradeLink!, cancellationToken: ct);
        }
        catch (SteamGatewayException exception) when (exception.IsTradeUrlExpired)
        {
            user.TradeUrl = null;
            user.UpdatedAt = DateTime.UtcNow;
            await unitOfWork.SaveChangesAsync(ct);

            return Result.Fail<CreateListingsResponse>(CreateExpiredTradeUrlError());
        }

        var inventoryByAssetId = inventory.ToDictionary(item => item.AssetId, StringComparer.Ordinal);
        var selectedItems = new List<(InventoryItemDto InventoryItem, long SteamAssetId, decimal Price)>(normalizedItems.Length);
        foreach (var item in normalizedItems)
        {
            if (!inventoryByAssetId.TryGetValue(item.AssetId, out var inventoryItem))
                return Result.Fail<CreateListingsResponse>($"Item {item.AssetId} was not found in your Steam inventory.");
            if (!long.TryParse(item.AssetId, out var steamAssetId))
                return Result.Fail<CreateListingsResponse>($"Steam asset id {item.AssetId} is invalid.");

            selectedItems.Add((inventoryItem, steamAssetId, item.Price));
        }

        var activeAssetIds = await listingRepository.GetActiveSteamAssetIdsAsync(
            selectedItems.Select(item => item.SteamAssetId).ToArray(),
            ct);
        if (activeAssetIds.Count > 0)
            return Result.Fail<CreateListingsResponse>($"These items already have active listings: {string.Join(", ", activeAssetIds)}.");

        var marketHashNames = selectedItems
            .Select(item => item.InventoryItem.MarketHashName)
            .Distinct(StringComparer.Ordinal)
            .ToArray();
        var baseItems = await itemRepository.GetByMarketHashNamesAsync(marketHashNames, ct);
        var missingCatalogItems = marketHashNames
            .Where(hashName => !baseItems.ContainsKey(hashName))
            .ToArray();
        if (missingCatalogItems.Length > 0)
            return Result.Fail<CreateListingsResponse>($"These items are not currently supported by the market catalog: {string.Join(", ", missingCatalogItems)}.");

        var createdAt = DateTimeOffset.UtcNow;
        var listings = selectedItems.Select(item => new Listing
        {
            Id = Guid.NewGuid(),
            Price = item.Price,
            Status = ListingStatus.Active,
            CreatedAt = createdAt,
            SellerId = user.Id,
            ItemId = baseItems[item.InventoryItem.MarketHashName].Id,
            SteamAssetId = item.SteamAssetId,
            FloatValue = item.InventoryItem.FloatValue,
            PaintSeed = item.InventoryItem.PaintSeed,
            Metadata = item.InventoryItem.MetadataHex
        }).ToArray();

        var pendingScreenshotIds = await AttachScreenshotsAsync(listings, ct);

        listingRepository.AddRange(listings);
        await unitOfWork.SaveChangesAsync(ct);

        // Ставимо джоби лише після коміту, щоб воркер не стартував раніше за запис у БД.
        foreach (var screenshotId in pendingScreenshotIds)
        {
            backgroundJobClient.Enqueue<IScreenshotJobs>(
                jobs => jobs.CaptureAsync(screenshotId, CancellationToken.None));
        }

        return Result.Ok(new CreateListingsResponse
        {
            ListingIds = listings.Select(listing => listing.Id).ToArray()
        });
    }

    // Зв'язує листинги зі скріншотами за inspect-hex (Listing.Metadata).
    // Уже відрендерені екземпляри перевикористовуються; нові та невдалі йдуть у чергу на захоплення.
    private async Task<IReadOnlyList<Guid>> AttachScreenshotsAsync(
        IReadOnlyList<Listing> listings,
        CancellationToken ct)
    {
        var inspectHexes = listings
            .Where(listing => !string.IsNullOrWhiteSpace(listing.Metadata))
            .Select(listing => listing.Metadata!)
            .Distinct(StringComparer.Ordinal)
            .ToArray();
        if (inspectHexes.Length == 0)
            return Array.Empty<Guid>();

        var existing = await itemScreenshotRepository.GetByInspectHexesAsync(inspectHexes, ct);
        var screenshotsByHex = existing.ToDictionary(screenshot => screenshot.InspectHex, StringComparer.Ordinal);

        var pendingIds = new List<Guid>();
        foreach (var hex in inspectHexes)
        {
            if (screenshotsByHex.TryGetValue(hex, out var screenshot))
            {
                // Попередній рендер не вдався — пробуємо знову разом з новим листингом.
                if (screenshot.Status == ScreenshotStatus.Failed)
                {
                    screenshot.Status = ScreenshotStatus.Pending;
                    screenshot.Attempts = 0;
                    screenshot.LastError = null;
                    pendingIds.Add(screenshot.Id);
                }
                continue;
            }

            screenshot = new ItemScreenshot
            {
                Id = Guid.NewGuid(),
                InspectHex = hex,
                Status = ScreenshotStatus.Pending,
                CreatedAt = DateTimeOffset.UtcNow
            };
            itemScreenshotRepository.Add(screenshot);
            screenshotsByHex.Add(hex, screenshot);
            pendingIds.Add(screenshot.Id);
        }

        foreach (var listing in listings)
        {
            if (listing.Metadata is not null &&
                screenshotsByHex.TryGetValue(listing.Metadata, out var screenshot))
            {
                listing.ScreenshotId = screenshot.Id;
            }
        }

        return pendingIds;
    }

    public async Task<Result> UpdateListingAsync(
        Guid sellerId,
        Guid listingId,
        UpdateListingRequest request,
        CancellationToken ct)
    {
        if (listingId == Guid.Empty)
            return Result.Fail("ListingId is required.");

        var priceValidation = ValidateListingPrice(request.Price);
        if (priceValidation.IsFailed)
            return Result.Fail(priceValidation.Errors);

        var listing = await listingRepository.GetByIdForUpdateAsync(listingId, ct);
        if (listing is null)
            return Result.Fail("Listing not found.");
        if (listing.SellerId != sellerId)
            return Result.Fail("You can only update your own listings.");
        if (listing.Status != ListingStatus.Active)
            return Result.Fail("Only active listings can be updated.");

        listing.Price = request.Price;

        await listingRepository.UpdateAsync(listing, ct);
        await unitOfWork.SaveChangesAsync(ct);
        return Result.Ok();
    }

    public async Task<Result> RemoveListingAsync(Guid sellerId, Guid listingId, CancellationToken ct)
    {
        if (listingId == Guid.Empty)
            return Result.Fail("ListingId is required.");

        var listing = await listingRepository.GetByIdForUpdateAsync(listingId, ct);
        if (listing is null)
            return Result.Fail("Listing not found.");
        if (listing.SellerId != sellerId)
            return Result.Fail("You can only remove your own listings.");
        if (listing.Status != ListingStatus.Active)
            return Result.Fail("Only active listings can be removed.");

        listing.Status = ListingStatus.Cancelled;

        await listingRepository.UpdateAsync(listing, ct);
        await unitOfWork.SaveChangesAsync(ct);
        return Result.Ok();
    }

    public async Task<PagedResult<ListingCatalogItemDto>> GetCatalogAsync(
        GetListingsRequest request,
        CancellationToken ct)
    {
        ValidateCatalogRequest(request);
        var (listings, totalCount) = await listingRepository.GetActivePageAsync(request, ct);

        return new PagedResult<ListingCatalogItemDto>
        {
            Items = listings.Select(listing => new ListingCatalogItemDto
            {
                Id = listing.Id,
                Price = listing.Price,
                SellerId = listing.SellerId,
                SellerSteamId = listing.Seller.SteamId,
                ItemId = listing.ItemId,
                MarketHashName = listing.Item.MarketHashName,
                FloatValue = listing.FloatValue,
                PaintSeed = listing.PaintSeed,
                CreatedAt = listing.CreatedAt,
                InspectHex = listing.Metadata,
                ScreenshotFrontUrl = BuildScreenshotUrl(listing.Screenshot, listing.Screenshot?.FrontImagePath),
                ScreenshotBackUrl = BuildScreenshotUrl(listing.Screenshot, listing.Screenshot?.BackImagePath)
            }).ToList(),
            TotalCount = totalCount,
            Page = request.Page,
            PageSize = request.PageSize
        };
    }

    public async Task<Result<MarketItemPageDto>> GetItemPageAsync(
        MarketItemPageRequest request,
        CancellationToken ct)
    {
        var marketHashName = request.MarketHashName.Trim();
        if (marketHashName.Length < 2)
            return Result.Fail<MarketItemPageDto>("MarketHashName must be at least 2 characters.");

        var item = await itemRepository.GetByMarketHashNameAsync(marketHashName, ct);
        if (item is null)
            return Result.Fail<MarketItemPageDto>("Item was not found.");

        // Всі споріднені предмети (та сама зброя+скін): інші якості та StatTrak/Souvenir варіанти.
        var siblings = await itemRepository.GetByBaseNameAsync(item.BaseName, ct);
        var minByItem = await listingRepository.GetMinPriceByItemIdsAsync(
            siblings.Select(sibling => sibling.Id).ToArray(),
            ct);

        // Таби якості — лише той самий варіант (звичайний/StatTrak/сувенір), що й у поточного предмета.
        var wears = siblings
            .Where(sibling =>
                sibling.IsStatTrak == item.IsStatTrak &&
                sibling.IsSouvenir == item.IsSouvenir &&
                !string.IsNullOrWhiteSpace(sibling.Wear))
            .OrderBy(sibling => GetWearOrder(sibling.Wear!))
            .Select(sibling => new WearLinkDto
            {
                Wear = sibling.Wear!,
                MarketHashName = sibling.MarketHashName,
                MinPrice = minByItem.TryGetValue(sibling.Id, out var price) ? price : null,
                IsActive = sibling.Id == item.Id
            })
            .ToList();

        var variants = new List<VariantLinkDto>();
        AddVariantLink(variants, "normal", isStatTrak: false, isSouvenir: false, siblings, item);
        AddVariantLink(variants, "stattrak", isStatTrak: true, isSouvenir: false, siblings, item);
        AddVariantLink(variants, "souvenir", isStatTrak: false, isSouvenir: true, siblings, item);

        var summary = await listingRepository.GetItemPriceSummaryAsync(item.Id, ct);

        var listings = await GetCatalogAsync(new GetListingsRequest
        {
            Page = request.Page,
            PageSize = request.PageSize,
            ItemId = item.Id,
            MinPrice = request.MinPrice,
            MaxPrice = request.MaxPrice,
            MinFloat = request.MinFloat,
            MaxFloat = request.MaxFloat,
            PaintSeed = request.PaintSeed,
            SortBy = request.SortBy
        }, ct);

        return Result.Ok(new MarketItemPageDto
        {
            MarketHashName = item.MarketHashName,
            BaseName = item.BaseName,
            SkinName = ItemNameParser.GetSkinName(item.BaseName),
            Weapon = item.Weapon,
            Category = item.Category,
            Rarity = item.Rarity,
            Wear = item.Wear,
            IsStatTrak = item.IsStatTrak,
            IsSouvenir = item.IsSouvenir,
            ItemId = item.Id,
            Wears = wears,
            Variants = variants,
            ImageUrl = $"https://community.cloudflare.steamstatic.com/economy/image/{item.ImageHash}/300fx300f",
            RarityColor = item.Color,
            MinPrice = summary.MinPrice,
            AvgPrice = summary.AvgPrice,
            Listings = listings
        });
    }

    private static void AddVariantLink(
        List<VariantLinkDto> variants,
        string kind,
        bool isStatTrak,
        bool isSouvenir,
        IReadOnlyList<Entities.Item> siblings,
        Entities.Item current)
    {
        var group = siblings
            .Where(sibling => sibling.IsStatTrak == isStatTrak && sibling.IsSouvenir == isSouvenir)
            .ToList();
        if (group.Count == 0)
            return;

        // Ведемо на ту саму якість в іншому варіанті, інакше на найкращу доступну якість.
        var target = group.FirstOrDefault(sibling => sibling.Wear == current.Wear)
            ?? group.OrderBy(sibling => GetWearOrder(sibling.Wear ?? string.Empty)).First();

        variants.Add(new VariantLinkDto
        {
            Kind = kind,
            MarketHashName = target.MarketHashName,
            IsActive = isStatTrak == current.IsStatTrak && isSouvenir == current.IsSouvenir
        });
    }

    private string? BuildScreenshotUrl(ItemScreenshot? screenshot, string? imagePath)
    {
        if (screenshot?.Status != ScreenshotStatus.Ready || string.IsNullOrEmpty(imagePath))
            return null;

        return $"{screenshotOptions.Value.PublicBasePath.TrimEnd('/')}/{imagePath}";
    }

    private static int GetWearOrder(string wear)
    {
        var index = Array.IndexOf(WearOrder, wear);
        return index >= 0 ? index : int.MaxValue;
    }

    public async Task<Result<IReadOnlyList<MarketSearchTipDto>>> SearchTipsAsync(
        MarketSearchTipRequest request,
        CancellationToken ct)
    {
        var query = request.Query.Trim();
        if (query.Length < 2)
            return Result.Fail<IReadOnlyList<MarketSearchTipDto>>("Search query must be at least 2 characters.");
        if (query.Length > 80)
            return Result.Fail<IReadOnlyList<MarketSearchTipDto>>("Search query must be no more than 80 characters.");
        if (request.Limit is < 1 or > MaxSearchTipLimit)
            return Result.Fail<IReadOnlyList<MarketSearchTipDto>>($"Limit must be between 1 and {MaxSearchTipLimit}.");

        var tips = await itemRepository.SearchTipsAsync(query, request.Limit, ct);
        return Result.Ok(tips);
    }

    public async Task<Result<IReadOnlyList<MarketItemSearchResultDto>>> SearchItemsAsync(
        MarketSearchTipRequest request,
        CancellationToken ct)
    {
        var query = request.Query.Trim();
        if (query.Length < 2)
            return Result.Fail<IReadOnlyList<MarketItemSearchResultDto>>("Search query must be at least 2 characters.");
        if (query.Length > 80)
            return Result.Fail<IReadOnlyList<MarketItemSearchResultDto>>("Search query must be no more than 80 characters.");
        if (request.Limit is < 1 or > MaxSearchTipLimit)
            return Result.Fail<IReadOnlyList<MarketItemSearchResultDto>>($"Limit must be between 1 and {MaxSearchTipLimit}.");

        var items = await itemRepository.SearchItemsAsync(query, request.Limit, ct);

        var results = items
            .Select(item => new MarketItemSearchResultDto
            {
                MarketHashName = item.MarketHashName,
                BaseName = item.BaseName,
                Wear = item.Wear,
                IsStatTrak = item.IsStatTrak,
                IsSouvenir = item.IsSouvenir,
                Category = item.Category,
                Rarity = item.Rarity,
                Color = item.Color,
                ImageUrl = $"https://community.cloudflare.steamstatic.com/economy/image/{item.ImageHash}/300fx300f"
            })
            .ToList();

        return Result.Ok<IReadOnlyList<MarketItemSearchResultDto>>(results);
    }

    private static void ValidateCatalogRequest(GetListingsRequest request)
    {
        if (request.Page < 1)
            throw new ArgumentOutOfRangeException(nameof(request.Page), "Page must be at least 1.");
        if (request.PageSize is < 1 or > 100)
            throw new ArgumentOutOfRangeException(nameof(request.PageSize), "PageSize must be between 1 and 100.");
        if (request.MinPrice is < 0 || request.MaxPrice is < 0)
            throw new ArgumentOutOfRangeException(nameof(request), "Price filters cannot be negative.");
        if (request.MinPrice.HasValue && request.MaxPrice.HasValue && request.MinPrice > request.MaxPrice)
            throw new ArgumentException("MinPrice cannot be greater than MaxPrice.", nameof(request));
        if (request.MinFloat is < 0 or > 1 || request.MaxFloat is < 0 or > 1)
            throw new ArgumentOutOfRangeException(nameof(request), "Float filters must be between 0 and 1.");
        if (request.MinFloat.HasValue && request.MaxFloat.HasValue && request.MinFloat > request.MaxFloat)
            throw new ArgumentException("MinFloat cannot be greater than MaxFloat.", nameof(request));
        if (request.PaintSeed is < 0 or > 1000)
            throw new ArgumentOutOfRangeException(nameof(request.PaintSeed), "PaintSeed must be between 0 and 1000.");
        if (!string.IsNullOrWhiteSpace(request.SearchTerm) && request.SearchTerm.Trim().Length < 2)
            throw new ArgumentException("SearchTerm must be at least 2 characters.", nameof(request));
    }

    private static Result ValidateListingPrice(decimal price)
    {
        return price is <= 0 or > MaxListingPrice
            ? Result.Fail($"Price must be greater than zero and no more than {MaxListingPrice}.")
            : Result.Ok();
    }

    private static Error CreateExpiredTradeUrlError()
    {
        return new Error("Your Steam trade link is no longer valid. Please attach a new trade link.")
            .WithMetadata("errorCode", BusinessErrorCodes.RequireNewTradeUrl);
    }

    public async Task<PagedResult<SaleHistoryItemDto>> GetSaleHistoryAsync(
        int itemId, int page, int pageSize, CancellationToken ct)
    {
        if (page < 1) page = 1;
        if (pageSize is < 1 or > 100) pageSize = 20;

        var (rows, totalCount) = await listingRepository.GetSaleHistoryPageAsync(itemId, page, pageSize, ct);

        return new PagedResult<SaleHistoryItemDto>
        {
            Items = rows.Select(row =>
            {
                var listing = row.Listing;
                return new SaleHistoryItemDto
                {
                    Id = listing.Id,
                    Price = listing.Price,
                    SellerId = listing.SellerId,
                    SellerSteamId = listing.Seller?.SteamId ?? string.Empty,
                    ItemId = listing.ItemId,
                    MarketHashName = listing.Item?.MarketHashName ?? string.Empty,
                    FloatValue = listing.FloatValue,
                    PaintSeed = listing.PaintSeed,
                    CreatedAt = listing.CreatedAt,
                    InspectHex = listing.Metadata,
                    ScreenshotFrontUrl = BuildScreenshotUrl(listing.Screenshot, listing.Screenshot?.FrontImagePath),
                    ScreenshotBackUrl = BuildScreenshotUrl(listing.Screenshot, listing.Screenshot?.BackImagePath),
                    SoldAt = row.SoldAt
                };
            }).ToList(),
            TotalCount = totalCount,
            Page = page,
            PageSize = pageSize
        };
    }
}
