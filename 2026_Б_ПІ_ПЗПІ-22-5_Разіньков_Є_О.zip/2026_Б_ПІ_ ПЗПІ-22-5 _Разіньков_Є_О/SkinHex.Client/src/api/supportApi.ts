import type { AuthorizedFetch } from '../types';
import { readApiError } from '../utils/api';

// ---- DTOs (mirror SkinHex.Core.Models.Admin ticket DTOs, user-facing endpoints) ----

export type TicketCategory = 'Order' | 'Deposit' | 'Withdrawal' | 'Account' | 'Other';
export type SupportTicketStatus = 'Open' | 'PendingSupport' | 'PendingUser' | 'Resolved' | 'Closed';

export interface SupportTicketMessage {
  id: string;
  senderId: string;
  isFromSupport: boolean;
  body: string;
  createdAt: string;
}

export interface SupportTicketListItem {
  id: string;
  subject: string;
  category: string;
  status: string;
  userId: string;
  username: string;
  orderId: string | null;
  assignedAdminId: string | null;
  messagesCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface SupportTicketDetail {
  id: string;
  subject: string;
  category: string;
  status: string;
  userId: string;
  username: string;
  orderId: string | null;
  assignedAdminId: string | null;
  createdAt: string;
  updatedAt: string;
  closedAt: string | null;
  messages: SupportTicketMessage[];
}

async function json<T>(response: Response): Promise<T> {
  if (!response.ok) {
    throw new Error(await readApiError(response));
  }
  return response.json() as Promise<T>;
}

export async function fetchMyTickets(fetcher: AuthorizedFetch): Promise<SupportTicketListItem[]> {
  return json<SupportTicketListItem[]>(await fetcher('/support/tickets/my'));
}

export async function fetchMyTicket(fetcher: AuthorizedFetch, id: string): Promise<SupportTicketDetail> {
  return json<SupportTicketDetail>(await fetcher(`/support/tickets/${id}`));
}

export async function createTicket(
  fetcher: AuthorizedFetch,
  payload: { subject: string; category: TicketCategory; message: string; orderId?: string | null },
): Promise<SupportTicketDetail> {
  return json<SupportTicketDetail>(
    await fetcher('/support/tickets', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  );
}

export async function replyToMyTicket(fetcher: AuthorizedFetch, id: string, body: string): Promise<SupportTicketDetail> {
  return json<SupportTicketDetail>(
    await fetcher(`/support/tickets/${id}/reply`, {
      method: 'POST',
      body: JSON.stringify({ body }),
    }),
  );
}

// ---- Support page deep-link prefill (e.g. "Problem with this order" button) ----

export const SUPPORT_PREFILL_KEY = 'skinhex_support_prefill';

export type SupportPrefill = {
  orderId?: string | null;
  category?: TicketCategory;
  subject?: string;
};

export function storeSupportPrefill(prefill: SupportPrefill): void {
  sessionStorage.setItem(SUPPORT_PREFILL_KEY, JSON.stringify(prefill));
}

export function takeSupportPrefill(): SupportPrefill | null {
  const raw = sessionStorage.getItem(SUPPORT_PREFILL_KEY);
  if (!raw) return null;
  sessionStorage.removeItem(SUPPORT_PREFILL_KEY);
  try {
    return JSON.parse(raw) as SupportPrefill;
  } catch {
    return null;
  }
}
