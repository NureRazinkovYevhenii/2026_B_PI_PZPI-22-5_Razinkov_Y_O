using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Logging;
using Moq;
using SkinHex.API.Controllers;
using SkinHex.Core.Entities;
using SkinHex.Core.Interfaces;
using SkinHex.Core.Interfaces.Services;
using SkinHex.Core.Models.Admin;
using SkinHex.Infrastructure;
using Xunit;

namespace SkinHex.Core.Tests.Withdrawals;

public class AdminWithdrawalsTests
{
    private readonly SkinHexDbContext _dbContext;
    private readonly Mock<INowPaymentsPayoutService> _payoutServiceMock = new();
    private readonly Guid _adminId = Guid.NewGuid();

    public AdminWithdrawalsTests()
    {
        var dbOptions = new DbContextOptionsBuilder<SkinHexDbContext>()
            .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
            .ConfigureWarnings(w => w.Ignore(InMemoryEventId.TransactionIgnoredWarning))
            .Options;
        _dbContext = new SkinHexDbContext(dbOptions);
    }

    private AdminController CreateController()
    {
        var controller = new AdminController(
            _dbContext,
            Mock.Of<IUserService>(),
            _payoutServiceMock.Object,
            Mock.Of<INotificationService>(),
            Mock.Of<IDisputeService>(),
            Mock.Of<ILogger<AdminController>>());
        var principal = new ClaimsPrincipal(new ClaimsIdentity(new[]
        {
            new Claim(ClaimTypes.NameIdentifier, _adminId.ToString())
        }));
        controller.ControllerContext = new ControllerContext { HttpContext = new DefaultHttpContext { User = principal } };
        return controller;
    }

    private Withdrawal SeedWithdrawal(decimal userBalance, WithdrawalStatus status = WithdrawalStatus.Pending)
    {
        var user = new User { Id = Guid.NewGuid(), SteamId = "s", Username = "u", Balance = userBalance };
        var tx = new FinancialTransaction
        {
            Id = Guid.NewGuid(), UserId = user.Id, Amount = 5m,
            Type = FinancialTransactionType.Withdrawal, Status = FinancialTransactionStatus.Pending
        };
        var withdrawal = new Withdrawal
        {
            Id = Guid.NewGuid(), UserId = user.Id, TransactionId = tx.Id,
            AmountUsd = 5m, PlatformFeeUsd = 0m, PayoutAmountUsd = 5m,
            PayCurrency = "usdttrc20", PayoutAddress = "TAddr", Status = status
        };
        _dbContext.Users.Add(user);
        _dbContext.FinancialTransactions.Add(tx);
        _dbContext.Withdrawals.Add(withdrawal);
        _dbContext.SaveChanges();
        return withdrawal;
    }

    [Fact]
    public async Task Approve_CallsPayoutServiceAndSetsProcessing()
    {
        var withdrawal = SeedWithdrawal(userBalance: 5m);
        _payoutServiceMock
            .Setup(s => s.CreatePayoutAsync("TAddr", "usdttrc20", 5m, null, It.IsAny<CancellationToken>()))
            .ReturnsAsync(new PayoutResult("batch1", "payout1", "creating"));
        var controller = CreateController();

        Assert.IsType<OkObjectResult>(await controller.ApproveWithdrawal(withdrawal.Id, default));

        var updated = await _dbContext.Withdrawals.FindAsync(withdrawal.Id);
        Assert.Equal(WithdrawalStatus.Processing, updated!.Status);
        Assert.Equal("payout1", updated.NowPaymentsPayoutId);
        Assert.Equal(_adminId, updated.ProcessedByAdminId);
    }

    [Fact]
    public async Task Approve_ReturnsBadGateway_WhenPayoutFails_AndKeepsPending()
    {
        var withdrawal = SeedWithdrawal(userBalance: 5m);
        _payoutServiceMock
            .Setup(s => s.CreatePayoutAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<decimal>(), It.IsAny<string?>(), It.IsAny<CancellationToken>()))
            .ThrowsAsync(new PayoutException("Payouts are not configured."));
        var controller = CreateController();

        var result = await controller.ApproveWithdrawal(withdrawal.Id, default);

        var obj = Assert.IsType<ObjectResult>(result);
        Assert.Equal(StatusCodes.Status502BadGateway, obj.StatusCode);
        Assert.Equal(WithdrawalStatus.Pending, (await _dbContext.Withdrawals.FindAsync(withdrawal.Id))!.Status);
    }

    [Fact]
    public async Task Approve_RejectsNonPending()
    {
        var withdrawal = SeedWithdrawal(userBalance: 5m, status: WithdrawalStatus.Processing);
        var controller = CreateController();

        Assert.IsType<BadRequestObjectResult>(await controller.ApproveWithdrawal(withdrawal.Id, default));
    }

    [Fact]
    public async Task Reject_RefundsBalanceAndCancelsTransaction()
    {
        var withdrawal = SeedWithdrawal(userBalance: 5m);
        var controller = CreateController();

        Assert.IsType<OkObjectResult>(await controller.RejectWithdrawal(withdrawal.Id, new RejectWithdrawalRequest("bad address"), default));

        var updated = await _dbContext.Withdrawals.Include(w => w.User).Include(w => w.Transaction).FirstAsync(w => w.Id == withdrawal.Id);
        Assert.Equal(WithdrawalStatus.Rejected, updated.Status);
        Assert.Equal(10m, updated.User.Balance); // 5 refunded onto the seeded 5
        Assert.Equal(FinancialTransactionStatus.Cancelled, updated.Transaction.Status);
    }
}
