using SkinHex.Core.Models.Steam;

namespace SkinHex.SteamGateway.Steam;

public interface ISteamBotSessionProvider
{
    Task<SteamBotSession> GetAnyReadySessionAsync(CancellationToken cancellationToken = default);

    /// <summary>
    /// Quarantines a bot account so it is skipped when picking a session, e.g. after Steam
    /// rate-limits (429) or bans it. Mirrors proxy quarantine in <see cref="Proxies.RandomProxyProvider"/>.
    /// </summary>
    void Quarantine(string username, string reason);
}
