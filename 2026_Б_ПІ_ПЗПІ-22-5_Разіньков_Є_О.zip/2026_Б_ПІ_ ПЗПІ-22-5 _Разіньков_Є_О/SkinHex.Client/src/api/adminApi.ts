import type { AuthorizedFetch, PagedResult } from '../types';
import { readApiError } from '../utils/api';

// ---- DTOs (mirror SkinHex.Core.Models.Admin) ----

export interface AdminUserListItem {
  id: string;
  steamId: string;
  username: string;
  email: string | null;
  avatarUrl: string | null;
  role: string;
  balance: number;
  frozenBalance: number;
  createdAt: string;
}

export interface AdminTransaction {
  id: string;
  amount: number;
  type: string;
  status: string;
  referenceId: string | null;
  createdAt: string;
}

export interface AdminUserDetail {
  id: string;
  steamId: string;
  username: string;
  email: string | null;
  avatarUrl: string | null;
  tradeUrl: string | null;
  role: string;
  balance: number;
  frozenBalance: number;
  createdAt: string;
  updatedAt: string | null;
  activeListingsCount: number;
  ordersAsBuyer: number;
  ordersAsSeller: number;
  openTicketsCount: number;
  recentTransactions: AdminTransaction[];
}

export interface AdminParticipant {
  id: string;
  username: string;
  steamId: string;
  avatarUrl: string | null;
}

export interface AdminOrderListItem {
  orderId: string;
  status: string;
  price: number;
  buyer: AdminParticipant;
  seller: AdminParticipant;
  marketHashName: string;
  createdAt: string;
}

export interface AdminOrderTrade {
  id: string;
  tradeOfferId: string;
  tradeId: string | null;
  offerState: string;
  tradeStatus: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface AdminOrderDetail {
  orderId: string;
  listingId: string;
  status: string;
  price: number;
  cancelledBy: string | null;
  cancelReason: string | null;
  createdAt: string;
  confirmedAt: string | null;
  tradeSentAt: string | null;
  holdEndsAt: string | null;
  cancelledAt: string | null;
  updatedAt: string;
  buyer: AdminParticipant;
  seller: AdminParticipant;
  marketHashName: string;
  wear: string | null;
  float: number | null;
  trades: AdminOrderTrade[];
}

export interface TicketMessage {
  id: string;
  senderId: string;
  isFromSupport: boolean;
  body: string;
  createdAt: string;
}

export interface TicketListItem {
  id: string;
  subject: string;
  category: string;
  status: string;
  userId: string;
  username: string;
  orderId: string | null;
  assignedAdminId: string | null;
  messagesCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface TicketDetail {
  id: string;
  subject: string;
  category: string;
  status: string;
  userId: string;
  username: string;
  orderId: string | null;
  assignedAdminId: string | null;
  createdAt: string;
  updatedAt: string;
  closedAt: string | null;
  messages: TicketMessage[];
}

export interface DashboardStats {
  totalUsers: number;
  bannedUsers: number;
  openTickets: number;
  pendingOrders: number;
  totalUserBalance: number;
  totalFrozenBalance: number;
  openDisputes: number;
}

export type TicketStatus = 'Open' | 'PendingSupport' | 'PendingUser' | 'Resolved' | 'Closed';

export interface AdminWithdrawalListItem {
  id: string;
  userId: string;
  username: string;
  amountUsd: number;
  platformFeeUsd: number;
  payoutAmountUsd: number;
  payCurrency: string;
  payoutAddress: string;
  payoutExtraId: string | null;
  status: string;
  rejectionReason: string | null;
  nowPaymentsPayoutId: string | null;
  createdAt: string;
  processedAt: string | null;
}

// ---- helpers ----

async function json<T>(response: Response): Promise<T> {
  if (!response.ok) {
    throw new Error(await readApiError(response));
  }
  return response.json() as Promise<T>;
}

function buildQuery(params: Record<string, unknown>): string {
  const search = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined && value !== null && value !== '') {
      search.set(key, String(value));
    }
  }
  const qs = search.toString();
  return qs ? `?${qs}` : '';
}

// ---- Dashboard ----

export async function fetchDashboard(fetcher: AuthorizedFetch): Promise<DashboardStats> {
  return json<DashboardStats>(await fetcher('/admin/dashboard'));
}

// ---- Users ----

export type UsersQuery = {
  search?: string;
  role?: string;
  page?: number;
  pageSize?: number;
};

export async function fetchUsers(fetcher: AuthorizedFetch, query: UsersQuery = {}): Promise<PagedResult<AdminUserListItem>> {
  return json<PagedResult<AdminUserListItem>>(await fetcher(`/admin/users${buildQuery(query)}`));
}

export async function fetchUser(fetcher: AuthorizedFetch, id: string): Promise<AdminUserDetail> {
  return json<AdminUserDetail>(await fetcher(`/admin/users/${id}`));
}

export async function banUser(fetcher: AuthorizedFetch, id: string): Promise<void> {
  const response = await fetcher(`/admin/users/${id}/ban`, { method: 'POST' });
  if (!response.ok) throw new Error(await readApiError(response));
}

export async function unbanUser(fetcher: AuthorizedFetch, id: string): Promise<void> {
  const response = await fetcher(`/admin/users/${id}/unban`, { method: 'POST' });
  if (!response.ok) throw new Error(await readApiError(response));
}

export async function adjustBalance(
  fetcher: AuthorizedFetch,
  id: string,
  amount: number,
  reason: string,
): Promise<{ balance: number }> {
  return json<{ balance: number }>(
    await fetcher(`/admin/users/${id}/balance-adjust`, {
      method: 'POST',
      body: JSON.stringify({ amount, reason }),
    }),
  );
}

// ---- Orders ----

export type OrdersQuery = {
  status?: string;
  search?: string;
  page?: number;
  pageSize?: number;
};

export async function fetchOrders(fetcher: AuthorizedFetch, query: OrdersQuery = {}): Promise<PagedResult<AdminOrderListItem>> {
  return json<PagedResult<AdminOrderListItem>>(await fetcher(`/admin/orders${buildQuery(query)}`));
}

export async function fetchOrder(fetcher: AuthorizedFetch, id: string): Promise<AdminOrderDetail> {
  return json<AdminOrderDetail>(await fetcher(`/admin/orders/${id}`));
}

// ---- Tickets ----

export type TicketsQuery = {
  status?: string;
  category?: string;
  search?: string;
  page?: number;
  pageSize?: number;
};

export async function fetchTickets(fetcher: AuthorizedFetch, query: TicketsQuery = {}): Promise<PagedResult<TicketListItem>> {
  return json<PagedResult<TicketListItem>>(await fetcher(`/admin/tickets${buildQuery(query)}`));
}

export async function fetchTicket(fetcher: AuthorizedFetch, id: string): Promise<TicketDetail> {
  return json<TicketDetail>(await fetcher(`/admin/tickets/${id}`));
}

export async function replyToTicket(fetcher: AuthorizedFetch, id: string, body: string): Promise<TicketDetail> {
  return json<TicketDetail>(
    await fetcher(`/admin/tickets/${id}/reply`, {
      method: 'POST',
      body: JSON.stringify({ body }),
    }),
  );
}

export async function setTicketStatus(fetcher: AuthorizedFetch, id: string, status: TicketStatus): Promise<TicketDetail> {
  return json<TicketDetail>(
    await fetcher(`/admin/tickets/${id}/status`, {
      method: 'POST',
      body: JSON.stringify({ status }),
    }),
  );
}

// ---- Disputes ----

export type DisputeResolution =
  | 'RefundBuyer'
  | 'CompleteOrder'
  | 'ApplyBuyerPenalty'
  | 'ReverseBuyerPenalty'
  | 'NoAction';

export interface AdminDisputeListItem {
  id: string;
  orderId: string;
  openedByUserId: string | null;
  openedByUsername: string | null;
  reason: string;
  status: string;
  resolution: string;
  orderStatus: string;
  orderPrice: number;
  frozenPenaltyAmount: number | null;
  createdAt: string;
  updatedAt: string;
}

export interface AdminDisputeInfo {
  id: string;
  orderId: string;
  openedByUserId: string | null;
  reason: string;
  status: string;
  resolution: string;
  description: string;
  resolutionNote: string | null;
  frozenPenaltyAmount: number | null;
  createdAt: string;
  updatedAt: string;
  resolvedAt: string | null;
}

export interface AdminDisputeOrder {
  orderId: string;
  status: string;
  lockPrice: number;
  buyerId: string;
  buyerUsername: string;
  sellerId: string;
  sellerUsername: string;
  marketHashName: string | null;
  listingAssetId: number;
  cancelledBy: string | null;
  cancelReason: string | null;
  createdAt: string;
}

export interface AdminDisputeTrade {
  tradeOfferId: string;
  steamTradeId: string | null;
  offerState: string;
  tradeStatus: string | null;
  buyerReportedOfferState: string | null;
  buyerReportedAt: string | null;
  buyerSeenAssetIds: string | null;
  buyerAssetMatchesListing: boolean | null;
  createdAt: string;
  updatedAt: string;
}

export interface AdminDisputeProof {
  id: string;
  steamTradeId: string | null;
  tradeStatus: number | null;
  steamIdOther: string | null;
  transferredAssetIds: string | null;
  outcome: string;
  failureCode: string | null;
  failureReason: string | null;
  receivedAt: string;
}

export interface AdminDisputeDetail {
  dispute: AdminDisputeInfo;
  order: AdminDisputeOrder;
  trades: AdminDisputeTrade[];
  proofs: AdminDisputeProof[];
}

export type DisputesQuery = {
  status?: string;
  reason?: string;
  search?: string;
  page?: number;
  pageSize?: number;
};

export async function fetchDisputes(fetcher: AuthorizedFetch, query: DisputesQuery = {}): Promise<PagedResult<AdminDisputeListItem>> {
  return json<PagedResult<AdminDisputeListItem>>(await fetcher(`/admin/disputes${buildQuery(query)}`));
}

export async function fetchDispute(fetcher: AuthorizedFetch, id: string): Promise<AdminDisputeDetail> {
  return json<AdminDisputeDetail>(await fetcher(`/admin/disputes/${id}`));
}

export async function takeDisputeUnderReview(fetcher: AuthorizedFetch, id: string): Promise<AdminDisputeInfo> {
  return json<AdminDisputeInfo>(await fetcher(`/admin/disputes/${id}/review`, { method: 'POST' }));
}

export async function resolveDispute(
  fetcher: AuthorizedFetch,
  id: string,
  resolution: DisputeResolution,
  note: string,
): Promise<AdminDisputeInfo> {
  return json<AdminDisputeInfo>(
    await fetcher(`/admin/disputes/${id}/resolve`, {
      method: 'POST',
      body: JSON.stringify({ resolution, note }),
    }),
  );
}

// ---- Withdrawals ----

export type WithdrawalsQuery = {
  status?: string;
  search?: string;
  page?: number;
  pageSize?: number;
};

export async function fetchWithdrawals(fetcher: AuthorizedFetch, query: WithdrawalsQuery = {}): Promise<PagedResult<AdminWithdrawalListItem>> {
  return json<PagedResult<AdminWithdrawalListItem>>(await fetcher(`/admin/withdrawals${buildQuery(query)}`));
}

export async function approveWithdrawal(fetcher: AuthorizedFetch, id: string): Promise<void> {
  const response = await fetcher(`/admin/withdrawals/${id}/approve`, { method: 'POST' });
  if (!response.ok) throw new Error(await readApiError(response));
}

export async function rejectWithdrawal(fetcher: AuthorizedFetch, id: string, reason: string): Promise<void> {
  const response = await fetcher(`/admin/withdrawals/${id}/reject`, {
    method: 'POST',
    body: JSON.stringify({ reason }),
  });
  if (!response.ok) throw new Error(await readApiError(response));
}
