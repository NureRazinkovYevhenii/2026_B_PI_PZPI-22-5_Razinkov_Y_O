namespace SkinHex.Core.Entities;

public enum DepositStatus
{
    Waiting = 0,
    Confirming = 1,
    PartiallyPaid = 2,
    Finished = 3,
    Failed = 4,
    Expired = 5
}

public class Deposit
{
    public Guid Id { get; set; }
    public Guid UserId { get; set; }
    public string NowPaymentsPaymentId { get; set; } = string.Empty;
    public decimal FiatAmount { get; set; }
    public string PayCurrency { get; set; } = string.Empty;
    public decimal? PayAmount { get; set; }

    /// <summary>Blockchain transaction hash of the user's incoming payment (NOWPayments "payin_hash").</summary>
    public string? PayinHash { get; set; }

    public DepositStatus Status { get; set; }
    public Guid TransactionId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    
    public FinancialTransaction Transaction { get; set; } = null!;
    public User User { get; set; } = null!;
}
