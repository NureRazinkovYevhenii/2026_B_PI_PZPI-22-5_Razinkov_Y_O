using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;

namespace SkinHex.API.Hubs;

/// <summary>
/// Single realtime hub for the platform. Server-to-client only for now: clients subscribe
/// to the events listed in <see cref="SkinHex.Core.Models.Notifications.RealtimeEvents"/>.
/// User targeting relies on the default IUserIdProvider, which maps connections by the
/// ClaimTypes.NameIdentifier claim from the JWT — the same user id the controllers use.
/// </summary>
[Authorize]
public class NotificationsHub : Hub
{
}
