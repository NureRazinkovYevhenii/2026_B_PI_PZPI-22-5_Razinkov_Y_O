namespace SkinHex.Core.Models;

public sealed class MarketSearchTipRequest
{
    public string Query { get; set; } = string.Empty;
    public int Limit { get; set; } = 10;
}
