using Microsoft.EntityFrameworkCore;
using SkinHex.Core.Entities;
using SkinHex.Core.Interfaces.Repositories;

namespace SkinHex.Infrastructure.Repositories;

public sealed class NotificationRepository(SkinHexDbContext dbContext) : INotificationRepository
{
    public async Task AddAsync(Notification notification, CancellationToken ct = default)
    {
        await dbContext.Notifications.AddAsync(notification, ct);
    }

    public Task<List<Notification>> GetLatestAsync(Guid userId, int limit, DateTime? before, CancellationToken ct = default)
    {
        var query = dbContext.Notifications
            .AsNoTracking()
            .Where(n => n.UserId == userId);

        if (before.HasValue)
            query = query.Where(n => n.CreatedAt < before.Value);

        return query
            .OrderByDescending(n => n.CreatedAt)
            .Take(limit)
            .ToListAsync(ct);
    }

    public Task<int> GetUnreadCountAsync(Guid userId, CancellationToken ct = default)
    {
        return dbContext.Notifications.CountAsync(n => n.UserId == userId && !n.IsRead, ct);
    }

    public Task<int> MarkReadAsync(Guid userId, IReadOnlyCollection<Guid> ids, DateTime readAt, CancellationToken ct = default)
    {
        return dbContext.Notifications
            .Where(n => n.UserId == userId && !n.IsRead && ids.Contains(n.Id))
            .ExecuteUpdateAsync(setters => setters
                .SetProperty(n => n.IsRead, true)
                .SetProperty(n => n.ReadAt, readAt), ct);
    }

    public Task<int> MarkAllReadAsync(Guid userId, DateTime readAt, CancellationToken ct = default)
    {
        return dbContext.Notifications
            .Where(n => n.UserId == userId && !n.IsRead)
            .ExecuteUpdateAsync(setters => setters
                .SetProperty(n => n.IsRead, true)
                .SetProperty(n => n.ReadAt, readAt), ct);
    }

    public Task<List<Guid>> GetUserIdsWithListingInCartAsync(Guid listingId, Guid? excludeUserId, CancellationToken ct = default)
    {
        var query = dbContext.CartItems
            .AsNoTracking()
            .Where(c => c.ListingId == listingId);

        if (excludeUserId.HasValue)
            query = query.Where(c => c.UserId != excludeUserId.Value);

        return query
            .Select(c => c.UserId)
            .Distinct()
            .ToListAsync(ct);
    }
}
