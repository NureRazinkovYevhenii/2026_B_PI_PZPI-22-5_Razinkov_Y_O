import { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { ExternalLink } from 'lucide-react';
import type { AuthorizedFetch, ItemDictionaryEntry } from '../types';
import { getTransactions, type Transaction } from '../api/transactionsApi';
import { getItemImageUrl, loadItemDictionary } from '../utils/itemDictionary';
import { Pager } from './admin/adminShared';

type Props = { authorizedFetch: AuthorizedFetch };

const PAGE_SIZE = 10;
const INCOMING = new Set(['Deposit', 'Sale', 'Refund']);
const OUTGOING = new Set(['Withdrawal', 'Purchase', 'Commission']);

function amountSign(type: string, amount: number): { text: string; color: string } {
  if (INCOMING.has(type)) return { text: `+$${amount.toFixed(2)}`, color: '#34d399' };
  if (OUTGOING.has(type)) return { text: `−$${amount.toFixed(2)}`, color: '#f87171' };
  // Penalty (signed: charged vs. compensation), AdminAdjustment, or unknown: respect the stored sign.
  return amount < 0
    ? { text: `−$${Math.abs(amount).toFixed(2)}`, color: '#f87171' }
    : { text: `+$${amount.toFixed(2)}`, color: '#34d399' };
}

function formatDate(value: string): string {
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? '—' : d.toLocaleString();
}

function shortHash(hash: string): string {
  return hash.length > 16 ? `${hash.slice(0, 8)}…${hash.slice(-6)}` : hash;
}

export function TransactionsPanel({ authorizedFetch }: Props) {
  const { t } = useTranslation();
  const [page, setPage] = useState(1);
  const [items, setItems] = useState<Transaction[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [dictionary, setDictionary] = useState<Record<string, ItemDictionaryEntry>>({});

  useEffect(() => {
    void loadItemDictionary().then(setDictionary).catch(() => { /* icons are best-effort */ });
  }, []);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await getTransactions(authorizedFetch, page, PAGE_SIZE);
      setItems(result.items);
      setTotalCount(result.totalCount);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load transactions');
    } finally {
      setLoading(false);
    }
  }, [authorizedFetch, page]);

  useEffect(() => {
    void load();
  }, [load]);

  const renderDetails = (tx: Transaction) => {
    if (tx.skin) {
      const icon = getItemImageUrl(dictionary[tx.skin.marketHashName] ?? null);
      return (
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          {icon ? (
            <img src={icon} alt="" style={{ width: 40, height: 30, objectFit: 'contain', flexShrink: 0 }} />
          ) : (
            <div style={{ width: 40, height: 30, background: 'var(--surface-hover)', borderRadius: 4, flexShrink: 0 }} />
          )}
          <div>
            <div style={{ fontWeight: 600, color: 'var(--text-h)' }}>{tx.skin.marketHashName}</div>
            <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>
              {t(
                tx.skin.role === 'Purchase'
                  ? 'transactions.boughtFrom'
                  : tx.skin.role === 'Sale'
                    ? 'transactions.soldTo'
                    : 'transactions.orderWith',
                { user: tx.skin.partnerUsername },
              )}
              {tx.skin.wear ? ` · ${tx.skin.wear}` : ''}
            </div>
          </div>
        </div>
      );
    }

    if (tx.crypto) {
      const { crypto } = tx;
      return (
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontWeight: 600, color: 'var(--text-h)' }}>
            {crypto.payCurrency.toUpperCase()}
            {crypto.network && <span className="admin-chip">{crypto.network}</span>}
            {crypto.amount != null && (
              <span style={{ fontSize: 12, color: 'var(--text-muted)', fontWeight: 500 }}>
                {crypto.amount} {crypto.payCurrency.toUpperCase()}
              </span>
            )}
          </div>

          {crypto.address && (
            <div style={{ fontSize: 12, color: 'var(--text-muted)', fontFamily: 'monospace', wordBreak: 'break-all', marginTop: 2 }}>
              {t('transactions.to')}: {crypto.address}
            </div>
          )}

          <div style={{ marginTop: 4 }}>
            {crypto.explorerUrl ? (
              <a
                href={crypto.explorerUrl}
                target="_blank"
                rel="noopener noreferrer"
                style={{ display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: 12, color: 'var(--accent)', textDecoration: 'none', fontFamily: 'monospace' }}
              >
                {shortHash(crypto.txHash!)} <ExternalLink size={12} />
              </a>
            ) : crypto.txHash ? (
              <span style={{ fontSize: 12, color: 'var(--text-muted)', fontFamily: 'monospace' }}>{shortHash(crypto.txHash)}</span>
            ) : (
              <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>{t('transactions.txPending')}</span>
            )}
          </div>
        </div>
      );
    }

    return <span style={{ color: 'var(--text-h)' }}>{t(`transactions.types.${tx.type}`, tx.type)}</span>;
  };

  return (
    <article className="trade-url-panel">
      <div>
        <p className="eyebrow">{t('transactions.eyebrow')}</p>
        <h2>{t('transactions.title')}</h2>
      </div>

      {error ? (
        <div className="inventory-state"><strong>{error}</strong></div>
      ) : loading ? (
        <div className="inventory-state"><strong>{t('transactions.loading')}</strong></div>
      ) : items.length === 0 ? (
        <div className="inventory-state"><strong>{t('transactions.none')}</strong></div>
      ) : (
        <>
          <div className="admin-table-wrap">
            <table className="admin-table">
              <thead>
                <tr>
                  <th>{t('transactions.details')}</th>
                  <th>{t('transactions.type')}</th>
                  <th style={{ textAlign: 'right' }}>{t('transactions.amount')}</th>
                  <th>{t('transactions.status')}</th>
                  <th>{t('transactions.date')}</th>
                </tr>
              </thead>
              <tbody>
                {items.map((tx) => {
                  const sign = amountSign(tx.type, tx.amount);
                  return (
                    <tr key={tx.id}>
                      <td>{renderDetails(tx)}</td>
                      <td style={{ color: 'var(--text-muted)' }}>{t(`transactions.types.${tx.type}`, tx.type)}</td>
                      <td style={{ textAlign: 'right', fontWeight: 700, color: sign.color, whiteSpace: 'nowrap' }}>{sign.text}</td>
                      <td style={{ color: 'var(--text-muted)', fontSize: 13 }}>{tx.status}</td>
                      <td style={{ color: 'var(--text-muted)', fontSize: 13, whiteSpace: 'nowrap' }}>{formatDate(tx.createdAt)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <Pager page={page} pageSize={PAGE_SIZE} totalCount={totalCount} onPage={setPage} />
        </>
      )}
    </article>
  );
}
