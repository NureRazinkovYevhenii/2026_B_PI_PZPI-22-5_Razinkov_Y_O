import type { PingResponse } from "./types";

export async function getVersion(): Promise<PingResponse> {
    return {
        success: true,
        version: chrome.runtime.getManifest().version,
    };
}