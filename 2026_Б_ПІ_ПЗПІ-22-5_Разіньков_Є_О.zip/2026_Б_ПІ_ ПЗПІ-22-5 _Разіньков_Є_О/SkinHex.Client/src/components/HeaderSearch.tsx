import { useEffect, useRef, useState, type KeyboardEvent } from 'react';
import { Loader2, Search } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { API_BASE_URL } from '../config';
import type { MarketItemSearchResult } from '../types';

const MIN_QUERY = 2;
const LIMIT = 8;

/** Global item search — suggestions navigate straight to a specific skin page (#skin/<marketHashName>). */
export function HeaderSearch() {
  const { t } = useTranslation();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<MarketItemSearchResult[]>([]);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(0);
  const [loading, setLoading] = useState(false);

  const wrapRef = useRef<HTMLDivElement>(null);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const term = query.trim();
    if (term.length < MIN_QUERY) {
      setResults([]);
      setOpen(false);
      setLoading(false);
      return;
    }

    setLoading(true);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(async () => {
      try {
        const res = await fetch(
          `${API_BASE_URL}/market/item-search?query=${encodeURIComponent(term)}&limit=${LIMIT}`,
        );
        if (res.ok) {
          const data = (await res.json()) as MarketItemSearchResult[];
          setResults(data);
          setActive(0);
          setOpen(true);
        }
      } catch {
        // Network hiccup — leave the previous results in place.
      } finally {
        setLoading(false);
      }
    }, 250);

    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, [query]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (wrapRef.current && !wrapRef.current.contains(event.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const openItem = (marketHashName: string) => {
    window.location.hash = `skin/${encodeURIComponent(marketHashName)}`;
    setOpen(false);
    setQuery('');
    setResults([]);
  };

  const handleKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'Escape') {
      setOpen(false);
      return;
    }
    if (!open || results.length === 0) return;

    if (event.key === 'ArrowDown') {
      event.preventDefault();
      setActive((current) => Math.min(results.length - 1, current + 1));
    } else if (event.key === 'ArrowUp') {
      event.preventDefault();
      setActive((current) => Math.max(0, current - 1));
    } else if (event.key === 'Enter') {
      event.preventDefault();
      // Enter opens the highlighted match (top result by default) — no separate results page.
      const target = results[active] ?? results[0];
      if (target) openItem(target.marketHashName);
    }
  };

  const term = query.trim();
  const showDropdown = open && term.length >= MIN_QUERY;

  return (
    <div className="hdr-search" ref={wrapRef}>
      <Search size={16} className="hdr-search-icon" />
      <input
        type="text"
        className="hdr-search-input"
        placeholder={t('header.searchPlaceholder', 'Search for a skin…')}
        value={query}
        onChange={(event) => setQuery(event.target.value)}
        onKeyDown={handleKeyDown}
        onFocus={() => {
          if (results.length > 0) setOpen(true);
        }}
        role="combobox"
        aria-expanded={showDropdown}
        aria-controls="hdr-search-list"
        aria-autocomplete="list"
      />
      {loading ? <Loader2 size={15} className="hdr-search-spinner spin-animation" /> : null}

      {showDropdown ? (
        <div className="hdr-search-dropdown" id="hdr-search-list" role="listbox">
          {results.length === 0 ? (
            <div className="hdr-search-empty">{loading ? 'Searching…' : 'No items found'}</div>
          ) : (
            results.map((item, index) => {
              const color = item.color ? `#${item.color}` : 'var(--border)';
              return (
                <button
                  key={item.marketHashName}
                  type="button"
                  role="option"
                  aria-selected={index === active}
                  className={`hdr-search-row ${index === active ? 'active' : ''}`}
                  onMouseEnter={() => setActive(index)}
                  onMouseDown={(event) => {
                    event.preventDefault(); // keep input focus until navigation
                    openItem(item.marketHashName);
                  }}
                >
                  <span
                    className="hdr-search-thumb"
                    style={{ borderColor: `${color}66`, background: `${color}18` }}
                  >
                    <img src={item.imageUrl} alt="" loading="lazy" />
                  </span>
                  <span className="hdr-search-text">
                    <span className="hdr-search-name">
                      {item.baseName}
                      {item.wear ? <span className="hdr-search-wear"> ({item.wear})</span> : null}
                    </span>
                    <span className="hdr-search-sub">
                      {item.isStatTrak ? <span className="hdr-search-badge stattrak">ST™</span> : null}
                      {item.isSouvenir ? <span className="hdr-search-badge souvenir">SV</span> : null}
                      <span style={{ color }}>{item.rarity}</span>
                      <span className="hdr-search-sep">·</span>
                      <span>{item.category}</span>
                    </span>
                  </span>
                </button>
              );
            })
          )}
        </div>
      ) : null}
    </div>
  );
}
