using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SkinHex.API.Controllers;
using SkinHex.Core.Entities;
using SkinHex.Core.Models.Admin;
using SkinHex.Infrastructure;
using Xunit;

namespace SkinHex.Core.Tests.Admin;

public class SupportTicketsControllerTests
{
    private readonly SkinHexDbContext _dbContext;
    private readonly Guid _userId = Guid.NewGuid();

    public SupportTicketsControllerTests()
    {
        var dbOptions = new DbContextOptionsBuilder<SkinHexDbContext>()
            .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
            .Options;
        _dbContext = new SkinHexDbContext(dbOptions);
        _dbContext.Users.Add(new User
        {
            Id = _userId,
            SteamId = "steam",
            Username = "owner",
            Role = UserRole.User
        });
        _dbContext.SaveChanges();
    }

    private SupportTicketsController CreateController(Guid? actingUserId = null)
    {
        var controller = new SupportTicketsController(_dbContext);
        var principal = new ClaimsPrincipal(new ClaimsIdentity(new[]
        {
            new Claim(ClaimTypes.NameIdentifier, (actingUserId ?? _userId).ToString())
        }));
        controller.ControllerContext = new ControllerContext
        {
            HttpContext = new DefaultHttpContext { User = principal }
        };
        return controller;
    }

    [Fact]
    public async Task CreateTicket_CreatesTicketWithFirstMessage()
    {
        var controller = CreateController();

        var result = Assert.IsType<OkObjectResult>(await controller.CreateTicket(
            new CreateTicketRequest("Cannot withdraw", TicketCategory.Account, null, "Please help"), default));
        var detail = Assert.IsType<TicketDetailDto>(result.Value);

        Assert.Equal(nameof(TicketStatus.Open), detail.Status);
        Assert.Equal("Cannot withdraw", detail.Subject);
        var message = Assert.Single(detail.Messages);
        Assert.False(message.IsFromSupport);
        Assert.Equal("Please help", message.Body);
    }

    [Fact]
    public async Task CreateTicket_RejectsOrderThatIsNotTheUsers()
    {
        var foreignOrderId = Guid.NewGuid();
        var controller = CreateController();

        var result = await controller.CreateTicket(
            new CreateTicketRequest("Order issue", TicketCategory.Order, foreignOrderId, "msg"), default);

        Assert.IsType<BadRequestObjectResult>(result);
        Assert.Empty(_dbContext.SupportTickets.ToList());
    }

    [Fact]
    public async Task Reply_SetsPendingSupport()
    {
        var ticket = new SupportTicket
        {
            Id = Guid.NewGuid(),
            UserId = _userId,
            Subject = "s",
            Category = TicketCategory.Other,
            Status = TicketStatus.PendingUser
        };
        _dbContext.SupportTickets.Add(ticket);
        await _dbContext.SaveChangesAsync();
        var controller = CreateController();

        var result = Assert.IsType<OkObjectResult>(await controller.Reply(ticket.Id, new TicketReplyRequest("thanks"), default));
        var detail = Assert.IsType<TicketDetailDto>(result.Value);

        Assert.Equal(nameof(TicketStatus.PendingSupport), detail.Status);
    }

    [Fact]
    public async Task Reply_ForbidsNonOwner()
    {
        var ticket = new SupportTicket
        {
            Id = Guid.NewGuid(),
            UserId = _userId,
            Subject = "s",
            Category = TicketCategory.Other,
            Status = TicketStatus.Open
        };
        _dbContext.SupportTickets.Add(ticket);
        await _dbContext.SaveChangesAsync();

        var controller = CreateController(actingUserId: Guid.NewGuid());
        var result = await controller.Reply(ticket.Id, new TicketReplyRequest("intrusion"), default);

        Assert.IsType<ForbidResult>(result);
    }

    [Fact]
    public async Task GetTicket_ReturnsNotFoundForNonOwner()
    {
        var ticket = new SupportTicket
        {
            Id = Guid.NewGuid(),
            UserId = _userId,
            Subject = "s",
            Category = TicketCategory.Other,
            Status = TicketStatus.Open
        };
        _dbContext.SupportTickets.Add(ticket);
        await _dbContext.SaveChangesAsync();

        var controller = CreateController(actingUserId: Guid.NewGuid());
        Assert.IsType<NotFoundResult>(await controller.GetTicket(ticket.Id, default));
    }
}
