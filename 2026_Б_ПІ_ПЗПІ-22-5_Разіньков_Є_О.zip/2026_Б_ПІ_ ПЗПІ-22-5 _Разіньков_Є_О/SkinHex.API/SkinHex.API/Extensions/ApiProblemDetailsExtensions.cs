using FluentResults;
using Microsoft.AspNetCore.Mvc;

namespace SkinHex.API.Errors;

public static class ApiProblemDetailsExtensions
{
    public static IActionResult ToProblemDetails(
        this ControllerBase controller,
        IReadOnlyList<IError> errors,
        int statusCode = StatusCodes.Status400BadRequest,
        string? title = null)
    {
        var messages = errors.Select(error => error.Message).ToArray();
        var problemDetails = new ProblemDetails
        {
            Status = statusCode,
            Title = title ?? GetDefaultTitle(statusCode),
            Detail = messages.FirstOrDefault(),
            Instance = controller.HttpContext.Request.Path
        };

        problemDetails.Extensions["errors"] = messages;

        var metadataErrorCode = errors
            .Select(error => error.Metadata.TryGetValue("errorCode", out var value) ? value?.ToString() : null)
            .FirstOrDefault(value => !string.IsNullOrWhiteSpace(value));
        var messageErrorCode = messages.FirstOrDefault(message => message.StartsWith("REQUIRE_", StringComparison.Ordinal));
        var errorCode = metadataErrorCode ?? messageErrorCode;
        if (errorCode is not null)
            problemDetails.Extensions["errorCode"] = errorCode;

        return new ObjectResult(problemDetails) { StatusCode = statusCode };
    }

    private static string GetDefaultTitle(int statusCode) => statusCode switch
    {
        StatusCodes.Status401Unauthorized => "Authentication failed",
        StatusCodes.Status403Forbidden => "Access denied",
        StatusCodes.Status404NotFound => "Resource not found",
        StatusCodes.Status409Conflict => "Request conflict",
        _ => "Request validation failed"
    };
}
