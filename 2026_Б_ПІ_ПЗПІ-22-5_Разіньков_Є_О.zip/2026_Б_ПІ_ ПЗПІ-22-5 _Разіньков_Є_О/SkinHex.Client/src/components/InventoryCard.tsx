import type { CSSProperties } from 'react';
import { ShoppingCart, Check } from 'lucide-react';
import type { InventoryItem, ItemDictionaryEntry } from '../types';
import { parseInventoryName } from '../utils/inventory';
import { getItemImageUrl } from '../utils/itemDictionary';
import { FloatBar } from './FloatBar';
import { useTranslation } from 'react-i18next';

type InventoryCardProps = {
  item: InventoryItem;
  itemStatic: ItemDictionaryEntry | null;
  quantity?: number;
  isInSalePanel?: boolean;
  onCardClick: () => void;
  onSellClick: (e: React.MouseEvent) => void;
};

export function InventoryCard({ item, itemStatic, quantity = 1, isInSalePanel = false, onCardClick, onSellClick }: InventoryCardProps) {
  const { t } = useTranslation();
  const parsedName = parseInventoryName(item.marketHashName);
  const accentColor = itemStatic?.color ? `#${itemStatic.color}` : '#3b82f6';
  const imageUrl = getItemImageUrl(itemStatic);

  const hasFloat = item.floatValue != null && item.floatValue > 0;

  return (
    <article
      className={`inv-card ${isInSalePanel ? 'in-sale' : ''}`}
      style={{ '--item-accent': accentColor } as CSSProperties}
      onClick={onCardClick}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => { if (e.key === 'Enter') onCardClick(); }}
    >
      {/* Rarity accent line */}
      <div className="inv-card-accent" />

      {/* Quantity badge */}
      {quantity > 1 && (
        <span className="inv-card-qty">x{quantity}</span>
      )}

      {/* In-sale indicator */}
      {isInSalePanel && (
        <span className="inv-card-check">
          <Check size={14} strokeWidth={3} />
        </span>
      )}

      {/* Header */}
      <div className="inv-card-header">
        <h3 className="inv-card-name" title={parsedName.title}>
          {parsedName.title}
        </h3>
        <span className="inv-card-exterior">
          {parsedName.exterior ?? itemStatic?.category ?? 'Item'}
        </span>
      </div>

      {/* Image */}
      <div className="inv-card-image">
        {imageUrl && <img alt={item.marketHashName} loading="lazy" src={imageUrl} />}
      </div>

      {/* Float bar */}
      {hasFloat && (
        <div className="inv-card-float">
          <FloatBar
            floatValue={item.floatValue!}
            minFloat={itemStatic?.minF}
            maxFloat={itemStatic?.maxF}
            paintSeed={item.paintSeed}
            size="compact"
          />
        </div>
      )}

      {/* Sell button — slides up on hover */}
      <button
        className={`inv-card-sell-btn ${isInSalePanel ? 'remove' : ''}`}
        onClick={(e) => {
          e.stopPropagation();
          onSellClick(e);
        }}
        type="button"
      >
        {isInSalePanel ? (
          <>
            <Check size={14} />
            {t('inventory.removeFromSale', 'Remove')}
          </>
        ) : (
          <>
            <ShoppingCart size={14} />
            {t('inventory.sell', 'Sell')}
          </>
        )}
      </button>
    </article>
  );
}
