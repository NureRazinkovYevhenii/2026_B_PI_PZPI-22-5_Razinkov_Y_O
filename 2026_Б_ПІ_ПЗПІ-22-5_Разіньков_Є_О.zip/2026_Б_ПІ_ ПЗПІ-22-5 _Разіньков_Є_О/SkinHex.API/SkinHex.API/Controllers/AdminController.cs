using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SkinHex.API.Errors;
using SkinHex.Core.Entities;
using SkinHex.Core.Interfaces;
using SkinHex.Core.Interfaces.Services;
using SkinHex.Core.Models;
using SkinHex.Core.Models.Admin;
using SkinHex.Core.Models.Disputes;
using SkinHex.Infrastructure;

namespace SkinHex.API.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize(Roles = nameof(UserRole.Admin))]
public sealed class AdminController : ControllerBase
{
    private const int MaxPageSize = 100;
    private const int RecentTransactionsCount = 20;

    private readonly SkinHexDbContext _dbContext;
    private readonly IUserService _userService;
    private readonly INowPaymentsPayoutService _payoutService;
    private readonly INotificationService _notificationService;
    private readonly IDisputeService _disputeService;
    private readonly ILogger<AdminController> _logger;

    public AdminController(
        SkinHexDbContext dbContext,
        IUserService userService,
        INowPaymentsPayoutService payoutService,
        INotificationService notificationService,
        IDisputeService disputeService,
        ILogger<AdminController> logger)
    {
        _dbContext = dbContext;
        _userService = userService;
        _payoutService = payoutService;
        _notificationService = notificationService;
        _disputeService = disputeService;
        _logger = logger;
    }

    // ---------- Dashboard ----------

    [HttpGet("dashboard")]
    public async Task<IActionResult> GetDashboard(CancellationToken ct)
    {
        var stats = new DashboardStatsDto(
            TotalUsers: await _dbContext.Users.CountAsync(ct),
            BannedUsers: await _dbContext.Users.CountAsync(u => u.Role == UserRole.Banned, ct),
            OpenTickets: await _dbContext.SupportTickets.CountAsync(
                t => t.Status != TicketStatus.Resolved && t.Status != TicketStatus.Closed, ct),
            PendingOrders: await _dbContext.Orders.CountAsync(
                o => o.Status != OrderStatus.Completed && o.Status != OrderStatus.Cancelled, ct),
            TotalUserBalance: await _dbContext.Users.SumAsync(u => u.Balance, ct),
            TotalFrozenBalance: await _dbContext.Users.SumAsync(u => u.FrozenBalance, ct),
            OpenDisputes: await _dbContext.OrderDisputes.CountAsync(
                d => d.Status == DisputeStatus.Open || d.Status == DisputeStatus.UnderReview, ct));

        return Ok(stats);
    }

    // ---------- Users ----------

    [HttpGet("users")]
    public async Task<IActionResult> GetUsers(
        [FromQuery] string? search,
        [FromQuery] string? role,
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 20,
        CancellationToken ct = default)
    {
        (page, pageSize) = NormalizePaging(page, pageSize);

        var query = _dbContext.Users.AsNoTracking();

        if (!string.IsNullOrWhiteSpace(search))
        {
            var term = search.Trim();
            query = query.Where(u =>
                u.Id.ToString().Contains(term) ||
                u.Username.Contains(term) ||
                u.SteamId.Contains(term) ||
                (u.Email != null && u.Email.Contains(term)));
        }

        if (!string.IsNullOrWhiteSpace(role) && Enum.TryParse<UserRole>(role, ignoreCase: true, out var parsedRole))
        {
            query = query.Where(u => u.Role == parsedRole);
        }

        var totalCount = await query.CountAsync(ct);

        var rows = await query
            .OrderByDescending(u => u.CreatedAt)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .Select(u => new { u.Id, u.SteamId, u.Username, u.Email, u.AvatarUrl, u.Role, u.Balance, u.FrozenBalance, u.CreatedAt })
            .ToListAsync(ct);

        var items = rows
            .Select(u => new AdminUserListItemDto(
                u.Id, u.SteamId, u.Username, u.Email, u.AvatarUrl, u.Role.ToString(), u.Balance, u.FrozenBalance, u.CreatedAt))
            .ToList();

        return Ok(new PagedResult<AdminUserListItemDto>
        {
            Items = items,
            TotalCount = totalCount,
            Page = page,
            PageSize = pageSize
        });
    }

    [HttpGet("users/{id:guid}")]
    public async Task<IActionResult> GetUser(Guid id, CancellationToken ct)
    {
        var user = await _dbContext.Users.AsNoTracking().FirstOrDefaultAsync(u => u.Id == id, ct);
        if (user is null)
            return NotFound();

        var activeListings = await _dbContext.Listings
            .CountAsync(l => l.SellerId == id && l.Status == ListingStatus.Active, ct);
        var ordersAsBuyer = await _dbContext.Orders.CountAsync(o => o.BuyerId == id, ct);
        var ordersAsSeller = await _dbContext.Orders.CountAsync(o => o.SellerId == id, ct);
        var openTickets = await _dbContext.SupportTickets
            .CountAsync(t => t.UserId == id && t.Status != TicketStatus.Resolved && t.Status != TicketStatus.Closed, ct);

        var txRows = await _dbContext.FinancialTransactions
            .AsNoTracking()
            .Where(t => t.UserId == id)
            .OrderByDescending(t => t.CreatedAt)
            .Take(RecentTransactionsCount)
            .Select(t => new { t.Id, t.Amount, t.Type, t.Status, t.ReferenceId, t.CreatedAt })
            .ToListAsync(ct);

        var transactions = txRows
            .Select(t => new AdminTransactionDto(t.Id, t.Amount, t.Type.ToString(), t.Status.ToString(), t.ReferenceId, t.CreatedAt))
            .ToList();

        var detail = new AdminUserDetailDto(
            user.Id, user.SteamId, user.Username, user.Email, user.AvatarUrl, user.TradeUrl,
            user.Role.ToString(), user.Balance, user.FrozenBalance, user.CreatedAt, user.UpdatedAt,
            activeListings, ordersAsBuyer, ordersAsSeller, openTickets, transactions);

        return Ok(detail);
    }

    [HttpPost("users/{id:guid}/ban")]
    public async Task<IActionResult> BanUser(Guid id, CancellationToken ct)
    {
        var result = await _userService.BanUserAsync(id, ct);
        return result.IsSuccess ? Ok(new { message = "User banned." }) : this.ToProblemDetails(result.Errors);
    }

    [HttpPost("users/{id:guid}/unban")]
    public async Task<IActionResult> UnbanUser(Guid id, CancellationToken ct)
    {
        var result = await _userService.UnbanUserAsync(id, ct);
        return result.IsSuccess ? Ok(new { message = "User unbanned." }) : this.ToProblemDetails(result.Errors);
    }

    [HttpPost("users/{id:guid}/balance-adjust")]
    public async Task<IActionResult> AdjustBalance(Guid id, [FromBody] BalanceAdjustRequest request, CancellationToken ct)
    {
        if (request.Amount == 0)
            return BadRequest(new { message = "Amount must be non-zero." });
        if (string.IsNullOrWhiteSpace(request.Reason))
            return BadRequest(new { message = "Reason is required." });

        var user = await _dbContext.Users.FirstOrDefaultAsync(u => u.Id == id, ct);
        if (user is null)
            return NotFound();

        if (user.Balance + request.Amount < 0)
            return BadRequest(new { message = "Adjustment would make the balance negative." });

        // Match the InMemory-safe transaction pattern used by DepositsController/WebhooksController.
        var useTransaction = _dbContext.Database.ProviderName != "Microsoft.EntityFrameworkCore.InMemory";
        var dbTransaction = useTransaction ? await _dbContext.Database.BeginTransactionAsync(ct) : null;

        try
        {
            var adminId = GetCurrentUserId();

            user.Balance += request.Amount;
            user.UpdatedAt = DateTime.UtcNow;

            _dbContext.FinancialTransactions.Add(new FinancialTransaction
            {
                Id = Guid.NewGuid(),
                UserId = id,
                Amount = request.Amount,
                Type = FinancialTransactionType.AdminAdjustment,
                Status = FinancialTransactionStatus.Completed,
                ReferenceId = adminId,
                CreatedAt = DateTime.UtcNow
            });

            await _dbContext.SaveChangesAsync(ct);
            if (dbTransaction != null)
                await dbTransaction.CommitAsync(ct);

            _logger.LogInformation(
                "Admin {AdminId} adjusted balance of user {UserId} by {Amount}. Reason: {Reason}",
                adminId, id, request.Amount, request.Reason);

            return Ok(new { balance = user.Balance });
        }
        finally
        {
            if (dbTransaction != null)
                await dbTransaction.DisposeAsync();
        }
    }

    // ---------- Orders ----------

    [HttpGet("orders")]
    public async Task<IActionResult> GetOrders(
        [FromQuery] string? status,
        [FromQuery] string? search,
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 20,
        CancellationToken ct = default)
    {
        (page, pageSize) = NormalizePaging(page, pageSize);

        var query = _dbContext.Orders.AsNoTracking();

        if (!string.IsNullOrWhiteSpace(status) && Enum.TryParse<OrderStatus>(status, ignoreCase: true, out var parsedStatus))
        {
            query = query.Where(o => o.Status == parsedStatus);
        }

        if (!string.IsNullOrWhiteSpace(search))
        {
            var term = search.Trim();
            query = query.Where(o =>
                o.Id.ToString().Contains(term) ||
                o.Buyer.Username.Contains(term) ||
                o.Seller.Username.Contains(term) ||
                o.Buyer.SteamId.Contains(term) ||
                o.Seller.SteamId.Contains(term) ||
                o.Listing.Item.MarketHashName.Contains(term));
        }

        var totalCount = await query.CountAsync(ct);

        var rows = await query
            .OrderByDescending(o => o.CreatedAt)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .Select(o => new
            {
                o.Id,
                o.Status,
                o.LockPrice,
                o.CreatedAt,
                BuyerId = o.Buyer.Id,
                BuyerName = o.Buyer.Username,
                BuyerSteamId = o.Buyer.SteamId,
                BuyerAvatar = o.Buyer.AvatarUrl,
                SellerId = o.Seller.Id,
                SellerName = o.Seller.Username,
                SellerSteamId = o.Seller.SteamId,
                SellerAvatar = o.Seller.AvatarUrl,
                MarketHashName = o.Listing.Item.MarketHashName
            })
            .ToListAsync(ct);

        var items = rows
            .Select(o => new AdminOrderListItemDto(
                o.Id,
                o.Status.ToString(),
                o.LockPrice,
                new AdminParticipantDto(o.BuyerId, o.BuyerName, o.BuyerSteamId, o.BuyerAvatar),
                new AdminParticipantDto(o.SellerId, o.SellerName, o.SellerSteamId, o.SellerAvatar),
                o.MarketHashName,
                o.CreatedAt))
            .ToList();

        return Ok(new PagedResult<AdminOrderListItemDto>
        {
            Items = items,
            TotalCount = totalCount,
            Page = page,
            PageSize = pageSize
        });
    }

    [HttpGet("orders/{id:guid}")]
    public async Task<IActionResult> GetOrder(Guid id, CancellationToken ct)
    {
        var row = await _dbContext.Orders
            .AsNoTracking()
            .Where(o => o.Id == id)
            .Select(o => new
            {
                o.Id,
                o.ListingId,
                o.Status,
                o.LockPrice,
                o.CancelledBy,
                o.CancelReason,
                o.CreatedAt,
                o.ConfirmedAt,
                o.TradeSentAt,
                o.HoldEndsAt,
                o.CancelledAt,
                o.UpdatedAt,
                BuyerId = o.Buyer.Id,
                BuyerName = o.Buyer.Username,
                BuyerSteamId = o.Buyer.SteamId,
                BuyerAvatar = o.Buyer.AvatarUrl,
                SellerId = o.Seller.Id,
                SellerName = o.Seller.Username,
                SellerSteamId = o.Seller.SteamId,
                SellerAvatar = o.Seller.AvatarUrl,
                MarketHashName = o.Listing.Item.MarketHashName,
                o.Listing.Item.Wear,
                Float = o.Listing.FloatValue,
                Trades = o.SteamTrades
                    .OrderBy(t => t.CreatedAt)
                    .Select(t => new { t.Id, t.TradeOfferId, t.TradeId, t.OfferState, t.TradeStatus, t.CreatedAt, t.UpdatedAt })
                    .ToList()
            })
            .FirstOrDefaultAsync(ct);

        if (row is null)
            return NotFound();

        var trades = row.Trades
            .Select(t => new AdminOrderTradeDto(
                t.Id, t.TradeOfferId, t.TradeId,
                t.OfferState.ToString(),
                t.TradeStatus.HasValue ? t.TradeStatus.Value.ToString() : null,
                t.CreatedAt, t.UpdatedAt))
            .ToList();

        var detail = new AdminOrderDetailDto(
            row.Id, row.ListingId, row.Status.ToString(), row.LockPrice,
            row.CancelledBy?.ToString(), row.CancelReason,
            row.CreatedAt, row.ConfirmedAt, row.TradeSentAt, row.HoldEndsAt, row.CancelledAt, row.UpdatedAt,
            new AdminParticipantDto(row.BuyerId, row.BuyerName, row.BuyerSteamId, row.BuyerAvatar),
            new AdminParticipantDto(row.SellerId, row.SellerName, row.SellerSteamId, row.SellerAvatar),
            row.MarketHashName, row.Wear, row.Float, trades);

        return Ok(detail);
    }

    // ---------- Tickets ----------

    [HttpGet("tickets")]
    public async Task<IActionResult> GetTickets(
        [FromQuery] string? status,
        [FromQuery] string? category,
        [FromQuery] string? search,
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 20,
        CancellationToken ct = default)
    {
        (page, pageSize) = NormalizePaging(page, pageSize);

        var query = _dbContext.SupportTickets.AsNoTracking();

        if (!string.IsNullOrWhiteSpace(status) && Enum.TryParse<TicketStatus>(status, ignoreCase: true, out var parsedStatus))
        {
            query = query.Where(t => t.Status == parsedStatus);
        }

        if (!string.IsNullOrWhiteSpace(category) && Enum.TryParse<TicketCategory>(category, ignoreCase: true, out var parsedCategory))
        {
            query = query.Where(t => t.Category == parsedCategory);
        }

        if (!string.IsNullOrWhiteSpace(search))
        {
            var term = search.Trim();
            query = query.Where(t =>
                t.Id.ToString().Contains(term) ||
                (t.OrderId != null && t.OrderId.ToString()!.Contains(term)) ||
                t.Subject.Contains(term) ||
                t.User.Username.Contains(term));
        }

        var totalCount = await query.CountAsync(ct);

        var rows = await query
            .OrderByDescending(t => t.UpdatedAt)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .Select(t => new
            {
                t.Id,
                t.Subject,
                t.Category,
                t.Status,
                t.UserId,
                Username = t.User.Username,
                t.OrderId,
                t.AssignedAdminId,
                MessagesCount = t.Messages.Count,
                t.CreatedAt,
                t.UpdatedAt
            })
            .ToListAsync(ct);

        var items = rows
            .Select(t => new TicketListItemDto(
                t.Id, t.Subject, t.Category.ToString(), t.Status.ToString(),
                t.UserId, t.Username, t.OrderId, t.AssignedAdminId, t.MessagesCount, t.CreatedAt, t.UpdatedAt))
            .ToList();

        return Ok(new PagedResult<TicketListItemDto>
        {
            Items = items,
            TotalCount = totalCount,
            Page = page,
            PageSize = pageSize
        });
    }

    [HttpGet("tickets/{id:guid}")]
    public async Task<IActionResult> GetTicket(Guid id, CancellationToken ct)
    {
        var detail = await LoadTicketDetailAsync(id, ct);
        return detail is null ? NotFound() : Ok(detail);
    }

    [HttpPost("tickets/{id:guid}/reply")]
    public async Task<IActionResult> ReplyToTicket(Guid id, [FromBody] TicketReplyRequest request, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(request.Body))
            return BadRequest(new { message = "Message body is required." });

        var ticket = await _dbContext.SupportTickets.FirstOrDefaultAsync(t => t.Id == id, ct);
        if (ticket is null)
            return NotFound();

        if (ticket.Status == TicketStatus.Closed)
            return BadRequest(new { message = "Ticket is closed." });

        var adminId = GetCurrentUserId();

        _dbContext.TicketMessages.Add(new TicketMessage
        {
            Id = Guid.NewGuid(),
            TicketId = id,
            SenderId = adminId,
            IsFromSupport = true,
            Body = request.Body.Trim(),
            CreatedAt = DateTime.UtcNow
        });

        ticket.Status = TicketStatus.PendingUser;
        ticket.AssignedAdminId ??= adminId;
        ticket.UpdatedAt = DateTime.UtcNow;

        await _dbContext.SaveChangesAsync(ct);

        var detail = await LoadTicketDetailAsync(id, ct);
        return Ok(detail);
    }

    [HttpPost("tickets/{id:guid}/status")]
    public async Task<IActionResult> ChangeTicketStatus(Guid id, [FromBody] TicketStatusRequest request, CancellationToken ct)
    {
        var ticket = await _dbContext.SupportTickets.FirstOrDefaultAsync(t => t.Id == id, ct);
        if (ticket is null)
            return NotFound();

        var adminId = GetCurrentUserId();

        ticket.Status = request.Status;
        ticket.UpdatedAt = DateTime.UtcNow;

        if (request.Status is TicketStatus.Resolved or TicketStatus.Closed)
            ticket.ClosedAt = DateTime.UtcNow;
        else
            ticket.ClosedAt = null;

        // Taking any action assigns the ticket to the acting admin if unassigned.
        ticket.AssignedAdminId ??= adminId;

        await _dbContext.SaveChangesAsync(ct);

        var detail = await LoadTicketDetailAsync(id, ct);
        return Ok(detail);
    }

    // ---------- Disputes ----------

    [HttpGet("disputes")]
    public async Task<IActionResult> GetDisputes(
        [FromQuery] string? status,
        [FromQuery] string? reason,
        [FromQuery] string? search,
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 20,
        CancellationToken ct = default)
    {
        (page, pageSize) = NormalizePaging(page, pageSize);

        var query = _dbContext.OrderDisputes.AsNoTracking();

        if (!string.IsNullOrWhiteSpace(status) && Enum.TryParse<DisputeStatus>(status, ignoreCase: true, out var parsedStatus))
        {
            query = query.Where(d => d.Status == parsedStatus);
        }

        if (!string.IsNullOrWhiteSpace(reason) && Enum.TryParse<DisputeReason>(reason, ignoreCase: true, out var parsedReason))
        {
            query = query.Where(d => d.Reason == parsedReason);
        }

        if (!string.IsNullOrWhiteSpace(search))
        {
            var term = search.Trim();
            query = query.Where(d =>
                d.Id.ToString().Contains(term) ||
                d.OrderId.ToString().Contains(term) ||
                d.Order.Buyer.Username.Contains(term) ||
                d.Order.Seller.Username.Contains(term));
        }

        var totalCount = await query.CountAsync(ct);

        var rows = await query
            .OrderByDescending(d => d.UpdatedAt)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .Select(d => new
            {
                d.Id,
                d.OrderId,
                d.OpenedByUserId,
                OpenedByUsername = d.OpenedByUserId == d.Order.BuyerId ? d.Order.Buyer.Username
                    : d.OpenedByUserId == d.Order.SellerId ? d.Order.Seller.Username
                    : null,
                d.Reason,
                d.Status,
                d.Resolution,
                OrderStatus = d.Order.Status,
                OrderPrice = d.Order.LockPrice,
                d.FrozenPenaltyAmount,
                d.CreatedAt,
                d.UpdatedAt
            })
            .ToListAsync(ct);

        var items = rows
            .Select(d => new AdminDisputeListItemDto(
                d.Id, d.OrderId, d.OpenedByUserId, d.OpenedByUsername,
                d.Reason.ToString(), d.Status.ToString(), d.Resolution.ToString(),
                d.OrderStatus.ToString(), d.OrderPrice, d.FrozenPenaltyAmount,
                d.CreatedAt, d.UpdatedAt))
            .ToList();

        return Ok(new PagedResult<AdminDisputeListItemDto>
        {
            Items = items,
            TotalCount = totalCount,
            Page = page,
            PageSize = pageSize
        });
    }

    [HttpGet("disputes/{id:guid}")]
    public async Task<IActionResult> GetDispute(Guid id, CancellationToken ct)
    {
        var dispute = await _dbContext.OrderDisputes
            .AsNoTracking()
            .Include(d => d.Order).ThenInclude(o => o.Buyer)
            .Include(d => d.Order).ThenInclude(o => o.Seller)
            .Include(d => d.Order).ThenInclude(o => o.Listing).ThenInclude(l => l.Item)
            .Include(d => d.Order).ThenInclude(o => o.SteamTrades)
            .FirstOrDefaultAsync(d => d.Id == id, ct);

        if (dispute is null)
            return NotFound();

        var order = dispute.Order;

        var proofs = await _dbContext.TlsnProofRecords
            .AsNoTracking()
            .Where(p => p.OrderId == order.Id)
            .OrderByDescending(p => p.ReceivedAt)
            .Select(p => new AdminDisputeProofDto(
                p.Id, p.SteamTradeId, p.TradeStatus, p.SteamIdOther, p.TransferredAssetIds,
                p.Outcome.ToString(), p.FailureCode, p.FailureReason, p.ReceivedAt))
            .ToListAsync(ct);

        var trades = order.SteamTrades
            .OrderByDescending(t => t.CreatedAt)
            .Select(t => new AdminDisputeTradeDto(
                t.TradeOfferId, t.TradeId, t.OfferState.ToString(), t.TradeStatus?.ToString(),
                t.BuyerReportedOfferState?.ToString(), t.BuyerReportedAt, t.BuyerSeenAssetIds, t.BuyerAssetMatchesListing,
                t.CreatedAt, t.UpdatedAt))
            .ToList();

        var detail = new AdminDisputeDetailDto(
            Dispute: new DisputeDto(
                dispute.Id, dispute.OrderId, dispute.OpenedByUserId,
                dispute.Reason.ToString(), dispute.Status.ToString(), dispute.Resolution.ToString(),
                dispute.Description, dispute.ResolutionNote, dispute.FrozenPenaltyAmount,
                dispute.CreatedAt, dispute.UpdatedAt, dispute.ResolvedAt),
            Order: new AdminDisputeOrderDto(
                order.Id, order.Status.ToString(), order.LockPrice,
                order.BuyerId, order.Buyer.Username,
                order.SellerId, order.Seller.Username,
                order.Listing?.Item?.MarketHashName, order.Listing?.SteamAssetId ?? 0,
                order.CancelledBy?.ToString(), order.CancelReason, order.CreatedAt),
            Trades: trades,
            Proofs: proofs);

        return Ok(detail);
    }

    [HttpPost("disputes/{id:guid}/review")]
    public async Task<IActionResult> TakeDisputeUnderReview(Guid id, CancellationToken ct)
    {
        var adminId = GetCurrentUserId();
        var dispute = await _disputeService.TakeUnderReviewAsync(id, adminId, ct);
        return Ok(dispute);
    }

    [HttpPost("disputes/{id:guid}/resolve")]
    public async Task<IActionResult> ResolveDispute(Guid id, [FromBody] ResolveDisputeRequest request, CancellationToken ct)
    {
        var adminId = GetCurrentUserId();
        var dispute = await _disputeService.ResolveDisputeAsync(id, adminId, request.Resolution, request.Note, ct);
        return Ok(dispute);
    }

    // ---------- Withdrawals ----------

    [HttpGet("withdrawals")]
    public async Task<IActionResult> GetWithdrawals(
        [FromQuery] string? status,
        [FromQuery] string? search,
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 20,
        CancellationToken ct = default)
    {
        (page, pageSize) = NormalizePaging(page, pageSize);

        var query = _dbContext.Withdrawals.AsNoTracking();

        if (!string.IsNullOrWhiteSpace(status) && Enum.TryParse<WithdrawalStatus>(status, ignoreCase: true, out var parsedStatus))
        {
            query = query.Where(w => w.Status == parsedStatus);
        }

        if (!string.IsNullOrWhiteSpace(search))
        {
            var term = search.Trim();
            query = query.Where(w =>
                w.Id.ToString().Contains(term) ||
                w.User.Username.Contains(term) ||
                w.PayoutAddress.Contains(term) ||
                (w.NowPaymentsPayoutId != null && w.NowPaymentsPayoutId.Contains(term)));
        }

        var totalCount = await query.CountAsync(ct);

        var rows = await query
            .OrderByDescending(w => w.CreatedAt)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .Select(w => new
            {
                w.Id,
                w.UserId,
                Username = w.User.Username,
                w.AmountUsd,
                w.PlatformFeeUsd,
                w.PayoutAmountUsd,
                w.PayCurrency,
                w.PayoutAddress,
                w.PayoutExtraId,
                w.Status,
                w.RejectionReason,
                w.NowPaymentsPayoutId,
                w.CreatedAt,
                w.ProcessedAt
            })
            .ToListAsync(ct);

        var items = rows
            .Select(w => new AdminWithdrawalListItemDto(
                w.Id, w.UserId, w.Username, w.AmountUsd, w.PlatformFeeUsd, w.PayoutAmountUsd,
                w.PayCurrency, w.PayoutAddress, w.PayoutExtraId, w.Status.ToString(),
                w.RejectionReason, w.NowPaymentsPayoutId, w.CreatedAt, w.ProcessedAt))
            .ToList();

        return Ok(new PagedResult<AdminWithdrawalListItemDto>
        {
            Items = items,
            TotalCount = totalCount,
            Page = page,
            PageSize = pageSize
        });
    }

    [HttpPost("withdrawals/{id:guid}/approve")]
    public async Task<IActionResult> ApproveWithdrawal(Guid id, CancellationToken ct)
    {
        var withdrawal = await _dbContext.Withdrawals.FirstOrDefaultAsync(w => w.Id == id, ct);
        if (withdrawal is null)
            return NotFound();
        if (withdrawal.Status != WithdrawalStatus.Pending)
            return BadRequest(new { message = "Only pending withdrawals can be approved." });

        try
        {
            var result = await _payoutService.CreatePayoutAsync(
                withdrawal.PayoutAddress,
                withdrawal.PayCurrency,
                withdrawal.PayoutAmountUsd,
                withdrawal.PayoutExtraId,
                ct);

            // The batch is created "waiting for verification"; confirm it via the 2FA/TOTP code
            // so NOWPayments actually sends the funds without manual dashboard approval.
            await _payoutService.VerifyPayoutAsync(result.BatchId, ct);

            withdrawal.Status = WithdrawalStatus.Processing;
            withdrawal.NowPaymentsBatchId = result.BatchId;
            withdrawal.NowPaymentsPayoutId = result.PayoutId;
            withdrawal.ProcessedByAdminId = GetCurrentUserId();
            withdrawal.ProcessedAt = DateTime.UtcNow;
            withdrawal.UpdatedAt = DateTime.UtcNow;

            await _dbContext.SaveChangesAsync(ct);

            _logger.LogInformation("Withdrawal {WithdrawalId} approved, payout {PayoutId}", id, result.PayoutId);
            return Ok(new { status = withdrawal.Status.ToString(), payoutId = result.PayoutId });
        }
        catch (PayoutException ex)
        {
            // Balance stays debited but the request remains Pending so the admin can retry after fixing config.
            _logger.LogError(ex, "Payout failed for withdrawal {WithdrawalId}", id);
            return StatusCode(StatusCodes.Status502BadGateway, new { message = ex.Message });
        }
    }

    [HttpPost("withdrawals/{id:guid}/reject")]
    public async Task<IActionResult> RejectWithdrawal(Guid id, [FromBody] RejectWithdrawalRequest request, CancellationToken ct)
    {
        var withdrawal = await _dbContext.Withdrawals
            .Include(w => w.User)
            .Include(w => w.Transaction)
            .FirstOrDefaultAsync(w => w.Id == id, ct);

        if (withdrawal is null)
            return NotFound();
        if (withdrawal.Status != WithdrawalStatus.Pending)
            return BadRequest(new { message = "Only pending withdrawals can be rejected." });

        var useTransaction = _dbContext.Database.ProviderName != "Microsoft.EntityFrameworkCore.InMemory";
        var dbTransaction = useTransaction ? await _dbContext.Database.BeginTransactionAsync(ct) : null;
        try
        {
            // Refund the debited amount back to the main balance.
            withdrawal.User.Balance += withdrawal.AmountUsd;
            withdrawal.User.UpdatedAt = DateTime.UtcNow;

            withdrawal.Status = WithdrawalStatus.Rejected;
            withdrawal.RejectionReason = string.IsNullOrWhiteSpace(request.Reason) ? "Rejected by admin." : request.Reason.Trim();
            withdrawal.ProcessedByAdminId = GetCurrentUserId();
            withdrawal.ProcessedAt = DateTime.UtcNow;
            withdrawal.UpdatedAt = DateTime.UtcNow;

            withdrawal.Transaction.Status = FinancialTransactionStatus.Cancelled;

            await _dbContext.SaveChangesAsync(ct);
            if (dbTransaction != null)
                await dbTransaction.CommitAsync(ct);
        }
        finally
        {
            if (dbTransaction != null)
                await dbTransaction.DisposeAsync();
        }

        // Rejection refunded the balance — notify the user and sync their wallet live.
        await _notificationService.NotifyWithdrawalStatusAsync(withdrawal.UserId, withdrawal, ct);
        await _notificationService.PushBalanceUpdateAsync(withdrawal.User, withdrawal.AmountUsd, "withdrawal_refund", ct);

        return Ok(new { status = withdrawal.Status.ToString() });
    }

    // ---------- Helpers ----------

    private async Task<TicketDetailDto?> LoadTicketDetailAsync(Guid id, CancellationToken ct)
    {
        var row = await _dbContext.SupportTickets
            .AsNoTracking()
            .Where(t => t.Id == id)
            .Select(t => new
            {
                t.Id,
                t.Subject,
                t.Category,
                t.Status,
                t.UserId,
                Username = t.User.Username,
                t.OrderId,
                t.AssignedAdminId,
                t.CreatedAt,
                t.UpdatedAt,
                t.ClosedAt,
                Messages = t.Messages
                    .OrderBy(m => m.CreatedAt)
                    .Select(m => new { m.Id, m.SenderId, m.IsFromSupport, m.Body, m.CreatedAt })
                    .ToList()
            })
            .FirstOrDefaultAsync(ct);

        if (row is null)
            return null;

        var messages = row.Messages
            .Select(m => new TicketMessageDto(m.Id, m.SenderId, m.IsFromSupport, m.Body, m.CreatedAt))
            .ToList();

        return new TicketDetailDto(
            row.Id, row.Subject, row.Category.ToString(), row.Status.ToString(),
            row.UserId, row.Username, row.OrderId, row.AssignedAdminId,
            row.CreatedAt, row.UpdatedAt, row.ClosedAt, messages);
    }

    private Guid GetCurrentUserId()
    {
        var value = User.FindFirstValue(ClaimTypes.NameIdentifier);
        return Guid.TryParse(value, out var id) ? id : Guid.Empty;
    }

    private static (int Page, int PageSize) NormalizePaging(int page, int pageSize)
    {
        page = page < 1 ? 1 : page;
        pageSize = pageSize < 1 ? 20 : Math.Min(pageSize, MaxPageSize);
        return (page, pageSize);
    }
}
