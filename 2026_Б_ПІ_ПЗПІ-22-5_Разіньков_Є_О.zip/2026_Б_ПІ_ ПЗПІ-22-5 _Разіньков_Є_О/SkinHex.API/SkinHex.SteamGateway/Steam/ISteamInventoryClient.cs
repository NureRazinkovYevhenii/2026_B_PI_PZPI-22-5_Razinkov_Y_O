using SkinHex.Core.Models;

namespace SkinHex.SteamGateway.Steam;

public interface ISteamInventoryClient
{
    Task<IReadOnlyList<InventoryItemDto>> FetchInventoryAsync(
        SteamInventoryRequest request,
        CancellationToken cancellationToken = default);

    Task ValidateTradeLinkAsync(
        SteamInventoryRequest request,
        CancellationToken cancellationToken = default);
}
