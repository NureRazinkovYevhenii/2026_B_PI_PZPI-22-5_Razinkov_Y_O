using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SkinHex.Core.Entities;
using SkinHex.Core.Interfaces.Repositories;
using SkinHex.Core.Interfaces.Services;
using SkinHex.Infrastructure;

namespace SkinHex.API.Controllers;

[ApiController]
[Route("api/webhooks/nowpayments")]
public class WebhooksController : ControllerBase
{
    private readonly SkinHexDbContext _dbContext;
    private readonly INowPaymentsService _nowPaymentsService;
    private readonly INotificationService _notificationService;
    private readonly ILogger<WebhooksController> _logger;

    public WebhooksController(
        SkinHexDbContext dbContext,
        INowPaymentsService nowPaymentsService,
        INotificationService notificationService,
        ILogger<WebhooksController> logger)
    {
        _dbContext = dbContext;
        _nowPaymentsService = nowPaymentsService;
        _notificationService = notificationService;
        _logger = logger;
    }

    [HttpPost]
    public async Task<IActionResult> HandleIpn()
    {
        var signature = Request.Headers["x-nowpayments-sig"].ToString();
        if (string.IsNullOrEmpty(signature))
        {
            _logger.LogWarning("Missing x-nowpayments-sig header");
            return Unauthorized();
        }

        using var reader = new StreamReader(Request.Body);
        var rawBody = await reader.ReadToEndAsync();

        if (!_nowPaymentsService.VerifyIpnSignature(rawBody, signature))
        {
            _logger.LogWarning("Invalid IPN signature");
            return Unauthorized();
        }

        try
        {
            using var jsonDocument = JsonDocument.Parse(rawBody);
            var root = jsonDocument.RootElement;
            
            var orderIdStr = root.GetProperty("order_id").GetString();
            if (!Guid.TryParse(orderIdStr, out var depositId))
            {
                _logger.LogWarning("Invalid order_id in IPN: {OrderId}", orderIdStr);
                return Ok();
            }

            var paymentStatus = root.GetProperty("payment_status").GetString();

            var deposit = await _dbContext.Deposits
                .Include(d => d.Transaction)
                .Include(d => d.User)
                .FirstOrDefaultAsync(d => d.Id == depositId);

            if (deposit == null)
            {
                _logger.LogWarning("Deposit not found for order_id: {OrderId}", orderIdStr);
                return Ok(); // Acknowledge so NowPayments doesn't retry
            }

            // Idempotency: skip if already finished
            if (deposit.Status == DepositStatus.Finished)
            {
                return Ok();
            }

            var newStatus = MapStatus(paymentStatus);

            // The invoice flow spawns an underlying payment with its own id, distinct from the invoice
            // id we stored at creation time. Track the real payment id once NOWPayments tells us it.
            var realPaymentId = ReadString(root, "payment_id");
            if (!string.IsNullOrWhiteSpace(realPaymentId))
                deposit.NowPaymentsPaymentId = realPaymentId;

            var payAmountFromIpn = ReadDecimal(root, "pay_amount") ?? ReadDecimal(root, "actually_paid");
            if (payAmountFromIpn.HasValue)
                deposit.PayAmount = payAmountFromIpn;

            var payinHashFromIpn = ReadString(root, "payin_hash");
            if (!string.IsNullOrWhiteSpace(payinHashFromIpn))
            {
                deposit.PayinHash = payinHashFromIpn;
            }
            else if (newStatus == DepositStatus.Finished && string.IsNullOrWhiteSpace(deposit.PayinHash))
            {
                // Fallback: the IPN body didn't carry the hash, so fetch the extended payment record.
                // Best-effort — a failure here must not block balance crediting.
                try
                {
                    var details = await _nowPaymentsService.GetPaymentDetailsAsync(deposit.NowPaymentsPaymentId, HttpContext.RequestAborted);
                    if (!string.IsNullOrWhiteSpace(details.PayinHash))
                        deposit.PayinHash = details.PayinHash;
                    if (details.PayAmount.HasValue)
                        deposit.PayAmount = details.PayAmount;
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Failed to backfill payin hash for deposit {DepositId}", deposit.Id);
                }
            }

            if (newStatus == DepositStatus.Finished && deposit.Status != DepositStatus.Finished)
            {
                var useTransaction = _dbContext.Database.ProviderName != "Microsoft.EntityFrameworkCore.InMemory";
                var dbTransaction = useTransaction ? await _dbContext.Database.BeginTransactionAsync() : null;
                
                try
                {
                    deposit.Status = DepositStatus.Finished;
                    deposit.UpdatedAt = DateTime.UtcNow;

                    deposit.Transaction.Status = FinancialTransactionStatus.Completed;
                    deposit.User.Balance += deposit.FiatAmount;

                    await _dbContext.SaveChangesAsync();

                    if (dbTransaction != null)
                        await dbTransaction.CommitAsync();
                }
                finally
                {
                    if (dbTransaction != null)
                        await dbTransaction.DisposeAsync();
                }

                // Balance is credited and committed — tell the user and refresh their wallet live.
                await _notificationService.NotifyDepositCompletedAsync(
                    deposit.UserId, deposit.Id, deposit.FiatAmount, deposit.PayCurrency, HttpContext.RequestAborted);
                await _notificationService.PushBalanceUpdateAsync(
                    deposit.User, deposit.FiatAmount, "deposit", HttpContext.RequestAborted);
            }
            else
            {
                deposit.Status = newStatus;
                deposit.UpdatedAt = DateTime.UtcNow;
                
                // If it fails or expires
                if (newStatus == DepositStatus.Failed || newStatus == DepositStatus.Expired)
                {
                    deposit.Transaction.Status = FinancialTransactionStatus.Failed;
                }
                else if (newStatus == DepositStatus.PartiallyPaid)
                {
                    // Do nothing with balance, manual review
                }

                await _dbContext.SaveChangesAsync();
            }

            return Ok();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error processing IPN");
            return StatusCode(500);
        }
    }

    [HttpPost("payout")]
    public async Task<IActionResult> HandlePayoutIpn()
    {
        var signature = Request.Headers["x-nowpayments-sig"].ToString();
        if (string.IsNullOrEmpty(signature))
        {
            _logger.LogWarning("Missing x-nowpayments-sig header on payout IPN");
            return Unauthorized();
        }

        using var reader = new StreamReader(Request.Body);
        var rawBody = await reader.ReadToEndAsync();

        if (!_nowPaymentsService.VerifyIpnSignature(rawBody, signature))
        {
            _logger.LogWarning("Invalid payout IPN signature");
            return Unauthorized();
        }

        try
        {
            using var jsonDocument = JsonDocument.Parse(rawBody);
            var root = jsonDocument.RootElement;

            var payoutId = ReadString(root, "id");
            var status = ReadString(root, "status") ?? ReadString(root, "payment_status");
            if (string.IsNullOrEmpty(payoutId))
            {
                _logger.LogWarning("Payout IPN without id");
                return Ok();
            }

            var withdrawal = await _dbContext.Withdrawals
                .Include(w => w.User)
                .Include(w => w.Transaction)
                .FirstOrDefaultAsync(w => w.NowPaymentsPayoutId == payoutId || w.NowPaymentsBatchId == payoutId);

            if (withdrawal is null)
            {
                _logger.LogWarning("Payout IPN for unknown payout {PayoutId}", payoutId);
                return Ok();
            }

            // Idempotency: ignore once terminal.
            if (withdrawal.Status is WithdrawalStatus.Completed or WithdrawalStatus.Rejected or WithdrawalStatus.Failed)
                return Ok();

            // Record the outgoing blockchain transaction hash as soon as NOWPayments reports it
            // (may arrive on an earlier, non-terminal event before the payout is fully "finished").
            var txHash = ReadString(root, "hash");
            if (!string.IsNullOrWhiteSpace(txHash))
                withdrawal.PayoutTxHash = txHash;

            var wasRefunded = false;

            switch (status?.ToLowerInvariant())
            {
                case "finished":
                    withdrawal.Status = WithdrawalStatus.Completed;
                    withdrawal.Transaction.Status = FinancialTransactionStatus.Completed;
                    withdrawal.UpdatedAt = DateTime.UtcNow;
                    break;

                case "failed":
                case "rejected":
                case "expired":
                    // Refund: the balance was debited up front at request time.
                    withdrawal.User.Balance += withdrawal.AmountUsd;
                    withdrawal.User.UpdatedAt = DateTime.UtcNow;
                    withdrawal.Status = WithdrawalStatus.Failed;
                    withdrawal.Transaction.Status = FinancialTransactionStatus.Failed;
                    withdrawal.UpdatedAt = DateTime.UtcNow;
                    wasRefunded = true;
                    break;

                default:
                    withdrawal.Status = WithdrawalStatus.Processing;
                    withdrawal.UpdatedAt = DateTime.UtcNow;
                    break;
            }

            await _dbContext.SaveChangesAsync();

            // Notify only on terminal states; "processing" IPNs are intermediate noise.
            if (withdrawal.Status is WithdrawalStatus.Completed or WithdrawalStatus.Failed)
            {
                await _notificationService.NotifyWithdrawalStatusAsync(
                    withdrawal.UserId, withdrawal, HttpContext.RequestAborted);

                if (wasRefunded)
                    await _notificationService.PushBalanceUpdateAsync(
                        withdrawal.User, withdrawal.AmountUsd, "withdrawal_refund", HttpContext.RequestAborted);
            }

            return Ok();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error processing payout IPN");
            return StatusCode(500);
        }
    }

    private static string? ReadString(JsonElement root, string propertyName)
    {
        if (!root.TryGetProperty(propertyName, out var element))
            return null;

        return element.ValueKind switch
        {
            JsonValueKind.String => element.GetString(),
            JsonValueKind.Number => element.GetRawText(),
            _ => null
        };
    }

    /// <summary>Reads a decimal that NOWPayments may return either as a JSON number or a stringified number.</summary>
    private static decimal? ReadDecimal(JsonElement root, string propertyName)
    {
        if (!root.TryGetProperty(propertyName, out var element))
            return null;

        return element.ValueKind switch
        {
            JsonValueKind.Number => element.GetDecimal(),
            JsonValueKind.String when decimal.TryParse(element.GetString(), System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out var parsed) => parsed,
            _ => null
        };
    }

    private DepositStatus MapStatus(string? status)
    {
        return status?.ToLowerInvariant() switch
        {
            "waiting" => DepositStatus.Waiting,
            "confirming" => DepositStatus.Confirming,
            "confirmed" => DepositStatus.Confirming,
            "sending" => DepositStatus.Confirming,
            "partially_paid" => DepositStatus.PartiallyPaid,
            "finished" => DepositStatus.Finished,
            "failed" => DepositStatus.Failed,
            "expired" => DepositStatus.Expired,
            _ => DepositStatus.Waiting
        };
    }
}
