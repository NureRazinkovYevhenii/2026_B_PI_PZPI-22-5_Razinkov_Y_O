export const API_BASE_URL = (import.meta.env.VITE_API_URL ?? 'https://localhost:7148/api').replace(/\/$/, '');
export const LOGIN_URL = `${API_BASE_URL}/auth/login`;

/** API host without the /api suffix — for static assets (item screenshots) served by the backend. */
export const API_ORIGIN = API_BASE_URL.replace(/\/api$/, '');

