using SkinHex.Core.Models.Orders;
using SkinHex.Core.Entities;

namespace SkinHex.Core.Interfaces.Services;

public interface IOrderService
{
    Task<CreateOrderResponse> CreateOrderAsync(Guid listingId, Guid buyerId, CancellationToken ct = default);
    Task<IEnumerable<OrderDto>> GetUserOrdersAsync(Guid userId, string? roleFilter = null, CancellationToken ct = default);
    Task<OrderDto> ConfirmOrderAsync(Guid orderId, Guid sellerId, CancellationToken ct = default);
    Task<OrderDto> CancelOrderAsync(Guid orderId, Guid? initiatorId, string? reason, Entities.CancelledBy? cancelledBy = null, CancellationToken ct = default);
    Task<TradeInfoDto> GetTradeInfoAsync(Guid orderId, Guid sellerId, CancellationToken ct = default);
    Task<PendingTradeSyncResponse> GetPendingTradeSyncAsync(Guid userId, string? actorRole, CancellationToken ct = default);
    Task<BatchTradeSyncUpdateResponse> BatchSyncTradeAttemptsAsync(Guid userId, BatchTradeSyncUpdateRequest request, CancellationToken ct = default);
    Task<SteamTradeDto> CreateTradeAttemptAsync(Guid orderId, Guid sellerId, string tradeOfferId, SteamOfferState offerState, CancellationToken ct = default);
    Task<SteamTradeDto> UpdateTradeAttemptAsync(
        Guid orderId,
        Guid sellerId,
        string tradeOfferId,
        SteamOfferState offerState,
        string? tradeId,
        SteamTradeStatus? tradeStatus,
        long? timeUpdated = null,
        CancellationToken ct = default);
    Task ProcessTlsnTradeStatusProofAsync(
        string steamTradeId,
        SteamTradeStatus tradeStatus,
        string? steamIdOther,
        IReadOnlyCollection<string> transferredAssetIds,
        long? timeSettlementUnix,
        DateTimeOffset proofObservedAtUtc,
        CancellationToken ct = default);
}

