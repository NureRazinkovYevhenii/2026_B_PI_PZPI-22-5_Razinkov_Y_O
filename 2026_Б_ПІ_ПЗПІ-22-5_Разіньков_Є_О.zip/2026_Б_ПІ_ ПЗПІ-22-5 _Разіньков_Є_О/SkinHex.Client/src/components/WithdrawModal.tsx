import React, { useEffect, useMemo, useState } from 'react';
import { X, Loader2, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import type { DepositCurrency } from '../api/depositApi';
import {
  createWithdrawal,
  getWithdrawalCurrencies,
  getWithdrawalEstimate,
  type WithdrawalEstimate,
} from '../api/withdrawApi';

type WithdrawModalProps = {
  isOpen: boolean;
  onClose: () => void;
  balance?: number | null;
};

const DEFAULT_CODE = 'usdttrc20';

const CoinIcon: React.FC<{ currency: DepositCurrency }> = ({ currency }) => {
  const [failed, setFailed] = useState(false);
  if (failed) {
    return <span className="dep-coin-icon" style={{ background: currency.color }}>{currency.ticker.slice(0, 3)}</span>;
  }
  return (
    <img
      className="dep-coin-img"
      src={`/coins/${currency.code}.svg`}
      alt={`${currency.ticker}${currency.network ? ` ${currency.network}` : ''}`}
      onError={() => setFailed(true)}
    />
  );
};

export const WithdrawModal: React.FC<WithdrawModalProps> = ({ isOpen, onClose, balance }) => {
  const { t } = useTranslation();
  const [currencies, setCurrencies] = useState<DepositCurrency[]>([]);
  const [minUsd, setMinUsd] = useState(2.5);
  const [selectedCode, setSelectedCode] = useState(DEFAULT_CODE);
  const [amountUsd, setAmountUsd] = useState('');
  const [address, setAddress] = useState('');
  const [estimate, setEstimate] = useState<WithdrawalEstimate | null>(null);
  const [loadingCurrencies, setLoadingCurrencies] = useState(false);
  const [loadingEstimate, setLoadingEstimate] = useState(false);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  const selected = useMemo(() => currencies.find((c) => c.code === selectedCode) ?? null, [currencies, selectedCode]);

  useEffect(() => {
    if (!isOpen || currencies.length > 0) return;
    let cancelled = false;
    setLoadingCurrencies(true);
    getWithdrawalCurrencies()
      .then((data) => {
        if (cancelled) return;
        setCurrencies(data.currencies);
        setMinUsd(data.minWithdrawalUsd);
        if (!data.currencies.some((c) => c.code === DEFAULT_CODE) && data.currencies[0]) {
          setSelectedCode(data.currencies[0].code);
        }
      })
      .catch((err) => !cancelled && setError(err.message || 'Failed to load currencies'))
      .finally(() => !cancelled && setLoadingCurrencies(false));
    return () => { cancelled = true; };
  }, [isOpen, currencies.length]);

  // Live estimate (debounced) when amount or currency changes.
  useEffect(() => {
    const usd = parseFloat(amountUsd);
    if (!isOpen || !selected || !Number.isFinite(usd) || usd <= 0) {
      setEstimate(null);
      return;
    }
    const controller = new AbortController();
    const timer = window.setTimeout(() => {
      setLoadingEstimate(true);
      getWithdrawalEstimate(usd, selected.code, controller.signal)
        .then((data) => !controller.signal.aborted && setEstimate(data))
        .catch(() => { /* estimate is best-effort */ })
        .finally(() => !controller.signal.aborted && setLoadingEstimate(false));
    }, 400);
    return () => { controller.abort(); window.clearTimeout(timer); };
  }, [isOpen, selected, amountUsd]);

  if (!isOpen) return null;

  const amountUsdNum = parseFloat(amountUsd);
  const belowMin = Number.isFinite(amountUsdNum) && amountUsdNum < minUsd;
  const overBalance = typeof balance === 'number' && Number.isFinite(amountUsdNum) && amountUsdNum > balance;
  const canSubmit =
    !!selected && !submitting && Number.isFinite(amountUsdNum) && amountUsdNum > 0 &&
    !belowMin && !overBalance && address.trim().length > 0;

  const close = () => {
    setDone(false);
    setError('');
    setAmountUsd('');
    setAddress('');
    setEstimate(null);
    onClose();
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selected) return;
    setError('');
    if (!Number.isFinite(amountUsdNum) || amountUsdNum <= 0) { setError(t('withdraw.invalidAmount')); return; }
    if (amountUsdNum < minUsd) { setError(t('withdraw.belowMin', { min: minUsd.toFixed(2) })); return; }
    if (overBalance) { setError(t('withdraw.insufficient')); return; }

    setSubmitting(true);
    try {
      await createWithdrawal({ amountUsd: amountUsdNum, payCurrency: selected.code, address: address.trim() });
      setDone(true);
    } catch (err: any) {
      setError(err.message || 'Something went wrong');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="dep-overlay" onClick={close}>
      <div className="dep-modal glass-panel" onClick={(e) => e.stopPropagation()}>
        <button className="dep-close" onClick={close} aria-label="Close"><X size={20} /></button>

        <header className="dep-header">
          <h2 className="dep-title">{t('withdraw.title')}</h2>
          <p className="dep-subtitle">{t('withdraw.subtitle')}</p>
        </header>

        {done ? (
          <div className="dep-form" style={{ alignItems: 'center', textAlign: 'center', gap: 14 }}>
            <CheckCircle2 size={48} color="var(--accent)" />
            <strong style={{ fontSize: 18, color: 'var(--text-h)' }}>{t('withdraw.requested')}</strong>
            <p style={{ color: 'var(--text-muted)', fontSize: 14 }}>{t('withdraw.pendingApproval')}</p>
            <button type="button" className="dep-submit" onClick={close}>{t('withdraw.done')}</button>
          </div>
        ) : loadingCurrencies ? (
          <div className="dep-loading"><Loader2 size={24} className="spin-animation" /></div>
        ) : (
          <form onSubmit={handleSubmit} className="dep-form">
            <div className="dep-section">
              <div className="dep-section-head">
                <span className="dep-dot dep-dot-green" />
                <span className="dep-section-label">{t('withdraw.chooseCoin')}</span>
              </div>
              <div className="dep-coin-grid">
                {currencies.map((currency) => (
                  <button
                    key={currency.code}
                    type="button"
                    className={`dep-coin ${selectedCode === currency.code ? 'selected' : ''}`}
                    onClick={() => setSelectedCode(currency.code)}
                  >
                    <CoinIcon currency={currency} />
                    <span className="dep-coin-text">
                      <span className="dep-coin-ticker">
                        {currency.ticker}
                        {currency.network && <span className="dep-coin-network">{currency.network}</span>}
                      </span>
                      <span className="dep-coin-name">{currency.name}</span>
                    </span>
                  </button>
                ))}
              </div>
            </div>

            <div className="dep-field">
              <label className="dep-field-label">{t('withdraw.amount')}</label>
              <div className="dep-input-wrap">
                <span className="dep-input-prefix">$</span>
                <input
                  type="number" min="0" step="0.01" inputMode="decimal"
                  value={amountUsd}
                  onChange={(e) => setAmountUsd(e.target.value)}
                  className="dep-input" placeholder="0.00"
                />
              </div>
              {typeof balance === 'number' && (
                <button type="button" className="admin-btn-ghost" style={{ marginTop: 6, alignSelf: 'flex-start', padding: '4px 10px', fontSize: 12 }}
                  onClick={() => setAmountUsd(balance.toFixed(2))}>
                  {t('withdraw.max')} ${balance.toFixed(2)}
                </button>
              )}
            </div>

            <div className="dep-field">
              <label className="dep-field-label">{t('withdraw.address', { ticker: selected?.ticker ?? '', network: selected?.network ?? '' })}</label>
              <div className="dep-input-wrap">
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="dep-input"
                  placeholder={t('withdraw.addressPlaceholder')}
                  spellCheck={false}
                  autoComplete="off"
                />
              </div>
            </div>

            {estimate && Number.isFinite(amountUsdNum) && amountUsdNum > 0 ? (
              <div className="dep-fee">
                <div className="dep-fee-row">
                  <span>{t('withdraw.amountLabel')}</span>
                  <span>${estimate.amountUsd.toFixed(2)}</span>
                </div>
                {estimate.platformFeeUsd > 0 && (
                  <div className="dep-fee-row dep-fee-muted">
                    <span>{t('withdraw.platformFee')} ({(estimate.platformFeePercent * 100).toFixed(estimate.platformFeePercent * 100 % 1 === 0 ? 0 : 2)}%)</span>
                    <span>−${estimate.platformFeeUsd.toFixed(2)}</span>
                  </div>
                )}
                <div className="dep-fee-row dep-fee-muted">
                  <span>{t('withdraw.networkFee')}</span>
                  <span>{estimate.estNetworkFeeUsd != null ? `≈ −$${estimate.estNetworkFeeUsd.toFixed(2)}` : t('withdraw.varies')}</span>
                </div>
                <div className="dep-fee-row dep-fee-total">
                  <span>{t('withdraw.youReceive')}</span>
                  <span>≈ ${estimate.estimatedReceiveUsd.toFixed(2)}</span>
                </div>
                {loadingEstimate && <p className="admin-hint" style={{ marginTop: 4 }}>{t('withdraw.updating')}</p>}
              </div>
            ) : null}

            <div className={`dep-min ${belowMin ? 'dep-min-warn' : ''}`}>
              <span>{t('withdraw.minimum')}: <strong>${minUsd.toFixed(2)}</strong></span>
            </div>

            {overBalance && <div className="dep-error">{t('withdraw.insufficient')}</div>}
            {error && <div className="dep-error">{error}</div>}

            <button type="submit" className="dep-submit" disabled={!canSubmit}>
              {submitting ? (<><Loader2 size={18} className="spin-animation" /> {t('withdraw.processing')}</>) : t('withdraw.submit')}
            </button>

            <p className="dep-secure"><ShieldCheck size={14} /> {t('withdraw.secured')}</p>
          </form>
        )}
      </div>
    </div>
  );
};
