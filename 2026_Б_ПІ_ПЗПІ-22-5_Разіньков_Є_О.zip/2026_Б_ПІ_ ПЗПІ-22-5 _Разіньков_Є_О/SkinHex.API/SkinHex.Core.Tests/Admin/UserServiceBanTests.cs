using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Caching.Memory;
using Moq;
using SkinHex.Core.Entities;
using SkinHex.Core.Interfaces.Steam;
using SkinHex.Core.Services;
using SkinHex.Infrastructure;
using SkinHex.Infrastructure.Repositories;
using Xunit;

namespace SkinHex.Core.Tests.Admin;

public class UserServiceBanTests
{
    private readonly SkinHexDbContext _dbContext;
    private readonly UserService _service;
    private readonly Mock<ISteamGatewayClient> _steamGatewayClientMock;

    public UserServiceBanTests()
    {
        var dbOptions = new DbContextOptionsBuilder<SkinHexDbContext>()
            .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
            // BanUserAsync opens a transaction; the in-memory provider only warns.
            .ConfigureWarnings(w => w.Ignore(InMemoryEventId.TransactionIgnoredWarning))
            .Options;
        _dbContext = new SkinHexDbContext(dbOptions);
        _steamGatewayClientMock = new Mock<ISteamGatewayClient>();

        _service = new UserService(
            new UserRepository(_dbContext),
            _steamGatewayClientMock.Object,
            new ListingRepository(_dbContext),
            new EfUnitOfWork(_dbContext),
            new MemoryCache(new MemoryCacheOptions()));
    }

    [Fact]
    public async Task GetInventoryAsync_ExcludesItemsThatAreAlreadyListedByUser()
    {
        const uint partnerId = 1;
        var user = new User
        {
            Id = Guid.NewGuid(),
            SteamId = (76561197960265728UL + partnerId).ToString(),
            Username = "u",
            TradeUrl = $"https://steamcommunity.com/tradeoffer/new/?partner={partnerId}&token=test-token"
        };

        _dbContext.Users.Add(user);
        _dbContext.Listings.Add(new Listing
        {
            Id = Guid.NewGuid(),
            SellerId = user.Id,
            ItemId = 1,
            Price = 10m,
            Status = ListingStatus.Active,
            SteamAssetId = 1001
        });
        _dbContext.Listings.Add(new Listing
        {
            Id = Guid.NewGuid(),
            SellerId = user.Id,
            ItemId = 2,
            Price = 20m,
            Status = ListingStatus.Cancelled,
            SteamAssetId = 2002
        });
        await _dbContext.SaveChangesAsync();

        _steamGatewayClientMock
            .Setup(client => client.GetInventoryAsync(It.IsAny<Models.Steam.SteamTradeLink>(), false, It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<Models.InventoryItemDto>
            {
                new() { AssetId = "1001", MarketHashName = "Listed item" },
                new() { AssetId = "2002", MarketHashName = "Previously cancelled" },
                new() { AssetId = "3003", MarketHashName = "Available item" }
            });

        var result = await _service.GetInventoryAsync(user.Id, false, default);

        Assert.True(result.IsSuccess);
        var inventory = Assert.IsAssignableFrom<IReadOnlyList<Models.InventoryItemDto>>(result.Value);
        Assert.Equal(2, inventory.Count);
        Assert.DoesNotContain(inventory, item => item.AssetId == "1001");
        Assert.Contains(inventory, item => item.AssetId == "2002");
        Assert.Contains(inventory, item => item.AssetId == "3003");
    }

    [Fact]
    public async Task BanUserAsync_SetsBannedRoleAndCancelsActiveListings()
    {
        var user = new User { Id = Guid.NewGuid(), SteamId = "s", Username = "u", Role = UserRole.User };
        _dbContext.Users.Add(user);
        _dbContext.Listings.Add(new Listing
        {
            Id = Guid.NewGuid(), SellerId = user.Id, ItemId = 1, Price = 10m, Status = ListingStatus.Active
        });
        _dbContext.Listings.Add(new Listing
        {
            Id = Guid.NewGuid(), SellerId = user.Id, ItemId = 2, Price = 20m, Status = ListingStatus.Sold
        });
        await _dbContext.SaveChangesAsync();

        var result = await _service.BanUserAsync(user.Id, default);

        Assert.True(result.IsSuccess);
        Assert.Equal(UserRole.Banned, (await _dbContext.Users.FindAsync(user.Id))!.Role);

        var listings = _dbContext.Listings.Where(l => l.SellerId == user.Id).ToList();
        Assert.Equal(ListingStatus.Cancelled, listings.Single(l => l.ItemId == 1).Status);
        // A sold listing must not be touched by a ban.
        Assert.Equal(ListingStatus.Sold, listings.Single(l => l.ItemId == 2).Status);
    }

    [Fact]
    public async Task UnbanUserAsync_RestoresUserRole()
    {
        var user = new User { Id = Guid.NewGuid(), SteamId = "s", Username = "u", Role = UserRole.Banned };
        _dbContext.Users.Add(user);
        await _dbContext.SaveChangesAsync();

        var result = await _service.UnbanUserAsync(user.Id, default);

        Assert.True(result.IsSuccess);
        Assert.Equal(UserRole.User, (await _dbContext.Users.FindAsync(user.Id))!.Role);
    }

    [Fact]
    public async Task UnbanUserAsync_FailsWhenUserNotBanned()
    {
        var user = new User { Id = Guid.NewGuid(), SteamId = "s", Username = "u", Role = UserRole.User };
        _dbContext.Users.Add(user);
        await _dbContext.SaveChangesAsync();

        var result = await _service.UnbanUserAsync(user.Id, default);

        Assert.True(result.IsFailed);
    }
}
