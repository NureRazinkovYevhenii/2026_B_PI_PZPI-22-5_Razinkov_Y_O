using System.Net;

namespace SkinHex.SteamGateway.Steam;

public sealed class SteamIntegrationException : Exception
{
    public SteamIntegrationException(
        string message,
        HttpStatusCode? statusCode = null,
        string? responseBody = null)
        : base(message)
    {
        StatusCode = statusCode;
        ResponseBody = responseBody;
    }

    public HttpStatusCode? StatusCode { get; }
    public string? ResponseBody { get; }
}
