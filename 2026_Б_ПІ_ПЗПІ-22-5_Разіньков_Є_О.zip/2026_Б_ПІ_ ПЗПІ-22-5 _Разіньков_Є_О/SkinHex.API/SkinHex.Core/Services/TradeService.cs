using SkinHex.Core.Entities;
using SkinHex.Core.Interfaces.Services;
using SkinHex.Core.Models.Orders;

namespace SkinHex.Core.Services;

public sealed class TradeService(IOrderService orderService) : ITradeService
{
    public Task<TradeInfoDto> GetTradeInfoAsync(Guid orderId, Guid sellerId, CancellationToken ct = default)
        => orderService.GetTradeInfoAsync(orderId, sellerId, ct);

    public Task<PendingTradeSyncResponse> GetPendingTradeSyncAsync(Guid userId, string? actorRole, CancellationToken ct = default)
        => orderService.GetPendingTradeSyncAsync(userId, actorRole, ct);

    public Task<BatchTradeSyncUpdateResponse> BatchSyncTradeAttemptsAsync(Guid userId, BatchTradeSyncUpdateRequest request, CancellationToken ct = default)
        => orderService.BatchSyncTradeAttemptsAsync(userId, request, ct);

    public Task<SteamTradeDto> CreateTradeAttemptAsync(Guid orderId, Guid sellerId, string tradeOfferId, SteamOfferState offerState, CancellationToken ct = default)
        => orderService.CreateTradeAttemptAsync(orderId, sellerId, tradeOfferId, offerState, ct);

    public Task<SteamTradeDto> UpdateTradeAttemptAsync(
        Guid orderId,
        Guid sellerId,
        string tradeOfferId,
        SteamOfferState offerState,
        string? tradeId,
        SteamTradeStatus? tradeStatus,
        long? timeUpdated = null,
        CancellationToken ct = default)
        => orderService.UpdateTradeAttemptAsync(orderId, sellerId, tradeOfferId, offerState, tradeId, tradeStatus, timeUpdated, ct);

    public Task ProcessTlsnTradeStatusProofAsync(
        string steamTradeId,
        SteamTradeStatus tradeStatus,
        string? steamIdOther,
        IReadOnlyCollection<string> transferredAssetIds,
        long? timeSettlementUnix,
        DateTimeOffset proofObservedAtUtc,
        CancellationToken ct = default)
        => orderService.ProcessTlsnTradeStatusProofAsync(
            steamTradeId,
            tradeStatus,
            steamIdOther,
            transferredAssetIds,
            timeSettlementUnix,
            proofObservedAtUtc,
            ct);
}
