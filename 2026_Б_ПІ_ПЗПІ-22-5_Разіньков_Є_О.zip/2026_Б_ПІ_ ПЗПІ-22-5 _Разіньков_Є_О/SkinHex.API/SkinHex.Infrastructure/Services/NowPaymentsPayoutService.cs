using System.Globalization;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;
using SkinHex.Core.Interfaces.Services;
using SkinHex.Core.Options;

namespace SkinHex.Infrastructure.Services;

public class NowPaymentsPayoutService : INowPaymentsPayoutService
{
    private const string JwtCacheKey = "nowpayments:payout:jwt";
    private static readonly TimeSpan JwtTtl = TimeSpan.FromMinutes(4); // NOWPayments JWT lives 5 min

    private readonly HttpClient _httpClient;
    private readonly NowPaymentsOptions _options;
    private readonly IMemoryCache _cache;

    public NowPaymentsPayoutService(HttpClient httpClient, IOptions<NowPaymentsOptions> options, IMemoryCache cache)
    {
        _httpClient = httpClient;
        _options = options.Value;
        _cache = cache;
        _httpClient.BaseAddress = new Uri(_options.BaseUrl);
        _httpClient.DefaultRequestHeaders.Add("x-api-key", _options.ApiKey);
    }

    public async Task<PayoutResult> CreatePayoutAsync(
        string address,
        string currencyCode,
        decimal amountUsd,
        string? extraId = null,
        CancellationToken ct = default)
    {
        var jwt = await AuthenticateAsync(ct);

        var withdrawal = new Dictionary<string, object?>
        {
            ["address"] = address,
            ["currency"] = currencyCode,
            ["amount"] = amountUsd
        };
        if (!string.IsNullOrWhiteSpace(extraId))
            withdrawal["extra_id"] = extraId;

        var body = new Dictionary<string, object?>
        {
            ["ipn_callback_url"] = _options.PayoutIpnCallbackUrl,
            ["withdrawals"] = new[] { withdrawal }
        };

        using var request = new HttpRequestMessage(HttpMethod.Post, "/v1/payout")
        {
            Content = JsonContent.Create(body)
        };
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", jwt);

        var response = await _httpClient.SendAsync(request, ct);
        var payload = await response.Content.ReadAsStringAsync(ct);

        if (!response.IsSuccessStatusCode)
            throw new PayoutException($"NOWPayments payout failed ({(int)response.StatusCode}): {payload}");

        using var document = JsonDocument.Parse(payload);
        var root = document.RootElement;

        var batchId = root.TryGetProperty("id", out var idEl) ? idEl.ToString() : string.Empty;

        var payoutId = batchId;
        var status = "creating";
        if (root.TryGetProperty("withdrawals", out var withdrawals) &&
            withdrawals.ValueKind == JsonValueKind.Array &&
            withdrawals.GetArrayLength() > 0)
        {
            var first = withdrawals[0];
            if (first.TryGetProperty("id", out var wid))
                payoutId = wid.ToString();
            if (first.TryGetProperty("status", out var st))
                status = st.GetString() ?? status;
        }

        return new PayoutResult(batchId, payoutId, status);
    }

    public async Task VerifyPayoutAsync(string batchId, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(batchId))
            throw new PayoutException("Cannot verify payout: batch id is empty.");
        if (string.IsNullOrWhiteSpace(_options.PayoutTotpSecret))
            throw new PayoutException("Payout verification is not configured (missing NOWPayments TOTP secret).");

        var jwt = await AuthenticateAsync(ct);
        var code = Totp.Generate(_options.PayoutTotpSecret);

        var body = new Dictionary<string, object?> { ["verification_code"] = code };

        using var request = new HttpRequestMessage(HttpMethod.Post, $"/v1/payout/{batchId}/verify")
        {
            Content = JsonContent.Create(body)
        };
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", jwt);

        var response = await _httpClient.SendAsync(request, ct);
        var payload = await response.Content.ReadAsStringAsync(ct);

        if (!response.IsSuccessStatusCode)
            throw new PayoutException($"NOWPayments payout verify failed ({(int)response.StatusCode}): {payload}");
    }

    public async Task<string> GetPayoutStatusAsync(string payoutId, CancellationToken ct = default)
    {
        var jwt = await AuthenticateAsync(ct);

        using var request = new HttpRequestMessage(HttpMethod.Get, $"/v1/payout/{payoutId}");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", jwt);

        var response = await _httpClient.SendAsync(request, ct);
        var payload = await response.Content.ReadAsStringAsync(ct);

        if (!response.IsSuccessStatusCode)
            throw new PayoutException($"NOWPayments payout status failed ({(int)response.StatusCode}): {payload}");

        using var document = JsonDocument.Parse(payload);
        return document.RootElement.TryGetProperty("status", out var st) ? st.GetString() ?? "unknown" : "unknown";
    }

    /// <summary>Returns a cached JWT, obtaining a fresh one via POST /v1/auth when needed.</summary>
    private async Task<string> AuthenticateAsync(CancellationToken ct)
    {
        if (_cache.TryGetValue(JwtCacheKey, out string? cached) && !string.IsNullOrEmpty(cached))
            return cached;

        if (string.IsNullOrWhiteSpace(_options.PayoutEmail) || string.IsNullOrWhiteSpace(_options.PayoutPassword))
            throw new PayoutException("Payouts are not configured (missing NOWPayments payout credentials).");

        var authBody = new { email = _options.PayoutEmail, password = _options.PayoutPassword };
        var response = await _httpClient.PostAsJsonAsync("/v1/auth", authBody, ct);
        var payload = await response.Content.ReadAsStringAsync(ct);

        if (!response.IsSuccessStatusCode)
            throw new PayoutException($"NOWPayments auth failed ({(int)response.StatusCode}): {payload}");

        using var document = JsonDocument.Parse(payload);
        if (!document.RootElement.TryGetProperty("token", out var tokenEl) || tokenEl.GetString() is not { Length: > 0 } token)
            throw new PayoutException("NOWPayments auth response did not contain a token.");

        _cache.Set(JwtCacheKey, token, JwtTtl);
        return token;
    }
}
