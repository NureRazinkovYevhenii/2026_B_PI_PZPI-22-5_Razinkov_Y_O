namespace SkinHex.Core.Models.Auth;

public sealed record SendOtpRequest(string Email);
