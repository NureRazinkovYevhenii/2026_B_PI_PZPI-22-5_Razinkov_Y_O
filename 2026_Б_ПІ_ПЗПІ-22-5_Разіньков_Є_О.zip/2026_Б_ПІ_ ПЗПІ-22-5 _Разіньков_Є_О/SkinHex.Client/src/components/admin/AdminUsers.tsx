import { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import type { AuthorizedFetch } from '../../types';
import {
  adjustBalance,
  banUser,
  fetchUser,
  fetchUsers,
  unbanUser,
  type AdminUserDetail,
  type AdminUserListItem,
} from '../../api/adminApi';
import { formatDateTime, formatMoney, IdCell, Pager, StateBlock, StatusBadge } from './adminShared';

type Props = { authorizedFetch: AuthorizedFetch };

const PAGE_SIZE = 20;
const ROLE_OPTIONS = ['', 'Unverified', 'User', 'Admin', 'Banned'];

export function AdminUsers({ authorizedFetch }: Props) {
  const { t } = useTranslation();
  const [search, setSearch] = useState('');
  const [role, setRole] = useState('');
  const [page, setPage] = useState(1);
  const [items, setItems] = useState<AdminUserListItem[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await fetchUsers(authorizedFetch, { search: search.trim(), role, page, pageSize: PAGE_SIZE });
      setItems(result.items);
      setTotalCount(result.totalCount);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load users');
    } finally {
      setLoading(false);
    }
  }, [authorizedFetch, search, role, page]);

  useEffect(() => {
    void load();
  }, [load]);

  const onSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1);
    void load();
  };

  return (
    <div>
      <form className="admin-toolbar" onSubmit={onSearchSubmit}>
        <input
          className="admin-input"
          placeholder={t('admin.users.searchPlaceholder')}
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <select
          className="admin-select"
          value={role}
          onChange={(e) => {
            setRole(e.target.value);
            setPage(1);
          }}
        >
          {ROLE_OPTIONS.map((r) => (
            <option key={r} value={r}>
              {r === '' ? t('admin.users.allRoles') : r}
            </option>
          ))}
        </select>
        <button className="primary-button" type="submit">{t('admin.search')}</button>
      </form>

      {error ? (
        <StateBlock><strong>{t('admin.error')}</strong><p>{error}</p></StateBlock>
      ) : loading ? (
        <StateBlock><strong>{t('admin.loading')}</strong></StateBlock>
      ) : items.length === 0 ? (
        <StateBlock><strong>{t('admin.users.none')}</strong></StateBlock>
      ) : (
        <div className="admin-table-wrap">
          <table className="admin-table">
            <thead>
              <tr>
                <th>{t('admin.id')}</th>
                <th>{t('admin.users.user')}</th>
                <th>{t('admin.users.role')}</th>
                <th style={{ textAlign: 'right' }}>{t('admin.users.balance')}</th>
                <th style={{ textAlign: 'right' }}>{t('admin.users.frozen')}</th>
                <th>{t('admin.users.joined')}</th>
              </tr>
            </thead>
            <tbody>
              {items.map((u) => (
                <tr key={u.id} onClick={() => setSelectedId(u.id)} className="admin-row">
                  <td><IdCell id={u.id} /></td>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                      {u.avatarUrl ? (
                        <img src={u.avatarUrl} alt="" style={{ width: 28, height: 28, borderRadius: '50%' }} />
                      ) : (
                        <div className="admin-avatar-fallback">{u.username.charAt(0)}</div>
                      )}
                      <div>
                        <div style={{ fontWeight: 600, color: 'var(--text-h)' }}>{u.username}</div>
                        <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{u.steamId}</div>
                      </div>
                    </div>
                  </td>
                  <td><StatusBadge status={u.role} /></td>
                  <td style={{ textAlign: 'right', fontWeight: 600 }}>{formatMoney(u.balance)}</td>
                  <td style={{ textAlign: 'right', color: 'var(--text-muted)' }}>{formatMoney(u.frozenBalance)}</td>
                  <td style={{ color: 'var(--text-muted)', fontSize: 13 }}>{formatDateTime(u.createdAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Pager page={page} pageSize={PAGE_SIZE} totalCount={totalCount} onPage={setPage} />

      {selectedId && (
        <UserDetailModal
          authorizedFetch={authorizedFetch}
          userId={selectedId}
          onClose={() => setSelectedId(null)}
          onChanged={() => void load()}
        />
      )}
    </div>
  );
}

type ModalProps = {
  authorizedFetch: AuthorizedFetch;
  userId: string;
  onClose: () => void;
  onChanged: () => void;
};

function UserDetailModal({ authorizedFetch, userId, onClose, onChanged }: ModalProps) {
  const { t } = useTranslation();
  const [detail, setDetail] = useState<AdminUserDetail | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [amount, setAmount] = useState('');
  const [reason, setReason] = useState('');
  const [actionError, setActionError] = useState<string | null>(null);

  const reload = useCallback(async () => {
    try {
      setDetail(await fetchUser(authorizedFetch, userId));
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load user');
    }
  }, [authorizedFetch, userId]);

  useEffect(() => {
    void reload();
  }, [reload]);

  const runAction = async (fn: () => Promise<unknown>) => {
    setBusy(true);
    setActionError(null);
    try {
      await fn();
      await reload();
      onChanged();
    } catch (e) {
      setActionError(e instanceof Error ? e.message : 'Action failed');
    } finally {
      setBusy(false);
    }
  };

  const onAdjust = (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = Number(amount);
    if (!Number.isFinite(parsed) || parsed === 0) {
      setActionError(t('admin.users.invalidAmount'));
      return;
    }
    if (!reason.trim()) {
      setActionError(t('admin.users.reasonRequired'));
      return;
    }
    void runAction(async () => {
      await adjustBalance(authorizedFetch, userId, parsed, reason.trim());
      setAmount('');
      setReason('');
    });
  };

  const isBanned = detail?.role === 'Banned';

  return (
    <div className="admin-modal-overlay" onClick={onClose}>
      <div className="admin-modal glass-panel" onClick={(e) => e.stopPropagation()}>
        <div className="admin-modal-head">
          <div>
            <h3>{t('admin.users.detailTitle')}</h3>
            <IdCell id={userId} />
          </div>
          <button className="admin-modal-close" onClick={onClose} aria-label="Close">✕</button>
        </div>

        {error ? (
          <StateBlock><strong>{error}</strong></StateBlock>
        ) : !detail ? (
          <StateBlock><strong>{t('admin.loading')}</strong></StateBlock>
        ) : (
          <div className="admin-modal-body">
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
              {detail.avatarUrl ? (
                <img src={detail.avatarUrl} alt="" style={{ width: 48, height: 48, borderRadius: '50%' }} />
              ) : (
                <div className="admin-avatar-fallback" style={{ width: 48, height: 48, fontSize: 20 }}>{detail.username.charAt(0)}</div>
              )}
              <div>
                <div style={{ fontWeight: 700, fontSize: 18, color: 'var(--text-h)' }}>{detail.username}</div>
                <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>{detail.steamId}</div>
              </div>
              <div style={{ marginLeft: 'auto' }}><StatusBadge status={detail.role} /></div>
            </div>

            <div className="admin-kv-grid">
              <div><span>{t('admin.users.balance')}</span><strong>{formatMoney(detail.balance)}</strong></div>
              <div><span>{t('admin.users.frozen')}</span><strong>{formatMoney(detail.frozenBalance)}</strong></div>
              <div><span>{t('admin.users.activeListings')}</span><strong>{detail.activeListingsCount}</strong></div>
              <div><span>{t('admin.users.openTickets')}</span><strong>{detail.openTicketsCount}</strong></div>
              <div><span>{t('admin.users.ordersBuyer')}</span><strong>{detail.ordersAsBuyer}</strong></div>
              <div><span>{t('admin.users.ordersSeller')}</span><strong>{detail.ordersAsSeller}</strong></div>
            </div>

            {actionError && <div className="admin-inline-error">{actionError}</div>}

            <div className="admin-action-row">
              {isBanned ? (
                <button className="primary-button" disabled={busy} onClick={() => void runAction(() => unbanUser(authorizedFetch, userId))}>
                  {t('admin.users.unban')}
                </button>
              ) : (
                <button className="admin-btn-danger" disabled={busy} onClick={() => void runAction(() => banUser(authorizedFetch, userId))}>
                  {t('admin.users.ban')}
                </button>
              )}
            </div>

            <form className="admin-adjust-form" onSubmit={onAdjust}>
              <h4>{t('admin.users.adjustBalance')}</h4>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                <input
                  className="admin-input"
                  style={{ width: 120 }}
                  type="number"
                  step="0.01"
                  placeholder={t('admin.users.amount')}
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                />
                <input
                  className="admin-input"
                  style={{ flex: 1, minWidth: 160 }}
                  placeholder={t('admin.users.reason')}
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                />
                <button className="primary-button" type="submit" disabled={busy}>{t('admin.users.apply')}</button>
              </div>
              <p className="admin-hint">{t('admin.users.adjustHint')}</p>
            </form>

            <h4 style={{ marginTop: 20 }}>{t('admin.users.recentTransactions')}</h4>
            {detail.recentTransactions.length === 0 ? (
              <p className="admin-hint">{t('admin.users.noTransactions')}</p>
            ) : (
              <div className="admin-table-wrap">
                <table className="admin-table">
                  <thead>
                    <tr>
                      <th>{t('admin.users.type')}</th>
                      <th style={{ textAlign: 'right' }}>{t('admin.users.amount')}</th>
                      <th>{t('admin.users.status')}</th>
                      <th>{t('admin.users.date')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {detail.recentTransactions.map((tx) => (
                      <tr key={tx.id}>
                        <td>{tx.type}</td>
                        <td style={{ textAlign: 'right', fontWeight: 600, color: tx.amount < 0 ? '#f87171' : '#34d399' }}>
                          {formatMoney(tx.amount)}
                        </td>
                        <td><StatusBadge status={tx.status} /></td>
                        <td style={{ color: 'var(--text-muted)', fontSize: 13 }}>{formatDateTime(tx.createdAt)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
