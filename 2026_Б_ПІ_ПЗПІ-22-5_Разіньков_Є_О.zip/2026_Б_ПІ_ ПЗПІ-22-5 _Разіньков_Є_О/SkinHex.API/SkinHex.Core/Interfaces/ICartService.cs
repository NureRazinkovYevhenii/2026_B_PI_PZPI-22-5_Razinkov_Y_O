using SkinHex.Core.Models.Cart;

namespace SkinHex.Core.Interfaces;

public interface ICartService
{
    Task<List<CartItemDto>> GetCartAsync(Guid userId);
    Task<CartItemDto> AddToCartAsync(Guid userId, Guid listingId);
    Task RemoveFromCartAsync(Guid userId, Guid cartItemId);
    Task ClearCartAsync(Guid userId);
}
