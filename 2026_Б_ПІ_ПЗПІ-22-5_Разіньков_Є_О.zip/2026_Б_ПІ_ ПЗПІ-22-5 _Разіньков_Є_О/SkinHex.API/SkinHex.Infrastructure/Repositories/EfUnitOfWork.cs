using SkinHex.Core.Interfaces.Repositories;

namespace SkinHex.Infrastructure.Repositories;

public class EfUnitOfWork : IUnitOfWork
{
    private readonly SkinHexDbContext _context;

    public EfUnitOfWork(SkinHexDbContext context)
    {
        _context = context;
    }

    public Task SaveChangesAsync(CancellationToken ct = default)
    {
        return _context.SaveChangesAsync(ct);
    }

    public Task<Microsoft.EntityFrameworkCore.Storage.IDbContextTransaction> BeginTransactionAsync(CancellationToken ct = default)
    {
        return _context.Database.BeginTransactionAsync(ct);
    }

    public void ClearChangeTracker()
    {
        _context.ChangeTracker.Clear();
    }
}
