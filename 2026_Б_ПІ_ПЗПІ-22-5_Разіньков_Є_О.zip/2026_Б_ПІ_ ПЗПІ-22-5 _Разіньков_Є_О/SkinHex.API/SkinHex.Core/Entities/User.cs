namespace SkinHex.Core.Entities;

public enum UserRole
{
    Unverified = 0,
    Banned = 1,
    User = 2,
    Admin = 3
}

public class User
{
    public Guid Id { get; set; }
    public string SteamId { get; set; } = string.Empty;
    public string Username { get; set; } = string.Empty;
    public string? Email { get; set; }
    public string? AvatarUrl { get; set; }
    public string? TradeUrl { get; set; }

    public decimal Balance { get; set; }
    public decimal FrozenBalance { get; set; }

    public UserRole Role { get; set; } = UserRole.Unverified;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }

    public ICollection<RefreshToken> RefreshTokens { get; set; } = new List<RefreshToken>();
    public ICollection<Listing> Listings { get; set; } = new List<Listing>();
    public ICollection<CartItem> CartItems { get; set; } = new List<CartItem>();
    public ICollection<FinancialTransaction> FinancialTransactions { get; set; } = new List<FinancialTransaction>();
    public ICollection<Deposit> Deposits { get; set; } = new List<Deposit>();

}