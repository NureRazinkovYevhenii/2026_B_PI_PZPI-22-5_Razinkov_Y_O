import { useCallback, useRef } from 'react';

type DualRangeSliderProps = {
  min: number;
  max: number;
  step: number;
  valueMin: number;
  valueMax: number;
  onChange: (min: number, max: number) => void;
  /** If provided, renders colored segments on the track (e.g., for float bar) */
  trackSegments?: { color: string; start: number; end: number }[];
  formatLabel?: (value: number) => string;
};

export function DualRangeSlider({
  min,
  max,
  step,
  valueMin,
  valueMax,
  onChange,
  trackSegments,
  formatLabel,
}: DualRangeSliderProps) {
  const trackRef = useRef<HTMLDivElement>(null);

  const range = max - min || 1;
  const leftPercent = ((valueMin - min) / range) * 100;
  const rightPercent = ((valueMax - min) / range) * 100;

  const handleMinChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const newMin = Number(e.target.value);
      onChange(Math.min(newMin, valueMax - step), valueMax);
    },
    [onChange, valueMax, step],
  );

  const handleMaxChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const newMax = Number(e.target.value);
      onChange(valueMin, Math.max(newMax, valueMin + step));
    },
    [onChange, valueMin, step],
  );

  return (
    <div className="dual-range-slider">
      <div className="dual-range-track" ref={trackRef}>
        {trackSegments ? (
          trackSegments.map((seg, i) => {
            const segLeft = ((seg.start - min) / range) * 100;
            const segWidth = ((seg.end - seg.start) / range) * 100;
            return (
              <div
                key={i}
                className="dual-range-segment"
                style={{
                  left: `${segLeft}%`,
                  width: `${segWidth}%`,
                  backgroundColor: seg.color,
                }}
              />
            );
          })
        ) : (
          <div className="dual-range-track-bg" />
        )}
        {/* Highlighted range */}
        <div
          className="dual-range-highlight"
          style={{
            left: `${leftPercent}%`,
            width: `${rightPercent - leftPercent}%`,
          }}
        />
        {/* Thumb indicators */}
        <div className="dual-range-thumb-visual" style={{ left: `${leftPercent}%` }} />
        <div className="dual-range-thumb-visual" style={{ left: `${rightPercent}%` }} />
      </div>
      <div className="dual-range-inputs">
        <input
          type="range"
          min={min}
          max={max}
          step={step}
          value={valueMin}
          onChange={handleMinChange}
          className="dual-range-input dual-range-input-min"
        />
        <input
          type="range"
          min={min}
          max={max}
          step={step}
          value={valueMax}
          onChange={handleMaxChange}
          className="dual-range-input dual-range-input-max"
        />
      </div>
      {formatLabel && (
        <div className="dual-range-labels">
          <span>{formatLabel(valueMin)}</span>
          <span>{formatLabel(valueMax)}</span>
        </div>
      )}
    </div>
  );
}
