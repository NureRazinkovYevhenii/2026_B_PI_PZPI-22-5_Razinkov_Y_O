using Microsoft.Extensions.Options;
using SkinHex.Core.Interfaces.Steam;
using SkinHex.Core.Models.Steam;
using SteamKit2;
using SteamKit2.Authentication;

namespace SkinHex.SteamBotAuthService;

public sealed class Worker : BackgroundService
{
    private readonly ILogger<Worker> _logger;
    private readonly ISteamBotSessionStore _sessionStore;
    private readonly IReadOnlyList<SteamBotOptions> _bots;
    private readonly SteamAuthenticationOptions _options;

    public Worker(
        ILogger<Worker> logger,
        ISteamBotSessionStore sessionStore,
        IOptions<List<SteamBotOptions>> bots,
        IOptions<SteamAuthenticationOptions> options)
    {
        _logger = logger;
        _sessionStore = sessionStore;
        _bots = bots.Value;
        _options = options.Value;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Steam bot auth service started with {BotCount} bot(s).", _bots.Count);

        try
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                await Task.WhenAll(_bots.Select(bot => RefreshBotSafelyAsync(bot, stoppingToken)));
                await Task.Delay(
                    TimeSpan.FromMinutes(_options.RefreshIntervalMinutes),
                    stoppingToken);
            }
        }
        catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
        {
            _logger.LogInformation("Steam bot auth service is stopping.");
        }
    }

    private async Task RefreshBotSafelyAsync(
        SteamBotOptions bot,
        CancellationToken cancellationToken)
    {
        try
        {
            await AuthenticateBotAsync(bot, cancellationToken);
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            throw;
        }
        catch (Exception exception)
        {
            _logger.LogError(exception, "Could not refresh Steam session for bot {BotUsername}.", bot.Username);
        }
    }

    private async Task AuthenticateBotAsync(
        SteamBotOptions bot,
        CancellationToken cancellationToken)
    {
        var steamClient = new SteamClient();
        var callbackManager = new CallbackManager(steamClient);
        var connected = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
        using var callbackPumpCancellation = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);

        callbackManager.Subscribe<SteamClient.ConnectedCallback>(_ => connected.TrySetResult(true));
        callbackManager.Subscribe<SteamClient.DisconnectedCallback>(_ =>
            connected.TrySetException(new InvalidOperationException("Steam disconnected before authentication.")));

        var callbackPump = Task.Run(
            () => RunCallbackPump(callbackManager, callbackPumpCancellation.Token),
            CancellationToken.None);

        try
        {
            steamClient.Connect();
            await connected.Task.WaitAsync(
                TimeSpan.FromSeconds(_options.ConnectionTimeoutSeconds),
                cancellationToken);

            var authSession = await steamClient.Authentication.BeginAuthSessionViaCredentialsAsync(
                new AuthSessionDetails
                {
                    Username = bot.Username,
                    Password = bot.Password,
                    IsPersistentSession = false,
                    Authenticator = new AutoAuthenticator(bot.SharedSecret)
                }).WaitAsync(cancellationToken);

            var authResult = await authSession.PollingWaitForResultAsync()
                .WaitAsync(cancellationToken);

            var session = new SteamBotSession
            {
                Username = bot.Username,
                SessionId = Guid.NewGuid().ToString("N"),
                SteamLoginSecure = $"{bot.SteamId}%7C%7C{authResult.AccessToken}",
                RefreshedAtUtc = DateTimeOffset.UtcNow
            };

            await _sessionStore.StoreAsync(session, cancellationToken);
            _logger.LogInformation("Steam session for bot {BotUsername} was refreshed in Redis.", bot.Username);
        }
        finally
        {
            steamClient.Disconnect();
            callbackPumpCancellation.Cancel();

            try
            {
                await callbackPump;
            }
            catch (OperationCanceledException)
            {
                // Expected while stopping the callback pump.
            }
        }
    }

    private static void RunCallbackPump(
        CallbackManager callbackManager,
        CancellationToken cancellationToken)
    {
        while (!cancellationToken.IsCancellationRequested)
        {
            callbackManager.RunWaitCallbacks(TimeSpan.FromMilliseconds(500));
        }
    }

    private sealed class AutoAuthenticator : IAuthenticator
    {
        private readonly SteamGuardCodeGenerator _codeGenerator;

        public AutoAuthenticator(string sharedSecret)
        {
            _codeGenerator = new SteamGuardCodeGenerator(sharedSecret);
        }

        public Task<string> GetDeviceCodeAsync(bool previousCodeWasIncorrect) =>
            Task.FromResult(_codeGenerator.GenerateCode());

        public Task<string> GetEmailCodeAsync(string email, bool previousCodeWasIncorrect) =>
            Task.FromResult(string.Empty);

        public Task<bool> AcceptDeviceConfirmationAsync() => Task.FromResult(false);
    }
}
