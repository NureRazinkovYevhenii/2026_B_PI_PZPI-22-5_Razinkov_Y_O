interface CachedToken {
    token: string;
    expiresAt: number; // Timestamp у мс
    steamId: string;
}

export class TokenManager {
    private static instance: TokenManager;
    private refreshPromise: Promise<string> | null = null; // Повертаємо лише рядок токена

    private constructor() {}

    public static getInstance(): TokenManager {
        if (!TokenManager.instance) {
            TokenManager.instance = new TokenManager();
        }
        return TokenManager.instance;
    }

    /**
     * Основний метод, який потрібно викликати всюди перед запитами до Steam Web API
     */
    public async getToken(): Promise<string> {
        const now = Date.now();

        // 1. Перевіряємо сховище (воно переживає сон Service Worker'а)
        const storage = await chrome.storage.local.get("STEAM_JWT_TOKEN");
        const cached = storage["STEAM_JWT_TOKEN"] as CachedToken | undefined;

        // Якщо токен є і він валідний (із запасом у 30 секунд) — віддаємо
        if (cached && cached.expiresAt > now + 30000) {
            return cached.token;
        }

        // 2. Якщо токен уже оновлюється в цей момент — чекаємо цей самий Promise
        if (this.refreshPromise) {
            return await this.refreshPromise;
        }

        // 3. Токена немає або він протух — запускаємо оновлення
        this.refreshPromise = this.refreshAccessToken();
        
        try {
            return await this.refreshPromise;
        } finally {
            this.refreshPromise = null; // Очищаємо посилання після завершення
        }
    }

    /**
     * Повертає SteamID поточного авторизованого користувача
     */
    public async getActiveSteamId(): Promise<string> {
        // Спочатку намагаємося дістати зі сховища (додана типізація)
        const storage = await chrome.storage.local.get("STEAM_JWT_TOKEN");
        const cached = storage["STEAM_JWT_TOKEN"] as CachedToken | undefined;

        // Якщо кеш живий і там є steamId, повертаємо його
        if (cached && cached.steamId) {
            return cached.steamId;
        }

        // Якщо кешу немає (наприклад, перший запуск),
        // примусово оновлюємо токен (він заразом збереже steamId у сховищі)
        await this.getToken();
        
        // Дістаємо свіжі дані (додана типізація)
        const freshStorage = await chrome.storage.local.get("STEAM_JWT_TOKEN");
        const freshCached = freshStorage["STEAM_JWT_TOKEN"] as CachedToken | undefined;
        
        if (!freshCached || !freshCached.steamId) {
            throw new Error('Failed to obtain SteamID. User is not authenticated.');
        }

        return freshCached.steamId;
    }

    private async refreshAccessToken(): Promise<string> {
        const resp = await fetch('https://steamcommunity.com', {
            credentials: 'include',
            headers: {
                // Важливий заголовок, щоб Steam оновив куки
                Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'
            }
        });

        const body = await resp.text();

        // Перевіряємо, чи не викинув нас Steam
        if (body.includes('id="loginForm"')) {
            throw new Error('User is not authenticated in Steam (redirected to the login page).');
        }

        // Шукаємо той самий довгий JWT токен у HTML
        const webAPITokenMatch = /data-loyalty_webapi_token="&quot;([a-zA-Z0-9_.-]+)&quot;"/.exec(body);
        
        if (!webAPITokenMatch) {
            throw new Error('Failed to find loyalty_webapi_token on the Steam page. Steam may have changed its markup.');
        }

        const token = webAPITokenMatch[1];

        // Парсимо JWT, щоб дізнатися реальний час життя
        const payload = this.parseJwt(token);
        const expiresAt = payload.exp * 1000;
        const steamId = payload.sub; // У токені лежить твій SteamID64

        const cachedToken: CachedToken = {
            token: token,
            expiresAt: expiresAt,
            steamId: steamId
        };

        // Зберігаємо в локальне сховище розширення
        await chrome.storage.local.set({ "STEAM_JWT_TOKEN": cachedToken });

        return cachedToken.token;
    }

    /**
     * Легковаговий парсер JWT
     */
    private parseJwt(token: string) {
        try {
            const base64Url = token.split('.')[1];
            const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
            const jsonPayload = decodeURIComponent(
                atob(base64)
                    .split('')
                    .map((c) => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
                    .join('')
            );
            return JSON.parse(jsonPayload);
        } catch (e) {
            throw new Error('Failed to parse Steam JWT token structure');
        }
    }
}