namespace SkinHex.SteamGateway.Steam;

public sealed class SteamTradePartnerUnavailableException : Exception
{
    public const string ErrorCode = "TRADE_PARTNER_UNAVAILABLE";

    public SteamTradePartnerUnavailableException()
        : base("Steam trade partner is not available for trading.")
    {
    }
}
