﻿namespace SkinHex.Core.Models;

public class CreateListingRequest
{
    public string AssetId { get; set; } = null!; // Той самий довгий ID зі Steam-інвентаря
    public decimal Price { get; set; }           // Ціна, за яку користувач хоче продати
}