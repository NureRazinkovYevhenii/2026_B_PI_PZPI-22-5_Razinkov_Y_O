namespace SkinHex.Core.Models.Cart;

public class CartItemDto
{
    public Guid Id { get; set; }
    public Guid ListingId { get; set; }
    
    public decimal Price { get; set; }
    public string MarketHashName { get; set; } = string.Empty;
    public string? ItemImageHash { get; set; }
    
    public double? FloatValue { get; set; }
    public int? PaintSeed { get; set; }
    
    public bool IsAvailable { get; set; }
    
    public DateTimeOffset AddedAt { get; set; }
}
