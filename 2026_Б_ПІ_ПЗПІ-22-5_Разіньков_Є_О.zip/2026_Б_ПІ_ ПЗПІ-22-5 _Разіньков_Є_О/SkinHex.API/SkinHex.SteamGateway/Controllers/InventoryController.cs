using Microsoft.AspNetCore.Mvc;
using SkinHex.Core.Models;
using SkinHex.SteamGateway.Steam;

namespace SkinHex.SteamGateway.Controllers;

[ApiController]
[Route("api/inventory")]
public sealed class InventoryController(ISteamInventoryService inventoryService) : ControllerBase
{
    [HttpGet("{steamId}")]
    [ProducesResponseType<IReadOnlyList<InventoryItemDto>>(StatusCodes.Status200OK)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status400BadRequest)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status502BadGateway)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status503ServiceUnavailable)]
    public async Task<ActionResult<IReadOnlyList<InventoryItemDto>>> GetInventory(
        string steamId,
        [FromQuery] string? tradeUrl,
        [FromQuery] string? token,
        [FromQuery] bool forceReload,
        CancellationToken cancellationToken)
    {
        if (!SteamInventoryRequest.TryCreate(steamId, tradeUrl, token, forceReload, out var request, out var error))
        {
            return Problem(
                statusCode: StatusCodes.Status400BadRequest,
                title: "Invalid Steam inventory request.",
                detail: error);
        }

        var inventory = await inventoryService.GetInventoryAsync(request!, cancellationToken);
        return Ok(inventory);
    }

    [HttpGet("{steamId}/validate")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status400BadRequest)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status502BadGateway)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status503ServiceUnavailable)]
    public async Task<ActionResult> ValidateTradeLink(
        string steamId,
        [FromQuery] string? tradeUrl,
        [FromQuery] string? token,
        CancellationToken cancellationToken)
    {
        if (!SteamInventoryRequest.TryCreate(steamId, tradeUrl, token, false, out var request, out var error))
        {
            return Problem(
                statusCode: StatusCodes.Status400BadRequest,
                title: "Invalid Steam inventory request.",
                detail: error);
        }

        await inventoryService.ValidateTradeLinkAsync(request!, cancellationToken);
        return Ok();
    }
}
