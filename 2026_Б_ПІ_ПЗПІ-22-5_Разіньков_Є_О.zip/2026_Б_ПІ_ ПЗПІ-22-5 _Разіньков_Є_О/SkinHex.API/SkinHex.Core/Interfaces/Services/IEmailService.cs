using FluentResults;

namespace SkinHex.Core.Interfaces.Services;

public interface IEmailService
{
    Task<Result> SendOtpAsync(string toEmail, int code, CancellationToken cancellationToken);
}
