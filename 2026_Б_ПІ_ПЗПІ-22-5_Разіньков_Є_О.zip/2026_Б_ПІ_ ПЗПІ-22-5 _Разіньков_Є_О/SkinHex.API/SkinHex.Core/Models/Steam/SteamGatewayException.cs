using System.Net;

namespace SkinHex.Core.Models.Steam;

public sealed class SteamGatewayException : Exception
{
    public const string TradeUrlExpiredErrorCode = "TRADE_URL_EXPIRED";
    public const string TradePartnerUnavailableErrorCode = "TRADE_PARTNER_UNAVAILABLE";

    public SteamGatewayException(
        string message,
        HttpStatusCode? statusCode = null,
        string? errorCode = null)
        : base(message)
    {
        StatusCode = statusCode;
        ErrorCode = errorCode;
    }

    public HttpStatusCode? StatusCode { get; }
    public string? ErrorCode { get; }

    public bool IsTradeUrlExpired =>
        StatusCode == HttpStatusCode.BadRequest &&
        string.Equals(ErrorCode, TradeUrlExpiredErrorCode, StringComparison.Ordinal);

    public bool IsTradePartnerUnavailable =>
        StatusCode == HttpStatusCode.BadRequest &&
        string.Equals(ErrorCode, TradePartnerUnavailableErrorCode, StringComparison.Ordinal);
}
