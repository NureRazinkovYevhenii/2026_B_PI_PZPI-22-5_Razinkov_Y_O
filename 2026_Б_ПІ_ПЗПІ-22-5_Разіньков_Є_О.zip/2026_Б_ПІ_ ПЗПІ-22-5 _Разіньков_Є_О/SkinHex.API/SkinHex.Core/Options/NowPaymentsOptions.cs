namespace SkinHex.Core.Options;

public class NowPaymentsOptions
{
    public string ApiKey { get; set; } = string.Empty;
    public string IpnSecret { get; set; } = string.Empty;
    public string BaseUrl { get; set; } = string.Empty;

    /// <summary>
    /// The currency of our internal NOWPayments custody wallet (the "outcome" currency).
    /// NOWPayments derives the per-coin minimum payment amount relative to this currency,
    /// so it must match the wallet configured in the NOWPayments dashboard.
    /// </summary>
    public string OutcomeCurrency { get; set; } = "usdtbsc";

    /// <summary>Platform-wide minimum deposit in USD. Applied on top of the NOWPayments per-coin minimum.</summary>
    public decimal MinDepositUsd { get; set; } = 3m;

    /// <summary>
    /// Deposit fee, charged on top of the requested amount (gross-up) to cover the NOWPayments service fee.
    /// 0.01 = 1%. The user is credited the amount they request and pays request × (1 + fee) in the invoice.
    /// </summary>
    public decimal DepositFeePercent { get; set; } = 0.01m;

    /// <summary>Public URL NOWPayments calls with IPN (webhook) notifications.</summary>
    public string IpnCallbackUrl { get; set; } = string.Empty;

    /// <summary>URL the user is redirected to after paying the hosted invoice.</summary>
    public string SuccessUrl { get; set; } = string.Empty;

    // ---- Payouts / Withdrawals ----

    /// <summary>Account email used to obtain the payout JWT (POST /v1/auth). Required for payouts.</summary>
    public string PayoutEmail { get; set; } = string.Empty;

    /// <summary>Account password used to obtain the payout JWT. Required for payouts.</summary>
    public string PayoutPassword { get; set; } = string.Empty;

    /// <summary>
    /// Base32-encoded 2FA/TOTP secret for the payout account. Used to generate the verification
    /// code required to auto-confirm a payout via POST /v1/payout/{batchId}/verify.
    /// Required for automatic payout verification.
    /// </summary>
    public string PayoutTotpSecret { get; set; } = string.Empty;

    /// <summary>Public URL NOWPayments calls with payout IPN notifications.</summary>
    public string PayoutIpnCallbackUrl { get; set; } = string.Empty;

    /// <summary>Platform-wide minimum withdrawal in USD.</summary>
    public decimal MinWithdrawalUsd { get; set; } = 2.5m;

    /// <summary>Platform withdrawal fee, taken from the requested amount. 0.01 = 1%. Configurable.</summary>
    public decimal WithdrawalFeePercent { get; set; } = 0m;

    /// <summary>
    /// Estimated network (blockchain) fee per pay currency, in USD, shown to the user before withdrawing.
    /// The real network fee is deducted by NOWPayments from the payout at send time (receiver pays);
    /// this is a display-only estimate keyed by pay-currency code (e.g. "usdttrc20": 1.0, "usdtbsc": 0.3).
    /// </summary>
    public Dictionary<string, decimal> NetworkFeeEstimateUsd { get; set; } = new();
}
