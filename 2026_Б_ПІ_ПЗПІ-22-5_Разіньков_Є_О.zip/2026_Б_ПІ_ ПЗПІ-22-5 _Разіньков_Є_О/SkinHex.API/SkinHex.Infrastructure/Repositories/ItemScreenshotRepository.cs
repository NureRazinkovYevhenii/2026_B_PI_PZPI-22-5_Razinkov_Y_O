using Microsoft.EntityFrameworkCore;
using SkinHex.Core.Entities;
using SkinHex.Core.Interfaces.Repositories;

namespace SkinHex.Infrastructure.Repositories;

public sealed class ItemScreenshotRepository(SkinHexDbContext dbContext) : IItemScreenshotRepository
{
    public Task<ItemScreenshot?> GetByIdAsync(Guid id, CancellationToken ct = default)
    {
        return dbContext.ItemScreenshots.FirstOrDefaultAsync(screenshot => screenshot.Id == id, ct);
    }

    public Task<List<ItemScreenshot>> GetByInspectHexesAsync(
        IReadOnlyCollection<string> inspectHexes,
        CancellationToken ct = default)
    {
        return dbContext.ItemScreenshots
            .Where(screenshot => inspectHexes.Contains(screenshot.InspectHex))
            .ToListAsync(ct);
    }

    public void Add(ItemScreenshot screenshot)
    {
        dbContext.ItemScreenshots.Add(screenshot);
    }
}
