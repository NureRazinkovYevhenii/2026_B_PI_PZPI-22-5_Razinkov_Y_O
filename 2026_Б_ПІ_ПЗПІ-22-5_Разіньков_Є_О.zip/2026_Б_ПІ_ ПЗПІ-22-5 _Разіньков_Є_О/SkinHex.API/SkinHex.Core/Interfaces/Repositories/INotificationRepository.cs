using SkinHex.Core.Entities;

namespace SkinHex.Core.Interfaces.Repositories;

public interface INotificationRepository
{
    Task AddAsync(Notification notification, CancellationToken ct = default);

    /// <summary>Latest notifications for a user, newest first. Pass <paramref name="before"/> (CreatedAt cursor) to page further back.</summary>
    Task<List<Notification>> GetLatestAsync(Guid userId, int limit, DateTime? before, CancellationToken ct = default);

    Task<int> GetUnreadCountAsync(Guid userId, CancellationToken ct = default);

    /// <summary>Marks the given notifications as read. Only affects rows owned by <paramref name="userId"/>. Returns affected row count.</summary>
    Task<int> MarkReadAsync(Guid userId, IReadOnlyCollection<Guid> ids, DateTime readAt, CancellationToken ct = default);

    Task<int> MarkAllReadAsync(Guid userId, DateTime readAt, CancellationToken ct = default);

    /// <summary>Users (other than <paramref name="excludeUserId"/>) that currently have the listing in their cart — fan-out targets for cart invalidation.</summary>
    Task<List<Guid>> GetUserIdsWithListingInCartAsync(Guid listingId, Guid? excludeUserId, CancellationToken ct = default);
}
