import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import type { ReactNode } from 'react';
import type { CartItem, AuthorizedFetch } from '../types';
import { createOrder } from './orders';

interface CartContextType {
  cart: CartItem[];
  isLoading: boolean;
  addToCart: (listingId: string) => Promise<void>;
  removeFromCart: (cartItemId: string) => Promise<void>;
  clearCart: () => Promise<void>;
  checkoutAvailable: () => Promise<{ successCount: number; failedCount: number }>;
  refreshCart: () => Promise<void>;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({
  children,
  authorizedFetch,
  isAuthenticated,
}: {
  children: ReactNode;
  authorizedFetch: AuthorizedFetch;
  isAuthenticated: boolean;
}) {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const refreshCart = useCallback(async () => {
    if (!isAuthenticated) {
      setCart([]);
      return;
    }
    
    setIsLoading(true);
    try {
      const res = await authorizedFetch('/cart');
      if (res.ok) {
        const data = await res.json();
        setCart(data);
      }
    } catch (e) {
      console.error('Failed to load cart', e);
    } finally {
      setIsLoading(false);
    }
  }, [authorizedFetch, isAuthenticated]);

  useEffect(() => {
    refreshCart();
  }, [refreshCart]);

  const addToCart = async (listingId: string) => {
    if (!isAuthenticated) return;
    
    // Optimistic check
    if (cart.some(item => item.listingId === listingId)) return;

    try {
      const res = await authorizedFetch(`/cart/${listingId}`, {
        method: 'POST',
      });
      if (res.ok) {
        const newItem = await res.json();
        setCart(prev => [newItem, ...prev]);
      } else {
        const error = await res.json();
        throw new Error(error.message || 'Failed to add to cart');
      }
    } catch (e) {
      console.error(e);
      throw e;
    }
  };

  const removeFromCart = async (cartItemId: string) => {
    if (!isAuthenticated) return;
    
    setCart(prev => prev.filter(c => c.id !== cartItemId));
    try {
      await authorizedFetch(`/cart/${cartItemId}`, { method: 'DELETE' });
    } catch (e) {
      console.error(e);
      // rollback in a real app if needed
    }
  };

  const clearCart = async () => {
    if (!isAuthenticated) return;
    
    setCart([]);
    try {
      await authorizedFetch('/cart', { method: 'DELETE' });
    } catch (e) {
      console.error(e);
    }
  };

  const checkoutAvailable = async () => {
    if (!isAuthenticated) {
      return { successCount: 0, failedCount: 0 };
    }

    const availableItems = cart.filter((item) => item.isAvailable);
    let successCount = 0;
    let failedCount = 0;

    for (const item of availableItems) {
      try {
        await createOrder(authorizedFetch, item.listingId);
        successCount += 1;
        setCart((prev) => prev.filter((c) => c.id !== item.id));
        await authorizedFetch(`/cart/${item.id}`, { method: 'DELETE' });
      } catch (error) {
        failedCount += 1;
        console.error('Failed to checkout cart item', item.id, error);
      }
    }

    return { successCount, failedCount };
  };

  return (
    <CartContext.Provider value={{ cart, isLoading, addToCart, removeFromCart, clearCart, checkoutAvailable, refreshCart }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}
