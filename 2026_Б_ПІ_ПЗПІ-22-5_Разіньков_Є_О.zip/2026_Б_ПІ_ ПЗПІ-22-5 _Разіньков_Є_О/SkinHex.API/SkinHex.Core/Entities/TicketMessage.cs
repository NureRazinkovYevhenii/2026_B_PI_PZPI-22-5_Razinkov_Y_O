namespace SkinHex.Core.Entities;

public class TicketMessage
{
    public Guid Id { get; set; }
    public Guid TicketId { get; set; }

    /// <summary>The user who wrote the message (the ticket author or an admin).</summary>
    public Guid SenderId { get; set; }

    /// <summary>True when the message was posted by support/admin; false when posted by the ticket author.</summary>
    public bool IsFromSupport { get; set; }

    public string Body { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public SupportTicket Ticket { get; set; } = null!;
}
