using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using SkinHex.SteamGateway.Steam;

namespace SkinHex.SteamGateway.Errors;

public sealed class GlobalExceptionHandler(
    IProblemDetailsService problemDetailsService,
    ILogger<GlobalExceptionHandler> logger) : IExceptionHandler
{
    public async ValueTask<bool> TryHandleAsync(
        HttpContext httpContext,
        Exception exception,
        CancellationToken cancellationToken)
    {
        var problem = exception switch
        {
            SteamTradeUrlExpiredException => CreateTradeUrlExpiredProblem(httpContext),
            SteamTradePartnerUnavailableException => CreateTradePartnerUnavailableProblem(httpContext),
            SteamIntegrationException steamException => CreateSteamIntegrationProblem(httpContext, steamException),
            InvalidOperationException invalidOperationException => CreateServiceUnavailableProblem(httpContext, invalidOperationException),
            _ => CreateInternalServerErrorProblem(httpContext, exception)
        };

        logger.LogError(exception, "SteamGateway request failed with {StatusCode}.", problem.Status);
        httpContext.Response.StatusCode = problem.Status ?? StatusCodes.Status500InternalServerError;

        return await problemDetailsService.TryWriteAsync(new ProblemDetailsContext
        {
            HttpContext = httpContext,
            ProblemDetails = problem,
            Exception = exception
        });
    }

    private static ProblemDetails CreateTradeUrlExpiredProblem(HttpContext httpContext)
    {
        var problem = new ProblemDetails
        {
            Status = StatusCodes.Status400BadRequest,
            Type = "https://skinhex.dev/problems/trade-url-expired",
            Title = "Steam trade URL is expired.",
            Detail = "The Steam trade URL token is no longer valid.",
            Instance = httpContext.Request.Path
        };
        problem.Extensions["errorCode"] = SteamTradeUrlExpiredException.ErrorCode;
        return problem;
    }

    private static ProblemDetails CreateTradePartnerUnavailableProblem(HttpContext httpContext)
    {
        var problem = new ProblemDetails
        {
            Status = StatusCodes.Status400BadRequest,
            Type = "https://skinhex.dev/problems/trade-partner-unavailable",
            Title = "Steam trade partner is unavailable.",
            Detail = "The Steam account from the trade URL is currently unable to trade.",
            Instance = httpContext.Request.Path
        };
        problem.Extensions["errorCode"] = SteamTradePartnerUnavailableException.ErrorCode;
        return problem;
    }

    private static ProblemDetails CreateSteamIntegrationProblem(
        HttpContext httpContext,
        SteamIntegrationException exception)
    {
        var status = exception.StatusCode.HasValue
            ? StatusCodes.Status502BadGateway
            : StatusCodes.Status503ServiceUnavailable;

        var problem = new ProblemDetails
        {
            Status = status,
            Type = "https://skinhex.dev/problems/steam-integration",
            Title = "Steam integration failed.",
            Detail = exception.Message,
            Instance = httpContext.Request.Path
        };
        problem.Extensions["errorCode"] = "STEAM_INTEGRATION_FAILED";
        return problem;
    }

    private static ProblemDetails CreateServiceUnavailableProblem(
        HttpContext httpContext,
        InvalidOperationException exception)
    {
        var problem = new ProblemDetails
        {
            Status = StatusCodes.Status503ServiceUnavailable,
            Type = "https://skinhex.dev/problems/steam-gateway-unavailable",
            Title = "SteamGateway is temporarily unavailable.",
            Detail = exception.Message,
            Instance = httpContext.Request.Path
        };
        problem.Extensions["errorCode"] = "STEAM_GATEWAY_UNAVAILABLE";
        return problem;
    }

    private static ProblemDetails CreateInternalServerErrorProblem(
        HttpContext httpContext,
        Exception exception)
    {
        var problem = new ProblemDetails
        {
            Status = StatusCodes.Status500InternalServerError,
            Type = "https://skinhex.dev/problems/internal-error",
            Title = "Unexpected SteamGateway error.",
            Detail = exception.Message,
            Instance = httpContext.Request.Path
        };
        problem.Extensions["errorCode"] = "INTERNAL_ERROR";
        return problem;
    }
}
