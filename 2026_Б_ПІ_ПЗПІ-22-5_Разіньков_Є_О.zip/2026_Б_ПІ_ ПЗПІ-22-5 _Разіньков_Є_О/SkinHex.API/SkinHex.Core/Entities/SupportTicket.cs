using System.Text.Json.Serialization;

namespace SkinHex.Core.Entities;

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum TicketStatus
{
    Open = 0,
    PendingSupport = 1,
    PendingUser = 2,
    Resolved = 3,
    Closed = 4
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum TicketCategory
{
    Order = 0,
    Deposit = 1,
    Withdrawal = 2,
    Account = 3,
    Other = 4
}

public class SupportTicket
{
    public Guid Id { get; set; }

    /// <summary>The user who opened the ticket.</summary>
    public Guid UserId { get; set; }

    /// <summary>Optional link to an order the ticket is about ("тікети щодо замовлень").</summary>
    public Guid? OrderId { get; set; }

    public string Subject { get; set; } = string.Empty;
    public TicketCategory Category { get; set; }
    public TicketStatus Status { get; set; } = TicketStatus.Open;

    /// <summary>Admin currently handling the ticket. Plain id, no navigation.</summary>
    public Guid? AssignedAdminId { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? ClosedAt { get; set; }

    public User User { get; set; } = null!;
    public Order? Order { get; set; }
    public ICollection<TicketMessage> Messages { get; set; } = new List<TicketMessage>();
}
