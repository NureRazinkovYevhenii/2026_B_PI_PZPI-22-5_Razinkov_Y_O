namespace SkinHex.Core.Models;

/// <summary>
/// Один конкретний предмет у підказках хедер-пошуку — веде прямо на сторінку цієї якості/варіанта.
/// На відміну від <see cref="MarketSearchTipDto"/> (каталог) результати НЕ групуються за базовим іменем.
/// </summary>
public sealed class MarketItemSearchResultDto
{
    public string MarketHashName { get; set; } = null!;
    public string BaseName { get; set; } = null!;
    public string? Wear { get; set; }
    public bool IsStatTrak { get; set; }
    public bool IsSouvenir { get; set; }
    public string Category { get; set; } = null!;
    public string Rarity { get; set; } = null!;
    public string Color { get; set; } = null!;
    public string ImageUrl { get; set; } = null!;
}
