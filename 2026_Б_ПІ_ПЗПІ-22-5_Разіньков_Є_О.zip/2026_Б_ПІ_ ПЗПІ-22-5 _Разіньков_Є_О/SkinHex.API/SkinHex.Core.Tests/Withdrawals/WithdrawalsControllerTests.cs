using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using SkinHex.API.Controllers;
using SkinHex.Core.Entities;
using SkinHex.Core.Models.Withdrawals;
using SkinHex.Core.Options;
using SkinHex.Infrastructure;
using Xunit;

namespace SkinHex.Core.Tests.Withdrawals;

public class WithdrawalsControllerTests
{
    private readonly SkinHexDbContext _dbContext;
    private readonly Guid _userId = Guid.NewGuid();
    private readonly NowPaymentsOptions _options = new()
    {
        MinWithdrawalUsd = 2.5m,
        WithdrawalFeePercent = 0m
    };

    public WithdrawalsControllerTests()
    {
        var dbOptions = new DbContextOptionsBuilder<SkinHexDbContext>()
            .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
            .ConfigureWarnings(w => w.Ignore(InMemoryEventId.TransactionIgnoredWarning))
            .Options;
        _dbContext = new SkinHexDbContext(dbOptions);
    }

    private WithdrawalsController CreateController(Guid? actingUserId = null)
    {
        var controller = new WithdrawalsController(
            _dbContext,
            Microsoft.Extensions.Options.Options.Create(_options),
            Mock.Of<ILogger<WithdrawalsController>>());
        var principal = new ClaimsPrincipal(new ClaimsIdentity(new[]
        {
            new Claim(ClaimTypes.NameIdentifier, (actingUserId ?? _userId).ToString())
        }));
        controller.ControllerContext = new ControllerContext { HttpContext = new DefaultHttpContext { User = principal } };
        return controller;
    }

    private User SeedUser(decimal balance, UserRole role = UserRole.User)
    {
        var user = new User { Id = _userId, SteamId = "s", Username = "u", Balance = balance, Role = role };
        _dbContext.Users.Add(user);
        _dbContext.SaveChanges();
        return user;
    }

    [Fact]
    public async Task Create_DebitsBalanceAndCreatesPendingTransaction()
    {
        SeedUser(balance: 10m);
        var controller = CreateController();

        var result = await controller.CreateWithdrawal(
            new CreateWithdrawalRequest(5m, "usdttrc20", "TAddr123", null), default);

        var ok = Assert.IsType<OkObjectResult>(result);
        var dto = Assert.IsType<WithdrawalDto>(ok.Value);
        Assert.Equal(nameof(WithdrawalStatus.Pending), dto.Status);

        Assert.Equal(5m, (await _dbContext.Users.FindAsync(_userId))!.Balance);

        var withdrawal = Assert.Single(_dbContext.Withdrawals.ToList());
        Assert.Equal(WithdrawalStatus.Pending, withdrawal.Status);
        Assert.Equal(5m, withdrawal.AmountUsd);

        var tx = Assert.Single(_dbContext.FinancialTransactions.ToList());
        Assert.Equal(FinancialTransactionType.Withdrawal, tx.Type);
        Assert.Equal(FinancialTransactionStatus.Pending, tx.Status);
    }

    [Fact]
    public async Task Create_RejectsBelowMinimum()
    {
        SeedUser(balance: 10m);
        var controller = CreateController();

        var result = await controller.CreateWithdrawal(
            new CreateWithdrawalRequest(1m, "usdttrc20", "TAddr", null), default);

        Assert.IsType<BadRequestObjectResult>(result);
        Assert.Empty(_dbContext.Withdrawals.ToList());
    }

    [Fact]
    public async Task Create_RejectsInsufficientBalance()
    {
        SeedUser(balance: 3m);
        var controller = CreateController();

        var result = await controller.CreateWithdrawal(
            new CreateWithdrawalRequest(5m, "usdttrc20", "TAddr", null), default);

        Assert.IsType<BadRequestObjectResult>(result);
        Assert.Equal(3m, (await _dbContext.Users.FindAsync(_userId))!.Balance);
    }

    [Fact]
    public async Task Create_RejectsNonStablecoin()
    {
        SeedUser(balance: 10m);
        var controller = CreateController();

        var result = await controller.CreateWithdrawal(
            new CreateWithdrawalRequest(5m, "btc", "addr", null), default);

        Assert.IsType<BadRequestObjectResult>(result);
    }

    [Fact]
    public async Task Create_ForbidsBannedUser()
    {
        SeedUser(balance: 10m, role: UserRole.Banned);
        var controller = CreateController();

        var result = await controller.CreateWithdrawal(
            new CreateWithdrawalRequest(5m, "usdttrc20", "TAddr", null), default);

        var status = Assert.IsType<ObjectResult>(result);
        Assert.Equal(StatusCodes.Status403Forbidden, status.StatusCode);
    }

    [Fact]
    public void Estimate_BreaksDownFeeAndReceiveAmount()
    {
        _options.WithdrawalFeePercent = 0.02m;
        _options.NetworkFeeEstimateUsd["usdttrc20"] = 1m;
        var controller = CreateController();

        var result = Assert.IsType<OkObjectResult>(controller.GetEstimate(100m, "usdttrc20"));
        var dto = Assert.IsType<WithdrawalEstimateDto>(result.Value);

        Assert.Equal(2m, dto.PlatformFeeUsd);
        Assert.Equal(1m, dto.EstNetworkFeeUsd);
        Assert.Equal(97m, dto.EstimatedReceiveUsd);
    }

    [Fact]
    public async Task GetWithdrawal_ForbidsNonOwner()
    {
        SeedUser(balance: 10m);
        var owner = CreateController();
        var created = (await owner.CreateWithdrawal(new CreateWithdrawalRequest(5m, "usdttrc20", "TAddr", null), default)) as OkObjectResult;
        var id = ((WithdrawalDto)created!.Value!).Id;

        var intruder = CreateController(actingUserId: Guid.NewGuid());
        Assert.IsType<ForbidResult>(await intruder.GetWithdrawal(id, default));
    }
}
