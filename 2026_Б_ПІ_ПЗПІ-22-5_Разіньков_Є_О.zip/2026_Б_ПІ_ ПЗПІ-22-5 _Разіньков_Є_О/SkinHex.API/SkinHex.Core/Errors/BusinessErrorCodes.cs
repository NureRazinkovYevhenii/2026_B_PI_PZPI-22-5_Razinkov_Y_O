namespace SkinHex.Core.Errors;

public static class BusinessErrorCodes
{
    public const string RequireTradeUrl = "REQUIRE_TRADE_URL";
    public const string RequireNewTradeUrl = "REQUIRE_NEW_TRADE_URL";
    public const string InventoryReloadRateLimited = "INVENTORY_RELOAD_RATE_LIMITED";

    // Order creation
    public const string ListingNotFound = "LISTING_NOT_FOUND";
    public const string ListingUnavailable = "LISTING_UNAVAILABLE";
    public const string CannotBuyOwnListing = "CANNOT_BUY_OWN_LISTING";
    public const string InsufficientBalance = "INSUFFICIENT_BALANCE";

    // Order management
    public const string OrderNotFound = "ORDER_NOT_FOUND";
    public const string OrderNotPending = "ORDER_NOT_PENDING";
    public const string ConfirmDeadlineExceeded = "ConfirmDeadlineExceeded"; // Requested by user as is
    public const string TooEarlyToCancel = "TooEarlyToCancel"; // Requested by user as is
    public const string Forbidden = "FORBIDDEN";
    public const string InvalidOrderStatus = "INVALID_ORDER_STATUS";
    public const string TradeNotFound = "TRADE_NOT_FOUND";

    // Disputes
    public const string DisputeNotFound = "DISPUTE_NOT_FOUND";
    public const string DisputeAlreadyOpen = "DISPUTE_ALREADY_OPEN";
    public const string DisputeNotAllowed = "DISPUTE_NOT_ALLOWED";
    public const string OrderDisputed = "ORDER_DISPUTED";
    public const string InvalidDisputeResolution = "INVALID_DISPUTE_RESOLUTION";

    // TLSN proof validation (distinct codes so the webhook processor can auto-open disputes on mismatch)
    public const string TlsnSteamIdMismatch = "TLSN_STEAMID_MISMATCH";
    public const string TlsnAssetMismatch = "TLSN_ASSET_MISMATCH";
}
