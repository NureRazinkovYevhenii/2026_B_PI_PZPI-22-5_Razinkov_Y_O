using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SkinHex.Core.Errors;
using SkinHex.Core.Models.Steam;
using System.Collections;
using System.Net;

namespace SkinHex.API.Errors;

public sealed class GlobalExceptionHandler(
    IProblemDetailsService problemDetailsService,
    ILogger<GlobalExceptionHandler> logger) : IExceptionHandler
{
    public async ValueTask<bool> TryHandleAsync(
        HttpContext httpContext,
        Exception exception,
        CancellationToken cancellationToken)
    {
        var (statusCode, title, detail) = MapException(exception);

        if (statusCode >= StatusCodes.Status500InternalServerError)
            logger.LogError(exception, "Unhandled request exception.");
        else
            logger.LogWarning(exception, "Request failed with status code {StatusCode}.", statusCode);

        httpContext.Response.StatusCode = statusCode;

        var problemDetails = new ProblemDetails
        {
            Status = statusCode,
            Title = title,
            Detail = detail,
            Instance = httpContext.Request.Path
        };

        if (exception is BusinessException businessException)
        {
            foreach (DictionaryEntry entry in businessException.Data)
            {
                if (entry.Key is string key)
                    problemDetails.Extensions[key] = entry.Value;
            }
        }

        return await problemDetailsService.TryWriteAsync(new ProblemDetailsContext
        {
            HttpContext = httpContext,
            Exception = exception,
            ProblemDetails = problemDetails
        });
    }

    private static (int StatusCode, string Title, string Detail) MapException(Exception exception) =>
        exception switch
        {
            BusinessException bex => (bex.StatusCode, bex.ErrorCode, bex.Message),
            SteamGatewayException sgEx => (
                (int)(sgEx.StatusCode ?? HttpStatusCode.BadGateway),
                "SteamGateway Error",
                sgEx.Message),
            KeyNotFoundException => (
                StatusCodes.Status404NotFound,
                "Resource not found",
                exception.Message),
            ArgumentException => (
                StatusCodes.Status400BadRequest,
                "Invalid request",
                exception.Message),
            DbUpdateConcurrencyException => (
                StatusCodes.Status409Conflict,
                "Concurrent update conflict",
                "The resource was changed by another request. Please retry."),
            DbUpdateException => (
                StatusCodes.Status409Conflict,
                "Database constraint conflict",
                "The operation conflicts with the current resource state."),
            InvalidOperationException => (
                StatusCodes.Status409Conflict,
                "Request conflict",
                exception.Message),
            _ => (
                StatusCodes.Status500InternalServerError,
                "Unexpected server error",
                "An unexpected error occurred.")
        };
}
