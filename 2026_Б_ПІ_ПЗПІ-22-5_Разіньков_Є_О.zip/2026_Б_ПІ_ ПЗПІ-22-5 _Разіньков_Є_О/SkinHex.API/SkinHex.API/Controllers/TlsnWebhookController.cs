using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using SkinHex.Core.Models.Tlsn;
using SkinHex.Core.Interfaces;

namespace SkinHex.API.Controllers
{
    [ApiController]
    [Route("api/tlsn")]
    public class TlsnWebhookController : ControllerBase
    {
        private readonly ITlsnWebhookProcessor _processor;
        private readonly ILogger<TlsnWebhookController> _logger;
        private readonly IConfiguration _configuration;

        public TlsnWebhookController(
            ITlsnWebhookProcessor processor,
            ILogger<TlsnWebhookController> logger,
            IConfiguration configuration)
        {
            _processor = processor;
            _logger = logger;
            _configuration = configuration;
        }

        [HttpPost("webhook")]
        public async Task<IActionResult> ReceiveWebhook([FromBody] WebhookPayload payload)
        {
            // 1. Verify Authorization Header
            if (!Request.Headers.TryGetValue("Authorization", out var authHeader))
            {
                _logger.LogWarning("Missing Authorization header.");
                return Unauthorized();
            }

            var expectedToken = _configuration["TlsnOptions:WebhookSecret"];
            if (string.IsNullOrEmpty(expectedToken))
            {
                _logger.LogError("WebhookSecret is not configured in appsettings.");
                return StatusCode(500, "Internal server error");
            }

            if (authHeader.ToString() != $"Bearer {expectedToken}")
            {
                _logger.LogWarning("Invalid Authorization header.");
                return Unauthorized();
            }

            // 2. Process the payload
            try
            {
                await _processor.ProcessWebhookAsync(payload);
                return Ok();
            }
            catch (System.Exception ex)
            {
                _logger.LogError(ex, "Error processing TLSN webhook.");
                return StatusCode(500, "Error processing webhook");
            }
        }
    }
}
