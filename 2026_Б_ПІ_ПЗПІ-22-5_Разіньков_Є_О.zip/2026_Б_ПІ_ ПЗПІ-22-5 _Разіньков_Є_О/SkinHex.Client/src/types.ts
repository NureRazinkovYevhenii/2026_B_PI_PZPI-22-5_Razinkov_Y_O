export type TokenPair = {
  accessToken: string;
  refreshToken: string | null;
};

export type AuthState = TokenPair & {
  expiresAt: number | null;
  name: string | null;
  role: string | null;
  roles: string[];
  tradeUrl: string | null;
  userId: string | null;
  steamId: string | null;
  balance: number;
  frozenBalance: number;
  avatarUrl: string | null;
};

export type JwtPayload = Record<string, unknown> & {
  exp?: number;
};

export type PromptReason = 'welcome' | 'gate';

export type PageKey = 'home' | 'profile' | 'inventory' | 'catalog' | 'orders' | 'my-listings' | 'deposit-pending' | 'skin' | 'admin' | 'support';

export type AuthorizedFetch = (path: string, init?: RequestInit) => Promise<Response>;

export type OrderStatus = 0 | 1 | 2 | 3 | 4 | 5 | 'Pending' | 'Confirmed' | 'TradeSent' | 'InEscrow' | 'Completed' | 'Cancelled';

export type OrderRole = 'Buyer' | 'Seller';

export type OrderRoleFilter = 'buyer' | 'seller';

export type Order = {
  orderId: string;
  listingId: string;
  role: OrderRole;
  status: OrderStatus;
  cancelledAtStatus?: OrderStatus | null;
  confirmDeadline: string | null;
  sendTradeDeadline: string | null;
  tradeAcceptDeadline: string | null;
  escrowEndsAt: string | null;
  buyerCancelableAt: string | null;
  cancelledBy?: string | null;
  cancelReason?: string | null;
  price: number;
  createdAt: string;
  partner: {
    id: string;
    username: string;
    avatarUrl: string | null;
  };
  item: {
    marketHashName: string;
    wear: string | null;
    float: number | null;
  };
  activeTrade?: {
    tradeId: string;
    tradeOfferId: string;
    steamTradeId?: string | null;
    offerState: number;
    tradeStatus?: number | null;
    createdAt: string;
    updatedAt: string;
  } | null;
};

export type InventoryItem = {
  assetId: string;
  marketHashName: string;
  floatValue?: number | null;
  paintSeed?: number | null;
  paintIndex?: number | null;
  metadataHex?: string | null;
};

export type InventoryItemGroup = {
  items: InventoryItem[];
  count: number;
};

export type ListingCatalogItem = {
  id: string;
  price: number;
  sellerId: string;
  sellerSteamId: string;
  marketHashName: string;
  floatValue?: number | null;
  paintSeed?: number | null;
  createdAt: string;
  /** Hex payload of the in-game inspect link. */
  inspectHex?: string | null;
  /** Site-relative URLs of rendered screenshots; null until the render job finishes. */
  screenshotFrontUrl?: string | null;
  screenshotBackUrl?: string | null;
};

/** A sold listing entry, mirrors C# SaleHistoryItemDto. */
export type SaleHistoryItem = ListingCatalogItem & {
  soldAt: string;
};

/** Matches C# SortOption enum values */
export type CatalogSortOption = 0 | 1 | 2 | 3 | 4;

/** One page of listings, mirrors C# PagedResult<T> */
export type PagedResult<T> = {
  items: T[];
  totalCount: number;
  page: number;
  pageSize: number;
  totalPages: number;
};

/** Item variant kind — StatTrak™ / Souvenir / plain. */
export type SkinVariant = 'normal' | 'stattrak' | 'souvenir';

/** A sibling exterior of the same skin+variant, its own page keyed by market hash name. */
export type WearLink = {
  wear: string;
  marketHashName: string;
  minPrice: number | null;
  isActive: boolean;
};

/** A sibling variant (normal / StatTrak / Souvenir), its own page keyed by market hash name. */
export type VariantLink = {
  kind: SkinVariant;
  marketHashName: string;
  isActive: boolean;
};

/** Skin detail page payload, mirrors C# MarketItemPageDto (GET /market/items/by-name). */
export type MarketItemPage = {
  marketHashName: string;
  baseName: string;
  skinName: string;
  weapon: string | null;
  category: string;
  rarity: string;
  wear: string | null;
  isStatTrak: boolean;
  isSouvenir: boolean;
  itemId: number;
  wears: WearLink[];
  variants: VariantLink[];
  imageUrl: string;
  rarityColor: string;
  minPrice: number | null;
  avgPrice: number | null;
  listings: PagedResult<ListingCatalogItem>;
};

export type CatalogFilters = {
  searchTerm: string;
  category: string | null;
  weapon: string | null;
  minPrice: string;
  maxPrice: string;
  minFloat: string;
  maxFloat: string;
  paintSeed: string;
  wear: string | null;
  sortBy: CatalogSortOption;
};

export type ParsedInventoryName = {
  title: string;
  exterior: string | null;
};

export type ItemDictionaryEntry = {
  icon: string;
  color: string;
  rarity: string;
  category: string;
  weapon?: string | null;
  minF?: number | null;
  maxF?: number | null;
};

export type SaleItem = {
  group: InventoryItemGroup;
  itemStatic: ItemDictionaryEntry | null;
  price: string;
  quantity: number;
};

export type SortOption = 'name-asc' | 'name-desc' | 'float-asc' | 'float-desc' | 'rarity';

export type CartItem = {
  id: string;
  listingId: string;
  price: number;
  marketHashName: string;
  itemImageHash?: string | null;
  floatValue?: number | null;
  paintSeed?: number | null;
  isAvailable: boolean;
  addedAt: string;
};

export type MarketSearchTipDto = {
  baseName: string;
};

/** One concrete item in the header search — navigates straight to its skin page (ungrouped). */
export type MarketItemSearchResult = {
  marketHashName: string;
  baseName: string;
  wear: string | null;
  isStatTrak: boolean;
  isSouvenir: boolean;
  category: string;
  rarity: string;
  color: string;
  imageUrl: string;
};
