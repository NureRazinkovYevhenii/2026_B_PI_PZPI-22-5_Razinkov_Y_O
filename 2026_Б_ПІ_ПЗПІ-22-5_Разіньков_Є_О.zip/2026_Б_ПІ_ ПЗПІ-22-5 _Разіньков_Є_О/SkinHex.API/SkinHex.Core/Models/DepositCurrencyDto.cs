namespace SkinHex.Core.Models;

/// <summary>Metadata for a coin the user can deposit with, shown in the deposit currency picker.</summary>
public sealed record DepositCurrencyDto(
    string Code,      // NOWPayments ticker, e.g. "usdttrc20"
    string Ticker,    // Display symbol, e.g. "USDT"
    string Name,      // Full name, e.g. "Tether USD"
    string? Network,  // Network label, e.g. "TRC20" / "BSC"; null for native coins
    string Color,     // Brand color used for the icon chip
    string Group      // "popular" | "stablecoin"
);

public static class SupportedDepositCurrencies
{
    public const string GroupPopular = "popular";
    public const string GroupStablecoin = "stablecoin";

    public static readonly IReadOnlyList<DepositCurrencyDto> All = new[]
    {
        // Popular coins
        new DepositCurrencyDto("btc", "BTC", "Bitcoin", null, "#f7931a", GroupPopular),
        new DepositCurrencyDto("eth", "ETH", "Ethereum", null, "#627eea", GroupPopular),
        new DepositCurrencyDto("ltc", "LTC", "Litecoin", null, "#345d9d", GroupPopular),
        new DepositCurrencyDto("trx", "TRX", "Tron", null, "#ef0027", GroupPopular),
        new DepositCurrencyDto("ton", "TON", "Toncoin", null, "#0098ea", GroupPopular),
        new DepositCurrencyDto("bnbbsc", "BNB", "Binance Coin", "BSC", "#f0b90b", GroupPopular),

        // Stablecoins
        new DepositCurrencyDto("usdttrc20", "USDT", "Tether USD", "TRC20", "#26a17b", GroupStablecoin),
        new DepositCurrencyDto("usdtbsc", "USDT", "Tether USD", "BSC", "#26a17b", GroupStablecoin),
        new DepositCurrencyDto("usdterc20", "USDT", "Tether USD", "ERC20", "#26a17b", GroupStablecoin),
        new DepositCurrencyDto("usdc", "USDC", "USD Coin", "ERC20", "#2775ca", GroupStablecoin),
        new DepositCurrencyDto("usdcbsc", "USDC", "USD Coin", "BSC", "#2775ca", GroupStablecoin),
        new DepositCurrencyDto("usdtsol", "USDT", "Tether USD", "SOL", "#26a17b", GroupStablecoin),
        new DepositCurrencyDto("usdcsol", "USDC", "USD Coin", "SOL", "#2775ca", GroupStablecoin),
        new DepositCurrencyDto("usdtmatic", "USDT", "Tether USD", "POLYGON", "#26a17b", GroupStablecoin),
        new DepositCurrencyDto("usdtton", "USDT", "Tether USD", "TON", "#26a17b", GroupStablecoin),
    };

    private static readonly HashSet<string> Codes =
        All.Select(c => c.Code).ToHashSet(StringComparer.OrdinalIgnoreCase);

    public static bool IsSupported(string? code) =>
        !string.IsNullOrWhiteSpace(code) && Codes.Contains(code);
}
