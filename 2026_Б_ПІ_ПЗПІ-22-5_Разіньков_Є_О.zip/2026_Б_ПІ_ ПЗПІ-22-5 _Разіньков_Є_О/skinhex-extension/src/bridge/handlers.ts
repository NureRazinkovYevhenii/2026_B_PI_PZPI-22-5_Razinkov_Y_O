import { proveTradeWithTlsn } from "../offscreen/tlsn";
import { getSteamStatus } from "../steam/auth";
import { syncPendingTrades } from "../steam/tradeSync";
import { cancelTradeOffer, checkTradeStatus, checkTradeOfferStatus, createTradeOffer } from "../steam/trades";
import { RequestType } from "./types";
import { getVersion } from "./version";

export async function handleRequest(request: any): Promise<any> {
    switch (request.type) {
        case RequestType.PING:
            return getVersion();
        
        case RequestType.FETCH_STEAM_USER:
            return await getSteamStatus(request.expectedSteamID);
        
        case RequestType.CREATE_TRADE_OFFER: 
            return await createTradeOffer(request);

        case RequestType.SYNC_PENDING_TRADES:
            return await syncPendingTrades(request);

        case RequestType.CANCEL_TRADE_OFFER:
            return await cancelTradeOffer(request);
        
        case RequestType.CHECK_TRADE_OFFER_STATUS:
            return await checkTradeOfferStatus(request);
        
        case RequestType.CHECK_TRADE_STATUS:
            return await checkTradeStatus(request);
        
        case RequestType.TLSN_PROVE:
            return await proveTradeWithTlsn(request);

        default:
            throw new Error(`Unknown request type: ${request.type}`);
    }
}