using SkinHex.Core.Models;

namespace SkinHex.SteamGateway.Steam;

public interface ISteamInventoryService
{
    Task<IReadOnlyList<InventoryItemDto>> GetInventoryAsync(
        SteamInventoryRequest request,
        CancellationToken cancellationToken = default);

    Task ValidateTradeLinkAsync(
        SteamInventoryRequest request,
        CancellationToken cancellationToken = default);
}
