namespace SkinHex.Core.Models;
public class PagedResult<T>
{
    public List<T> Items { get; set; } = new();
    public int TotalCount { get; set; }
    public int Page { get; set; }
    public int PageSize { get; set; }
    public int TotalPages => (int)Math.Ceiling((double)TotalCount / PageSize);
}



// DTO самого лота для вітрини (щоб не віддавати зайві дані користувача)
public class ListingCatalogItemDto
{
    public Guid Id { get; set; }
    public decimal Price { get; set; }

    // Додаємо ID продавця
    public Guid SellerId { get; set; }
    public string SellerSteamId { get; set; } = string.Empty;

    public int ItemId { get; set; }
    public string MarketHashName { get; set; } = null!;

    [System.Text.Json.Serialization.JsonIgnore(Condition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull)]
    public double? FloatValue { get; set; }

    [System.Text.Json.Serialization.JsonIgnore(Condition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull)]
    public int? PaintSeed { get; set; }
    public DateTimeOffset CreatedAt { get; set; }

    // Hex-пейлоад inspect-посилання: фронт будує steam://run/730//+csgo_econ_action_preview%20{hex}
    [System.Text.Json.Serialization.JsonIgnore(Condition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull)]
    public string? InspectHex { get; set; }

    // Site-relative URL готових скріншотів (null, поки рендер не завершено)
    [System.Text.Json.Serialization.JsonIgnore(Condition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull)]
    public string? ScreenshotFrontUrl { get; set; }

    [System.Text.Json.Serialization.JsonIgnore(Condition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull)]
    public string? ScreenshotBackUrl { get; set; }
}
