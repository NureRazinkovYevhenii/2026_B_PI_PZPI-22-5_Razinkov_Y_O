using SkinHex.Core.Entities;

namespace SkinHex.Core.Models.Admin;

public record TicketMessageDto(
    Guid Id,
    Guid SenderId,
    bool IsFromSupport,
    string Body,
    DateTime CreatedAt);

public record TicketListItemDto(
    Guid Id,
    string Subject,
    string Category,
    string Status,
    Guid UserId,
    string Username,
    Guid? OrderId,
    Guid? AssignedAdminId,
    int MessagesCount,
    DateTime CreatedAt,
    DateTime UpdatedAt);

public record TicketDetailDto(
    Guid Id,
    string Subject,
    string Category,
    string Status,
    Guid UserId,
    string Username,
    Guid? OrderId,
    Guid? AssignedAdminId,
    DateTime CreatedAt,
    DateTime UpdatedAt,
    DateTime? ClosedAt,
    IReadOnlyList<TicketMessageDto> Messages);

/// <summary>User-facing create-ticket payload. <paramref name="OrderId"/> is optional (ticket about an order).</summary>
public record CreateTicketRequest(
    string Subject,
    TicketCategory Category,
    Guid? OrderId,
    string Message);

public record TicketReplyRequest(string Body);

public record TicketStatusRequest(TicketStatus Status);
