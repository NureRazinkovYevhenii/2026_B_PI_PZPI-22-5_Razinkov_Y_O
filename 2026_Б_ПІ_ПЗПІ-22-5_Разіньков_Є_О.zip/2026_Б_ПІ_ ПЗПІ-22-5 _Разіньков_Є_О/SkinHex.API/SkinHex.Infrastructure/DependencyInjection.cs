using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SkinHex.Core.Interfaces;
using SkinHex.Core.Interfaces.Repositories;
using SkinHex.Core.Interfaces.Screenshots;
using SkinHex.Core.Interfaces.Services;
using SkinHex.Core.Interfaces.Steam;
using SkinHex.Core.Options;
using SkinHex.Infrastructure.Options;
using SkinHex.Infrastructure.Repositories;
using SkinHex.Infrastructure.Seed;
using SkinHex.Infrastructure.Services;
using SkinHex.Infrastructure.Steam;
using SkinHex.Infrastructure.SteamGateway;
using StackExchange.Redis;

namespace SkinHex.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructure(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("DefaultConnection");

        services.AddDbContext<SkinHexDbContext>(options =>
            options.UseNpgsql(connectionString));

        services.AddOptions<JwtOptions>()
            .Bind(configuration.GetSection("Jwt"))
            .Validate(options => !string.IsNullOrWhiteSpace(options.SecretKey), "Jwt:SecretKey is required.")
            .Validate(options => !string.IsNullOrWhiteSpace(options.Issuer), "Jwt:Issuer is required.")
            .Validate(options => !string.IsNullOrWhiteSpace(options.Audience), "Jwt:Audience is required.")
            .ValidateOnStart();

        services.AddOptions<SmtpOptions>()
            .Bind(configuration.GetSection("SmtpSettings"));

        services.AddScoped<IUserRepository, UserRepository>();
        services.AddScoped<IRefreshTokenRepository, RefreshTokenRepository>();
        services.AddScoped<IListingRepository, ListingRepository>();
        services.AddScoped<IItemRepository, ItemRepository>();
        services.AddScoped<IOrderRepository, OrderRepository>();
        services.AddScoped<ISteamTradeRepository, SteamTradeRepository>();
        services.AddScoped<IFinancialTransactionRepository, FinancialTransactionRepository>();
        services.AddScoped<INotificationRepository, NotificationRepository>();
        services.AddScoped<IItemScreenshotRepository, ItemScreenshotRepository>();
        services.AddScoped<IDisputeRepository, DisputeRepository>();
        services.AddScoped<ITlsnProofRecordRepository, TlsnProofRecordRepository>();
        services.AddScoped<IUnitOfWork, EfUnitOfWork>();

        services.AddScoped<ITokenService, TokenService>();
        services.AddScoped<IEmailService, EmailService>();
        services.AddScoped<ICartService, CartService>();
        services.AddHttpClient<INowPaymentsService, NowPaymentsService>();
        services.AddHttpClient<INowPaymentsPayoutService, NowPaymentsPayoutService>();
        services.Configure<NowPaymentsOptions>(configuration.GetSection("NowPayments"));
        services.AddSingleton<IEmailVerificationCodeStore, MemoryEmailVerificationCodeStore>();

        services.AddOptions<SteamGatewayOptions>()
            .Bind(configuration.GetSection(SteamGatewayOptions.SectionName))
            .Validate(
                options => Uri.TryCreate(options.BaseAddress, UriKind.Absolute, out _),
                "SteamGateway:BaseAddress must be a valid absolute URI.")
            .Validate(
                options => options.TimeoutSeconds > 0,
                "SteamGateway:TimeoutSeconds must be greater than zero.")
            .ValidateOnStart();

        services.AddHttpClient<ISteamGatewayClient, SteamGatewayClient>((serviceProvider, client) =>
        {
            var options = serviceProvider.GetRequiredService<Microsoft.Extensions.Options.IOptions<SteamGatewayOptions>>().Value;
            client.BaseAddress = new Uri(options.BaseAddress.TrimEnd('/') + "/");
            client.Timeout = TimeSpan.FromSeconds(options.TimeoutSeconds);
        });

        services.AddOptions<ScreenshotOptions>()
            .Bind(configuration.GetSection(ScreenshotOptions.SectionName))
            .Validate(
                options => Uri.TryCreate(options.BaseAddress, UriKind.Absolute, out _),
                "Screenshots:BaseAddress must be a valid absolute URI.")
            .Validate(
                options => options.TimeoutSeconds > 0,
                "Screenshots:TimeoutSeconds must be greater than zero.")
            .Validate(
                options => !string.IsNullOrWhiteSpace(options.StorageRootPath),
                "Screenshots:StorageRootPath is required.")
            .ValidateOnStart();

        services.AddSingleton<IScreenshotStorage, LocalScreenshotStorage>();
        services.AddHttpClient<IInspectScreenshotClient, CsMarketCapScreenshotClient>((serviceProvider, client) =>
        {
            var options = serviceProvider.GetRequiredService<Microsoft.Extensions.Options.IOptions<ScreenshotOptions>>().Value;
            client.BaseAddress = new Uri(options.BaseAddress.TrimEnd('/') + "/");
            client.Timeout = TimeSpan.FromSeconds(options.TimeoutSeconds);
        });

        return services;
    }

    public static IServiceCollection AddSteamSessionRedis(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.AddOptions<RedisOptions>()
            .Bind(configuration.GetSection(RedisOptions.SectionName))
            .Validate(
                options => !string.IsNullOrWhiteSpace(options.ConnectionString),
                "Redis:ConnectionString is required.")
            .Validate(
                options => !string.IsNullOrWhiteSpace(options.SteamSessionsKey),
                "Redis:SteamSessionsKey is required.")
            .Validate(
                options => options.SessionTtlMinutes > 0,
                "Redis:SessionTtlMinutes must be greater than zero.")
            .ValidateOnStart();

        services.AddSingleton<IConnectionMultiplexer>(serviceProvider =>
        {
            var options = serviceProvider.GetRequiredService<Microsoft.Extensions.Options.IOptions<RedisOptions>>().Value;
            var redisConfiguration = ConfigurationOptions.Parse(options.ConnectionString);
            redisConfiguration.AbortOnConnectFail = false;
            redisConfiguration.ClientName = "SkinHex";
            return ConnectionMultiplexer.Connect(redisConfiguration);
        });

        services.AddSingleton<RedisSteamBotSessionStore>();
        services.AddSingleton<ISteamBotSessionProvider>(serviceProvider =>
            serviceProvider.GetRequiredService<RedisSteamBotSessionStore>());
        services.AddSingleton<ISteamBotSessionStore>(serviceProvider =>
            serviceProvider.GetRequiredService<RedisSteamBotSessionStore>());

        return services;
    }
}
