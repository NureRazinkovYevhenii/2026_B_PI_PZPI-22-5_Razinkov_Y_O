import type { AuthorizedFetch } from '../types';
import { readApiError } from '../utils/api';

/** Hand-off channel between a clicked notification and the OrdersPage tab it should open. */
export const ORDERS_TAB_STORAGE_KEY = 'skinhex_orders_tab';
export const ORDERS_TAB_EVENT = 'skinhex:orders-tab';

/** Mirrors NotificationType enum names on the backend (serialized as strings in NotificationDto.Type). */
export type NotificationType =
  | 'System'
  | 'ItemSold'
  | 'SaleCompleted'
  | 'OrderStatusChanged'
  | 'OrderCancelled'
  | 'TradeOfferSent'
  | 'TradeOfferAccepted'
  | 'DepositCompleted'
  | 'WithdrawalStatusChanged';

export interface AppNotification {
  id: string;
  type: NotificationType | string;
  payload: Record<string, unknown>;
  isRead: boolean;
  createdAt: string;
  readAt: string | null;
}

export interface NotificationsPage {
  items: AppNotification[];
  unreadCount: number;
  hasMore: boolean;
}

// --- Realtime payloads (camelCase mirrors of the backend payload records) ---

export interface ItemSoldPayload {
  orderId: string;
  listingId: string;
  marketHashName: string;
  wear: string | null;
  price: number;
  buyerId: string;
  buyerUsername: string;
  confirmDeadline: string | null;
}

export interface OrderStatusChangedPayload {
  orderId: string;
  listingId: string;
  status: number;
  role: 'buyer' | 'seller';
  marketHashName: string | null;
  cancelledBy: string | null;
  cancelReason: string | null;
}

export interface DepositCompletedPayload {
  depositId: string;
  amount: number;
  payCurrency: string | null;
}

export interface WithdrawalStatusPayload {
  withdrawalId: string;
  status: string;
  amount: number;
  payCurrency: string | null;
  rejectionReason: string | null;
}

export interface BalanceChangedPayload {
  balance: number;
  frozenBalance: number;
  delta: number;
  reason: string;
}

export interface CartItemUnavailablePayload {
  listingId: string;
}

export async function getNotifications(
  fetcher: AuthorizedFetch,
  limit = 20,
  before?: string,
): Promise<NotificationsPage> {
  const params = new URLSearchParams({ limit: String(limit) });
  if (before) {
    params.set('before', before);
  }
  const response = await fetcher(`/notifications?${params}`);
  if (!response.ok) {
    throw new Error(await readApiError(response));
  }
  return response.json() as Promise<NotificationsPage>;
}

export async function getUnreadCount(fetcher: AuthorizedFetch): Promise<number> {
  const response = await fetcher('/notifications/unread-count');
  if (!response.ok) {
    throw new Error(await readApiError(response));
  }
  const data = (await response.json()) as { unreadCount: number };
  return data.unreadCount;
}

export async function markNotificationsRead(fetcher: AuthorizedFetch, ids: string[]): Promise<number> {
  const response = await fetcher('/notifications/read', {
    method: 'POST',
    body: JSON.stringify({ ids }),
  });
  if (!response.ok) {
    throw new Error(await readApiError(response));
  }
  const data = (await response.json()) as { updated: number };
  return data.updated;
}

export async function markAllNotificationsRead(fetcher: AuthorizedFetch): Promise<number> {
  const response = await fetcher('/notifications/read-all', { method: 'POST' });
  if (!response.ok) {
    throw new Error(await readApiError(response));
  }
  const data = (await response.json()) as { updated: number };
  return data.updated;
}
