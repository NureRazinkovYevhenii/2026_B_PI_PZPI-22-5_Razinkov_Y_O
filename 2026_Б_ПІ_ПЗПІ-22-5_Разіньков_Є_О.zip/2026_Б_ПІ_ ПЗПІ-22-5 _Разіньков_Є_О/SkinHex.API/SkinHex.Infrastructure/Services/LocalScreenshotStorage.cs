using Microsoft.Extensions.Options;
using SkinHex.Core.Interfaces.Screenshots;
using SkinHex.Core.Options;

namespace SkinHex.Infrastructure.Services;

public sealed class LocalScreenshotStorage(IOptions<ScreenshotOptions> options) : IScreenshotStorage
{
    public async Task<string> SaveAsync(string relativePath, byte[] content, CancellationToken ct = default)
    {
        var root = Path.GetFullPath(options.Value.StorageRootPath);
        var fullPath = Path.GetFullPath(Path.Combine(root, relativePath));
        if (!fullPath.StartsWith(root + Path.DirectorySeparatorChar, StringComparison.Ordinal))
            throw new InvalidOperationException($"Screenshot path escapes the storage root: {relativePath}");

        Directory.CreateDirectory(Path.GetDirectoryName(fullPath)!);
        await File.WriteAllBytesAsync(fullPath, content, ct);

        return relativePath.Replace('\\', '/');
    }
}
