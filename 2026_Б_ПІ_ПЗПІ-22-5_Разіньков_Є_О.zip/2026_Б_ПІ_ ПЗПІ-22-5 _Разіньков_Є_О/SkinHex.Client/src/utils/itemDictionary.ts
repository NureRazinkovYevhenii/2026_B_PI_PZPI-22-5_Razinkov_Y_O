import type { ItemDictionaryEntry } from '../types';

const SteamImageBaseUrl = 'https://community.cloudflare.steamstatic.com/economy/image';

let dictionaryPromise: Promise<Record<string, ItemDictionaryEntry>> | null = null;

const DICTIONARY_VERSION = '1.0';

export function loadItemDictionary() {
  dictionaryPromise ??= fetch(`/items_dict.json?v=${DICTIONARY_VERSION}`).then(async (response) => {
    if (!response.ok) {
      throw new Error('Failed to load item dictionary.');
    }

    return (await response.json()) as Record<string, ItemDictionaryEntry>;
  });

  return dictionaryPromise;
}

export function getItemStatic(
  dictionary: Record<string, ItemDictionaryEntry>,
  marketHashName: string,
) {
  return dictionary[marketHashName] ?? null;
}

export function getItemImageUrl(itemStatic: ItemDictionaryEntry | null) {
  return itemStatic?.icon ? `${SteamImageBaseUrl}/${itemStatic.icon}/300fx300f` : '';
}
