using System;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using SkinHex.Core.Entities;
using SkinHex.Core.Errors;
using Microsoft.Extensions.Logging;
using SkinHex.Core.Models.Tlsn;
using SkinHex.Core.Interfaces;
using SkinHex.Core.Interfaces.Repositories;
using SkinHex.Core.Interfaces.Services;

namespace SkinHex.Core.Services
{
    public class TlsnWebhookProcessor : ITlsnWebhookProcessor
    {
        private readonly ILogger<TlsnWebhookProcessor> _logger;
        private readonly ITradeService _tradeService;
        private readonly ITlsnProofRecordRepository _proofRecordRepository;
        private readonly IDisputeService _disputeService;
        private readonly IUnitOfWork _unitOfWork;

        public TlsnWebhookProcessor(
            ILogger<TlsnWebhookProcessor> logger,
            ITradeService tradeService,
            ITlsnProofRecordRepository proofRecordRepository,
            IDisputeService disputeService,
            IUnitOfWork unitOfWork)
        {
            _logger = logger;
            _tradeService = tradeService;
            _proofRecordRepository = proofRecordRepository;
            _disputeService = disputeService;
            _unitOfWork = unitOfWork;
        }

        public async Task ProcessWebhookAsync(WebhookPayload payload)
        {
            _logger.LogInformation("Processing TLSN Webhook for session {SessionId}", payload.Session.Id);

            // Evidence log: every webhook is persisted with its validation outcome, so disputes
            // always have a record of who proved what and when — including rejected proofs.
            var records = new List<TlsnProofRecord>();

            try
            {
                await ProcessAsync(payload, records);
            }
            finally
            {
                await PersistRecordsAsync(records);
            }
        }

        private async Task ProcessAsync(WebhookPayload payload, List<TlsnProofRecord> records)
        {
            if (payload.ServerName != "api.steampowered.com")
            {
                _logger.LogWarning("Ignoring webhook from unexpected server: {ServerName}", payload.ServerName);
                records.Add(CreateRecord(payload, ignoredCode: "UNEXPECTED_SERVER", ignoredReason: $"Unexpected server: {payload.ServerName}"));
                return;
            }

            var sentData = payload.Transcript.Sent;
            var recvData = payload.Transcript.Recv;

            // One proof can cover a single trade (GetTradeStatus) or a whole page of the
            // user's history (GetTradeHistory) — "confirm many trades in one session".
            var isBatchProof = sentData.Contains("GetTradeHistory", StringComparison.OrdinalIgnoreCase);
            var requestTradeId = ExtractTradeIdFromRequest(sentData);

            if (!isBatchProof && string.IsNullOrWhiteSpace(requestTradeId))
            {
                _logger.LogWarning("Could not extract tradeid from sent data.");
                records.Add(CreateRecord(payload, ignoredCode: "NO_TRADE_ID", ignoredReason: "Could not extract tradeid from sent data."));
                return;
            }

            var responseJson = ExtractResponseBody(recvData);
            if (responseJson is null)
            {
                _logger.LogWarning("Could not find HTTP response body separator.");
                records.Add(CreateRecord(payload, requestTradeId, "NO_RESPONSE_BODY", "Could not find HTTP response body separator."));
                return;
            }

            try
            {
                using var document = JsonDocument.Parse(responseJson);
                var trades = ExtractTrades(document.RootElement);
                if (trades.Count == 0)
                {
                    _logger.LogWarning("Response JSON did not contain expected trades array structure.");
                    records.Add(CreateRecord(payload, requestTradeId, "NO_TRADES_ARRAY", "Response JSON did not contain expected trades array structure."));
                    return;
                }

                if (isBatchProof)
                {
                    await ProcessBatchProofAsync(payload, trades, records);
                }
                else
                {
                    await ProcessSingleProofAsync(payload, trades[0], requestTradeId!, records);
                }
            }
            catch (JsonException ex)
            {
                _logger.LogError(ex, "Failed to parse JSON body from response.");
                records.Add(CreateRecord(payload, requestTradeId, "JSON_PARSE_ERROR", ex.Message));
            }
        }

        private async Task ProcessSingleProofAsync(WebhookPayload payload, JsonElement tradeElement, string requestTradeId, List<TlsnProofRecord> records)
        {
            var record = CreateRecord(payload);
            record.SteamTradeId = requestTradeId;
            records.Add(record);

            var responseTradeId = tradeElement.TryGetProperty("tradeid", out var tradeIdElement)
                ? tradeIdElement.GetString()
                : null;

            if (!string.Equals(responseTradeId, requestTradeId, StringComparison.Ordinal))
            {
                _logger.LogError("Trade ID mismatch. Request: {ReqTradeId}, Response: {ResTradeId}", requestTradeId, responseTradeId);
                MarkIgnored(record, "TRADE_ID_MISMATCH", $"Request tradeid {requestTradeId} != response tradeid {responseTradeId}.");
                return;
            }

            await ProcessTradeElementAsync(tradeElement, requestTradeId, record);
        }

        private async Task ProcessBatchProofAsync(WebhookPayload payload, IReadOnlyList<JsonElement> trades, List<TlsnProofRecord> records)
        {
            var processed = 0;

            foreach (var tradeElement in trades)
            {
                var tradeId = tradeElement.TryGetProperty("tradeid", out var tradeIdElement)
                    ? tradeIdElement.GetString()
                    : null;
                if (string.IsNullOrWhiteSpace(tradeId))
                    continue;

                // A history page contains the user's unrelated trades too — only trades
                // that map to a SkinHex order are processed and recorded.
                var orderId = await _proofRecordRepository.GetOrderIdBySteamTradeIdAsync(tradeId);
                if (orderId is null)
                    continue;

                var record = CreateRecord(payload);
                record.SteamTradeId = tradeId;
                record.OrderId = orderId;
                records.Add(record);

                await ProcessTradeElementAsync(tradeElement, tradeId, record);
                processed++;
            }

            _logger.LogInformation("Batch TLSN proof processed: {Processed} of {Total} trades matched SkinHex orders.", processed, trades.Count);

            if (processed == 0)
            {
                records.Add(CreateRecord(payload, ignoredCode: "NO_MATCHING_TRADES", ignoredReason: "History proof contained no trades matching SkinHex orders."));
            }
        }

        /// <summary>Validates and applies one proven trade element; fills the record with the outcome.</summary>
        private async Task ProcessTradeElementAsync(JsonElement tradeElement, string tradeId, TlsnProofRecord record)
        {
            if (!tradeElement.TryGetProperty("status", out var statusElement) ||
                statusElement.ValueKind != JsonValueKind.Number)
            {
                _logger.LogWarning("Trade status is missing in proof response for trade {TradeId}.", tradeId);
                MarkIgnored(record, "NO_TRADE_STATUS", "Trade status is missing in proof response.");
                return;
            }

            var status = statusElement.GetInt32();
            var steamIdOther = tradeElement.TryGetProperty("steamid_other", out var steamIdOtherElement)
                ? steamIdOtherElement.GetString()
                : null;
            var transferredAssetIds = ExtractAssetIds(tradeElement);
            var timeSettlementUnix = ExtractLong(tradeElement, "time_settlement");
            var proofObservedAtUtc = DateTimeOffset.UtcNow;

            record.TradeStatus = status;
            record.SteamIdOther = steamIdOther;
            record.TransferredAssetIds = transferredAssetIds.Count > 0 ? string.Join(",", transferredAssetIds) : null;
            record.TimeSettlementUnix = timeSettlementUnix;

            if (!Enum.IsDefined(typeof(SteamTradeStatus), status))
            {
                _logger.LogWarning("Unknown Steam trade status received in TLSN proof: {Status}", status);
                MarkIgnored(record, "UNKNOWN_TRADE_STATUS", $"Unknown Steam trade status: {status}.");
                return;
            }

            try
            {
                await _tradeService.ProcessTlsnTradeStatusProofAsync(
                    tradeId,
                    (SteamTradeStatus)status,
                    steamIdOther,
                    transferredAssetIds,
                    timeSettlementUnix,
                    proofObservedAtUtc);

                record.Outcome = TlsnProofOutcome.Accepted;
                _logger.LogInformation("Order flow finalized by TLSN proof for trade {TradeId}.", tradeId);
            }
            catch (BusinessException businessException)
            {
                // Expected domain outcomes should not break webhook processing.
                record.Outcome = TlsnProofOutcome.Rejected;
                record.FailureCode = businessException.ErrorCode;
                record.FailureReason = businessException.Message;

                _logger.LogWarning(
                    "TLSN proof processed with business guard for trade {TradeId}. Code={Code} Message={Message}",
                    tradeId,
                    businessException.ErrorCode,
                    businessException.Message);

                // Identity/content mismatches are fraud signals, not timing quirks:
                // the seller proved a trade that does not match the order. Support must look.
                if (businessException.ErrorCode is BusinessErrorCodes.TlsnAssetMismatch or BusinessErrorCodes.TlsnSteamIdMismatch)
                {
                    await TryOpenMismatchDisputeAsync(tradeId, businessException.ErrorCode, businessException.Message);
                }
            }
        }

        private async Task TryOpenMismatchDisputeAsync(string steamTradeId, string failureCode, string failureMessage)
        {
            try
            {
                var orderId = await _proofRecordRepository.GetOrderIdBySteamTradeIdAsync(steamTradeId);
                if (orderId is null)
                    return;

                await _disputeService.OpenSystemDisputeAsync(
                    orderId.Value,
                    DisputeReason.WrongItemReceived,
                    $"TLSN completion proof rejected: {failureMessage} ({failureCode}). " +
                    "The proven trade does not match the order — possible item substitution.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to open mismatch dispute for trade {TradeId}.", steamTradeId);
            }
        }

        private async Task PersistRecordsAsync(List<TlsnProofRecord> records)
        {
            if (records.Count == 0)
                return;

            try
            {
                foreach (var record in records)
                {
                    if (record.OrderId is null && record.SteamTradeId is not null)
                        record.OrderId = await _proofRecordRepository.GetOrderIdBySteamTradeIdAsync(record.SteamTradeId);

                    _proofRecordRepository.Add(record);
                }

                await _unitOfWork.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                // Evidence persistence must never mask the processing result.
                _logger.LogError(ex, "Failed to persist TLSN proof records for session.");
            }
        }

        private static TlsnProofRecord CreateRecord(WebhookPayload payload, string? steamTradeId = null, string? ignoredCode = null, string? ignoredReason = null)
        {
            var record = new TlsnProofRecord
            {
                Id = Guid.NewGuid(),
                SessionId = payload.Session.Id,
                ServerName = payload.ServerName,
                SteamTradeId = steamTradeId,
                PayloadJson = JsonSerializer.Serialize(payload),
                ReceivedAt = DateTime.UtcNow
            };

            if (ignoredCode is not null)
                MarkIgnored(record, ignoredCode, ignoredReason ?? ignoredCode);

            return record;
        }

        private static void MarkIgnored(TlsnProofRecord record, string code, string reason)
        {
            record.Outcome = TlsnProofOutcome.Ignored;
            record.FailureCode = code;
            record.FailureReason = reason;
        }

        private static string? ExtractTradeIdFromRequest(string sentData)
        {
            var tradeIdMatch = Regex.Match(sentData, @"tradeid=(\d+)");
            return tradeIdMatch.Success ? tradeIdMatch.Groups[1].Value : null;
        }

        private static string? ExtractResponseBody(string recvData)
        {
            var bodyIndex = recvData.IndexOf("\r\n\r\n", StringComparison.Ordinal);
            if (bodyIndex == -1)
                return null;

            return recvData[(bodyIndex + 4)..];
        }

        private static IReadOnlyList<JsonElement> ExtractTrades(JsonElement root)
        {
            if (!root.TryGetProperty("response", out var responseObj))
                return [];
            if (!responseObj.TryGetProperty("trades", out var tradesArray))
                return [];
            if (tradesArray.ValueKind != JsonValueKind.Array)
                return [];

            var trades = new List<JsonElement>(tradesArray.GetArrayLength());
            foreach (var trade in tradesArray.EnumerateArray())
                trades.Add(trade);

            return trades;
        }

        private static IReadOnlyCollection<string> ExtractAssetIds(JsonElement tradeElement)
        {
            var assetIds = new List<string>();

            if (!tradeElement.TryGetProperty("assets_given", out var assetsGivenElement) ||
                assetsGivenElement.ValueKind != JsonValueKind.Array)
            {
                return assetIds;
            }

            foreach (var asset in assetsGivenElement.EnumerateArray())
            {
                if (asset.TryGetProperty("assetid", out var assetIdElement) &&
                    assetIdElement.ValueKind == JsonValueKind.String)
                {
                    var assetId = assetIdElement.GetString();
                    if (!string.IsNullOrWhiteSpace(assetId))
                        assetIds.Add(assetId);
                }
            }

            return assetIds;
        }

        private static long? ExtractLong(JsonElement element, string propertyName)
        {
            if (!element.TryGetProperty(propertyName, out var property))
                return null;

            if (property.ValueKind == JsonValueKind.Number && property.TryGetInt64(out var numberValue))
                return numberValue;

            if (property.ValueKind == JsonValueKind.String && long.TryParse(property.GetString(), out var stringValue))
                return stringValue;

            return null;
        }
    }
}
