import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import type { AuthorizedFetch } from '../../types';
import { fetchDashboard, type DashboardStats } from '../../api/adminApi';
import { formatMoney, StateBlock } from './adminShared';

type Props = { authorizedFetch: AuthorizedFetch };

function StatCard({ label, value, accent }: { label: string; value: string; accent?: string }) {
  return (
    <div className="glass-panel admin-card">
      <span className="admin-card-label">{label}</span>
      <span className="admin-card-value" style={accent ? { color: accent } : undefined}>{value}</span>
    </div>
  );
}

export function AdminDashboard({ authorizedFetch }: Props) {
  const { t } = useTranslation();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    setLoading(true);
    fetchDashboard(authorizedFetch)
      .then((data) => {
        if (active) {
          setStats(data);
          setError(null);
        }
      })
      .catch((e) => active && setError(e instanceof Error ? e.message : 'Failed to load'))
      .finally(() => active && setLoading(false));
    return () => {
      active = false;
    };
  }, [authorizedFetch]);

  if (loading) return <StateBlock><strong>{t('admin.loading')}</strong></StateBlock>;
  if (error) return <StateBlock><strong>{t('admin.error')}</strong><p>{error}</p></StateBlock>;
  if (!stats) return null;

  return (
    <div className="admin-card-grid">
      <StatCard label={t('admin.dashboard.totalUsers')} value={String(stats.totalUsers)} />
      <StatCard label={t('admin.dashboard.bannedUsers')} value={String(stats.bannedUsers)} accent="#f87171" />
      <StatCard label={t('admin.dashboard.openTickets')} value={String(stats.openTickets)} accent="#fbbf24" />
      <StatCard label={t('admin.dashboard.openDisputes')} value={String(stats.openDisputes ?? 0)} accent="#f87171" />
      <StatCard label={t('admin.dashboard.pendingOrders')} value={String(stats.pendingOrders)} accent="#fbbf24" />
      <StatCard label={t('admin.dashboard.totalBalance')} value={formatMoney(stats.totalUserBalance)} accent="var(--accent)" />
      <StatCard label={t('admin.dashboard.frozenBalance')} value={formatMoney(stats.totalFrozenBalance)} />
    </div>
  );
}
