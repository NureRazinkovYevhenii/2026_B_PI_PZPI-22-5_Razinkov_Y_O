import { useEffect, useRef, useState } from 'react';
import { Bell, CheckCheck, PackageCheck, ShoppingBag, Wallet, XCircle, Send, Handshake, Info, Scale, ShieldAlert } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useNotifications } from '../utils/NotificationsContext';
import type { AppNotification } from '../api/notificationsApi';
import { ORDERS_TAB_EVENT, ORDERS_TAB_STORAGE_KEY } from '../api/notificationsApi';

const ORDER_STATUS_KEYS: Record<number, string> = {
  0: 'pending',
  1: 'confirmed',
  2: 'tradeSent',
  3: 'inEscrow',
  4: 'completed',
  5: 'cancelled',
};

type NotificationRoute =
  | { page: 'orders'; tab: 'buyer' | 'seller' }
  | { page: 'profile' }
  | null;

/** Where clicking a notification should take the user. */
function routeFor(notification: AppNotification): NotificationRoute {
  const role = notification.payload.role;
  const tabFromRole: 'buyer' | 'seller' = role === 'seller' ? 'seller' : 'buyer';

  switch (notification.type) {
    case 'ItemSold':
    case 'TradeOfferAccepted':
      return { page: 'orders', tab: 'seller' };
    case 'TradeOfferSent':
      return { page: 'orders', tab: 'buyer' };
    case 'OrderStatusChanged':
    case 'OrderCancelled':
    case 'SaleCompleted':
      return { page: 'orders', tab: tabFromRole };
    case 'DisputeOpened':
    case 'DisputeResolved':
      // Disputes are shown on the order card; role isn't in the payload, so default to the
      // buyer tab (most disputes are buyer-side) — the user can switch tabs if needed.
      return { page: 'orders', tab: tabFromRole };
    case 'DepositCompleted':
    case 'WithdrawalStatusChanged':
      return { page: 'profile' };
    default:
      return null;
  }
}

function navigateToNotification(notification: AppNotification) {
  const route = routeFor(notification);
  if (!route) return;

  if (route.page === 'orders') {
    // sessionStorage covers a cold mount (navigating from another page);
    // the event covers a warm switch when OrdersPage is already open.
    sessionStorage.setItem(ORDERS_TAB_STORAGE_KEY, route.tab);
    window.dispatchEvent(new CustomEvent(ORDERS_TAB_EVENT, { detail: { tab: route.tab } }));
    window.location.hash = 'orders';
  } else if (route.page === 'profile') {
    window.location.hash = 'profile';
  }
}

function iconFor(type: string) {
  switch (type) {
    case 'ItemSold':
      return <ShoppingBag size={16} color="var(--accent)" />;
    case 'SaleCompleted':
      return <PackageCheck size={16} color="var(--accent)" />;
    case 'OrderCancelled':
      return <XCircle size={16} color="#ef4444" />;
    case 'TradeOfferSent':
      return <Send size={16} color="var(--brand)" />;
    case 'TradeOfferAccepted':
      return <Handshake size={16} color="var(--accent)" />;
    case 'DepositCompleted':
    case 'WithdrawalStatusChanged':
      return <Wallet size={16} color="var(--accent)" />;
    case 'DisputeOpened':
      return <ShieldAlert size={16} color="#fbbf24" />;
    case 'DisputeResolved':
      return <Scale size={16} color="var(--accent)" />;
    default:
      return <Info size={16} color="var(--text-muted)" />;
  }
}

function useTimeAgo() {
  const { t } = useTranslation();

  return (iso: string) => {
    const seconds = Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 1000));
    if (seconds < 60) return t('notifications.time.justNow');
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return t('notifications.time.minutesAgo', { count: minutes });
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return t('notifications.time.hoursAgo', { count: hours });
    const days = Math.floor(hours / 24);
    if (days < 7) return t('notifications.time.daysAgo', { count: days });
    return new Date(iso).toLocaleDateString();
  };
}

function NotificationRow({ notification, onActivate }: { notification: AppNotification; onActivate: (n: AppNotification) => void }) {
  const { t } = useTranslation();
  const timeAgo = useTimeAgo();
  const p = notification.payload;

  const title = t(`notifications.types.${notification.type}`, { defaultValue: t('notifications.types.System') });

  let body: string | null = null;
  switch (notification.type) {
    case 'ItemSold':
      body = t('notifications.body.itemSold', {
        item: (p.marketHashName as string) || t('notifications.body.unknownItem'),
        price: Number(p.price ?? 0).toFixed(2),
        buyer: (p.buyerUsername as string) ?? '',
      });
      break;
    case 'OrderCancelled':
      body = t('notifications.body.orderCancelled', {
        reason: (p.cancelReason as string) || t('notifications.body.noReason'),
      });
      break;
    case 'TradeOfferSent':
      body = t('notifications.body.tradeOfferSent');
      break;
    case 'TradeOfferAccepted':
      body = t('notifications.body.tradeOfferAccepted');
      break;
    case 'SaleCompleted':
      body = t('notifications.body.saleCompleted');
      break;
    case 'OrderStatusChanged': {
      const statusKey = ORDER_STATUS_KEYS[Number(p.status)] ?? 'pending';
      body = t('notifications.body.orderStatusChanged', { status: t(`notifications.status.${statusKey}`, { defaultValue: statusKey }) });
      break;
    }
    case 'DisputeOpened': {
      const reason = t(`orders.dispute.reasons.${String(p.reason)}`, { defaultValue: String(p.reason ?? '') });
      body = t('notifications.body.disputeOpened', { reason });
      break;
    }
    case 'DisputeResolved': {
      const resolution = t(`orders.dispute.resolutions.${String(p.resolution)}`, { defaultValue: String(p.resolution ?? '') });
      body = t('notifications.body.disputeResolved', { resolution });
      break;
    }
    case 'DepositCompleted':
      body = t('notifications.body.depositCompleted', { amount: Number(p.amount ?? 0).toFixed(2) });
      break;
    case 'WithdrawalStatusChanged': {
      const w = String(p.status);
      body =
        w === 'Completed'
          ? t('notifications.body.withdrawalCompleted', { amount: Number(p.amount ?? 0).toFixed(2) })
          : t('notifications.body.withdrawalFailed', {
              amount: Number(p.amount ?? 0).toFixed(2),
              reason: (p.rejectionReason as string) || t('notifications.body.noReason'),
            });
      break;
    }
    default:
      // System notifications: an explicit message, or the "wrong item in the offer" warning.
      if (typeof p.message === 'string') {
        body = p.message;
      } else if (p.expectedAssetId != null) {
        body = t('notifications.body.tradeOfferMismatch');
      } else {
        body = null;
      }
  }

  return (
    <button
      onClick={() => onActivate(notification)}
      style={{
        display: 'flex',
        gap: '10px',
        width: '100%',
        textAlign: 'left',
        padding: '10px 14px',
        background: notification.isRead ? 'transparent' : 'rgba(16, 185, 129, 0.06)',
        border: 'none',
        borderBottom: '1px solid var(--border)',
        cursor: 'pointer',
      }}
    >
      <div style={{ marginTop: '2px', flexShrink: 0 }}>{iconFor(notification.type)}</div>
      <div style={{ minWidth: 0, flex: 1 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px' }}>
          <span style={{ fontWeight: 700, fontSize: '13px', color: 'var(--text-h)' }}>{title}</span>
          {!notification.isRead && (
            <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: 'var(--brand)', flexShrink: 0 }} />
          )}
        </div>
        {body ? (
          <div style={{ fontSize: '12px', color: 'var(--text-muted)', marginTop: '2px', overflowWrap: 'anywhere' }}>{body}</div>
        ) : null}
        <div style={{ fontSize: '11px', color: 'var(--text-muted)', marginTop: '4px', opacity: 0.7 }}>
          {timeAgo(notification.createdAt)}
        </div>
      </div>
    </button>
  );
}

export function NotificationsDropdown() {
  const { t } = useTranslation();
  const { notifications, unreadCount, hasMore, isLoading, loadMore, markAsRead, markAllAsRead } = useNotifications();
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [open]);

  return (
    <div ref={containerRef} style={{ position: 'relative' }}>
      <button
        className="icon-button"
        style={{ border: 'none', background: 'transparent', borderRadius: '50%', position: 'relative' }}
        onClick={() => setOpen((v) => !v)}
        aria-label={t('notifications.title')}
      >
        <Bell size={20} color="var(--text-h)" />
        {unreadCount > 0 && (
          <div
            style={{
              position: 'absolute',
              top: '-4px',
              right: '-4px',
              background: 'var(--brand)',
              color: 'white',
              fontSize: '10px',
              fontWeight: 800,
              minWidth: '16px',
              height: '16px',
              padding: '0 3px',
              borderRadius: '8px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            {unreadCount > 99 ? '99+' : unreadCount}
          </div>
        )}
      </button>

      {open && (
        <div
          className="glass-panel animate-fade-in"
          style={{
            position: 'absolute',
            right: 0,
            top: 'calc(100% + 8px)',
            width: '360px',
            maxHeight: '480px',
            display: 'flex',
            flexDirection: 'column',
            borderRadius: '12px',
            overflow: 'hidden',
            zIndex: 100,
            background: 'var(--surface)',
            border: '1px solid var(--border)',
          }}
        >
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: '12px 14px',
              borderBottom: '1px solid var(--border)',
            }}
          >
            <span style={{ fontWeight: 800, fontSize: '14px', color: 'var(--text-h)' }}>{t('notifications.title')}</span>
            {unreadCount > 0 && (
              <button
                onClick={() => void markAllAsRead()}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '4px',
                  background: 'transparent',
                  border: 'none',
                  cursor: 'pointer',
                  fontSize: '12px',
                  color: 'var(--accent)',
                }}
              >
                <CheckCheck size={14} /> {t('notifications.markAllRead')}
              </button>
            )}
          </div>

          <div style={{ overflowY: 'auto', flex: 1 }}>
            {notifications.length === 0 && !isLoading ? (
              <div style={{ padding: '32px 14px', textAlign: 'center', color: 'var(--text-muted)', fontSize: '13px' }}>
                {t('notifications.empty')}
              </div>
            ) : (
              notifications.map((n) => (
                <NotificationRow
                  key={n.id}
                  notification={n}
                  onActivate={(item) => {
                    if (!item.isRead) void markAsRead([item.id]);
                    navigateToNotification(item);
                    setOpen(false);
                  }}
                />
              ))
            )}
            {hasMore && (
              <button
                onClick={() => void loadMore()}
                disabled={isLoading}
                style={{
                  width: '100%',
                  padding: '10px',
                  background: 'transparent',
                  border: 'none',
                  cursor: 'pointer',
                  color: 'var(--accent)',
                  fontSize: '12px',
                  fontWeight: 700,
                }}
              >
                {isLoading ? t('common.loading', { defaultValue: '…' }) : t('notifications.loadMore')}
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
