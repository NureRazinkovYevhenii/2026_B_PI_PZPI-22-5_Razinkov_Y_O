import type { TlsnRequestConfig } from "../bridge/types";
import { TokenManager } from "../steam/tokenManager";

// ── Offscreen document management ────────────────────────────────────────────

async function ensureOffscreenDocument() {
    if (await chrome.offscreen.hasDocument()) {
        return;
    }
    await chrome.offscreen.createDocument({
        url: 'offscreen.html', 
        reasons: [chrome.offscreen.Reason.WORKERS],
        justification: 'TLSN cryptography requires Web Workers'
    });
}

// ── Generic proof executor ───────────────────────────────────────────────────
// Надсилає TlsnRequestConfig в offscreen → worker і чекає результат.

async function executeProof(config: TlsnRequestConfig, sessionData?: Record<string, unknown>): Promise<any> {
    await ensureOffscreenDocument();
    
    const response = await chrome.runtime.sendMessage({
        target: 'offscreen',
        type: 'TLSN_PROVE',
        data: {
            config,
            sessionData: sessionData ?? {}
        }
    });

    if (response?.error) {
        throw new Error(`Offscreen Error: ${response.error}`);
    }

    return response?.data;
}

// ── Proof builders ───────────────────────────────────────────────────────────
// Кожен builder знає, як сформувати TlsnRequestConfig для конкретного API.
// Щоб додати новий тип proof — просто додай новий builder.

/**
 * Будує proof для GetTradeStatus — перевіряє статус конкретного трейду.
 * Steam поверне: { response: { trades: [{ tradeid, status, assets_received, ... }] } }
 */
function buildTradeStatusConfig(tradeId: string, accessToken: string): TlsnRequestConfig {
    return {
        url: `https://api.steampowered.com/IEconService/GetTradeStatus/v1/?access_token=${accessToken}&tradeid=${tradeId}&language=en`,
        serverName: 'api.steampowered.com',
        method: 'GET',
        secretsToRedact: [accessToken],
    };
}

/** Скільки трейдів запитуємо в batch-пруфі. Обмежено maxRecvData:
 *  MPC-вартість зростає з розміром відповіді, а історія віддає найсвіжіші трейди. */
const HISTORY_PROOF_MAX_TRADES = 15;

/**
 * Будує proof для GetTradeHistory — одна TLSN-сесія підтверджує статуси
 * одразу багатьох трейдів ("підтвердити все однією кнопкою" / авто-пруф за будильником).
 * Бекенд сам вибере з відповіді трейди, що стосуються замовлень SkinHex.
 */
function buildTradeHistoryConfig(accessToken: string, maxTrades: number): TlsnRequestConfig {
    const clamped = Math.max(1, Math.min(maxTrades, HISTORY_PROOF_MAX_TRADES));
    return {
        url: `https://api.steampowered.com/IEconService/GetTradeHistory/v1/?access_token=${accessToken}&max_trades=${clamped}&include_failed=true&navigating_back=false&language=en`,
        serverName: 'api.steampowered.com',
        method: 'GET',
        secretsToRedact: [accessToken],
        // Сторінка історії помітно більша за один трейд.
        maxRecvData: 32768,
    };
}

// ── Public API ───────────────────────────────────────────────────────────────

/**
 * Точка входу: приймає запит від сайту, будує TlsnRequestConfig,
 * передає його в generic worker.
 */
export async function proveTradeWithTlsn(request: any): Promise<any> {
    // Підтримка як старого формату { type, tradeId }, так і нового { type, data: { proofType, ... } }
    const tradeId = request.data?.tradeId || request.tradeId;
    const tradeIds: string[] | undefined = request.data?.tradeIds;
    const proofType = request.data?.proofType || 'trade_status';

    console.log(`[Background] Starting TLSN_PROVE (${proofType})`, tradeIds ?? tradeId);

    // Отримуємо Steam access token
    const tokenManager = TokenManager.getInstance();
    const token = await tokenManager.getToken();
    if (!token) throw new Error("No access to Steam (token is missing)");

    // Обираємо builder за типом proof
    let config: TlsnRequestConfig;

    switch (proofType) {
        case 'trade_status':
            if (!tradeId) throw new Error("tradeId is required for proofType 'trade_status'");
            config = buildTradeStatusConfig(tradeId, token);
            break;
        case 'trade_history':
            config = buildTradeHistoryConfig(token, tradeIds?.length ?? HISTORY_PROOF_MAX_TRADES);
            break;
        default:
            throw new Error(`Unknown proof type: ${proofType}`);
    }

    const sessionData: Record<string, string> = {
        proofType,
        source: 'skinhex-extension'
    };

    if (tradeId) sessionData.tradeId = String(tradeId);
    if (tradeIds) sessionData.tradeIds = JSON.stringify(tradeIds);
    if (request.data?.orderId) sessionData.orderId = String(request.data.orderId);
    if (request.data?.targetSteamId) sessionData.targetSteamId = String(request.data.targetSteamId);

    // Запускаємо generic proof
    return executeProof(config, sessionData);
}