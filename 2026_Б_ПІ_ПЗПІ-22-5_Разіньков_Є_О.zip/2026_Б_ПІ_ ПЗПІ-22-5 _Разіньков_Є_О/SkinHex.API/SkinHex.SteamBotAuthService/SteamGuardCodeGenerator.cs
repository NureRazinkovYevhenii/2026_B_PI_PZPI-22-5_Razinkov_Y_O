using System.Security.Cryptography;
using System.Text;

namespace SkinHex.SteamBotAuthService;

public sealed class SteamGuardCodeGenerator
{
    private static readonly byte[] CodeCharacters =
        "23456789BCDFGHJKMNPQRTVWXY"u8.ToArray();

    private readonly byte[] _sharedSecret;

    public SteamGuardCodeGenerator(string sharedSecret)
    {
        _sharedSecret = Convert.FromBase64String(sharedSecret);
    }

    public string GenerateCode(DateTimeOffset? timestamp = null)
    {
        var timeStep = (timestamp ?? DateTimeOffset.UtcNow).ToUnixTimeSeconds() / 30;
        Span<byte> timeBytes = stackalloc byte[8];

        for (var index = timeBytes.Length - 1; index >= 0; index--)
        {
            timeBytes[index] = (byte)timeStep;
            timeStep >>= 8;
        }

        using var hmac = new HMACSHA1(_sharedSecret);
        var hash = hmac.ComputeHash(timeBytes.ToArray());
        var offset = hash[^1] & 0x0F;
        var codePoint =
            (hash[offset] & 0x7F) << 24 |
            (hash[offset + 1] & 0xFF) << 16 |
            (hash[offset + 2] & 0xFF) << 8 |
            hash[offset + 3] & 0xFF;

        Span<byte> code = stackalloc byte[5];
        for (var index = 0; index < code.Length; index++)
        {
            code[index] = CodeCharacters[codePoint % CodeCharacters.Length];
            codePoint /= CodeCharacters.Length;
        }

        return Encoding.ASCII.GetString(code);
    }
}
