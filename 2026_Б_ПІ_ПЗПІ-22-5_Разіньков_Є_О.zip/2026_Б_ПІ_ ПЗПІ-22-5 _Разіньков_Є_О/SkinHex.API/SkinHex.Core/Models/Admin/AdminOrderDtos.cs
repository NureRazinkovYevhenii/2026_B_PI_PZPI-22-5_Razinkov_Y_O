namespace SkinHex.Core.Models.Admin;

public record AdminParticipantDto(
    Guid Id,
    string Username,
    string SteamId,
    string? AvatarUrl);

public record AdminOrderListItemDto(
    Guid OrderId,
    string Status,
    decimal Price,
    AdminParticipantDto Buyer,
    AdminParticipantDto Seller,
    string MarketHashName,
    DateTime CreatedAt);

public record AdminOrderTradeDto(
    Guid Id,
    string TradeOfferId,
    string? TradeId,
    string OfferState,
    string? TradeStatus,
    DateTime CreatedAt,
    DateTime UpdatedAt);

public record AdminOrderDetailDto(
    Guid OrderId,
    Guid ListingId,
    string Status,
    decimal Price,
    string? CancelledBy,
    string? CancelReason,
    DateTime CreatedAt,
    DateTime? ConfirmedAt,
    DateTime? TradeSentAt,
    DateTime? HoldEndsAt,
    DateTime? CancelledAt,
    DateTime UpdatedAt,
    AdminParticipantDto Buyer,
    AdminParticipantDto Seller,
    string MarketHashName,
    string? Wear,
    double? Float,
    IReadOnlyList<AdminOrderTradeDto> Trades);
