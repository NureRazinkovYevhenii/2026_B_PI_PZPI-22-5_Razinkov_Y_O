using SkinHex.Core.Entities;
using SkinHex.Core.Models;

namespace SkinHex.Core.Interfaces.Repositories;

public interface IItemRepository
{
    Task<Item?> GetByMarketHashNameAsync(string hashName, CancellationToken ct);
    Task<IReadOnlyDictionary<string, Item>> GetByMarketHashNamesAsync(
        IReadOnlyCollection<string> hashNames,
        CancellationToken ct);
    Task<IReadOnlyList<Item>> GetByBaseNameAsync(string baseName, CancellationToken ct);
    Task<IReadOnlyList<MarketSearchTipDto>> SearchTipsAsync(string query, int limit, CancellationToken ct);

    /// <summary>Individual items matching the query (ungrouped), ranked by relevance — for the header item search.</summary>
    Task<IReadOnlyList<Item>> SearchItemsAsync(string query, int limit, CancellationToken ct);
}
