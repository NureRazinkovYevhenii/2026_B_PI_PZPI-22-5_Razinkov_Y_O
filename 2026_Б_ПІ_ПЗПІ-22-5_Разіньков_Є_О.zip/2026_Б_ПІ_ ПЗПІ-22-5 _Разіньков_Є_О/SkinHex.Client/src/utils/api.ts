export class ApiError extends Error {
  public status: number;
  public payload: any;

  constructor(message: string, status: number, payload: any) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.payload = payload;
  }
}

export async function readApiError(response: Response) {
  const responseCopy = response.clone();

  try {
    const payload = (await response.json()) as unknown;

    if (typeof payload === 'string') {
      return payload;
    }

    if (payload && typeof payload === 'object') {
      const record = payload as Record<string, unknown>;

      if (typeof record.message === 'string') {
        return record.message;
      }

      if (typeof record.detail === 'string') {
        return record.detail;
      }

      if (typeof record.title === 'string') {
        return record.title;
      }

      if (Array.isArray(record.errors)) {
        return record.errors
          .map((error) => {
            if (typeof error === 'string') {
              return error;
            }

            if (error && typeof error === 'object' && typeof (error as Record<string, unknown>).message === 'string') {
              return (error as Record<string, string>).message;
            }

            return null;
          })
          .filter(Boolean)
          .join(' ');
      }
    }
  } catch {
    const text = await responseCopy.text();

    if (text) {
      return text;
    }
  }

  return `Request failed with status ${response.status}.`;
}

