using SkinHex.Core.Entities;

namespace SkinHex.Core.Interfaces.Repositories;

public interface IItemScreenshotRepository
{
    Task<ItemScreenshot?> GetByIdAsync(Guid id, CancellationToken ct = default);
    Task<List<ItemScreenshot>> GetByInspectHexesAsync(IReadOnlyCollection<string> inspectHexes, CancellationToken ct = default);
    void Add(ItemScreenshot screenshot);
}
