﻿namespace SkinHex.Core.Entities;

public class Item
{
    public int Id { get; set; }
    public int? CollectionId { get; set; }

    public required string MarketHashName { get; set; } // "StatTrak™ AK-47 | Neon Rider (Field-Tested)"
    public required string BaseName { get; set; }       // "AK-47 | Neon Rider"
    public required string Category { get; set; }       // "Rifle", "Container", "Agent"
    public string? Weapon { get; set; }                 // "AK-47", null для кейсів
    public required string Rarity { get; set; }         // "Covert", "Mil-Spec"
    public string? Wear { get; set; }                   // "Factory New", "Field-Tested", null для кейсів

    public bool IsStatTrak { get; set; }
    public bool IsSouvenir { get; set; }

    public required string Color { get; set; }          // "eb4b4b"
    public required string ImageHash { get; set; }

    // Navigation
    public ICollection<Listing> Listings { get; set; } = new List<Listing>();
}