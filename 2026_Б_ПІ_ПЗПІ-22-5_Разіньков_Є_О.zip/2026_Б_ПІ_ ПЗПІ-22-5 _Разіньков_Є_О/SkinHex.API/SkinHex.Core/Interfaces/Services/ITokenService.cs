using FluentResults;
using SkinHex.Core.Entities;
using SkinHex.Core.Models.Auth;

namespace SkinHex.Core.Interfaces;

public interface ITokenService
{
    Result<TokenResult> GenerateTokens(User user);
    Result<string> GenerateAccessToken(User user);
}
