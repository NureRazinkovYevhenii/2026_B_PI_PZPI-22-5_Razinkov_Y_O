namespace SkinHex.Core.Models.Auth;

public sealed record RefreshTokenRequest(string RefreshToken);
