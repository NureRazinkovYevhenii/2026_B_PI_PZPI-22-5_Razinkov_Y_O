namespace SkinHex.Core.Interfaces.Services;

public interface IScreenshotJobs
{
    Task CaptureAsync(Guid screenshotId, CancellationToken ct);
}
