import React, { useEffect, useState } from 'react';
import { getDepositStatus } from '../api/depositApi';

export const DepositPendingPage: React.FC = () => {
  const [status, setStatus] = useState<string>('Waiting');
  const [fiatAmount, setFiatAmount] = useState<number>(0);
  const [error, setError] = useState('');

  useEffect(() => {
    const depositId = localStorage.getItem('last_deposit_id');
    if (!depositId) {
      setError('No pending deposit found.');
      return;
    }

    let intervalId: ReturnType<typeof setInterval>;

    const checkStatus = async () => {
      try {
        const response = await getDepositStatus(depositId);
        setStatus(response.status);
        setFiatAmount(response.fiatAmount);

        if (response.status === 'Finished' || response.status === 'Failed' || response.status === 'Expired') {
          clearInterval(intervalId);
          localStorage.removeItem('last_deposit_id');
        }
      } catch (err: any) {
        console.error(err);
      }
    };

    // Check immediately, then every 5 seconds
    checkStatus();
    intervalId = setInterval(checkStatus, 5000);

    return () => {
      clearInterval(intervalId);
    };
  }, []);

  return (
    <div className="container" style={{ maxWidth: '600px', margin: '0 auto', padding: '60px 20px', textAlign: 'center' }}>
      <div style={{ backgroundColor: 'var(--surface-color, #1A1A1A)', padding: '40px 24px', borderRadius: '16px' }}>
        
        {error ? (
          <div>
            <h2 style={{ color: '#ff4d4f', marginBottom: '16px' }}>Error</h2>
            <p style={{ color: '#aaa' }}>{error}</p>
          </div>
        ) : (
          <div>
            {status === 'Finished' ? (
              <div>
                <div style={{ fontSize: '48px', marginBottom: '16px' }}>✅</div>
                <h2 style={{ color: '#00B14F', marginBottom: '16px', fontSize: '28px' }}>Payment Confirmed!</h2>
                <p style={{ color: '#ccc', fontSize: '18px' }}>Your deposit of ${fiatAmount.toFixed(2)} has been credited to your balance.</p>
                <a href="/profile" style={{ display: 'inline-block', marginTop: '24px', color: '#00B14F', textDecoration: 'underline' }}>
                  Return to Profile
                </a>
              </div>
            ) : status === 'Failed' || status === 'Expired' ? (
              <div>
                <div style={{ fontSize: '48px', marginBottom: '16px' }}>❌</div>
                <h2 style={{ color: '#ff4d4f', marginBottom: '16px', fontSize: '28px' }}>Payment {status}</h2>
                <p style={{ color: '#ccc', fontSize: '18px' }}>Your deposit could not be completed.</p>
                <a href="/deposit" style={{ display: 'inline-block', marginTop: '24px', color: '#00B14F', textDecoration: 'underline' }}>
                  Try Again
                </a>
              </div>
            ) : (
              <div>
                <div style={{ fontSize: '48px', marginBottom: '24px', animation: 'spin 2s linear infinite' }}>⏳</div>
                <h2 style={{ marginBottom: '16px', fontSize: '24px' }}>Waiting for payment...</h2>
                <p style={{ color: '#aaa', marginBottom: '8px' }}>
                  Current Status: <strong style={{ color: 'white' }}>{status}</strong>
                </p>
                <p style={{ color: '#888', fontSize: '14px', maxWidth: '400px', margin: '0 auto' }}>
                  Please do not close this window. We are waiting for network confirmations.
                  This may take a few minutes depending on the cryptocurrency.
                </p>
              </div>
            )}
          </div>
        )}
      </div>

      <style>{`
        @keyframes spin {
          100% { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
};
