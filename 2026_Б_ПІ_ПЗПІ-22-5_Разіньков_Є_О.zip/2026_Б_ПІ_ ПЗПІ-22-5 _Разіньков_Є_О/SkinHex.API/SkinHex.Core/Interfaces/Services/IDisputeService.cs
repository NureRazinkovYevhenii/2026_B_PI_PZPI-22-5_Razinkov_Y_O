using SkinHex.Core.Entities;
using SkinHex.Core.Models.Disputes;

namespace SkinHex.Core.Interfaces.Services;

public interface IDisputeService
{
    /// <summary>Opens a dispute on behalf of an order participant. Allowed on TradeSent/InEscrow
    /// orders and on Cancelled orders within the appeal window.</summary>
    Task<DisputeDto> OpenDisputeAsync(Guid orderId, Guid userId, DisputeReason reason, string description, CancellationToken ct = default);

    /// <summary>Opens a system dispute and saves immediately (joins an ambient transaction when present).
    /// Returns null when the order already has an open dispute — the existing one covers the case.</summary>
    Task<OrderDispute?> OpenSystemDisputeAsync(Guid orderId, DisputeReason reason, string description, decimal? frozenPenaltyAmount = null, CancellationToken ct = default);

    Task<IReadOnlyCollection<DisputeDto>> GetMyDisputesAsync(Guid userId, CancellationToken ct = default);
    Task<DisputeDto> GetDisputeAsync(Guid disputeId, Guid userId, CancellationToken ct = default);

    /// <summary>Admin takes the dispute into review.</summary>
    Task<DisputeDto> TakeUnderReviewAsync(Guid disputeId, Guid adminId, CancellationToken ct = default);

    /// <summary>Admin resolves the dispute; balance movements are posted to the financial ledger.</summary>
    Task<DisputeDto> ResolveDisputeAsync(Guid disputeId, Guid adminId, DisputeResolution resolution, string? note, CancellationToken ct = default);
}
