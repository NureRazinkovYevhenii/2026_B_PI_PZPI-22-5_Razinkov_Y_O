using SkinHex.Core.Entities;

namespace SkinHex.Core.Models.Orders;

public record OrderItemDto(
    string MarketHashName,
    string? Wear,
    double? Float);

public record OrderDto(
    Guid OrderId,
    Guid ListingId,
    string Role,
    OrderStatus Status,
    decimal Price,
    DateTime CreatedAt,
    DateTime? ConfirmDeadline,
    DateTime? SendTradeDeadline,
    DateTime? TradeAcceptDeadline,
    DateTime? EscrowEndsAt,
    DateTime? BuyerCancelableAt,
    OrderStatus? CancelledAtStatus,
    string? CancelledBy,
    string? CancelReason,
    OrderParticipantDto Partner,
    OrderItemDto Item,
    SteamTradeDto? ActiveTrade);

public record SteamTradeDto(
    Guid TradeId,
    string TradeOfferId,
    string? SteamTradeId,
    SteamOfferState OfferState,
    SteamTradeStatus? TradeStatus,
    DateTime CreatedAt,
    DateTime UpdatedAt);

public record CreateTradeAttemptRequest(
    string TradeOfferId,
    SteamOfferState OfferState);

public record UpdateTradeAttemptRequest(
    string TradeOfferId,
    SteamOfferState OfferState,
    string? TradeId,
    SteamTradeStatus? TradeStatus,
    long? TimeUpdated);
