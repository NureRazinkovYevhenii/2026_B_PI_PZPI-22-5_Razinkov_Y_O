using SkinHex.Core.Models;
using SkinHex.SteamGateway.Proxies;

namespace SkinHex.SteamGateway.Steam;

public sealed class SteamInventoryClient(
    HttpClient httpClient,
    ISteamBotSessionProvider sessionProvider,
    ILogger<SteamInventoryClient> logger) : ISteamInventoryClient
{
    public async Task<IReadOnlyList<InventoryItemDto>> FetchInventoryAsync(
        SteamInventoryRequest request,
        CancellationToken cancellationToken = default)
    {
        var session = await sessionProvider.GetAnyReadySessionAsync(cancellationToken);
        if (string.IsNullOrWhiteSpace(session.SessionId) ||
            string.IsNullOrWhiteSpace(session.SteamLoginSecure))
        {
            throw new SteamIntegrationException("No valid Steam bot session is currently available.");
        }

        var sessionId = Uri.EscapeDataString(session.SessionId);
        var requestUri =
            $"tradeoffer/new/partnerinventory/?sessionid={sessionId}" +
            $"&partner={request.SteamId64}&appid=730&contextid=2";
        if (request.ForceReload)
        {
            requestUri += $"&_={DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()}";
        }

        using var httpRequest = new HttpRequestMessage(HttpMethod.Get, requestUri);
        if (request.Referrer is not null)
        {
            httpRequest.Headers.Referrer = request.Referrer;
        }

        httpRequest.Headers.Add("X-Requested-With", "XMLHttpRequest");
        httpRequest.Headers.Add("X-Prototype-Version", "1.7");
        httpRequest.Headers.Add(
            "Cookie",
            $"sessionid={session.SessionId}; steamLoginSecure={session.SteamLoginSecure}");

        using var response = await httpClient.SendAsync(
            httpRequest,
            HttpCompletionOption.ResponseHeadersRead,
            cancellationToken);

        Console.WriteLine("__________________________________________________");
        var rawJson = await response.Content.ReadAsStringAsync(cancellationToken);

        // Ban/unavailable signals must be checked first, otherwise broad EResult=15
        // handling can mask the real initiator for rollback attribution.
        if (SteamInventoryResponseParser.IsTradePartnerUnavailable(rawJson))
        {
            logger.LogWarning(
                "Steam partner unavailable detected for partner {PartnerId}. Response preview: {Preview}",
                request.PartnerAccountId,
                TruncateForLog(rawJson));
            throw new SteamTradePartnerUnavailableException();
        }

        if (SteamInventoryResponseParser.IsTradeUrlExpired(rawJson))
        {
            logger.LogWarning(
                "Steam trade URL expired/invalid detected for partner {PartnerId}. Response preview: {Preview}",
                request.PartnerAccountId,
                TruncateForLog(rawJson));
            throw new SteamTradeUrlExpiredException();
        }

        if (!response.IsSuccessStatusCode)
        {
            // Steam rate-limited/blocked this bot: quarantine it so the next request
            // picks a different account instead of hammering the flagged one.
            if (ProxyPenaltyHandler.ShouldPenalize(response.StatusCode))
            {
                sessionProvider.Quarantine(
                    session.Username,
                    $"Steam returned {(int)response.StatusCode} on partnerinventory.");
            }

            throw new SteamIntegrationException(
                "Steam inventory request failed.",
                response.StatusCode,
                rawJson);
        }

        return SteamInventoryResponseParser.Parse(rawJson);
    }

    private static string TruncateForLog(string raw)
    {
        const int max = 1200;
        if (string.IsNullOrEmpty(raw) || raw.Length <= max)
            return raw;

        return raw[..max] + "...";
    }

    public async Task ValidateTradeLinkAsync(
        SteamInventoryRequest request,
        CancellationToken cancellationToken = default)
    {
        if (request.Referrer is null)
            throw new ArgumentException("Referrer (trade URL) is required for validation.", nameof(request));

        var session = await sessionProvider.GetAnyReadySessionAsync(cancellationToken);
        if (string.IsNullOrWhiteSpace(session.SessionId) ||
            string.IsNullOrWhiteSpace(session.SteamLoginSecure))
        {
            throw new SteamIntegrationException("No valid Steam bot session is currently available.");
        }

        using var httpRequest = new HttpRequestMessage(HttpMethod.Get, request.Referrer);
        httpRequest.Headers.Add("Cookie", $"sessionid={session.SessionId}; steamLoginSecure={session.SteamLoginSecure}");

        using var response = await httpClient.SendAsync(
            httpRequest,
            HttpCompletionOption.ResponseHeadersRead,
            cancellationToken);

        var html = await response.Content.ReadAsStringAsync(cancellationToken);

        if (SteamInventoryResponseParser.IsTradePartnerUnavailable(html))
        {
            logger.LogWarning(
                "Steam partner unavailable detected for partner {PartnerId}. HTML preview: {Preview}",
                request.PartnerAccountId,
                TruncateForLog(html));
            throw new SteamTradePartnerUnavailableException();
        }

        if (SteamInventoryResponseParser.IsTradeUrlExpired(html))
        {
            logger.LogWarning(
                "Steam trade URL expired/invalid detected for partner {PartnerId}. HTML preview: {Preview}",
                request.PartnerAccountId,
                TruncateForLog(html));
            throw new SteamTradeUrlExpiredException();
        }
    }
}
