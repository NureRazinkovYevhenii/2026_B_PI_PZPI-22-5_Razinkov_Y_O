import type { AuthorizedFetch, Order, OrderRoleFilter } from '../types';
import { readApiError } from './api';

type CreateOrderResponse = {
  id: string;
  listingId: string;
  status: number;
  lockPrice: number;
  createdAt: string;
  confirmDeadline: string;
  buyer: { id: string; username: string; avatarUrl: string | null };
  seller: { id: string; username: string; avatarUrl: string | null };
};

export async function createOrder(
  authorizedFetch: AuthorizedFetch,
  listingId: string,
): Promise<CreateOrderResponse> {
  const response = await authorizedFetch('/orders', {
    method: 'POST',
    body: JSON.stringify({ listingId }),
  });

  if (!response.ok) {
    throw new Error(await readApiError(response));
  }

  return (await response.json()) as CreateOrderResponse;
}

export async function getUserOrders(
  authorizedFetch: AuthorizedFetch,
  role?: OrderRoleFilter,
): Promise<Order[]> {
  const params = new URLSearchParams();

  if (role) {
    params.set('role', role);
  }

  const query = params.toString();
  const response = await authorizedFetch(`/orders/my${query ? `?${query}` : ''}`);

  if (!response.ok) {
    throw new Error(await readApiError(response));
  }

  return (await response.json()) as Order[];
}

export async function confirmOrder(
  authorizedFetch: AuthorizedFetch,
  orderId: string,
): Promise<Order> {
  const response = await authorizedFetch(`/orders/${orderId}/confirm`, {
    method: 'POST',
  });

  if (!response.ok) {
    let payload;
    try { payload = await response.clone().json(); } catch {}
    throw new (await import('./api')).ApiError(await readApiError(response), response.status, payload);
  }

  return (await response.json()) as Order;
}

export async function cancelOrder(
  authorizedFetch: AuthorizedFetch,
  orderId: string,
  reason?: string | null,
): Promise<Order> {
  const response = await authorizedFetch(`/orders/${orderId}/cancel`, {
    method: 'POST',
    body: reason ? JSON.stringify({ reason }) : '{}',
  });

  if (!response.ok) {
    let payload;
    try { payload = await response.clone().json(); } catch {}
    throw new (await import('./api')).ApiError(await readApiError(response), response.status, payload);
  }

  return (await response.json()) as Order;
}

export async function createTradeAttempt(
  authorizedFetch: AuthorizedFetch,
  orderId: string,
  tradeOfferId: string,
  offerState: number
): Promise<any> {
  const response = await authorizedFetch(`/orders/${orderId}/trade`, {
    method: 'POST',
    body: JSON.stringify({ tradeOfferId, offerState }),
  });

  if (!response.ok) {
    let payload;
    try { payload = await response.clone().json(); } catch {}
    throw new (await import('./api')).ApiError(await readApiError(response), response.status, payload);
  }

  return (await response.json());
}

export async function updateTradeAttempt(
  authorizedFetch: AuthorizedFetch,
  orderId: string,
  tradeOfferId: string,
  offerState: number,
  tradeId?: string | null,
  tradeStatus?: number | null
): Promise<any> {
  const response = await authorizedFetch(`/orders/${orderId}/trade`, {
    method: 'PUT',
    body: JSON.stringify({ tradeOfferId, offerState, tradeId, tradeStatus }),
  });

  if (!response.ok) {
    let payload;
    try { payload = await response.clone().json(); } catch {}
    throw new (await import('./api')).ApiError(await readApiError(response), response.status, payload);
  }

  return (await response.json());
}
