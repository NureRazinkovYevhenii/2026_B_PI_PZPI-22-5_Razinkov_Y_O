namespace SkinHex.Core.Entities;

public enum FinancialTransactionType
{
    Deposit = 0,
    Withdrawal = 1,
    Purchase = 2,
    Sale = 3,
    Commission = 4,
    Penalty = 5,
    AdminAdjustment = 6,
    Refund = 7
}

public enum FinancialTransactionStatus
{
    Pending = 0,
    Completed = 1,
    Failed = 2,
    Cancelled = 3
}

public class FinancialTransaction
{
    public Guid Id { get; set; }
    public Guid UserId { get; set; }
    public decimal Amount { get; set; } 
    public FinancialTransactionType Type { get; set; }
    public FinancialTransactionStatus Status { get; set; }
    public Guid? ReferenceId { get; set; } 
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    
    public User User { get; set; } = null!;
}
