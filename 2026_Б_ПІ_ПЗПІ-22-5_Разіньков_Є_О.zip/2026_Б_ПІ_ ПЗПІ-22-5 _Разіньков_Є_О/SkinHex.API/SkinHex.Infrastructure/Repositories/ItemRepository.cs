using Microsoft.EntityFrameworkCore;
using SkinHex.Core.Entities;
using SkinHex.Core.Interfaces.Repositories;
using SkinHex.Core.Models;

namespace SkinHex.Infrastructure.Repositories;

public class ItemRepository : IItemRepository
{
    private readonly SkinHexDbContext _context;

    public ItemRepository(SkinHexDbContext context)
    {
        _context = context;
    }

    public Task<Item?> GetByMarketHashNameAsync(string hashName, CancellationToken ct = default)
    {
        return _context.Items.FirstOrDefaultAsync(i => i.MarketHashName == hashName, ct);
    }

    public async Task<IReadOnlyDictionary<string, Item>> GetByMarketHashNamesAsync(
        IReadOnlyCollection<string> hashNames,
        CancellationToken ct = default)
    {
        if (hashNames.Count == 0)
        {
            return new Dictionary<string, Item>();
        }

        return await _context.Items
            .Where(item => hashNames.Contains(item.MarketHashName))
            .ToDictionaryAsync(item => item.MarketHashName, ct);
    }

    public async Task<IReadOnlyList<Item>> GetByBaseNameAsync(string baseName, CancellationToken ct = default)
    {
        var normalizedBaseName = baseName.Trim();

        return await _context.Items
            .AsNoTracking()
            .Where(item => item.BaseName == normalizedBaseName)
            .OrderBy(item => item.Id)
            .ToListAsync(ct);
    }

    public async Task<IReadOnlyList<Item>> SearchItemsAsync(
        string query,
        int limit,
        CancellationToken ct)
    {
        var normalizedQuery = query.Trim();
        var terms = normalizedQuery.Split(' ', StringSplitOptions.RemoveEmptyEntries);

        var queryable = _context.Items.AsNoTracking();

        foreach (var term in terms)
        {
            var likePattern = $"%{term}%";
            queryable = queryable.Where(item => EF.Functions.ILike(item.MarketHashName, likePattern));
        }

        var prefixPattern = $"{normalizedQuery}%";

        return await queryable
            .OrderByDescending(item => EF.Functions.ILike(item.BaseName, prefixPattern))
            .ThenBy(item => item.BaseName)
            .ThenBy(item => item.MarketHashName)
            .Take(limit)
            .ToListAsync(ct);
    }

    public async Task<IReadOnlyList<MarketSearchTipDto>> SearchTipsAsync(
        string query,
        int limit,
        CancellationToken ct)
    {
        var normalizedQuery = query.Trim();
        var terms = normalizedQuery.Split(' ', StringSplitOptions.RemoveEmptyEntries);

        var queryable = _context.Items.AsNoTracking();

        foreach (var term in terms)
        {
            var likePattern = $"%{term}%";
            queryable = queryable.Where(item =>
                EF.Functions.ILike(item.BaseName, likePattern) ||
                EF.Functions.ILike(item.MarketHashName, likePattern));
        }

        var matchingBaseNames = await queryable
            .Select(item => item.BaseName)
            .Distinct()
            .Take(limit * 10)
            .ToListAsync(ct);

        return matchingBaseNames
            .Select(bn => ItemNameParser.StripWear(bn))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .OrderByDescending(n => n.StartsWith(normalizedQuery, StringComparison.OrdinalIgnoreCase))
            .ThenBy(n => n)
            .Take(limit)
            .Select(name => new MarketSearchTipDto { BaseName = name })
            .ToList();
    }
}
