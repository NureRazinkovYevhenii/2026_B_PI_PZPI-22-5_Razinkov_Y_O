namespace SkinHex.Infrastructure.Options;

public sealed class SmtpOptions
{
    public string Host { get; init; } = string.Empty;
    public int Port { get; init; }
    public string User { get; init; } = string.Empty;
    public string Password { get; init; } = string.Empty;
    public string FromName { get; init; } = string.Empty;
    public string FromEmail { get; init; } = string.Empty;
}
