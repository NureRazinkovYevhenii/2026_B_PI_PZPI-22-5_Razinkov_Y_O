namespace SkinHex.Core.Models.Auth;

public sealed record SteamUserInfo(
    string SteamId,
    string Username,
    string? AvatarUrl);
