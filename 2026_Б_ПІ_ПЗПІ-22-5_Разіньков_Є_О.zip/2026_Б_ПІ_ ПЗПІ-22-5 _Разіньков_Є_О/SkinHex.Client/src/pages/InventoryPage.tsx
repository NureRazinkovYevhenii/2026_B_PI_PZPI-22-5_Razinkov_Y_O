import { useCallback, useEffect, useState, useMemo, useRef } from 'react';
import { Search, RefreshCw, ChevronDown } from 'lucide-react';
import { CardSkeletonGrid } from '../components/CardSkeletonGrid';
import { InventoryCard } from '../components/InventoryCard';
import { SalePanel } from '../components/SalePanel';
import { ItemDetailModal } from '../components/ItemDetailModal';
import type { AuthState, AuthorizedFetch, InventoryItem, InventoryItemGroup, ItemDictionaryEntry, SaleItem, SortOption } from '../types';
import { readApiError } from '../utils/api';
import { getItemStatic, loadItemDictionary } from '../utils/itemDictionary';
import { getRarityOrder } from '../utils/inventory';
import { useTranslation } from 'react-i18next';

type InventoryPageProps = {
  auth: AuthState | null;
  authorizedFetch: AuthorizedFetch;
  onAuthUpdate: (auth: AuthState) => void;
  onRequireLogin: () => void;
  onRequireVerification: () => void;
};

export function InventoryPage({ auth, authorizedFetch, onAuthUpdate, onRequireLogin, onRequireVerification }: InventoryPageProps) {
  const { t } = useTranslation();
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [itemDictionary, setItemDictionary] = useState<Record<string, ItemDictionaryEntry>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [tradeUrl, setTradeUrl] = useState(() => auth?.tradeUrl ?? '');
  const [isSavingTradeUrl, setIsSavingTradeUrl] = useState(false);
  const [tradeUrlError, setTradeUrlError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  // Multi-item sale panel state
  const [saleItems, setSaleItems] = useState<SaleItem[]>([]);
  const [isCreatingSale, setIsCreatingSale] = useState(false);
  const [saleError, setSaleError] = useState<string | null>(null);

  // Search & sort
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOption, setSortOption] = useState<SortOption>('name-asc');
  const [isSortOpen, setIsSortOpen] = useState(false);
  const sortRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent | TouchEvent) => {
      if (sortRef.current && !sortRef.current.contains(event.target as Node)) {
        setIsSortOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside, true);
    document.addEventListener('touchstart', handleClickOutside, true);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside, true);
      document.removeEventListener('touchstart', handleClickOutside, true);
    };
  }, []);

  // Detail modal
  const [detailItem, setDetailItem] = useState<{ item: InventoryItem; itemStatic: ItemDictionaryEntry | null } | null>(null);

  useEffect(() => {
    setTradeUrl(auth?.tradeUrl ?? '');
  }, [auth?.tradeUrl]);

  const handleSaveTradeUrl = async () => {
    if (!auth) return;
    const trimmedTradeUrl = tradeUrl.trim();
    if (!trimmedTradeUrl) {
      setTradeUrlError('Enter Trade URL.');
      return;
    }
    setIsSavingTradeUrl(true);
    setTradeUrlError(null);
    setNotice(null);
    try {
      const response = await authorizedFetch('/user/trade-url', {
        method: 'POST',
        body: JSON.stringify({ tradeUrl: trimmedTradeUrl }),
      });
      if (!response.ok) throw new Error(await readApiError(response));
      onAuthUpdate({ ...auth, tradeUrl: trimmedTradeUrl });
      setNotice(t('inventory.tradeUrlSaved'));
    } catch (err) {
      setTradeUrlError(err instanceof Error ? err.message : t('inventory.tradeUrlFailed'));
    } finally {
      setIsSavingTradeUrl(false);
    }
  };

  const loadInventory = useCallback(async (forceReload = false) => {
    if (!auth) {
      setItems([]);
      setError(null);
      return;
    }
    if (!auth.tradeUrl) {
      setItems([]);
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const [response, dictionary] = await Promise.all([
        authorizedFetch(`/user/inventory${forceReload ? '?reload=true' : ''}`),
        loadItemDictionary(),
      ]);

      if (!response.ok) {
        throw new Error(await readApiError(response));
      }

      setItemDictionary(dictionary);
      setItems((await response.json()) as InventoryItem[]);
    } catch (loadError) {
      setItems([]);
      setError(loadError instanceof Error ? loadError.message : 'Failed to load inventory.');
    } finally {
      setIsLoading(false);
    }
  }, [auth, authorizedFetch]);

  useEffect(() => {
    void loadInventory();
  }, [loadInventory]);

  // Group items: items without float (or float=0) get grouped by marketHashName
  const groupedItems = useMemo(() => {
    const groups: { [key: string]: InventoryItemGroup } = {};
    const result: InventoryItemGroup[] = [];

    for (const item of items) {
      if (item.floatValue == null || item.floatValue === 0) {
        if (!groups[item.marketHashName]) {
          groups[item.marketHashName] = { items: [], count: 0 };
          result.push(groups[item.marketHashName]);
        }
        groups[item.marketHashName].items.push(item);
        groups[item.marketHashName].count++;
      } else {
        result.push({ items: [item], count: 1 });
      }
    }
    return result;
  }, [items]);

  // Filter & sort
  const filteredAndSorted = useMemo(() => {
    let filtered = groupedItems;

    // Search filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      filtered = filtered.filter(g =>
        g.items[0].marketHashName.toLowerCase().includes(q)
      );
    }

    // Sort
    const sorted = [...filtered];
    sorted.sort((a, b) => {
      const itemA = a.items[0];
      const itemB = b.items[0];
      const staticA = getItemStatic(itemDictionary, itemA.marketHashName);
      const staticB = getItemStatic(itemDictionary, itemB.marketHashName);

      switch (sortOption) {
        case 'name-asc':
          return itemA.marketHashName.localeCompare(itemB.marketHashName);
        case 'name-desc':
          return itemB.marketHashName.localeCompare(itemA.marketHashName);
        case 'float-asc':
          return (itemA.floatValue ?? 2) - (itemB.floatValue ?? 2);
        case 'float-desc':
          return (itemB.floatValue ?? -1) - (itemA.floatValue ?? -1);
        case 'rarity':
          return getRarityOrder(staticA?.rarity ?? '') - getRarityOrder(staticB?.rarity ?? '');
        default:
          return 0;
      }
    });

    return sorted;
  }, [groupedItems, searchQuery, sortOption, itemDictionary]);

  // Sale panel helpers
  const saleAssetIds = useMemo(
    () => new Set(saleItems.map(si => si.group.items[0].assetId)),
    [saleItems]
  );

  const isGroupInSale = (group: InventoryItemGroup) =>
    saleAssetIds.has(group.items[0].assetId);

  const toggleSaleItem = (group: InventoryItemGroup) => {
    if (!auth) {
      onRequireLogin();
      return;
    }
    if (!auth.tradeUrl) {
      onRequireVerification();
      return;
    }

    const assetId = group.items[0].assetId;
    if (saleAssetIds.has(assetId)) {
      setSaleItems(prev => prev.filter(si => si.group.items[0].assetId !== assetId));
    } else {
      const itemStatic = getItemStatic(itemDictionary, group.items[0].marketHashName);
      setSaleItems(prev => [...prev, {
        group,
        itemStatic,
        price: '',
        quantity: 1,
      }]);
    }
  };

  const handleUpdateSaleItem = (index: number, updates: Partial<Pick<SaleItem, 'price' | 'quantity'>>) => {
    setSaleItems(prev => prev.map((si, i) => i === index ? { ...si, ...updates } : si));
  };

  const handleRemoveSaleItem = (index: number) => {
    setSaleItems(prev => prev.filter((_, i) => i !== index));
  };

  const handleClearAll = () => {
    setSaleItems([]);
    setSaleError(null);
  };

  const handleSaleSuccess = () => {
    setNotice(t('salePanel.success', 'Item(s) listed for sale successfully!'));
    setSaleItems([]);
    setSaleError(null);
    void loadInventory();
  };

  const handleCardClick = (group: InventoryItemGroup) => {
    const item = group.items[0];
    const itemStatic = getItemStatic(itemDictionary, item.marketHashName);
    setDetailItem({ item, itemStatic });
  };

  const sortLabels: Record<SortOption, string> = {
    'name-asc': t('inventory.sortNameAsc', 'Name A-Z'),
    'name-desc': t('inventory.sortNameDesc', 'Name Z-A'),
    'float-asc': t('inventory.sortFloatAsc', 'Float ↑'),
    'float-desc': t('inventory.sortFloatDesc', 'Float ↓'),
    'rarity': t('inventory.sortRarity', 'Rarity'),
  };

  return (
    <section className="inventory-section" aria-labelledby="inventory-title">
      <div className="inventory-page-layout">
        <div className="inventory-main">
          {/* Header */}
          <div className="inv-toolbar">
            <div className="inv-toolbar-left">
              <h2 id="inventory-title">{t('inventory.eyebrow')}</h2>
              {items.length > 0 && (
                <span className="inv-item-count">
                  {items.length} {t('inventory.itemsLabel', 'items')}
                </span>
              )}
            </div>
            <div className="inv-toolbar-right">
              <button
                className="inv-refresh-btn"
                disabled={!auth || !auth.tradeUrl || isLoading}
                onClick={() => loadInventory(true)}
                type="button"
                title={t('inventory.refresh')}
              >
                <RefreshCw size={16} className={isLoading ? 'spin-animation' : ''} />
              </button>
            </div>
          </div>

          {/* Trade URL banner */}
          {auth && (
            <div className="trade-url-banner">
              <span className="icon" title="Steam Trade URL">🔗</span>
              <span style={{ color: 'var(--text-muted)', fontSize: '14px', fontWeight: 600 }}>Trade URL</span>
              <input
                type="text"
                value={tradeUrl}
                onChange={(e) => { setTradeUrl(e.target.value); setTradeUrlError(null); setNotice(null); }}
                placeholder={t('inventory.tradeUrlPlaceholder')}
              />
              <button className="btn-save" onClick={handleSaveTradeUrl} disabled={isSavingTradeUrl}>
                {isSavingTradeUrl ? t('inventory.saving') : t('inventory.save')}
              </button>
            </div>
          )}
          {tradeUrlError && <p className="inv-notice error">{tradeUrlError}</p>}
          {notice && <p className="inv-notice success">{notice}</p>}

          {/* Search & Sort toolbar */}
          {auth && auth.tradeUrl && !error && !isLoading && items.length > 0 && (
            <div className="inv-filters">
              <div className="inv-search-wrap">
                <Search size={16} className="inv-search-icon" />
                <input
                  type="text"
                  className="inv-search-input"
                  placeholder={t('inventory.searchPlaceholder', 'Search items...')}
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="inv-sort-wrap" ref={sortRef}>
                <button
                  className="inv-sort-btn"
                  onClick={() => setIsSortOpen(!isSortOpen)}
                  type="button"
                >
                  <span>{sortLabels[sortOption]}</span>
                  <ChevronDown size={14} className={isSortOpen ? 'rotate-180' : ''} />
                </button>
                {isSortOpen && (
                  <div className="inv-sort-dropdown glass-panel">
                    {(Object.keys(sortLabels) as SortOption[]).map(opt => (
                      <button
                        key={opt}
                        className={`inv-sort-option ${sortOption === opt ? 'active' : ''}`}
                        onClick={() => { setSortOption(opt); setIsSortOpen(false); }}
                      >
                        {sortLabels[opt]}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Content */}
          {!auth ? (
            <div className="inventory-state">
              <strong>{t('inventory.loginToSee')}</strong>
              <p>{t('inventory.loginDesc')}</p>
            </div>
          ) : !auth.tradeUrl ? (
            <div className="inventory-state">
              <strong>{t('inventory.needTradeUrl')}</strong>
              <p>{t('inventory.needTradeUrlDesc')}</p>
            </div>
          ) : error ? (
            <div className="inventory-state inventory-error" role="alert">
              <strong>{t('inventory.unavailable')}</strong>
              <p>{error}</p>
            </div>
          ) : isLoading ? (
            <CardSkeletonGrid />
          ) : filteredAndSorted.length ? (
            <div className="inventory-grid">
              {filteredAndSorted.map((group, index) => (
                <InventoryCard
                  item={group.items[0]}
                  itemStatic={getItemStatic(itemDictionary, group.items[0].marketHashName)}
                  quantity={group.count}
                  key={group.items[0].assetId || index}
                  isInSalePanel={isGroupInSale(group)}
                  onCardClick={() => handleCardClick(group)}
                  onSellClick={() => toggleSaleItem(group)}
                />
              ))}
            </div>
          ) : searchQuery ? (
            <div className="inventory-state">
              <strong>{t('inventory.noSearchResults', 'No items match your search')}</strong>
              <p>{t('inventory.tryDifferentSearch', 'Try a different search term.')}</p>
            </div>
          ) : (
            <div className="inventory-state">
              <strong>{t('inventory.noItems')}</strong>
              <p>{t('inventory.noItemsDesc')}</p>
            </div>
          )}
        </div>

        {/* Sticky sale panel sidebar */}
        <div className="sale-panel-sidebar">
          <SalePanel
            authorizedFetch={authorizedFetch}
            saleItems={saleItems}
            onUpdateItem={handleUpdateSaleItem}
            onRemoveItem={handleRemoveSaleItem}
            onClearAll={handleClearAll}
            onSuccess={handleSaleSuccess}
            isCreating={isCreatingSale}
            onSetCreating={setIsCreatingSale}
            error={saleError}
            onSetError={setSaleError}
          />
        </div>
      </div>

      {/* Item detail modal */}
      {detailItem && (
        <ItemDetailModal
          source={{ kind: 'inventory', item: detailItem.item }}
          itemStatic={detailItem.itemStatic}
          onClose={() => setDetailItem(null)}
          onSell={() => {
            const group = groupedItems.find(g => g.items[0].assetId === detailItem.item.assetId);
            if (group) toggleSaleItem(group);
            setDetailItem(null);
          }}
          isInSalePanel={saleAssetIds.has(detailItem.item.assetId)}
        />
      )}
    </section>
  );
}
