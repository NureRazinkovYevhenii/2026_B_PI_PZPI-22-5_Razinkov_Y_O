namespace SkinHex.Core.Models.Admin;

public record DashboardStatsDto(
    int TotalUsers,
    int BannedUsers,
    int OpenTickets,
    int PendingOrders,
    decimal TotalUserBalance,
    decimal TotalFrozenBalance,
    int OpenDisputes);
