namespace SkinHex.Core.Models;

/// <summary>Maps our NOWPayments currency codes to a block explorer transaction URL template.</summary>
public static class BlockchainExplorer
{
    private static readonly Dictionary<string, string> TxUrlTemplates = new(StringComparer.OrdinalIgnoreCase)
    {
        ["btc"] = "https://mempool.space/tx/{0}",
        ["eth"] = "https://etherscan.io/tx/{0}",
        ["ltc"] = "https://blockchair.com/litecoin/transaction/{0}",
        ["trx"] = "https://tronscan.org/#/transaction/{0}",
        ["ton"] = "https://tonscan.org/tx/{0}",
        ["bnbbsc"] = "https://bscscan.com/tx/{0}",
        ["usdttrc20"] = "https://tronscan.org/#/transaction/{0}",
        ["usdtbsc"] = "https://bscscan.com/tx/{0}",
        ["usdterc20"] = "https://etherscan.io/tx/{0}",
        ["usdc"] = "https://etherscan.io/tx/{0}",
        ["usdcbsc"] = "https://bscscan.com/tx/{0}",
        ["usdtsol"] = "https://solscan.io/tx/{0}",
        ["usdcsol"] = "https://solscan.io/tx/{0}",
        ["usdtmatic"] = "https://polygonscan.com/tx/{0}",
        ["usdtton"] = "https://tonscan.org/tx/{0}",
    };

    /// <summary>Builds a link to view <paramref name="txHash"/> on the appropriate block explorer, or null if unknown/missing.</summary>
    public static string? BuildTxUrl(string payCurrency, string? txHash)
    {
        if (string.IsNullOrWhiteSpace(txHash))
            return null;

        if (!TxUrlTemplates.TryGetValue(payCurrency, out var template))
            return null;

        return string.Format(template, Uri.EscapeDataString(txHash));
    }
}
