﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SkinHex.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class TlsnPayloadJsonToText : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "PayloadJson",
                table: "TlsnProofRecords",
                type: "text",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "jsonb");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "PayloadJson",
                table: "TlsnProofRecords",
                type: "jsonb",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "text");
        }
    }
}
