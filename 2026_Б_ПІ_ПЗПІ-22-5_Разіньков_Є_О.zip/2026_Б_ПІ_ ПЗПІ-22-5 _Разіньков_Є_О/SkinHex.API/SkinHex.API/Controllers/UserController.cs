using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using FluentResults;
using SkinHex.API.Errors;
using SkinHex.Core.Errors;
using SkinHex.Core.Interfaces;
using SkinHex.Core.Models;
using System.Security.Claims;

namespace SkinHex.API.Controllers;

[ApiController]
[Authorize]
[Route("api/[controller]")]
public sealed class UserController(IUserService _userService) : ControllerBase
{
    [HttpGet("me")]
    public async Task<IActionResult> GetCurrentUser(CancellationToken ct)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _userService.GetCurrentUserAsync(userId.Value, ct);
        if (result.IsFailed)
        {
            return this.ToProblemDetails(result.Errors);
        }

        return Ok(result.Value);
    }

    [HttpGet("balance")]
    public async Task<IActionResult> GetBalance(CancellationToken ct)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _userService.GetBalanceAsync(userId.Value, ct);
        if (result.IsFailed)
        {
            return this.ToProblemDetails(result.Errors);
        }

        return Ok(result.Value);
    }

    [HttpGet("inventory")]
    public async Task<IActionResult> GetInventory([FromQuery] bool reload, CancellationToken ct)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _userService.GetInventoryAsync(userId.Value, reload, ct);
        if (result.IsFailed)
        {
            if (HasErrorCode(result.Errors, BusinessErrorCodes.InventoryReloadRateLimited))
            {
                var retryAfterSeconds = GetRetryAfterSeconds(result.Errors);
                Response.Headers.RetryAfter = retryAfterSeconds.ToString(System.Globalization.CultureInfo.InvariantCulture);
                return this.ToProblemDetails(
                    result.Errors,
                    StatusCodes.Status429TooManyRequests,
                    "Inventory reload rate limited");
            }

            return this.ToProblemDetails(result.Errors);
        }

        return Ok(result.Value);
    }

    [HttpPost("trade-url")]
    public async Task<IActionResult> SaveTradeUrlForCurrentUser([FromBody] SaveTradeUrlRequest request, CancellationToken ct)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        if (string.IsNullOrWhiteSpace(request?.TradeUrl))
        {
            return this.ToProblemDetails([new Error("Trade URL is required.")]);
        }

        var result = await _userService.SaveTradeUrlAsync(userId.Value, request.TradeUrl, ct);
        if (result.IsFailed)
        {
            return this.ToProblemDetails(result.Errors);
        }

        return Ok(new { message = "Trade URL saved successfully." });
    }

    private Guid? GetCurrentUserId()
    {
        var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
        return Guid.TryParse(userId, out var parsedUserId)
            ? parsedUserId
            : null;
    }

    private static bool HasErrorCode(IReadOnlyList<IError> errors, string errorCode)
    {
        return errors.Any(error =>
            error.Metadata.TryGetValue("errorCode", out var value) &&
            string.Equals(value?.ToString(), errorCode, StringComparison.Ordinal));
    }

    private static int GetRetryAfterSeconds(IReadOnlyList<IError> errors)
    {
        var value = errors
            .Select(error => error.Metadata.TryGetValue("retryAfterSeconds", out var metadataValue)
                ? metadataValue
                : null)
            .FirstOrDefault(metadataValue => metadataValue is not null);

        return value is not null && int.TryParse(value.ToString(), out var seconds)
            ? seconds
            : 300;
    }

}

public class SaveTradeUrlRequest
{
    public string? TradeUrl { get; set; }
}
