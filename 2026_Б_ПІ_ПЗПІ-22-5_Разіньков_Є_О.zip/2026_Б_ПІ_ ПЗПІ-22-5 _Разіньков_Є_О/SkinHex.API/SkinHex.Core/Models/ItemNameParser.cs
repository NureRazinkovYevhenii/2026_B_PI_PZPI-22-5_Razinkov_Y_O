using System.Text.RegularExpressions;

namespace SkinHex.Core.Models;

public static partial class ItemNameParser
{
    private static readonly Regex WearSuffixRegex = CreateWearRegex();

    public static string GetSkinName(string baseName)
    {
        var separatorIndex = baseName.LastIndexOf('|');
        return separatorIndex >= 0 && separatorIndex + 1 < baseName.Length
            ? baseName[(separatorIndex + 1)..].Trim()
            : baseName.Trim();
    }

    /// <summary>
    /// Strips the wear suffix like "(Factory New)", "(Field-Tested)", etc. from an item name.
    /// "AK-47 | Asiimov (Factory New)" → "AK-47 | Asiimov"
    /// </summary>
    public static string StripWear(string name)
    {
        return WearSuffixRegex.Replace(name, "").TrimEnd();
    }

    /// <summary>
    /// Strips wear, StatTrak™, and Souvenir to get the raw base name of the item.
    /// "StatTrak™ AK-47 | Asiimov (Factory New)" → "AK-47 | Asiimov"
    /// </summary>
    public static string GetCleanBaseName(string name)
    {
        var clean = StripWear(name);
        clean = clean.Replace("StatTrak™ ", "");
        clean = clean.Replace("Souvenir ", "");
        return clean.Trim();
    }

    [GeneratedRegex(@"\s*\((Factory New|Minimal Wear|Field-Tested|Well-Worn|Battle-Scarred)\)\s*$", RegexOptions.IgnoreCase)]
    private static partial Regex CreateWearRegex();
}
