type CardSkeletonGridProps = {
  count?: number;
};

export function CardSkeletonGrid({ count = 8 }: CardSkeletonGridProps) {
  return (
    <div className="inventory-grid" aria-busy="true">
      {Array.from({ length: count }).map((_, index) => (
        <div className="inventory-card inventory-card-loading" key={index}>
          <span />
          <span />
          <span />
        </div>
      ))}
    </div>
  );
}

