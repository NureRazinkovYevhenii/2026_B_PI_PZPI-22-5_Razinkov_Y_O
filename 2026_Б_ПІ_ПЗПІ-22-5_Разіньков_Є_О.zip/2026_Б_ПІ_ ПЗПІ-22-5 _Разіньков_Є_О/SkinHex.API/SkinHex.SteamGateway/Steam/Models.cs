using System.Text.Json.Serialization;

namespace SkinHex.SteamGateway.Steam;

internal sealed class SteamInventoryResponse
{
    [JsonPropertyName("success")] public bool Success { get; set; }
    [JsonPropertyName("eresult")] public int? EResult { get; set; }
    [JsonPropertyName("message")] public string? Message { get; set; }
    [JsonPropertyName("rgInventory")] public Dictionary<string, RgInventoryItem>? RgInventory { get; set; }
    [JsonPropertyName("rgDescriptions")] public Dictionary<string, RgDescription>? RgDescriptions { get; set; }
    [JsonPropertyName("rgAssetProperties")] public Dictionary<string, List<RgAssetProperty>>? RgAssetProperties { get; set; }
}

internal sealed class RgInventoryItem
{
    [JsonPropertyName("id")] public string Id { get; set; } = null!;
    [JsonPropertyName("classid")] public string ClassId { get; set; } = null!;
    [JsonPropertyName("instanceid")] public string InstanceId { get; set; } = null!;
}

internal sealed class RgDescription
{
    [JsonPropertyName("market_hash_name")] public string MarketHashName { get; set; } = null!;
    [JsonPropertyName("icon_url")] public string IconUrl { get; set; } = null!;
    [JsonPropertyName("tradable")] public int Tradable { get; set; }
    [JsonPropertyName("name_color")] public string NameColor { get; set; } = null!;
    [JsonPropertyName("type")] public string Type { get; set; } = null!;
}

internal sealed class RgAssetProperty
{
    [JsonPropertyName("propertyid")] public int PropertyId { get; set; }
    [JsonPropertyName("float_value")] public string? FloatValue { get; set; }
    [JsonPropertyName("int_value")] public string? IntValue { get; set; }
    [JsonPropertyName("string_value")] public string? StringValue { get; set; }
}
