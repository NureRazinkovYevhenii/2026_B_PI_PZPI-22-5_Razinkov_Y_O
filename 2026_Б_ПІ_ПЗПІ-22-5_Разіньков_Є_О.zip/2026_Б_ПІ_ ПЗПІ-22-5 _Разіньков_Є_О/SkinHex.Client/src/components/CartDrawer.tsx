import { X, Trash2, ShoppingBag } from 'lucide-react';
import { useState } from 'react';
import { useCart } from '../utils/CartContext';
import { useTranslation } from 'react-i18next';
import type { PageKey } from '../types';

type CartDrawerProps = {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (page: PageKey) => void;
};

export function CartDrawer({ isOpen, onClose, onNavigate }: CartDrawerProps) {
  const { cart, removeFromCart, clearCart, checkoutAvailable } = useCart();
  const { t } = useTranslation();
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [checkoutMessage, setCheckoutMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const availableItems = cart.filter(c => c.isAvailable);
  const total = availableItems.reduce((sum, item) => sum + item.price, 0);

  const handleCheckout = async () => {
    if (availableItems.length === 0 || isCheckingOut) {
      return;
    }

    setIsCheckingOut(true);
    setCheckoutMessage(null);

    try {
      const { successCount, failedCount } = await checkoutAvailable();

      if (successCount > 0) {
        onClose();
        onNavigate('orders');
        return;
      }

      if (failedCount > 0) {
        setCheckoutMessage('Checkout failed. Please try again.');
      }
    } finally {
      setIsCheckingOut(false);
    }
  };

  return (
    <>
      <div 
        style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0, 0, 0, 0.5)',
          backdropFilter: 'blur(4px)',
          zIndex: 100
        }}
        onClick={onClose}
      />
      <div 
        className="glass-panel"
        style={{
          position: 'fixed',
          top: 0,
          right: 0,
          bottom: 0,
          width: '400px',
          maxWidth: '100%',
          zIndex: 101,
          display: 'flex',
          flexDirection: 'column',
          borderLeft: '1px solid var(--border)',
          background: 'var(--bg)'
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '24px', borderBottom: '1px solid var(--border)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <ShoppingBag color="var(--accent)" />
            <h2 style={{ margin: 0, fontSize: '20px', color: 'var(--text-h)' }}>{t('cart.title', 'Shopping Cart')}</h2>
          </div>
          <button onClick={onClose} style={{ background: 'transparent', border: 'none', cursor: 'pointer', color: 'var(--text-muted)' }}>
            <X size={24} />
          </button>
        </div>

        <div style={{ flex: 1, overflowY: 'auto', padding: '24px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
          {cart.length === 0 ? (
            <div style={{ textAlign: 'center', color: 'var(--text-muted)', marginTop: '40px' }}>
              <ShoppingBag size={48} style={{ opacity: 0.5, marginBottom: '16px' }} />
              <p>{t('cart.empty', 'Your cart is empty')}</p>
            </div>
          ) : (
            cart.map(item => (
              <div 
                key={item.id} 
                style={{ 
                  display: 'flex', 
                  gap: '16px', 
                  padding: '16px', 
                  borderRadius: '12px', 
                  background: 'var(--surface)', 
                  border: '1px solid var(--border)',
                  opacity: item.isAvailable ? 1 : 0.6
                }}
              >
                <div style={{ width: '80px', height: '60px', background: 'var(--surface-hover)', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  {item.itemImageHash ? (
                    <img src={`https://steamcommunity-a.akamaihd.net/economy/image/${item.itemImageHash}`} alt={item.marketHashName} style={{ maxWidth: '90%', maxHeight: '90%', objectFit: 'contain' }} />
                  ) : (
                    <span style={{ fontSize: '10px', color: 'var(--text-muted)' }}>No Image</span>
                  )}
                </div>
                <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
                  <div style={{ fontSize: '14px', fontWeight: 600, color: 'var(--text-h)', lineHeight: '1.2' }}>
                    {item.marketHashName}
                  </div>
                  {item.floatValue != null && (
                    <div style={{ fontSize: '12px', color: 'var(--text-muted)', marginTop: '4px' }}>
                      Float: {item.floatValue.toFixed(6)}
                      {item.paintSeed != null && <span style={{ marginLeft: '8px' }}>Seed: #{item.paintSeed}</span>}
                    </div>
                  )}
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '8px' }}>
                    {item.isAvailable ? (
                      <span style={{ color: 'var(--accent)', fontWeight: 700 }}>${item.price.toFixed(2)}</span>
                    ) : (
                      <span style={{ color: 'var(--danger)', fontSize: '12px', fontWeight: 600 }}>{t('cart.unavailable', 'Unavailable')}</span>
                    )}
                    <button 
                      onClick={() => removeFromCart(item.id)}
                      style={{ background: 'transparent', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', padding: '4px' }}
                      title="Remove"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {cart.length > 0 && (
          <div style={{ padding: '24px', borderTop: '1px solid var(--border)', background: 'var(--surface)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
              <span style={{ color: 'var(--text-muted)' }}>{t('cart.total', 'Total')}:</span>
              <span style={{ color: 'var(--accent)', fontSize: '24px', fontWeight: 800 }}>${total.toFixed(2)}</span>
            </div>
            <div style={{ display: 'flex', gap: '12px' }}>
              <button 
                onClick={() => clearCart()}
                style={{ flex: 1, padding: '12px', borderRadius: '8px', background: 'transparent', border: '1px solid var(--border)', color: 'var(--text-h)', cursor: 'pointer', fontWeight: 600 }}
              >
                {t('cart.clear', 'Clear')}
              </button>
              <button 
                style={{ flex: 2, padding: '12px', borderRadius: '8px', background: 'var(--brand)', border: 'none', color: '#fff', cursor: 'pointer', fontWeight: 600, opacity: availableItems.length === 0 ? 0.5 : 1 }}
                disabled={availableItems.length === 0}
                onClick={handleCheckout}
              >
                {isCheckingOut ? t('cart.processing', 'Processing...') : t('cart.checkout', 'Checkout')}
              </button>
            </div>
            {checkoutMessage ? (
              <p className="purchase-message" style={{ marginTop: '12px' }}>{checkoutMessage}</p>
            ) : null}
          </div>
        )}
      </div>
    </>
  );
}
