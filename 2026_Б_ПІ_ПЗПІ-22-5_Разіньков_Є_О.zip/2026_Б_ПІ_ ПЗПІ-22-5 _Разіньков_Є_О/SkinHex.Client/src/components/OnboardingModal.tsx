import { useState, useRef, useEffect } from 'react';
import type { ClipboardEvent, FormEvent, KeyboardEvent } from 'react';
import { Mail, Link as LinkIcon, HelpCircle } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import type { AuthState, AuthorizedFetch } from '../types';
import { readApiError } from '../utils/api';
import { buildAuthState, extractTokenPair, isUnverified } from '../utils/auth';

type OnboardingModalProps = {
  auth: AuthState;
  authorizedFetch: AuthorizedFetch;
  onAuthUpdate: (auth: AuthState) => void;
  onClose: () => void;
};

export function OnboardingModal({ auth, authorizedFetch, onAuthUpdate, onClose }: OnboardingModalProps) {
  const { t } = useTranslation();
  const isEmailVerified = !isUnverified(auth);
  const isTradeUrlSet = !!auth.tradeUrl;
  
  const [activeStep, setActiveStep] = useState(isEmailVerified ? 2 : 1);
  
  // Email State
  const [email, setEmail] = useState('');
  const [otpDigits, setOtpDigits] = useState<string[]>(() => Array(6).fill(''));
  const [isCodeSent, setCodeSent] = useState(false);
  const [isSendingCode, setSendingCode] = useState(false);
  const [isVerifying, setVerifying] = useState(false);
  const [emailError, setEmailError] = useState<string | null>(null);
  const [emailNotice, setEmailNotice] = useState<string | null>(null);
  const [cooldown, setCooldown] = useState(0);
  const otpRefs = useRef<Array<HTMLInputElement | null>>([]);
  const otpCode = otpDigits.join('');

  // Trade URL State
  const [tradeUrl, setTradeUrl] = useState(() => auth.tradeUrl ?? '');
  const [isSavingTradeUrl, setIsSavingTradeUrl] = useState(false);
  const [tradeError, setTradeError] = useState<string | null>(null);

  useEffect(() => {
    if (activeStep === 1 && isEmailVerified) {
      setActiveStep(2);
      setEmailError(null);
      setEmailNotice(null);
    } else if (activeStep === 2 && isEmailVerified && isTradeUrlSet) {
      onClose();
    }
  }, [activeStep, isEmailVerified, isTradeUrlSet, onClose]);

  useEffect(() => {
    if (cooldown > 0) {
      const timerId = window.setTimeout(() => setCooldown((c) => c - 1), 1000);
      return () => window.clearTimeout(timerId);
    }
  }, [cooldown]);

  const handleSendCode = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const trimmedEmail = email.trim();

    if (!trimmedEmail) {
      setEmailError(t('onboarding.enterEmail'));
      return;
    }

    setSendingCode(true);
    setEmailError(null);
    setEmailNotice(null);

    try {
      const response = await authorizedFetch('/auth/send-otp', {
        method: 'POST',
        body: JSON.stringify({ email: trimmedEmail }),
      });

      if (!response.ok) {
        throw new Error(await readApiError(response));
      }

      setCodeSent(true);
      setEmailNotice(t('onboarding.codeSent'));
      setCooldown(60);
      window.setTimeout(() => otpRefs.current[0]?.focus(), 0);
    } catch (error) {
      setEmailError(error instanceof Error ? error.message : t('onboarding.sendFailed'));
    } finally {
      setSendingCode(false);
    }
  };

  const handleVerifyEmail = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (otpCode.length !== 6) {
      setEmailError(t('onboarding.enterCode'));
      return;
    }

    setVerifying(true);
    setEmailError(null);
    setEmailNotice(null);

    try {
      const response = await authorizedFetch('/auth/verify-email', {
        method: 'POST',
        body: JSON.stringify({ email: email.trim(), code: otpCode }),
      });

      if (!response.ok) {
        throw new Error(await readApiError(response));
      }

      const responseBody = await response.json();
      const tokenPair = extractTokenPair(responseBody);

      if (!tokenPair) {
        throw new Error('Сервер не повернув токени.');
      }

      onAuthUpdate(
        buildAuthState(
          tokenPair.accessToken,
          tokenPair.refreshToken,
          auth.tradeUrl,
        ),
      );
      setEmailNotice(t('onboarding.emailVerified'));
    } catch (error) {
      setEmailError(error instanceof Error ? error.message : t('onboarding.verifyFailed'));
    } finally {
      setVerifying(false);
    }
  };

  const handleSaveTradeUrl = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const trimmedTradeUrl = tradeUrl.trim();

    if (!trimmedTradeUrl) {
      setTradeError(t('onboarding.enterTradeUrl'));
      return;
    }

    setIsSavingTradeUrl(true);
    setTradeError(null);

    try {
      const response = await authorizedFetch('/user/trade-url', {
        method: 'POST',
        body: JSON.stringify({ tradeUrl: trimmedTradeUrl }),
      });

      if (!response.ok) {
        throw new Error(await readApiError(response));
      }

      onAuthUpdate({ ...auth, tradeUrl: trimmedTradeUrl });
      onClose();
    } catch (error) {
      setTradeError(error instanceof Error ? error.message : t('onboarding.saveFailed'));
    } finally {
      setIsSavingTradeUrl(false);
    }
  };

  const handleOtpChange = (index: number, value: string) => {
    const digits = value.replace(/\D/g, '').slice(0, 6).split('');
    if (digits.length > 1) {
      const nextDigits = Array(6).fill('');
      digits.forEach((digit, digitIndex) => { nextDigits[digitIndex] = digit; });
      setOtpDigits(nextDigits);
      otpRefs.current[Math.min(digits.length, 5)]?.focus();
      return;
    }
    setOtpDigits((currentDigits) => {
      const nextDigits = [...currentDigits];
      nextDigits[index] = digits[0] ?? '';
      return nextDigits;
    });
    if (digits[0] && index < 5) otpRefs.current[index + 1]?.focus();
  };

  const handleOtpPaste = (index: number, event: ClipboardEvent<HTMLInputElement>) => {
    event.preventDefault();
    const pastedDigits = event.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6 - index).split('');
    if (!pastedDigits.length) return;
    setOtpDigits((currentDigits) => {
      const nextDigits = [...currentDigits];
      pastedDigits.forEach((digit, pastedIndex) => { nextDigits[index + pastedIndex] = digit; });
      return nextDigits;
    });
    otpRefs.current[Math.min(index + pastedDigits.length, 5)]?.focus();
  };

  const handleOtpKeyDown = (index: number, event: KeyboardEvent<HTMLInputElement>) => {
    if (event.key !== 'Backspace' || otpDigits[index] || index === 0) return;
    otpRefs.current[index - 1]?.focus();
  };

  return (
    <div className="modal-backdrop" role="presentation">
      <section className="verification-modal glass-panel" style={{ position: 'relative', padding: '32px', maxWidth: '440px', width: '100%', borderRadius: '16px', background: 'var(--surface)' }} role="dialog">
        <div style={{ textAlign: 'center', marginBottom: '24px' }}>
          <h2 style={{ fontSize: '24px', fontWeight: 700, marginBottom: '8px' }}>{t('onboarding.title')}</h2>
          <button aria-label="Закрити" className="icon-button" onClick={onClose} type="button" style={{ position: 'absolute', top: '16px', right: '16px', background: 'transparent', border: 'none', color: 'var(--text-muted)', fontSize: '20px', cursor: 'pointer' }}>
            ✕
          </button>
        </div>

        <div style={{ display: 'flex', gap: '8px', marginBottom: '32px' }}>
          <div style={{ flex: 1, height: '6px', borderRadius: '4px', background: isEmailVerified ? '#10b981' : (activeStep === 1 ? '#f59e0b' : 'var(--border)'), transition: 'background 0.3s ease' }} />
          <div style={{ flex: 1, height: '6px', borderRadius: '4px', background: isTradeUrlSet ? '#10b981' : (activeStep === 2 ? '#f59e0b' : 'var(--border)'), transition: 'background 0.3s ease' }} />
        </div>

        {activeStep === 1 && (
          <div className="animate-fade-in">
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px' }}>
              <div style={{ width: '40px', height: '40px', borderRadius: '50%', background: 'rgba(245, 158, 11, 0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#f59e0b' }}>
                <Mail size={20} />
              </div>
              <div>
                <h3 style={{ fontSize: '18px', fontWeight: 600 }}>{t('onboarding.step1')}</h3>
                <p style={{ color: 'var(--text-muted)', fontSize: '14px' }}>{t('onboarding.step1Desc')}</p>
              </div>
            </div>
            
            <form onSubmit={handleSendCode} style={{ marginBottom: '24px' }}>
              <label style={{ display: 'block', marginBottom: '8px', fontSize: '14px', fontWeight: 500 }}>{t('onboarding.emailLabel')}</label>
              <div style={{ display: 'flex', gap: '12px' }}>
                <input
                  type="email"
                  required
                  placeholder={t('onboarding.emailPlaceholder')}
                  disabled={isCodeSent}
                  onChange={(e) => { setEmail(e.target.value); setEmailError(null); }}
                  value={email}
                  style={{ flex: 1, padding: '12px 16px', borderRadius: '8px', border: '1px solid var(--border)', background: 'var(--bg)', color: 'var(--text)', outline: 'none' }}
                />
                <button className="primary-button" disabled={isSendingCode || cooldown > 0} type="submit" style={{ whiteSpace: 'nowrap' }}>
                  {isSendingCode ? t('onboarding.sending') : cooldown > 0 ? t('onboarding.wait', { time: cooldown }) : t('onboarding.getCode')}
                </button>
              </div>
            </form>

            {isCodeSent && (
              <form onSubmit={handleVerifyEmail} className="animate-fade-in">
                <label style={{ display: 'block', marginBottom: '8px', fontSize: '14px', fontWeight: 500 }}>{t('onboarding.codeLabel')}</label>
                <div style={{ display: 'flex', gap: '8px', marginBottom: '24px' }}>
                  {otpDigits.map((digit, index) => (
                    <input
                      key={index}
                      ref={(el) => { otpRefs.current[index] = el; }}
                      type="text"
                      maxLength={1}
                      value={digit}
                      onChange={(e) => handleOtpChange(index, e.target.value)}
                      onPaste={(e) => handleOtpPaste(index, e)}
                      onKeyDown={(e) => handleOtpKeyDown(index, e)}
                      style={{
                        width: '48px', height: '56px', fontSize: '24px', textAlign: 'center', borderRadius: '8px',
                        border: `1px solid ${emailError ? 'var(--danger)' : 'var(--border)'}`, background: 'var(--bg)', color: 'var(--text)', outline: 'none'
                      }}
                    />
                  ))}
                </div>
                <button className="primary-button" disabled={isVerifying || otpCode.length < 6} type="submit" style={{ width: '100%', padding: '14px' }}>
                  {isVerifying ? t('onboarding.verifying') : t('onboarding.verify')}
                </button>
              </form>
            )}

            {emailError ? <p style={{ color: 'var(--danger)', marginTop: '16px', fontSize: '14px' }}>{emailError}</p> : null}
            {emailNotice ? <p style={{ color: 'var(--brand)', marginTop: '16px', fontSize: '14px' }}>{emailNotice}</p> : null}
          </div>
        )}

        {activeStep === 2 && (
          <div className="animate-fade-in">
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px' }}>
              <div style={{ width: '40px', height: '40px', borderRadius: '50%', background: 'rgba(14, 165, 233, 0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#0ea5e9' }}>
                <LinkIcon size={20} />
              </div>
              <div>
                <h3 style={{ fontSize: '18px', fontWeight: 600 }}>{t('onboarding.step2')}</h3>
                <p style={{ color: 'var(--text-muted)', fontSize: '14px' }}>{t('onboarding.step2Desc')}</p>
              </div>
            </div>
            
            <form onSubmit={handleSaveTradeUrl} style={{ marginBottom: '24px' }}>
              <label style={{ display: 'block', marginBottom: '8px', fontSize: '14px', fontWeight: 500 }}>{t('onboarding.tradeLinkLabel')}</label>
              <input
                type="text"
                placeholder={t('inventory.tradeUrlPlaceholder')}
                onChange={(e) => { setTradeUrl(e.target.value); setTradeError(null); }}
                value={tradeUrl}
                style={{ width: '100%', padding: '12px 16px', borderRadius: '8px', border: '1px solid var(--border)', background: 'var(--bg)', color: 'var(--text)', outline: 'none', marginBottom: '16px' }}
              />
              <button className="primary-button" disabled={isSavingTradeUrl || !tradeUrl.trim()} type="submit" style={{ width: '100%', padding: '14px' }}>
                {isSavingTradeUrl ? t('inventory.saving') : t('onboarding.saveAndFinish')}
              </button>
            </form>
            
            <a href="https://steamcommunity.com/id/me/tradeoffers/privacy" target="_blank" rel="noopener noreferrer" style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--text-muted)', fontSize: '14px', textDecoration: 'none', justifyContent: 'center' }}>
              <HelpCircle size={14} /> {t('onboarding.whereToFind')}
            </a>

            {tradeError ? <p style={{ color: 'var(--danger)', marginTop: '16px', fontSize: '14px' }}>{tradeError}</p> : null}
          </div>
        )}
      </section>
    </div>
  );
}
