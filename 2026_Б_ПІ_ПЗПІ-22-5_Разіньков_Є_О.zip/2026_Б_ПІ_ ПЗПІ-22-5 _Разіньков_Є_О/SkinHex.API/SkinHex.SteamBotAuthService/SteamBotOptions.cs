namespace SkinHex.SteamBotAuthService;

public sealed class SteamBotOptions
{
    public string Username { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public string SharedSecret { get; set; } = string.Empty;
    public string IdentitySecret { get; set; } = string.Empty;
    public string SteamId { get; set; } = string.Empty;
}

public sealed class SteamAuthenticationOptions
{
    public const string SectionName = "SteamAuthentication";

    public int RefreshIntervalMinutes { get; set; } = 60;
    public int ConnectionTimeoutSeconds { get; set; } = 30;
}
