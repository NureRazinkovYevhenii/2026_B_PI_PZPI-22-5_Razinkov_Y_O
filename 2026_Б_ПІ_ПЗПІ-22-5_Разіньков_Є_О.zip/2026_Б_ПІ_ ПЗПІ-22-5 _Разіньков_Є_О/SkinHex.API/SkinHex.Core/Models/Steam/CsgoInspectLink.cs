namespace SkinHex.Core.Models.Steam;

public static class CsgoInspectLink
{
    // Новий формат inspect-посилання: hex-пейлоад приходить з rgAssetProperties (propertyid 6)
    // і зберігається в Listing.Metadata / ItemScreenshot.InspectHex.
    public static string FromHex(string inspectHex)
        => $"steam://run/730//+csgo_econ_action_preview%20{inspectHex}";
}
