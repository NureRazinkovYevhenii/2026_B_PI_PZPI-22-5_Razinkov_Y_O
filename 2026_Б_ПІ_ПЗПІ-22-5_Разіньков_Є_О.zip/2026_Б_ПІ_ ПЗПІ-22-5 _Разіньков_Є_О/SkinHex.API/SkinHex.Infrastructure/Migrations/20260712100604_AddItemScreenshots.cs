﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SkinHex.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class AddItemScreenshots : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<Guid>(
                name: "ScreenshotId",
                table: "Listings",
                type: "uuid",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "ItemScreenshots",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    InspectHex = table.Column<string>(type: "character varying(2048)", maxLength: 2048, nullable: false),
                    Status = table.Column<int>(type: "integer", nullable: false),
                    ExternalGuid = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    FrontImagePath = table.Column<string>(type: "character varying(300)", maxLength: 300, nullable: true),
                    BackImagePath = table.Column<string>(type: "character varying(300)", maxLength: 300, nullable: true),
                    Attempts = table.Column<int>(type: "integer", nullable: false),
                    LastError = table.Column<string>(type: "character varying(1000)", maxLength: 1000, nullable: true),
                    CreatedAt = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false),
                    CompletedAt = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ItemScreenshots", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Listings_ScreenshotId",
                table: "Listings",
                column: "ScreenshotId");

            migrationBuilder.CreateIndex(
                name: "IX_ItemScreenshots_InspectHex",
                table: "ItemScreenshots",
                column: "InspectHex",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Listings_ItemScreenshots_ScreenshotId",
                table: "Listings",
                column: "ScreenshotId",
                principalTable: "ItemScreenshots",
                principalColumn: "Id",
                onDelete: ReferentialAction.SetNull);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Listings_ItemScreenshots_ScreenshotId",
                table: "Listings");

            migrationBuilder.DropTable(
                name: "ItemScreenshots");

            migrationBuilder.DropIndex(
                name: "IX_Listings_ScreenshotId",
                table: "Listings");

            migrationBuilder.DropColumn(
                name: "ScreenshotId",
                table: "Listings");
        }
    }
}
