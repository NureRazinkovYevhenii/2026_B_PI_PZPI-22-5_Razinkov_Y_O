import { useEffect, useRef, useState } from 'react';
import { Snowflake } from 'lucide-react';
import { useTranslation } from 'react-i18next';

type FrozenBalancePillProps = {
  amount: number;
};

/**
 * Icy pill showing funds locked in pending trades. Pulses briefly whenever the
 * amount changes so a realtime BalanceUpdated push is noticeable without a refresh.
 */
export function FrozenBalancePill({ amount }: FrozenBalancePillProps) {
  const { t } = useTranslation();
  const [bump, setBump] = useState(false);
  const prevAmount = useRef(amount);

  useEffect(() => {
    if (prevAmount.current !== amount) {
      prevAmount.current = amount;
      setBump(true);
      const timer = window.setTimeout(() => setBump(false), 700);
      return () => window.clearTimeout(timer);
    }
  }, [amount]);

  if (amount <= 0) {
    return null;
  }

  return (
    <span
      className={`frozen-pill${bump ? ' frozen-pill--bump' : ''}`}
      role="status"
      aria-label={`${t('header.frozen')} $${amount.toFixed(2)}`}
    >
      <Snowflake size={13} className="frozen-pill__flake" strokeWidth={2.5} />
      <span>${amount.toFixed(2)}</span>
      <span className="frozen-pill__tip">{t('header.frozenTooltip')}</span>
    </span>
  );
}
