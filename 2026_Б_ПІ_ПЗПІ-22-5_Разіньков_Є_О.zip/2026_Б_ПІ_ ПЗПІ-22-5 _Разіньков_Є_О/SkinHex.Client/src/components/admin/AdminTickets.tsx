import { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import type { AuthorizedFetch } from '../../types';
import {
  fetchTicket,
  fetchTickets,
  replyToTicket,
  setTicketStatus,
  type TicketDetail,
  type TicketListItem,
  type TicketStatus,
} from '../../api/adminApi';
import { formatDateTime, IdCell, Pager, shortId, StateBlock, StatusBadge } from './adminShared';

type Props = { authorizedFetch: AuthorizedFetch };

const PAGE_SIZE = 20;
const STATUS_OPTIONS = ['', 'Open', 'PendingSupport', 'PendingUser', 'Resolved', 'Closed'];
const CATEGORY_OPTIONS = ['', 'Order', 'Deposit', 'Withdrawal', 'Account', 'Other'];

export function AdminTickets({ authorizedFetch }: Props) {
  const { t } = useTranslation();
  const [status, setStatus] = useState('');
  const [category, setCategory] = useState('');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [items, setItems] = useState<TicketListItem[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await fetchTickets(authorizedFetch, { status, category, search: search.trim(), page, pageSize: PAGE_SIZE });
      setItems(result.items);
      setTotalCount(result.totalCount);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load tickets');
    } finally {
      setLoading(false);
    }
  }, [authorizedFetch, status, category, search, page]);

  useEffect(() => {
    void load();
  }, [load]);

  const onSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1);
    void load();
  };

  return (
    <div>
      <form className="admin-toolbar" onSubmit={onSearchSubmit}>
        <input
          className="admin-input"
          placeholder={t('admin.tickets.searchPlaceholder')}
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <select className="admin-select" value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }}>
          {STATUS_OPTIONS.map((s) => (
            <option key={s} value={s}>{s === '' ? t('admin.tickets.allStatuses') : s}</option>
          ))}
        </select>
        <select className="admin-select" value={category} onChange={(e) => { setCategory(e.target.value); setPage(1); }}>
          {CATEGORY_OPTIONS.map((c) => (
            <option key={c} value={c}>{c === '' ? t('admin.tickets.allCategories') : c}</option>
          ))}
        </select>
        <button className="primary-button" type="submit">{t('admin.search')}</button>
      </form>

      {error ? (
        <StateBlock><strong>{t('admin.error')}</strong><p>{error}</p></StateBlock>
      ) : loading ? (
        <StateBlock><strong>{t('admin.loading')}</strong></StateBlock>
      ) : items.length === 0 ? (
        <StateBlock><strong>{t('admin.tickets.none')}</strong></StateBlock>
      ) : (
        <div className="admin-table-wrap">
          <table className="admin-table">
            <thead>
              <tr>
                <th>{t('admin.id')}</th>
                <th>{t('admin.tickets.subject')}</th>
                <th>{t('admin.tickets.user')}</th>
                <th>{t('admin.tickets.category')}</th>
                <th>{t('admin.tickets.status')}</th>
                <th style={{ textAlign: 'center' }}>{t('admin.tickets.messages')}</th>
                <th>{t('admin.tickets.updated')}</th>
              </tr>
            </thead>
            <tbody>
              {items.map((ticket) => (
                <tr key={ticket.id} className="admin-row" onClick={() => setSelectedId(ticket.id)}>
                  <td><IdCell id={ticket.id} /></td>
                  <td style={{ fontWeight: 600, color: 'var(--text-h)' }}>
                    {ticket.subject}
                    {ticket.orderId && <span className="admin-order-tag">#{shortId(ticket.orderId)}</span>}
                  </td>
                  <td>{ticket.username}</td>
                  <td>{ticket.category}</td>
                  <td><StatusBadge status={ticket.status} /></td>
                  <td style={{ textAlign: 'center' }}>{ticket.messagesCount}</td>
                  <td style={{ color: 'var(--text-muted)', fontSize: 13 }}>{formatDateTime(ticket.updatedAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Pager page={page} pageSize={PAGE_SIZE} totalCount={totalCount} onPage={setPage} />

      {selectedId && (
        <TicketDetailModal
          authorizedFetch={authorizedFetch}
          ticketId={selectedId}
          onClose={() => setSelectedId(null)}
          onChanged={() => void load()}
        />
      )}
    </div>
  );
}

type ModalProps = {
  authorizedFetch: AuthorizedFetch;
  ticketId: string;
  onClose: () => void;
  onChanged: () => void;
};

function TicketDetailModal({ authorizedFetch, ticketId, onClose, onChanged }: ModalProps) {
  const { t } = useTranslation();
  const [detail, setDetail] = useState<TicketDetail | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [reply, setReply] = useState('');
  const [busy, setBusy] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);

  const reload = useCallback(async () => {
    try {
      setDetail(await fetchTicket(authorizedFetch, ticketId));
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load ticket');
    }
  }, [authorizedFetch, ticketId]);

  useEffect(() => {
    void reload();
  }, [reload]);

  const onReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reply.trim()) return;
    setBusy(true);
    setActionError(null);
    try {
      const updated = await replyToTicket(authorizedFetch, ticketId, reply.trim());
      setDetail(updated);
      setReply('');
      onChanged();
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Reply failed');
    } finally {
      setBusy(false);
    }
  };

  const changeStatus = async (next: TicketStatus) => {
    setBusy(true);
    setActionError(null);
    try {
      setDetail(await setTicketStatus(authorizedFetch, ticketId, next));
      onChanged();
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Status change failed');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="admin-modal-overlay" onClick={onClose}>
      <div className="admin-modal glass-panel" onClick={(e) => e.stopPropagation()}>
        <div className="admin-modal-head">
          <div>
            <h3>{detail?.subject ?? t('admin.tickets.detailTitle')}</h3>
            <IdCell id={ticketId} />
          </div>
          <button className="admin-modal-close" onClick={onClose} aria-label="Close">✕</button>
        </div>

        {error ? (
          <StateBlock><strong>{error}</strong></StateBlock>
        ) : !detail ? (
          <StateBlock><strong>{t('admin.loading')}</strong></StateBlock>
        ) : (
          <div className="admin-modal-body">
            <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap', marginBottom: 12 }}>
              <StatusBadge status={detail.status} />
              <span className="admin-chip">{detail.category}</span>
              <span className="admin-chip">{detail.username}</span>
              {detail.orderId && <span className="admin-chip">order #{shortId(detail.orderId)}</span>}
            </div>

            <div className="admin-thread">
              {detail.messages.map((m) => (
                <div key={m.id} className={`admin-msg ${m.isFromSupport ? 'admin-msg-support' : 'admin-msg-user'}`}>
                  <div className="admin-msg-meta">
                    {m.isFromSupport ? t('admin.tickets.support') : t('admin.tickets.user')} · {formatDateTime(m.createdAt)}
                  </div>
                  <div className="admin-msg-body">{m.body}</div>
                </div>
              ))}
            </div>

            {actionError && <div className="admin-inline-error">{actionError}</div>}

            {detail.status !== 'Closed' && (
              <form className="admin-reply-form" onSubmit={onReply}>
                <textarea
                  className="admin-textarea"
                  rows={3}
                  placeholder={t('admin.tickets.replyPlaceholder')}
                  value={reply}
                  onChange={(e) => setReply(e.target.value)}
                />
                <div className="admin-action-row" style={{ marginTop: 8 }}>
                  <button className="primary-button" type="submit" disabled={busy || !reply.trim()}>
                    {t('admin.tickets.send')}
                  </button>
                  {detail.status !== 'Resolved' && (
                    <button type="button" className="admin-btn-ghost" disabled={busy} onClick={() => void changeStatus('Resolved')}>
                      {t('admin.tickets.resolve')}
                    </button>
                  )}
                  <button type="button" className="admin-btn-ghost" disabled={busy} onClick={() => void changeStatus('Closed')}>
                    {t('admin.tickets.close')}
                  </button>
                </div>
              </form>
            )}

            {detail.status === 'Closed' && (
              <div className="admin-action-row" style={{ marginTop: 12 }}>
                <button type="button" className="admin-btn-ghost" disabled={busy} onClick={() => void changeStatus('Open')}>
                  {t('admin.tickets.reopen')}
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
