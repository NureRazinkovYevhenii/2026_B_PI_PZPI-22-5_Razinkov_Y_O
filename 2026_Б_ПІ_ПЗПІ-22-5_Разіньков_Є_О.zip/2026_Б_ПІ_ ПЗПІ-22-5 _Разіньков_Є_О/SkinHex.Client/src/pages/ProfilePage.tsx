import { useEffect, useState } from 'react';
import type { AuthState, AuthorizedFetch } from '../types';
import { readApiError } from '../utils/api';
import { useTranslation } from 'react-i18next';
import { TransactionsPanel } from '../components/TransactionsPanel';

type ProfilePageProps = {
  auth: AuthState | null;
  authorizedFetch: AuthorizedFetch;
  isUnverified: boolean;
  onAuthUpdate: (auth: AuthState) => void;
  onLogin: () => void;
  onOpenVerification: () => void;
};

export function ProfilePage({
  auth,
  authorizedFetch,
  isUnverified,
  onAuthUpdate,
  onLogin,
  onOpenVerification,
}: ProfilePageProps) {
  const { t } = useTranslation();
  const [tradeUrl, setTradeUrl] = useState(() => auth?.tradeUrl ?? '');
  const [isSavingTradeUrl, setIsSavingTradeUrl] = useState(false);
  const [tradeUrlError, setTradeUrlError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    setTradeUrl(auth?.tradeUrl ?? '');
    setTradeUrlError(null);
    setNotice(null);
  }, [auth?.tradeUrl]);

  const handleSaveTradeUrl = async () => {
    if (!auth) {
      onLogin();
      return;
    }

    const trimmedTradeUrl = tradeUrl.trim();

    if (!trimmedTradeUrl) {
      setTradeUrlError('Введіть trade URL.');
      return;
    }

    setIsSavingTradeUrl(true);
    setTradeUrlError(null);
    setNotice(null);

    try {
      const response = await authorizedFetch('/user/trade-url', {
        method: 'POST',
        body: JSON.stringify({ tradeUrl: trimmedTradeUrl }),
      });

      if (!response.ok) {
        throw new Error(await readApiError(response));
      }

      onAuthUpdate({ ...auth, tradeUrl: trimmedTradeUrl });
      setTradeUrl(trimmedTradeUrl);
      setNotice(t('inventory.tradeUrlSaved'));
    } catch (error) {
      setTradeUrlError(error instanceof Error ? error.message : t('inventory.tradeUrlFailed'));
    } finally {
      setIsSavingTradeUrl(false);
    }
  };

  if (!auth) {
    return (
      <section className="profile-page">
        <article className="profile-panel">
          <p className="eyebrow">{t('profile.title')}</p>
          <h2>{t('orders.signInPrompt')}</h2>
          <p className="profile-copy">{t('orders.signInDescription')}</p>
          <button className="primary-button profile-action" onClick={onLogin} type="button">
            {t('common.signInSteam')}
          </button>
        </article>
      </section>
    );
  }

  return (
    <section className="profile-page">
      <div className="dashboard-grid">
        <article className="profile-panel">
          <p className="eyebrow">{t('profile.title')}</p>
          <h2>{auth.name ?? 'Steam user'}</h2>
          <dl>
            <div>
              <dt>{t('profile.email')}</dt>
              <dd>{isUnverified ? t('profile.unverified') : t('profile.verified')}</dd>
            </div>
            <div>
              <dt>Trade URL</dt>
              <dd>{auth.tradeUrl ? 'Added' : 'Not added'}</dd>
            </div>
          </dl>
          {isUnverified ? (
            <button className="secondary-button profile-action" onClick={onOpenVerification} type="button">
              {t('profile.verify')}
            </button>
          ) : null}
        </article>

        <article className="trade-url-panel">
          <div>
            <p className="eyebrow">Steam Trade</p>
            <h2>{t('profile.tradeUrl')}</h2>
          </div>
          <div className="trade-url-form">
            <label htmlFor="trade-url">Steam Trade Link</label>
            <div className="inline-field">
              <input
                id="trade-url"
                onChange={(event) => {
                  setTradeUrl(event.target.value);
                  setTradeUrlError(null);
                  setNotice(null);
                }}
                placeholder={t('inventory.tradeUrlPlaceholder')}
                type="text"
                value={tradeUrl}
              />
              <button className="primary-button" disabled={isSavingTradeUrl} onClick={handleSaveTradeUrl} type="button">
                {isSavingTradeUrl ? t('inventory.saving') : t('inventory.save')}
              </button>
            </div>
            {tradeUrlError ? <p className="form-error">{tradeUrlError}</p> : null}
            {notice ? <p className="form-notice">{notice}</p> : null}
          </div>
        </article>
      </div>

      <TransactionsPanel authorizedFetch={authorizedFetch} />
    </section>
  );
}

