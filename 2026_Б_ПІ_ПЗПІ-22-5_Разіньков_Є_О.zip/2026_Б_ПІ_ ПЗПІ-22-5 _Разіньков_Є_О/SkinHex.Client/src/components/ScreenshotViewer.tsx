import { useEffect, useRef, useState } from 'react';
import { ZoomIn } from 'lucide-react';
import { useTranslation } from 'react-i18next';

type ScreenshotSide = 'front' | 'back';

type ScreenshotViewerProps = {
  frontUrl: string;
  backUrl: string | null;
  alt: string;
};

const HOVER_SCALE = 1.1;
const MAX_SCALE = 5;
const WHEEL_STEP = 1.2;

/** In-game screenshot viewer: front/back tabs, gentle hover zoom, mouse wheel controls the scale. */
export function ScreenshotViewer({ frontUrl, backUrl, alt }: ScreenshotViewerProps) {
  const { t } = useTranslation();
  const stageRef = useRef<HTMLDivElement>(null);
  const [side, setSide] = useState<ScreenshotSide>('front');
  const [isHovering, setIsHovering] = useState(false);
  const [wheelZoom, setWheelZoom] = useState(1);
  const [origin, setOrigin] = useState('50% 50%');
  const [loadedUrls, setLoadedUrls] = useState<Record<string, boolean>>({});

  const activeUrl = side === 'back' && backUrl ? backUrl : frontUrl;
  const isLoaded = Boolean(loadedUrls[activeUrl]);
  const scale = isHovering && isLoaded ? Math.max(HOVER_SCALE, wheelZoom) : 1;

  // React attaches wheel listeners as passive, so preventDefault (to stop page
  // scroll while zooming) has to go through a manual non-passive listener.
  useEffect(() => {
    const stage = stageRef.current;
    if (!stage) return;

    const handleWheel = (e: WheelEvent) => {
      e.preventDefault();
      setWheelZoom((prev) => {
        const next = e.deltaY < 0 ? prev * WHEEL_STEP : prev / WHEEL_STEP;
        return Math.min(MAX_SCALE, Math.max(1, next));
      });
    };

    stage.addEventListener('wheel', handleWheel, { passive: false });
    return () => stage.removeEventListener('wheel', handleWheel);
  }, []);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    setOrigin(`${x}% ${y}%`);
  };

  const handleMouseLeave = () => {
    setIsHovering(false);
    setWheelZoom(1);
  };

  return (
    <div className="screenshot-viewer">
      <div className="screenshot-tabs" role="tablist">
        <button
          type="button"
          role="tab"
          aria-selected={side === 'front'}
          className={`screenshot-tab ${side === 'front' ? 'active' : ''}`}
          onClick={() => setSide('front')}
        >
          {t('itemDetail.frontSide', 'Front side')}
        </button>
        {backUrl && (
          <button
            type="button"
            role="tab"
            aria-selected={side === 'back'}
            className={`screenshot-tab ${side === 'back' ? 'active' : ''}`}
            onClick={() => setSide('back')}
          >
            {t('itemDetail.backSide', 'Back side')}
          </button>
        )}
      </div>

      <div
        ref={stageRef}
        className="screenshot-stage"
        onMouseEnter={() => setIsHovering(true)}
        onMouseLeave={handleMouseLeave}
        onMouseMove={handleMouseMove}
      >
        {!isLoaded && <div className="screenshot-loading" />}
        <img
          key={activeUrl}
          src={activeUrl}
          alt={`${alt} — ${side}`}
          className="screenshot-img"
          draggable={false}
          onLoad={() => setLoadedUrls((prev) => ({ ...prev, [activeUrl]: true }))}
          style={{
            transformOrigin: origin,
            transform: `scale(${scale})`,
            opacity: isLoaded ? 1 : 0,
          }}
        />
        <span className="screenshot-hint">
          <ZoomIn size={13} />
          {scale > HOVER_SCALE
            ? `${scale.toFixed(1)}×`
            : t('itemDetail.zoomHint', 'Scroll to zoom')}
        </span>
      </div>
    </div>
  );
}
