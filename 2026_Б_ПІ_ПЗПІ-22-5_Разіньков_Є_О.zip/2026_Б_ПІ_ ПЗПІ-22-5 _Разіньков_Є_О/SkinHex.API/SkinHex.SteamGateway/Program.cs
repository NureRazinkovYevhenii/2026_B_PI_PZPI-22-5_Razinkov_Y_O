using System.IO.Compression;
using System.Net;
using Microsoft.Extensions.Options;
using Polly;
using Polly.Timeout;
using SkinHex.SteamGateway.Errors;
using SkinHex.SteamGateway.Options;
using SkinHex.SteamGateway.Proxies;
using SkinHex.SteamGateway.Steam;
using StackExchange.Redis;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddProblemDetails();
builder.Services.AddExceptionHandler<GlobalExceptionHandler>();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddSingleton(TimeProvider.System);

builder.Services.AddOptions<SteamGatewayOptions>()
    .Bind(builder.Configuration.GetSection(SteamGatewayOptions.SectionName))
    .Validate(options => Uri.TryCreate(options.BaseAddress, UriKind.Absolute, out _), "SteamGateway:BaseAddress must be a valid absolute URI.")
    .Validate(options => options.RequestTimeoutSeconds > 0, "SteamGateway:RequestTimeoutSeconds must be greater than zero.")
    .Validate(options => options.RetryCount >= 0, "SteamGateway:RetryCount must be zero or greater.")
    .Validate(options => !string.IsNullOrWhiteSpace(options.UserAgent), "SteamGateway:UserAgent must not be empty.")
    .Validate(options => options.BotQuarantineMinutes > 0, "SteamGateway:BotQuarantineMinutes must be greater than zero.")
    .ValidateOnStart();

builder.Services.AddOptions<ProxyOptions>()
    .Bind(builder.Configuration.GetSection(ProxyOptions.SectionName))
    .Validate(options => options.Endpoints.Count > 0, "Proxy:Endpoints must contain at least one proxy.")
    .Validate(options => options.QuarantineMinutes > 0, "Proxy:QuarantineMinutes must be greater than zero.")
    .ValidateOnStart();

builder.Services.AddOptions<RedisOptions>()
    .Bind(builder.Configuration.GetSection(RedisOptions.SectionName))
    .Validate(options => !string.IsNullOrWhiteSpace(options.ConnectionString), "Redis:ConnectionString is required.")
    .Validate(options => !string.IsNullOrWhiteSpace(options.SteamSessionsKey), "Redis:SteamSessionsKey is required.")
    .Validate(options => options.SessionTtlMinutes > 0, "Redis:SessionTtlMinutes must be greater than zero.")
    .ValidateOnStart();

builder.Services.AddSingleton<IConnectionMultiplexer>(serviceProvider =>
{
    var options = serviceProvider.GetRequiredService<IOptions<RedisOptions>>().Value;
    var redisConfiguration = ConfigurationOptions.Parse(options.ConnectionString);
    redisConfiguration.AbortOnConnectFail = false;
    redisConfiguration.ClientName = "SkinHex.SteamGateway";
    return ConnectionMultiplexer.Connect(redisConfiguration);
});

builder.Services.AddSingleton<RandomProxyProvider>();
builder.Services.AddTransient<ProxyPenaltyHandler>();
builder.Services.AddSingleton<ISteamBotSessionProvider, RedisSteamBotSessionProvider>();
builder.Services.AddScoped<ISteamInventoryService, SteamInventoryService>();

builder.Services
    .AddHttpClient<ISteamInventoryClient, SteamInventoryClient>((serviceProvider, client) =>
    {
        var options = serviceProvider.GetRequiredService<IOptions<SteamGatewayOptions>>().Value;
        client.BaseAddress = new Uri(options.BaseAddress);
        client.Timeout = Timeout.InfiniteTimeSpan;

        // A realistic browser fingerprint is required: Steam returns 429 for requests
        // that lack a User-Agent, independent of IP or bot account.
        client.DefaultRequestHeaders.UserAgent.ParseAdd(options.UserAgent);
        client.DefaultRequestHeaders.Accept.ParseAdd("text/javascript, text/html, application/xml, text/xml, */*");
        client.DefaultRequestHeaders.AcceptLanguage.ParseAdd("en-US,en;q=0.9");
    })
    .AddPolicyHandler((serviceProvider, _) => CreateRetryPolicy(serviceProvider))
    .AddPolicyHandler((serviceProvider, _) => CreateTimeoutPolicy(serviceProvider))
    .AddHttpMessageHandler<ProxyPenaltyHandler>()
    .ConfigurePrimaryHttpMessageHandler(serviceProvider => new SocketsHttpHandler
    {
        AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate | DecompressionMethods.Brotli,
        ConnectTimeout = TimeSpan.FromSeconds(10),
        PooledConnectionLifetime = TimeSpan.FromMinutes(2),
        Proxy = serviceProvider.GetRequiredService<RandomProxyProvider>(),
        UseProxy = true
    });

var app = builder.Build();

app.UseExceptionHandler();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.MapControllers();

app.Run();

static IAsyncPolicy<HttpResponseMessage> CreateTimeoutPolicy(IServiceProvider serviceProvider)
{
    var options = serviceProvider.GetRequiredService<IOptions<SteamGatewayOptions>>().Value;
    return Policy.TimeoutAsync<HttpResponseMessage>(
        TimeSpan.FromSeconds(options.RequestTimeoutSeconds),
        TimeoutStrategy.Optimistic);
}

static IAsyncPolicy<HttpResponseMessage> CreateRetryPolicy(IServiceProvider serviceProvider)
{
    var options = serviceProvider.GetRequiredService<IOptions<SteamGatewayOptions>>().Value;
    var proxyProvider = serviceProvider.GetRequiredService<RandomProxyProvider>();
    var logger = serviceProvider
        .GetRequiredService<ILoggerFactory>()
        .CreateLogger("SteamGateway.Polly");

    return Policy<HttpResponseMessage>
        .Handle<HttpRequestException>()
        .Or<TimeoutRejectedException>()
        .Or<TaskCanceledException>(exception => exception.InnerException is TimeoutException)
        .OrResult(response => ProxyPenaltyHandler.ShouldPenalize(response.StatusCode))
        .WaitAndRetryAsync(
            options.RetryCount,
            retryAttempt => TimeSpan.FromMilliseconds(1000 * retryAttempt),
            (outcome, delay, retryAttempt, _) =>
            {
                var reason = outcome.Exception?.GetType().Name
                    ?? $"HTTP {(int)outcome.Result.StatusCode}";

                proxyProvider.PenalizeCurrentProxy(reason);
                logger.LogWarning(
                    "Retrying Steam request in {Delay} after {Reason}. Retry attempt {RetryAttempt}.",
                    delay,
                    reason,
                    retryAttempt);
            });
}
