import { useState } from 'react';
import type { AuthState, AuthorizedFetch } from '../types';
import { createOrder } from '../utils/orders';

type PurchaseButtonProps = {
  auth: AuthState | null;
  authorizedFetch: AuthorizedFetch;
  listingId: string;
  onCreated?: (orderId: string) => void;
  onRequireLogin: () => void;
};

export function PurchaseButton({ auth, authorizedFetch, listingId, onCreated, onRequireLogin }: PurchaseButtonProps) {
  const [isBuying, setIsBuying] = useState(false);
  const [isConfirming, setIsConfirming] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const handlePurchase = async () => {
    if (!auth?.userId) {
      onRequireLogin();
      return;
    }

    setIsBuying(true);
    setMessage(null);

    try {
      const order = await createOrder(authorizedFetch, listingId);
      setMessage('Order created.');
      onCreated?.(order.id);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Purchase failed.');
    } finally {
      setIsBuying(false);
    }
  };

  const handleStartPurchase = () => {
    if (!auth?.userId) {
      onRequireLogin();
      return;
    }

    setMessage(null);
    setIsConfirming(true);
  };

  const handleCancelConfirmation = () => {
    if (isBuying) {
      return;
    }

    setIsConfirming(false);
  };

  return (
    <div className="purchase-action">
      <button className="primary-button" disabled={isBuying} onClick={handleStartPurchase} type="button">
        {isBuying ? 'Buying...' : 'Buy'}
      </button>
      {isConfirming ? (
        <div style={{ marginTop: '8px', padding: '10px', borderRadius: '10px', border: '1px solid rgba(255, 255, 255, 0.12)', background: 'rgba(17, 24, 39, 0.75)' }}>
          <p style={{ margin: 0, marginBottom: '8px', fontSize: '13px', color: 'var(--text-muted)' }}>Are you sure?</p>
          <div style={{ display: 'flex', gap: '8px' }}>
            <button className="primary-button" disabled={isBuying} onClick={handlePurchase} type="button" style={{ flex: 1 }}>
              Yes
            </button>
            <button className="secondary-button" disabled={isBuying} onClick={handleCancelConfirmation} type="button" style={{ flex: 1 }}>
              No
            </button>
          </div>
        </div>
      ) : null}
      {message ? <p className="purchase-message">{message}</p> : null}
    </div>
  );
}

