using Microsoft.EntityFrameworkCore;
using SkinHex.Core.Entities;
using SkinHex.Core.Interfaces.Repositories;
using SkinHex.Core.Models;

namespace SkinHex.Infrastructure.Repositories;

public sealed class ListingRepository(SkinHexDbContext context) : IListingRepository
{
    public Task<Listing?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default) =>
        context.Listings.FirstOrDefaultAsync(listing => listing.Id == id, cancellationToken);

    public Task<Listing?> GetByIdWithItemAsync(Guid id, CancellationToken cancellationToken = default) =>
        context.Listings
            .Include(listing => listing.Item)
            .FirstOrDefaultAsync(listing => listing.Id == id, cancellationToken);

    public Task<Listing?> GetByIdForUpdateAsync(Guid id, CancellationToken cancellationToken = default) =>
        context.Listings.FirstOrDefaultAsync(listing => listing.Id == id, cancellationToken);

    public Task<bool> HasActiveListingAsync(long steamAssetId, CancellationToken cancellationToken = default) =>
        context.Listings.AnyAsync(
            listing => listing.SteamAssetId == steamAssetId && listing.Status == ListingStatus.Active,
            cancellationToken);

    public async Task<IReadOnlySet<long>> GetActiveSteamAssetIdsAsync(
        IReadOnlyCollection<long> steamAssetIds,
        CancellationToken cancellationToken = default)
    {
        if (steamAssetIds.Count == 0)
        {
            return new HashSet<long>();
        }

        var activeAssetIds = await context.Listings
            .AsNoTracking()
            .Where(listing =>
                steamAssetIds.Contains(listing.SteamAssetId) &&
                listing.Status == ListingStatus.Active)
            .Select(listing => listing.SteamAssetId)
            .ToListAsync(cancellationToken);

        return activeAssetIds.ToHashSet();
    }

    public async Task<IReadOnlyList<Listing>> GetActiveBySellerAsync(Guid sellerId, CancellationToken cancellationToken = default) =>
        await context.Listings
            .Where(listing => listing.SellerId == sellerId && listing.Status == ListingStatus.Active)
            .ToListAsync(cancellationToken);

    public async Task<IReadOnlyList<Listing>> GetUncancelledBySellerAsync(Guid sellerId, CancellationToken cancellationToken = default) =>
        await context.Listings
            .Where(listing => listing.SellerId == sellerId && listing.Status != ListingStatus.Cancelled)
            .ToListAsync(cancellationToken);

    public void Add(Listing listing) => context.Listings.Add(listing);

    public void AddRange(IEnumerable<Listing> listings) => context.Listings.AddRange(listings);

    public Task UpdateAsync(Listing listing, CancellationToken cancellationToken = default)
    {
        context.Listings.Update(listing);
        return Task.CompletedTask;
    }

    public async Task<(IReadOnlyList<Listing> Items, int TotalCount)> GetActivePageAsync(
        GetListingsRequest request,
        CancellationToken cancellationToken = default)
    {
        var query = context.Listings
            .Where(listing => listing.Status == ListingStatus.Active)
            .AsNoTracking();

        if (request.SellerId.HasValue)
            query = query.Where(listing => listing.SellerId == request.SellerId.Value);
        if (request.ItemId.HasValue)
            query = query.Where(listing => listing.ItemId == request.ItemId.Value);
        if (!string.IsNullOrWhiteSpace(request.BaseName))
        {
            var baseName = request.BaseName.Trim();
            query = query.Where(listing => listing.Item.BaseName == baseName);
        }
        if (!string.IsNullOrWhiteSpace(request.SkinName))
            query = ApplyExactSkinNameFilter(query, request.SkinName);
        if (!string.IsNullOrWhiteSpace(request.SearchTerm))
            query = ApplyFreeTextCatalogSearch(query, request.SearchTerm);
        if (!string.IsNullOrWhiteSpace(request.Category))
            query = query.Where(listing => listing.Item.Category == request.Category);
        if (!string.IsNullOrWhiteSpace(request.Weapon))
            query = query.Where(listing => listing.Item.Weapon == request.Weapon);
        if (!string.IsNullOrWhiteSpace(request.Wear))
            query = query.Where(listing => listing.Item.Wear == request.Wear);
        if (request.IsStatTrak.HasValue)
            query = query.Where(listing => listing.Item.IsStatTrak == request.IsStatTrak.Value);
        if (request.IsSouvenir.HasValue)
            query = query.Where(listing => listing.Item.IsSouvenir == request.IsSouvenir.Value);
        if (request.MinPrice.HasValue)
            query = query.Where(listing => listing.Price >= request.MinPrice.Value);
        if (request.MaxPrice.HasValue)
            query = query.Where(listing => listing.Price <= request.MaxPrice.Value);
        if (request.MinFloat.HasValue)
            query = query.Where(listing => listing.FloatValue >= request.MinFloat.Value);
        if (request.MaxFloat.HasValue)
            query = query.Where(listing => listing.FloatValue <= request.MaxFloat.Value);
        if (request.PaintSeed.HasValue)
            query = query.Where(listing => listing.PaintSeed == request.PaintSeed.Value);

        var totalCount = await query.CountAsync(cancellationToken);
        query = request.SortBy switch
        {
            SortOption.PriceDesc => query.OrderByDescending(listing => listing.Price),
            SortOption.Newest => query.OrderByDescending(listing => listing.CreatedAt),
            SortOption.FloatAsc => query
                .OrderBy(listing => listing.FloatValue == null)
                .ThenBy(listing => listing.FloatValue)
                .ThenBy(listing => listing.Price),
            SortOption.FloatDesc => query
                .OrderBy(listing => listing.FloatValue == null)
                .ThenByDescending(listing => listing.FloatValue)
                .ThenBy(listing => listing.Price),
            _ => query.OrderBy(listing => listing.Price)
        };

        var items = await query
            .Include(listing => listing.Item)
            .Include(listing => listing.Seller)
            .Include(listing => listing.Screenshot)
            .Skip((request.Page - 1) * request.PageSize)
            .Take(request.PageSize)
            .ToListAsync(cancellationToken);

        return (items, totalCount);
    }

    public async Task<IReadOnlyDictionary<int, decimal>> GetMinPriceByItemIdsAsync(
        IReadOnlyCollection<int> itemIds,
        CancellationToken cancellationToken = default)
    {
        if (itemIds.Count == 0)
            return new Dictionary<int, decimal>();

        var rows = await context.Listings
            .AsNoTracking()
            .Where(listing => listing.Status == ListingStatus.Active && itemIds.Contains(listing.ItemId))
            .GroupBy(listing => listing.ItemId)
            .Select(group => new { ItemId = group.Key, Min = group.Min(listing => listing.Price) })
            .ToListAsync(cancellationToken);

        return rows.ToDictionary(row => row.ItemId, row => row.Min);
    }

    public async Task<ItemPriceSummary> GetItemPriceSummaryAsync(
        int itemId,
        CancellationToken cancellationToken = default)
    {
        var totals = await context.Listings
            .AsNoTracking()
            .Where(listing => listing.Status == ListingStatus.Active && listing.ItemId == itemId)
            .GroupBy(_ => 1)
            .Select(group => new
            {
                Min = (decimal?)group.Min(listing => listing.Price),
                Avg = (decimal?)group.Average(listing => listing.Price),
                Count = group.Count()
            })
            .FirstOrDefaultAsync(cancellationToken);

        return new ItemPriceSummary
        {
            MinPrice = totals?.Min,
            AvgPrice = totals?.Avg,
            Count = totals?.Count ?? 0
        };
    }

    private static IQueryable<Listing> ApplyFreeTextCatalogSearch(
        IQueryable<Listing> query,
        string searchTerm)
    {
        var terms = searchTerm
            .Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .Take(8)
            .ToArray();

        foreach (var term in terms)
        {
            var pattern = $"%{term}%";
            query = query.Where(listing =>
                EF.Functions.ILike(listing.Item.MarketHashName, pattern) ||
                EF.Functions.ILike(listing.Item.BaseName, pattern) ||
                (listing.Item.Weapon != null && EF.Functions.ILike(listing.Item.Weapon, pattern)));
        }

        return query;
    }

    private static IQueryable<Listing> ApplyExactSkinNameFilter(
        IQueryable<Listing> query,
        string skinName)
    {
        var term = skinName.Trim();

        return query.Where(listing =>
            EF.Functions.ILike(listing.Item.BaseName, term) ||
            EF.Functions.ILike(listing.Item.BaseName, "%| " + term));
    }

    public async Task<(IReadOnlyList<SaleHistoryRow> Items, int TotalCount)> GetSaleHistoryPageAsync(
        int itemId,
        int page,
        int pageSize,
        CancellationToken cancellationToken = default)
    {
        // Sold listings = orders that reached at least Confirmed and were not cancelled.
        var query = context.Orders
            .AsNoTracking()
            .Where(o => o.Status != OrderStatus.Pending && o.Status != OrderStatus.Cancelled)
            .Where(o => o.Listing.ItemId == itemId);

        var totalCount = await query.CountAsync(cancellationToken);

        var rows = await query
            .OrderByDescending(o => o.CreatedAt)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .Select(o => new SaleHistoryRow
            {
                Listing = o.Listing,
                SoldAt = o.CreatedAt
            })
            .ToListAsync(cancellationToken);

        // Eagerly load related entities that Select() couldn't inline.
        var listingIds = rows.Select(r => r.Listing.Id).ToList();
        var listingsWithIncludes = await context.Listings
            .AsNoTracking()
            .Where(l => listingIds.Contains(l.Id))
            .Include(l => l.Item)
            .Include(l => l.Seller)
            .Include(l => l.Screenshot)
            .ToDictionaryAsync(l => l.Id, cancellationToken);

        foreach (var row in rows)
        {
            if (listingsWithIncludes.TryGetValue(row.Listing.Id, out var full))
                row.Listing = full;
        }

        return (rows, totalCount);
    }
}

