using System.Net;
using SkinHex.SteamGateway.Proxies;

namespace SkinHex.SteamGateway.Proxies;

public sealed class ProxyPenaltyHandler(RandomProxyProvider proxyProvider) : DelegatingHandler
{
    protected override async Task<HttpResponseMessage> SendAsync(
        HttpRequestMessage request,
        CancellationToken cancellationToken)
    {
        try
        {
            var response = await base.SendAsync(request, cancellationToken);
            if (ShouldPenalize(response.StatusCode))
            {
                proxyProvider.PenalizeCurrentProxy($"Steam returned {(int)response.StatusCode}.");
            }

            return response;
        }
        catch (TaskCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            proxyProvider.PenalizeCurrentProxy("Steam request timed out.");
            throw;
        }
        catch (HttpRequestException exception)
        {
            proxyProvider.PenalizeCurrentProxy(exception.Message);
            throw;
        }
    }

    public static bool ShouldPenalize(HttpStatusCode statusCode)
    {
        return statusCode is HttpStatusCode.TooManyRequests or HttpStatusCode.BadGateway or HttpStatusCode.ServiceUnavailable ||
               (int)statusCode >= 500;
    }
}
