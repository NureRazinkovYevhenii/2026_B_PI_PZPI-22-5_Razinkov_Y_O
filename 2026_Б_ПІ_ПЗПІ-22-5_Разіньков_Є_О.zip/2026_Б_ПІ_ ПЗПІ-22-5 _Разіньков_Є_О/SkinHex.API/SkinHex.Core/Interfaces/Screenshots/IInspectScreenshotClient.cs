using SkinHex.Core.Models.Screenshots;

namespace SkinHex.Core.Interfaces.Screenshots;

public interface IInspectScreenshotClient
{
    Task<InspectScreenshotResult> RequestSidesAsync(string inspectLink, CancellationToken ct = default);

    Task<byte[]> DownloadImageAsync(string imageUrl, CancellationToken ct = default);
}
