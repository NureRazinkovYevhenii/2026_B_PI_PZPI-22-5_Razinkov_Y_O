using System.Security.Claims;
using FluentResults;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Logging;
using Moq;
using SkinHex.API.Controllers;
using SkinHex.Core.Entities;
using SkinHex.Core.Interfaces;
using SkinHex.Core.Interfaces.Services;
using SkinHex.Core.Models;
using SkinHex.Core.Models.Admin;
using SkinHex.Infrastructure;
using Xunit;

namespace SkinHex.Core.Tests.Admin;

public class AdminControllerTests
{
    private readonly SkinHexDbContext _dbContext;
    private readonly Mock<IUserService> _userServiceMock = new();
    private readonly Mock<INowPaymentsPayoutService> _payoutServiceMock = new();
    private readonly Guid _adminId = Guid.NewGuid();

    public AdminControllerTests()
    {
        var dbOptions = new DbContextOptionsBuilder<SkinHexDbContext>()
            .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
            .ConfigureWarnings(w => w.Ignore(InMemoryEventId.TransactionIgnoredWarning))
            .Options;
        _dbContext = new SkinHexDbContext(dbOptions);
    }

    private AdminController CreateController()
    {
        var controller = new AdminController(_dbContext, _userServiceMock.Object, _payoutServiceMock.Object, Mock.Of<INotificationService>(), Mock.Of<IDisputeService>(), Mock.Of<ILogger<AdminController>>());
        var principal = new ClaimsPrincipal(new ClaimsIdentity(new[]
        {
            new Claim(ClaimTypes.NameIdentifier, _adminId.ToString()),
            new Claim(ClaimTypes.Role, nameof(UserRole.Admin))
        }));
        controller.ControllerContext = new ControllerContext
        {
            HttpContext = new DefaultHttpContext { User = principal }
        };
        return controller;
    }

    private User SeedUser(string username = "player", decimal balance = 0, UserRole role = UserRole.User)
    {
        var user = new User
        {
            Id = Guid.NewGuid(),
            SteamId = Guid.NewGuid().ToString("N"),
            Username = username,
            Balance = balance,
            Role = role,
            CreatedAt = DateTime.UtcNow
        };
        _dbContext.Users.Add(user);
        _dbContext.SaveChanges();
        return user;
    }

    private Order SeedOrder(User buyer, User seller)
    {
        var item = new Item
        {
            MarketHashName = "AK-47 | Redline (Field-Tested)",
            BaseName = "AK-47 | Redline",
            Category = "Rifle",
            Rarity = "Classified",
            Color = "eb4b4b",
            ImageHash = "hash"
        };
        var listing = new Listing
        {
            Id = Guid.NewGuid(),
            SellerId = seller.Id,
            Item = item,
            Price = 10m,
            Status = ListingStatus.Active,
            CreatedAt = DateTimeOffset.UtcNow
        };
        var order = new Order
        {
            Id = Guid.NewGuid(),
            BuyerId = buyer.Id,
            SellerId = seller.Id,
            ListingId = listing.Id,
            Status = OrderStatus.Pending,
            LockPrice = 10m,
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow,
            Buyer = buyer,
            Seller = seller,
            Listing = listing
        };
        _dbContext.Items.Add(item);
        _dbContext.Listings.Add(listing);
        _dbContext.Orders.Add(order);
        _dbContext.SaveChanges();
        return order;
    }

    private Withdrawal SeedWithdrawal(User user)
    {
        var tx = new FinancialTransaction
        {
            Id = Guid.NewGuid(), UserId = user.Id, Amount = 5m,
            Type = FinancialTransactionType.Withdrawal, Status = FinancialTransactionStatus.Pending
        };
        var withdrawal = new Withdrawal
        {
            Id = Guid.NewGuid(), UserId = user.Id, TransactionId = tx.Id,
            AmountUsd = 5m, PayoutAmountUsd = 5m, PayCurrency = "usdttrc20", PayoutAddress = "TAddr",
            Status = WithdrawalStatus.Pending
        };
        _dbContext.FinancialTransactions.Add(tx);
        _dbContext.Withdrawals.Add(withdrawal);
        _dbContext.SaveChanges();
        return withdrawal;
    }

    [Fact]
    public async Task GetUsers_FiltersBySearchTerm()
    {
        SeedUser("alice");
        SeedUser("bob");
        var controller = CreateController();

        var result = Assert.IsType<OkObjectResult>(await controller.GetUsers("ali", null));
        var page = Assert.IsType<PagedResult<AdminUserListItemDto>>(result.Value);

        Assert.Equal(1, page.TotalCount);
        Assert.Equal("alice", page.Items[0].Username);
    }

    [Fact]
    public async Task GetUsers_FiltersByIdSearchTerm()
    {
        var target = SeedUser("alice");
        SeedUser("bob");
        var controller = CreateController();

        var idFragment = target.Id.ToString()[..8];
        var result = Assert.IsType<OkObjectResult>(await controller.GetUsers(idFragment, null));
        var page = Assert.IsType<PagedResult<AdminUserListItemDto>>(result.Value);

        Assert.Equal(1, page.TotalCount);
        Assert.Equal(target.Id, page.Items[0].Id);
    }

    [Fact]
    public async Task GetOrders_FiltersByIdSearchTerm()
    {
        var order = SeedOrder(SeedUser("buyer1"), SeedUser("seller1"));
        SeedOrder(SeedUser("buyer2"), SeedUser("seller2"));
        var controller = CreateController();

        var idFragment = order.Id.ToString()[..8];
        var result = Assert.IsType<OkObjectResult>(await controller.GetOrders(null, idFragment, 1, 20, default));
        var page = Assert.IsType<PagedResult<AdminOrderListItemDto>>(result.Value);

        Assert.Equal(1, page.TotalCount);
        Assert.Equal(order.Id, page.Items[0].OrderId);
    }

    [Fact]
    public async Task GetTickets_FiltersByIdSearchTerm()
    {
        var user = SeedUser("ticketuser");
        var ticket = new SupportTicket { Id = Guid.NewGuid(), UserId = user.Id, Subject = "help me", Category = TicketCategory.Other, Status = TicketStatus.Open };
        var other = new SupportTicket { Id = Guid.NewGuid(), UserId = user.Id, Subject = "another", Category = TicketCategory.Other, Status = TicketStatus.Open };
        _dbContext.SupportTickets.AddRange(ticket, other);
        await _dbContext.SaveChangesAsync();
        var controller = CreateController();

        var idFragment = ticket.Id.ToString()[..8];
        var result = Assert.IsType<OkObjectResult>(await controller.GetTickets(null, null, idFragment, 1, 20, default));
        var page = Assert.IsType<PagedResult<TicketListItemDto>>(result.Value);

        Assert.Equal(1, page.TotalCount);
        Assert.Equal(ticket.Id, page.Items[0].Id);
    }

    [Fact]
    public async Task GetWithdrawals_FiltersByIdSearchTerm()
    {
        var withdrawal = SeedWithdrawal(SeedUser("withdrawuser"));
        SeedWithdrawal(SeedUser("other"));
        var controller = CreateController();

        var idFragment = withdrawal.Id.ToString()[..8];
        var result = Assert.IsType<OkObjectResult>(await controller.GetWithdrawals(null, idFragment, 1, 20, default));
        var page = Assert.IsType<PagedResult<AdminWithdrawalListItemDto>>(result.Value);

        Assert.Equal(1, page.TotalCount);
        Assert.Equal(withdrawal.Id, page.Items[0].Id);
    }

    [Fact]
    public async Task GetUser_ReturnsDetailWithCounts()
    {
        var user = SeedUser("carol", balance: 42m);
        _dbContext.FinancialTransactions.Add(new FinancialTransaction
        {
            Id = Guid.NewGuid(),
            UserId = user.Id,
            Amount = 42m,
            Type = FinancialTransactionType.Deposit,
            Status = FinancialTransactionStatus.Completed,
            CreatedAt = DateTime.UtcNow
        });
        await _dbContext.SaveChangesAsync();
        var controller = CreateController();

        var result = Assert.IsType<OkObjectResult>(await controller.GetUser(user.Id, default));
        var detail = Assert.IsType<AdminUserDetailDto>(result.Value);

        Assert.Equal("carol", detail.Username);
        Assert.Equal(42m, detail.Balance);
        Assert.Single(detail.RecentTransactions);
    }

    [Fact]
    public async Task GetUser_ReturnsNotFound_WhenMissing()
    {
        var controller = CreateController();
        Assert.IsType<NotFoundResult>(await controller.GetUser(Guid.NewGuid(), default));
    }

    [Fact]
    public async Task BanUser_DelegatesToServiceAndReturnsOk()
    {
        var userId = Guid.NewGuid();
        _userServiceMock.Setup(s => s.BanUserAsync(userId, It.IsAny<CancellationToken>())).ReturnsAsync(Result.Ok());
        var controller = CreateController();

        Assert.IsType<OkObjectResult>(await controller.BanUser(userId, default));
        _userServiceMock.Verify(s => s.BanUserAsync(userId, It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task AdjustBalance_CreditsBalanceAndRecordsTransaction()
    {
        var user = SeedUser("dave", balance: 10m);
        var controller = CreateController();

        var result = await controller.AdjustBalance(user.Id, new BalanceAdjustRequest(15m, "goodwill"), default);

        Assert.IsType<OkObjectResult>(result);
        var updated = await _dbContext.Users.FindAsync(user.Id);
        Assert.Equal(25m, updated!.Balance);

        var tx = Assert.Single(_dbContext.FinancialTransactions.ToList());
        Assert.Equal(FinancialTransactionType.AdminAdjustment, tx.Type);
        Assert.Equal(15m, tx.Amount);
        Assert.Equal(_adminId, tx.ReferenceId);
    }

    [Fact]
    public async Task AdjustBalance_RejectsWhenResultingBalanceNegative()
    {
        var user = SeedUser("erin", balance: 5m);
        var controller = CreateController();

        var result = await controller.AdjustBalance(user.Id, new BalanceAdjustRequest(-10m, "penalty"), default);

        Assert.IsType<BadRequestObjectResult>(result);
        Assert.Empty(_dbContext.FinancialTransactions.ToList());
    }

    [Fact]
    public async Task AdjustBalance_RejectsZeroAmountAndEmptyReason()
    {
        var user = SeedUser("frank", balance: 5m);
        var controller = CreateController();

        Assert.IsType<BadRequestObjectResult>(await controller.AdjustBalance(user.Id, new BalanceAdjustRequest(0m, "x"), default));
        Assert.IsType<BadRequestObjectResult>(await controller.AdjustBalance(user.Id, new BalanceAdjustRequest(5m, "  "), default));
    }

    [Fact]
    public async Task ReplyToTicket_AddsSupportMessageAndSetsPendingUser()
    {
        var user = SeedUser("grace");
        var ticket = new SupportTicket
        {
            Id = Guid.NewGuid(),
            UserId = user.Id,
            Subject = "help",
            Category = TicketCategory.Account,
            Status = TicketStatus.Open,
            Messages = { new TicketMessage { Id = Guid.NewGuid(), SenderId = user.Id, Body = "hi", IsFromSupport = false } }
        };
        _dbContext.SupportTickets.Add(ticket);
        await _dbContext.SaveChangesAsync();
        var controller = CreateController();

        var result = Assert.IsType<OkObjectResult>(await controller.ReplyToTicket(ticket.Id, new TicketReplyRequest("on it"), default));
        var detail = Assert.IsType<TicketDetailDto>(result.Value);

        Assert.Equal(nameof(TicketStatus.PendingUser), detail.Status);
        Assert.Equal(2, detail.Messages.Count);
        Assert.True(detail.Messages[1].IsFromSupport);
        Assert.Equal(_adminId, detail.AssignedAdminId);
    }

    [Fact]
    public async Task ChangeTicketStatus_ResolvedSetsClosedAt()
    {
        var user = SeedUser("heidi");
        var ticket = new SupportTicket
        {
            Id = Guid.NewGuid(),
            UserId = user.Id,
            Subject = "help",
            Category = TicketCategory.Other,
            Status = TicketStatus.PendingSupport
        };
        _dbContext.SupportTickets.Add(ticket);
        await _dbContext.SaveChangesAsync();
        var controller = CreateController();

        var result = Assert.IsType<OkObjectResult>(
            await controller.ChangeTicketStatus(ticket.Id, new TicketStatusRequest(TicketStatus.Resolved), default));
        var detail = Assert.IsType<TicketDetailDto>(result.Value);

        Assert.Equal(nameof(TicketStatus.Resolved), detail.Status);
        Assert.NotNull(detail.ClosedAt);
    }

    [Fact]
    public async Task GetDashboard_ReturnsAggregatedStats()
    {
        SeedUser("u1", balance: 100m);
        SeedUser("u2", balance: 50m, role: UserRole.Banned);
        var controller = CreateController();

        var result = Assert.IsType<OkObjectResult>(await controller.GetDashboard(default));
        var stats = Assert.IsType<DashboardStatsDto>(result.Value);

        Assert.Equal(2, stats.TotalUsers);
        Assert.Equal(1, stats.BannedUsers);
        Assert.Equal(150m, stats.TotalUserBalance);
    }
}
