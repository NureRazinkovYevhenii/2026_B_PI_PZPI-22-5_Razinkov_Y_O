namespace SkinHex.Core.Models;

public sealed class MarketSearchTipDto
{
    public string BaseName { get; set; } = null!;
}
