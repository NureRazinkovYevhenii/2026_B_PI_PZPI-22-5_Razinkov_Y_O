using SkinHex.Core.Entities;

namespace SkinHex.Core.Interfaces.Repositories;

public interface IFinancialTransactionRepository
{
    void Add(FinancialTransaction transaction);
    void AddRange(IEnumerable<FinancialTransaction> transactions);

    /// <summary>Completed ledger entries of the given type referencing an order (used to reverse penalties on appeal).</summary>
    Task<List<FinancialTransaction>> GetCompletedByReferenceAsync(Guid referenceId, FinancialTransactionType type, CancellationToken ct = default);
}
