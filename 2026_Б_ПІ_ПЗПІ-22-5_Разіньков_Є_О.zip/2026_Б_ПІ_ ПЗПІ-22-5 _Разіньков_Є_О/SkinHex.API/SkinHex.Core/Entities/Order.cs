using System.ComponentModel.DataAnnotations;

namespace SkinHex.Core.Entities;

public enum OrderStatus
{
    Pending = 0,
    Confirmed = 1,
    TradeSent = 2,
    InEscrow = 3,
    Completed = 4,
    Cancelled = 5
}

public enum CancelledBy
{
    Buyer = 0,
    Seller = 1,
    System = 2
}

public class Order
{
    [Key]
    public Guid Id { get; set; }

    public Guid ListingId { get; set; }
    public Guid BuyerId { get; set; }
    public Guid SellerId { get; set; }

    public OrderStatus Status { get; set; }
    public decimal LockPrice { get; set; }

    public CancelledBy? CancelledBy { get; set; }

    [MaxLength(500)]
    public string? CancelReason { get; set; }

    public DateTime CreatedAt { get; set; }
    public DateTime? ConfirmDeadline { get; set; }
    public DateTime? ConfirmedAt { get; set; }
    public DateTime? TradeSentAt { get; set; }
    public DateTime? TradeAcceptDeadline { get; set; }
    public DateTime? AcceptedAt { get; set; }
    public DateTime? HoldEndsAt { get; set; }
    public DateTime? CancelledAt { get; set; }
    public OrderStatus? CancelledAtStatus { get; set; }
    public DateTime UpdatedAt { get; set; }

    public Listing Listing { get; set; } = null!;
    public User Buyer { get; set; } = null!;
    public User Seller { get; set; } = null!;
    public ICollection<SteamTrade> SteamTrades { get; set; } = new List<SteamTrade>();
}
