using System;
using System.Threading;
using System.Threading.Tasks;

namespace SkinHex.Core.Interfaces.Services;

public interface IOrderTimeoutJobs
{
    Task ExecuteTimeoutCheckAsync(Guid orderId, CancellationToken ct);

    /// <summary>Scheduled at escrow-end + grace: if the order is still InEscrow the seller never ran
    /// the completion proof — nudge them and open a StuckEscrow dispute for support.</summary>
    Task ExecuteEscrowStuckCheckAsync(Guid orderId, CancellationToken ct);
}