using System.ComponentModel.DataAnnotations;

namespace SkinHex.Core.Entities;

public class SteamTrade
{
    [Key]
    public Guid Id { get; set; }

    public Guid OrderId { get; set; }

    [Required]
    [MaxLength(100)]
    public string TradeOfferId { get; set; } = string.Empty;

    [MaxLength(100)]
    public string? TradeId { get; set; }

    public SteamOfferState OfferState { get; set; }
    public SteamTradeStatus? TradeStatus { get; set; }


    public DateTime? SteamUpdatedAt { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }

    /// <summary>Offer state as observed by the buyer's extension. Corroboration only —
    /// buyer-reported data never drives the order lifecycle, it gates penalties and warnings.</summary>
    public SteamOfferState? BuyerReportedOfferState { get; set; }

    public DateTime? BuyerReportedAt { get; set; }

    /// <summary>Comma-separated asset ids the buyer saw inside the incoming offer.</summary>
    [MaxLength(2000)]
    public string? BuyerSeenAssetIds { get; set; }

    /// <summary>True when the buyer-reported offer contains the listing's asset id;
    /// null when the buyer never reported or reported without asset details.</summary>
    public bool? BuyerAssetMatchesListing { get; set; }

    public Order Order { get; set; } = null!;
}
