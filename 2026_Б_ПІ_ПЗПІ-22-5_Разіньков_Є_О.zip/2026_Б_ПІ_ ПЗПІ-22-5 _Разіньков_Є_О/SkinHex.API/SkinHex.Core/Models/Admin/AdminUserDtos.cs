namespace SkinHex.Core.Models.Admin;

public record AdminUserListItemDto(
    Guid Id,
    string SteamId,
    string Username,
    string? Email,
    string? AvatarUrl,
    string Role,
    decimal Balance,
    decimal FrozenBalance,
    DateTime CreatedAt);

public record AdminTransactionDto(
    Guid Id,
    decimal Amount,
    string Type,
    string Status,
    Guid? ReferenceId,
    DateTime CreatedAt);

public record AdminUserDetailDto(
    Guid Id,
    string SteamId,
    string Username,
    string? Email,
    string? AvatarUrl,
    string? TradeUrl,
    string Role,
    decimal Balance,
    decimal FrozenBalance,
    DateTime CreatedAt,
    DateTime? UpdatedAt,
    int ActiveListingsCount,
    int OrdersAsBuyer,
    int OrdersAsSeller,
    int OpenTicketsCount,
    IReadOnlyList<AdminTransactionDto> RecentTransactions);

/// <summary>Manual balance correction. <paramref name="Amount"/> may be positive (credit) or negative (debit).</summary>
public record BalanceAdjustRequest(decimal Amount, string Reason);
