using SkinHex.Core.Entities;

namespace SkinHex.Core.Interfaces.Repositories;

public interface IDisputeRepository
{
    /// <summary>Stages the dispute; persisted by the caller's SaveChanges.</summary>
    void Add(OrderDispute dispute);

    Task<bool> HasOpenDisputeAsync(Guid orderId, CancellationToken ct = default);
    Task<OrderDispute?> GetOpenByOrderIdAsync(Guid orderId, CancellationToken ct = default);
    Task<OrderDispute?> GetByIdAsync(Guid id, CancellationToken ct = default);

    /// <summary>Dispute with Order + Buyer + Seller + Listing loaded (tracked) for resolution.</summary>
    Task<OrderDispute?> GetByIdWithOrderDetailsAsync(Guid id, CancellationToken ct = default);

    /// <summary>All disputes on orders where the user is buyer or seller, newest first.</summary>
    Task<List<OrderDispute>> GetByParticipantAsync(Guid userId, CancellationToken ct = default);
}
