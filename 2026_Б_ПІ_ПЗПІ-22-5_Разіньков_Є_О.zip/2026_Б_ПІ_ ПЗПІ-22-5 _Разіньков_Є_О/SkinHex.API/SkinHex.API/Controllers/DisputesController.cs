using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SkinHex.Core.Interfaces.Services;
using SkinHex.Core.Models.Disputes;

namespace SkinHex.API.Controllers;

[ApiController]
[Authorize]
public sealed class DisputesController : ControllerBase
{
    private readonly IDisputeService _disputeService;

    public DisputesController(IDisputeService disputeService)
    {
        _disputeService = disputeService;
    }

    /// <summary>Учасник замовлення відкриває спір (проблема з трейдом, штрафом, застряглим ескроу).</summary>
    [HttpPost("api/orders/{orderId:guid}/disputes")]
    public async Task<IActionResult> OpenDispute(Guid orderId, [FromBody] OpenDisputeRequest request, CancellationToken ct)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
            return Unauthorized();

        var dispute = await _disputeService.OpenDisputeAsync(orderId, userId.Value, request.Reason, request.Description, ct);
        return Ok(dispute);
    }

    [HttpGet("api/disputes/my")]
    public async Task<IActionResult> GetMyDisputes(CancellationToken ct)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
            return Unauthorized();

        var disputes = await _disputeService.GetMyDisputesAsync(userId.Value, ct);
        return Ok(disputes);
    }

    [HttpGet("api/disputes/{id:guid}")]
    public async Task<IActionResult> GetDispute(Guid id, CancellationToken ct)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
            return Unauthorized();

        var dispute = await _disputeService.GetDisputeAsync(id, userId.Value, ct);
        return Ok(dispute);
    }

    private Guid? GetCurrentUserId()
    {
        var value = User.FindFirstValue(ClaimTypes.NameIdentifier);
        return Guid.TryParse(value, out var id) ? id : null;
    }
}
