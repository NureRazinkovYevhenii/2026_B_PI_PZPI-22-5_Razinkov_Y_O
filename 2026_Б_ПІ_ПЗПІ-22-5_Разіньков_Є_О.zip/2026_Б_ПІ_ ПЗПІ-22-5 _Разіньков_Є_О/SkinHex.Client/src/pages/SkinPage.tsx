import { useCallback, useEffect, useMemo, useState, type CSSProperties } from 'react';
import { ArrowLeft, Camera, ChevronLeft, ChevronRight, ExternalLink, Loader2 } from 'lucide-react';
import { CatalogSortBar } from '../components/CatalogSortBar';
import { FloatBar } from '../components/FloatBar';
import { ItemDetailModal } from '../components/ItemDetailModal';
import { PurchaseButton } from '../components/PurchaseButton';
import { API_BASE_URL } from '../config';
import type {
  AuthState,
  AuthorizedFetch,
  CatalogSortOption,
  ItemDictionaryEntry,
  ListingCatalogItem,
  MarketItemPage,
  PagedResult,
  SaleHistoryItem,
  SkinVariant,
} from '../types';
import { readApiError } from '../utils/api';
import { formatFloat, getWearTierRange } from '../utils/inventory';
import { getItemImageUrl, getItemStatic, loadItemDictionary } from '../utils/itemDictionary';

type SkinPageProps = {
  itemName: string | null;
  auth: AuthState | null;
  authorizedFetch: AuthorizedFetch;
  onRequireLogin: () => void;
  onBack: () => void;
};

type ContentTab = 'listings' | 'trades' | 'stats';

type Filters = {
  minFloat: string;
  maxFloat: string;
  paintSeed: string;
  minPrice: string;
  maxPrice: string;
};

const PAGE_SIZE = 24;
const EMPTY_FILTERS: Filters = { minFloat: '', maxFloat: '', paintSeed: '', minPrice: '', maxPrice: '' };

const VARIANT_LABEL: Record<SkinVariant, string> = {
  normal: 'Normal',
  stattrak: 'StatTrak™',
  souvenir: 'Souvenir',
};

function goToItem(marketHashName: string) {
  window.location.hash = `skin/${encodeURIComponent(marketHashName)}`;
}

/** Compact page-number sequence with ellipses, e.g. 1 … 4 5 [6] 7 8 … 20. */
function getPageWindow(current: number, total: number): (number | 'gap')[] {
  if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);

  const pages = new Set<number>([1, total, current, current - 1, current + 1]);
  const sorted = [...pages].filter((p) => p >= 1 && p <= total).sort((a, b) => a - b);

  const result: (number | 'gap')[] = [];
  let previous = 0;
  for (const page of sorted) {
    if (page - previous > 1) result.push('gap');
    result.push(page);
    previous = page;
  }
  return result;
}

export function SkinPage({ itemName, auth, authorizedFetch, onRequireLogin, onBack }: SkinPageProps) {
  const [data, setData] = useState<MarketItemPage | null>(null);
  const [dictionary, setDictionary] = useState<Record<string, ItemDictionaryEntry>>({});
  const [sortBy, setSortBy] = useState<CatalogSortOption>(0);
  const [page, setPage] = useState(1);
  const [filters, setFilters] = useState<Filters>(EMPTY_FILTERS);
  const [draft, setDraft] = useState<Filters>(EMPTY_FILTERS);
  const [activeTab, setActiveTab] = useState<ContentTab>('listings');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [detailListing, setDetailListing] = useState<ListingCatalogItem | null>(null);

  // Sale history state
  const [salesData, setSalesData] = useState<PagedResult<SaleHistoryItem> | null>(null);
  const [salesPage, setSalesPage] = useState(1);
  const [salesLoading, setSalesLoading] = useState(false);

  const fetchPage = useCallback(
    async (
      currentName: string,
      currentSort: CatalogSortOption,
      currentPage: number,
      currentFilters: Filters,
    ) => {
      setIsLoading(true);
      setError(null);

      try {
        const params = new URLSearchParams();
        params.set('marketHashName', currentName);
        params.set('page', String(currentPage));
        params.set('pageSize', String(PAGE_SIZE));
        params.set('sortBy', String(currentSort));
        if (currentFilters.minFloat) params.set('minFloat', currentFilters.minFloat);
        if (currentFilters.maxFloat) params.set('maxFloat', currentFilters.maxFloat);
        if (currentFilters.paintSeed) params.set('paintSeed', currentFilters.paintSeed);
        if (currentFilters.minPrice) params.set('minPrice', currentFilters.minPrice);
        if (currentFilters.maxPrice) params.set('maxPrice', currentFilters.maxPrice);

        const [response, dict] = await Promise.all([
          fetch(`${API_BASE_URL}/market/items/by-name?${params}`),
          loadItemDictionary(),
        ]);

        if (!response.ok) {
          throw new Error(await readApiError(response));
        }

        const payload = (await response.json()) as MarketItemPage;
        setDictionary(dict);
        setData(payload);
      } catch (loadError) {
        setData(null);
        setError(loadError instanceof Error ? loadError.message : 'Failed to load item.');
      } finally {
        setIsLoading(false);
      }
    },
    [],
  );

  const fetchSales = useCallback(
    async (currentItemId: number, currentPage: number) => {
      setSalesLoading(true);
      try {
        const params = new URLSearchParams();
        params.set('page', String(currentPage));
        params.set('pageSize', String(PAGE_SIZE));
        const response = await fetch(`${API_BASE_URL}/market/items/${currentItemId}/sales?${params}`);
        if (!response.ok) throw new Error(await readApiError(response));
        const payload = (await response.json()) as PagedResult<SaleHistoryItem>;
        setSalesData(payload);
      } catch {
        setSalesData(null);
      } finally {
        setSalesLoading(false);
      }
    },
    [],
  );

  // Reset the view whenever the target item changes (new exterior / variant page).
  useEffect(() => {
    setSortBy(0);
    setPage(1);
    setFilters(EMPTY_FILTERS);
    setDraft(EMPTY_FILTERS);
    setActiveTab('listings');
    setSalesData(null);
    setSalesPage(1);
  }, [itemName]);

  useEffect(() => {
    if (!itemName) {
      setData(null);
      setIsLoading(false);
      setError('No item selected.');
      return;
    }
    void fetchPage(itemName, sortBy, page, filters);
  }, [itemName, sortBy, page, filters, fetchPage]);

  // Fetch sales when the trades tab becomes active or the page changes.
  useEffect(() => {
    if (activeTab === 'trades' && data?.itemId != null) {
      void fetchSales(data.itemId, salesPage);
    }
  }, [activeTab, data?.itemId, salesPage, fetchSales]);

  const reload = () => {
    if (itemName) void fetchPage(itemName, sortBy, page, filters);
  };

  const changeSort = (next: CatalogSortOption) => {
    setSortBy(next);
    setPage(1);
  };

  // Float filter is bounded by this exterior's tier, intersected with the skin's own float cap.
  const floatBounds = useMemo<[number, number]>(() => {
    if (!data) return [0, 1];
    const [tierMin, tierMax] = data.wear ? getWearTierRange(data.wear) : [0, 1];
    const stat = getItemStatic(dictionary, data.marketHashName);
    const min = Math.max(tierMin, stat?.minF ?? tierMin);
    const max = Math.min(tierMax, stat?.maxF ?? tierMax);
    return [min, max];
  }, [data, dictionary]);

  const applyFilters = () => {
    const [lo, hi] = floatBounds;
    const clampFloat = (value: string) => {
      if (!value) return '';
      const parsed = Number(value);
      if (!Number.isFinite(parsed)) return '';
      return String(Math.min(hi, Math.max(lo, parsed)));
    };
    const next: Filters = {
      ...draft,
      minFloat: clampFloat(draft.minFloat),
      maxFloat: clampFloat(draft.maxFloat),
    };
    setDraft(next);
    setFilters(next);
    setPage(1);
  };

  const resetFilters = () => {
    setDraft(EMPTY_FILTERS);
    setFilters(EMPTY_FILTERS);
    setPage(1);
  };

  const accent = useMemo(() => {
    if (!data?.rarityColor) return '#3b82f6';
    return data.rarityColor.startsWith('#') ? data.rarityColor : `#${data.rarityColor}`;
  }, [data?.rarityColor]);

  const totalPages = data?.listings.totalPages ?? 1;
  const listings = data?.listings.items ?? [];
  const hasActiveFilters = Object.values(filters).some(Boolean);
  const showVariants = (data?.variants.length ?? 0) > 1;

  const steamUrl = data
    ? `https://steamcommunity.com/market/listings/730/${encodeURIComponent(data.marketHashName)}`
    : '#';

  const floatStep = useMemo(() => {
    const span = floatBounds[1] - floatBounds[0];
    return span > 0 && span < 0.1 ? '0.001' : '0.01';
  }, [floatBounds]);

  return (
    <section className="skin-page">
      <nav className="skin-breadcrumb">
        <button type="button" className="skin-back" onClick={onBack}>
          <ArrowLeft size={16} />
          <span>Market</span>
        </button>
        {data ? <span className="skin-crumb-current">{data.baseName}</span> : null}
      </nav>

      {isLoading && !data ? (
        <div className="skin-loading">
          <Loader2 size={28} className="spin-animation" />
        </div>
      ) : error && !data ? (
        <div className="inventory-state inventory-error" role="alert">
          <strong>Error</strong>
          <p>{error}</p>
          <button className="secondary-button" type="button" onClick={reload}>
            Retry
          </button>
        </div>
      ) : data ? (
        <>
          {/* ── Header ── */}
          <header className="skin-hero" style={{ '--item-accent': accent } as CSSProperties}>
            <div className="skin-hero-media">
              <div className="skin-hero-image">
                <div className="skin-hero-glow" />
                <img alt={data.baseName} src={data.imageUrl} />
              </div>
            </div>

            <div className="skin-hero-info">
              <div className="skin-hero-top">
                <div className="skin-hero-heading">
                  <div className="skin-hero-eyebrow">
                    <span className="skin-rarity-dot" style={{ background: accent }} />
                    <span style={{ color: accent }}>{data.rarity}</span>
                    <span className="skin-eyebrow-sep">·</span>
                    <span>{data.weapon ?? data.category}</span>
                  </div>
                  <h1 className="skin-hero-title">
                    {data.baseName}
                    {data.wear ? <span className="skin-hero-wear"> ({data.wear})</span> : null}
                  </h1>
                  <div className="skin-hero-tags">
                    {data.isStatTrak ? <span className="skin-tag stattrak">StatTrak™</span> : null}
                    {data.isSouvenir ? <span className="skin-tag souvenir">Souvenir</span> : null}
                    <span className="skin-tag muted">{data.category}</span>
                  </div>
                </div>

                <a className="skin-steam-link" href={steamUrl} target="_blank" rel="noopener noreferrer">
                  <ExternalLink size={14} />
                  <span>Steam Market</span>
                </a>
              </div>

              <div className="skin-hero-price">
                <span className="skin-hero-price-label">Reference price</span>
                <div className="skin-hero-price-row">
                  <span className="skin-hero-price-value">
                    {data.minPrice != null ? `$${data.minPrice.toFixed(2)}` : '—'}
                  </span>
                  {data.avgPrice != null ? (
                    <span className="skin-hero-price-avg">avg ${data.avgPrice.toFixed(2)}</span>
                  ) : null}
                </div>
              </div>

              {/* Wear tiers — each is its own page. */}
              {data.wears.length > 0 ? (
                <div className="skin-variations">
                  <span className="skin-variations-label">Exterior</span>
                  <div className="skin-wear-tabs">
                    {data.wears.map((w) => (
                      <button
                        key={w.marketHashName}
                        type="button"
                        className={`skin-wear-tab ${w.isActive ? 'active' : ''}`}
                        onClick={() => (w.isActive ? undefined : goToItem(w.marketHashName))}
                        style={{ '--item-accent': accent } as CSSProperties}
                      >
                        <span className="skin-wear-name">{w.wear}</span>
                        <span className={`skin-wear-price ${w.minPrice == null ? 'empty' : ''}`}>
                          {w.minPrice != null ? `$${w.minPrice.toFixed(2)}` : 'None'}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              ) : null}

              {/* Variant switchers — each navigates to another item page. */}
              {showVariants ? (
                <div className="skin-variations">
                  <span className="skin-variations-label">Variant</span>
                  <div className="skin-mod-tabs">
                    {data.variants.map((v) => (
                      <button
                        key={v.kind}
                        type="button"
                        className={`skin-mod-tab ${v.kind} ${v.isActive ? 'active' : ''}`}
                        onClick={() => (v.isActive ? undefined : goToItem(v.marketHashName))}
                      >
                        {VARIANT_LABEL[v.kind]}
                      </button>
                    ))}
                  </div>
                </div>
              ) : null}
            </div>
          </header>

          {/* ── Content tabs ── */}
          <div className="skin-tabbar" role="tablist">
            <button
              type="button"
              role="tab"
              aria-selected={activeTab === 'listings'}
              className={`skin-tab ${activeTab === 'listings' ? 'active' : ''}`}
              onClick={() => setActiveTab('listings')}
            >
              Listings <span className="skin-tab-count">({data.listings.totalCount})</span>
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={activeTab === 'trades'}
              className={`skin-tab ${activeTab === 'trades' ? 'active' : ''}`}
              onClick={() => setActiveTab('trades')}
            >
              Trades
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={activeTab === 'stats'}
              className={`skin-tab ${activeTab === 'stats' ? 'active' : ''}`}
              onClick={() => setActiveTab('stats')}
            >
              Statistics
            </button>
          </div>

          {activeTab === 'listings' ? (
            <div className="skin-listings">
              {/* Filters + sort */}
              <div className="skin-toolbar">
                <div className="skin-filters">
                  <div className="skin-filter-field">
                    <span className="skin-filter-label">
                      Float
                      <span className="skin-filter-hint">
                        {floatBounds[0].toFixed(2)}–{floatBounds[1].toFixed(2)}
                      </span>
                    </span>
                    <div className="skin-filter-range">
                      <input
                        className="skin-filter-input"
                        type="number"
                        step={floatStep}
                        min={floatBounds[0]}
                        max={floatBounds[1]}
                        placeholder={floatBounds[0].toFixed(2)}
                        aria-label="Float from"
                        value={draft.minFloat}
                        onChange={(e) => setDraft((d) => ({ ...d, minFloat: e.target.value }))}
                      />
                      <span className="skin-filter-dash">–</span>
                      <input
                        className="skin-filter-input"
                        type="number"
                        step={floatStep}
                        min={floatBounds[0]}
                        max={floatBounds[1]}
                        placeholder={floatBounds[1].toFixed(2)}
                        aria-label="Float to"
                        value={draft.maxFloat}
                        onChange={(e) => setDraft((d) => ({ ...d, maxFloat: e.target.value }))}
                      />
                    </div>
                  </div>

                  <div className="skin-filter-field">
                    <span className="skin-filter-label">Paint Seed</span>
                    <input
                      className="skin-filter-input seed"
                      inputMode="numeric"
                      placeholder="Pattern #"
                      aria-label="Paint seed"
                      value={draft.paintSeed}
                      onChange={(e) => setDraft((d) => ({ ...d, paintSeed: e.target.value }))}
                    />
                  </div>

                  <div className="skin-filter-field">
                    <span className="skin-filter-label">Price, $</span>
                    <div className="skin-filter-range">
                      <input
                        className="skin-filter-input"
                        inputMode="decimal"
                        placeholder="min"
                        aria-label="Price from"
                        value={draft.minPrice}
                        onChange={(e) => setDraft((d) => ({ ...d, minPrice: e.target.value }))}
                      />
                      <span className="skin-filter-dash">–</span>
                      <input
                        className="skin-filter-input"
                        inputMode="decimal"
                        placeholder="max"
                        aria-label="Price to"
                        value={draft.maxPrice}
                        onChange={(e) => setDraft((d) => ({ ...d, maxPrice: e.target.value }))}
                      />
                    </div>
                  </div>

                  <button type="button" className="primary-button skin-filter-apply" onClick={applyFilters}>
                    Apply
                  </button>
                  {hasActiveFilters ? (
                    <button type="button" className="skin-filter-reset" onClick={resetFilters}>
                      Reset
                    </button>
                  ) : null}
                </div>

                <CatalogSortBar sortBy={sortBy} onSortChange={changeSort} />
              </div>

              {listings.length === 0 ? (
                <div className="inventory-state">
                  <strong>No listings</strong>
                  <p>There are no active listings matching these filters right now.</p>
                </div>
              ) : (
                <>
                  <div className="skin-listing-head">
                    <span>Item</span>
                    <span>Float</span>
                    <span>Paint Seed</span>
                    <span className="skin-listing-head-price">Price</span>
                    <span />
                  </div>

                  <ul className="skin-listing-list">
                    {listings.map((listing) => {
                      const itemStatic = getItemStatic(dictionary, listing.marketHashName);
                      const imageUrl = getItemImageUrl(itemStatic) || data.imageUrl;
                      const hasFloat = listing.floatValue != null && listing.floatValue > 0;
                      const hasSeed = listing.paintSeed != null && listing.paintSeed > 0;
                      const isOwnListing = Boolean(auth && listing.sellerSteamId === auth.userId);

                      return (
                        <li key={listing.id} className="skin-listing-row">
                          <div className="skin-listing-item">
                            <button
                              type="button"
                              className="skin-listing-thumb"
                              style={{ '--item-accent': accent } as CSSProperties}
                              onClick={() => setDetailListing(listing)}
                              title="View screenshots"
                            >
                              <img alt={listing.marketHashName} loading="lazy" src={imageUrl} />
                              <span className="skin-listing-thumb-overlay">
                                <Camera size={16} />
                              </span>
                            </button>
                            {data.wear ? <span className="skin-listing-wear">{data.wear}</span> : null}
                          </div>

                          <div className="skin-listing-float">
                            {hasFloat ? (
                              <>
                                <FloatBar
                                  floatValue={listing.floatValue!}
                                  minFloat={itemStatic?.minF}
                                  maxFloat={itemStatic?.maxF}
                                  size="compact"
                                  showInfo={false}
                                />
                                <span className="skin-listing-floatval">{formatFloat(listing.floatValue)}</span>
                              </>
                            ) : (
                              <span className="skin-listing-floatval muted">—</span>
                            )}
                          </div>

                          <div className="skin-listing-seed">{hasSeed ? `#${listing.paintSeed}` : '—'}</div>

                          <div className="skin-listing-price">${listing.price.toFixed(2)}</div>

                          <div className="skin-listing-action">
                            {isOwnListing ? (
                              <span className="skin-listing-own">Your listing</span>
                            ) : (
                              <PurchaseButton
                                auth={auth}
                                authorizedFetch={authorizedFetch}
                                listingId={listing.id}
                                onCreated={reload}
                                onRequireLogin={onRequireLogin}
                              />
                            )}
                          </div>
                        </li>
                      );
                    })}
                  </ul>

                  {totalPages > 1 ? (
                    <nav className="skin-pager" aria-label="Listings pagination">
                      <button
                        type="button"
                        className="skin-page-btn"
                        disabled={page <= 1}
                        onClick={() => setPage((p) => Math.max(1, p - 1))}
                        aria-label="Previous page"
                      >
                        <ChevronLeft size={16} />
                      </button>
                      {getPageWindow(page, totalPages).map((entry, index) =>
                        entry === 'gap' ? (
                          <span key={`gap-${index}`} className="skin-page-gap">
                            …
                          </span>
                        ) : (
                          <button
                            key={entry}
                            type="button"
                            className={`skin-page-btn ${entry === page ? 'active' : ''}`}
                            onClick={() => setPage(entry)}
                          >
                            {entry}
                          </button>
                        ),
                      )}
                      <button
                        type="button"
                        className="skin-page-btn"
                        disabled={page >= totalPages}
                        onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                        aria-label="Next page"
                      >
                        <ChevronRight size={16} />
                      </button>
                    </nav>
                  ) : null}
                </>
              )}
            </div>
          ) : null}

          {activeTab === 'trades' ? (
            <div className="skin-listings">
              {salesLoading && !salesData ? (
                <div className="skin-loading">
                  <Loader2 size={28} className="spin-animation" />
                </div>
              ) : !salesData || salesData.items.length === 0 ? (
                <div className="inventory-state">
                  <strong>No sales yet</strong>
                  <p>There are no recorded sales for this item.</p>
                </div>
              ) : (
                <>
                  <div className="skin-listing-head skin-sales-head">
                    <span>Item</span>
                    <span>Float</span>
                    <span>Paint Seed</span>
                    <span className="skin-listing-head-price">Price</span>
                    <span>Sold</span>
                  </div>

                  <ul className="skin-listing-list">
                    {salesData.items.map((sale) => {
                      const itemStatic = getItemStatic(dictionary, sale.marketHashName);
                      const imageUrl = getItemImageUrl(itemStatic) || data.imageUrl;
                      const hasFloat = sale.floatValue != null && sale.floatValue > 0;
                      const hasSeed = sale.paintSeed != null && sale.paintSeed > 0;

                      return (
                        <li key={`${sale.id}-${sale.soldAt}`} className="skin-listing-row">
                          <div className="skin-listing-item">
                            <button
                              type="button"
                              className="skin-listing-thumb"
                              style={{ '--item-accent': accent } as CSSProperties}
                              onClick={() => setDetailListing(sale)}
                              title="View screenshots"
                            >
                              <img alt={sale.marketHashName} loading="lazy" src={imageUrl} />
                              <span className="skin-listing-thumb-overlay">
                                <Camera size={16} />
                              </span>
                            </button>
                            {data.wear ? <span className="skin-listing-wear">{data.wear}</span> : null}
                          </div>

                          <div className="skin-listing-float">
                            {hasFloat ? (
                              <>
                                <FloatBar
                                  floatValue={sale.floatValue!}
                                  minFloat={itemStatic?.minF}
                                  maxFloat={itemStatic?.maxF}
                                  size="compact"
                                  showInfo={false}
                                />
                                <span className="skin-listing-floatval">{formatFloat(sale.floatValue)}</span>
                              </>
                            ) : (
                              <span className="skin-listing-floatval muted">—</span>
                            )}
                          </div>

                          <div className="skin-listing-seed">{hasSeed ? `#${sale.paintSeed}` : '—'}</div>

                          <div className="skin-listing-price">${sale.price.toFixed(2)}</div>

                          <div className="skin-listing-sold-at">
                            {(() => {
                              const d = new Date(sale.soldAt);
                              const dd = String(d.getDate()).padStart(2, '0');
                              const mm = String(d.getMonth() + 1).padStart(2, '0');
                              const yyyy = d.getFullYear();
                              const hh = String(d.getHours()).padStart(2, '0');
                              const mins = String(d.getMinutes()).padStart(2, '0');
                              return `${dd}.${mm}.${yyyy} ${hh}:${mins}`;
                            })()}
                          </div>
                        </li>
                      );
                    })}
                  </ul>

                  {salesData.totalPages > 1 ? (
                    <nav className="skin-pager" aria-label="Sales pagination">
                      <button
                        type="button"
                        className="skin-page-btn"
                        disabled={salesPage <= 1}
                        onClick={() => setSalesPage((p) => Math.max(1, p - 1))}
                        aria-label="Previous page"
                      >
                        <ChevronLeft size={16} />
                      </button>
                      {getPageWindow(salesPage, salesData.totalPages).map((entry, index) =>
                        entry === 'gap' ? (
                          <span key={`gap-${index}`} className="skin-page-gap">
                            …
                          </span>
                        ) : (
                          <button
                            key={entry}
                            type="button"
                            className={`skin-page-btn ${entry === salesPage ? 'active' : ''}`}
                            onClick={() => setSalesPage(entry)}
                          >
                            {entry}
                          </button>
                        ),
                      )}
                      <button
                        type="button"
                        className="skin-page-btn"
                        disabled={salesPage >= salesData.totalPages}
                        onClick={() => setSalesPage((p) => Math.min(salesData!.totalPages, p + 1))}
                        aria-label="Next page"
                      >
                        <ChevronRight size={16} />
                      </button>
                    </nav>
                  ) : null}
                </>
              )}
            </div>
          ) : null}

          {activeTab === 'stats' ? (
            <div className="skin-tab-placeholder">
              <strong>Statistics</strong>
              <p>Price and volume charts are coming soon.</p>
            </div>
          ) : null}
        </>
      ) : null}

      {detailListing && (
        <ItemDetailModal
          source={{ kind: 'listing', listing: detailListing }}
          itemStatic={getItemStatic(dictionary, detailListing.marketHashName)}
          onClose={() => setDetailListing(null)}
          market={{
            auth,
            authorizedFetch,
            isOwnListing: Boolean(auth && detailListing.sellerSteamId === auth.userId),
            onChanged: reload,
            onRequireLogin,
          }}
        />
      )}
    </section>
  );
}
