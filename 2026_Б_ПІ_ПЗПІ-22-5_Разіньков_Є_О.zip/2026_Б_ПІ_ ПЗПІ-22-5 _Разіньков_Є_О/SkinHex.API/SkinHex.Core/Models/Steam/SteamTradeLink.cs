using System.Web;

namespace SkinHex.Core.Models.Steam;

public sealed record SteamTradeLink
{
    private const ulong SteamId64Offset = 76561197960265728UL;

    private SteamTradeLink(Uri uri, uint partnerAccountId, string token)
    {
        Uri = uri;
        PartnerAccountId = partnerAccountId;
        SteamId64 = SteamId64Offset + partnerAccountId;
        Token = token;
    }

    public Uri Uri { get; }
    public uint PartnerAccountId { get; }
    public ulong SteamId64 { get; }
    public string Token { get; }

    public static bool TryParse(
        string? value,
        out SteamTradeLink? tradeLink,
        out string error)
    {
        tradeLink = null;

        if (!System.Uri.TryCreate(value, UriKind.Absolute, out var uri) ||
            uri.Scheme != System.Uri.UriSchemeHttps ||
            !uri.Host.Equals("steamcommunity.com", StringComparison.OrdinalIgnoreCase) ||
            !uri.AbsolutePath.TrimEnd('/').Equals("/tradeoffer/new", StringComparison.OrdinalIgnoreCase))
        {
            error = "Trade link must be a valid Steam Community HTTPS trade offer URL.";
            return false;
        }

        var query = HttpUtility.ParseQueryString(uri.Query);
        if (!uint.TryParse(query["partner"], out var partnerAccountId) ||
            string.IsNullOrWhiteSpace(query["token"]))
        {
            error = "Trade link must contain valid partner and token parameters.";
            return false;
        }

        tradeLink = new SteamTradeLink(uri, partnerAccountId, query["token"]!);
        error = string.Empty;
        return true;
    }
}
