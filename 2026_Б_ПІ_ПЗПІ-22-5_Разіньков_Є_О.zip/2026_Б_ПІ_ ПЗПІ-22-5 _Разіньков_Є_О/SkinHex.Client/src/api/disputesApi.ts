import type { AuthorizedFetch } from '../types';
import { readApiError } from '../utils/api';

// ---- DTOs (mirror SkinHex.Core.Models.Disputes) ----

/** User-selectable dispute reasons. UnverifiedBuyerFault is system-only and never offered. */
export type DisputeReason =
  | 'OfferNotReceived'
  | 'WrongItemReceived'
  | 'RollbackFraud'
  | 'StuckEscrow'
  | 'PenaltyAppeal'
  | 'Other';

export type DisputeStatus = 'Open' | 'UnderReview' | 'Resolved' | 'Rejected';

export interface Dispute {
  id: string;
  orderId: string;
  openedByUserId: string | null;
  reason: string;
  status: string;
  resolution: string;
  description: string;
  resolutionNote: string | null;
  frozenPenaltyAmount: number | null;
  createdAt: string;
  updatedAt: string;
  resolvedAt: string | null;
}

export const USER_DISPUTE_REASONS: DisputeReason[] = [
  'OfferNotReceived',
  'WrongItemReceived',
  'RollbackFraud',
  'StuckEscrow',
  'PenaltyAppeal',
  'Other',
];

export function isDisputeOpen(dispute: Dispute | null | undefined): boolean {
  return dispute?.status === 'Open' || dispute?.status === 'UnderReview';
}

async function json<T>(response: Response): Promise<T> {
  if (!response.ok) {
    throw new Error(await readApiError(response));
  }
  return response.json() as Promise<T>;
}

export async function openDispute(
  fetcher: AuthorizedFetch,
  orderId: string,
  reason: DisputeReason,
  description: string,
): Promise<Dispute> {
  return json<Dispute>(
    await fetcher(`/orders/${orderId}/disputes`, {
      method: 'POST',
      body: JSON.stringify({ reason, description }),
    }),
  );
}

export async function fetchMyDisputes(fetcher: AuthorizedFetch): Promise<Dispute[]> {
  return json<Dispute[]>(await fetcher('/disputes/my'));
}

/** Latest dispute per order; an open one always wins over resolved history. */
export function indexDisputesByOrder(disputes: Dispute[]): Record<string, Dispute> {
  const byOrder: Record<string, Dispute> = {};
  for (const dispute of disputes) {
    const existing = byOrder[dispute.orderId];
    if (!existing || (isDisputeOpen(dispute) && !isDisputeOpen(existing))) {
      byOrder[dispute.orderId] = dispute;
    }
  }
  return byOrder;
}
