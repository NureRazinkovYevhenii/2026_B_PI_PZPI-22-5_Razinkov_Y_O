namespace SkinHex.Core.Models.Transactions;

/// <summary>Crypto details for deposit/withdrawal transactions.</summary>
public record TransactionCryptoDto(
    string PayCurrency,
    string? Network,
    decimal? Amount,       // amount in the coin (deposit) or payout USD (withdrawal)
    string? Address,       // payout address for withdrawals
    string? PaymentId,     // NOWPayments payment/payout id (internal reference)
    string? TxHash,        // on-chain transaction hash: payin hash (deposit) or payout hash (withdrawal)
    string? ExplorerUrl);  // link to view TxHash on the relevant block explorer, when known

/// <summary>Skin details for purchase/sale transactions.</summary>
public record TransactionSkinDto(
    string MarketHashName,
    string? Wear,
    double? Float,
    string PartnerUsername,
    string Role);      // "Purchase" or "Sale"

public record TransactionDto(
    Guid Id,
    decimal Amount,
    string Type,
    string Status,
    DateTime CreatedAt,
    TransactionCryptoDto? Crypto,
    TransactionSkinDto? Skin);
