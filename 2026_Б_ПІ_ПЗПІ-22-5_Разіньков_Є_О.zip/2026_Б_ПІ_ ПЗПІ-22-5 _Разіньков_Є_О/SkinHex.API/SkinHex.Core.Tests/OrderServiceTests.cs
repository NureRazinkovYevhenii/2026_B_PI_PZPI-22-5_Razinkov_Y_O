using FluentAssertions;
using Hangfire;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using SkinHex.Core.Entities;
using SkinHex.Core.Errors;
using SkinHex.Core.Interfaces;
using SkinHex.Core.Interfaces.Repositories;
using SkinHex.Core.Interfaces.Services;
using SkinHex.Core.Interfaces.Steam;
using SkinHex.Core.Options;
using SkinHex.Core.Services;

namespace SkinHex.Core.Tests;

public class OrderServiceTests
{
    private readonly Mock<IOrderRepository> _orderRepoMock;
    private readonly Mock<IListingRepository> _listingRepoMock;
    private readonly Mock<IUserRepository> _userRepoMock;
    private readonly Mock<IUnitOfWork> _uowMock;
    private readonly Mock<ISteamGatewayClient> _steamGatewayClientMock;
    private readonly Mock<IBackgroundJobClient> _backgroundJobClientMock;
    private readonly Mock<IUserService> _userServiceMock;
    private readonly Mock<IFinancialTransactionRepository> _financialTxRepoMock;
    private readonly Mock<INotificationService> _notificationServiceMock;
    private readonly Mock<IDisputeRepository> _disputeRepoMock;
    private readonly Mock<Microsoft.Extensions.Logging.ILogger<OrderService>> _loggerMock;
    private readonly OrderOptions _options;
    private readonly OrderService _sut;

    public OrderServiceTests()
    {
        _orderRepoMock = new Mock<IOrderRepository>();
        _listingRepoMock = new Mock<IListingRepository>();
        _userRepoMock = new Mock<IUserRepository>();
        _uowMock = new Mock<IUnitOfWork>();
        _steamGatewayClientMock = new Mock<ISteamGatewayClient>();
        _backgroundJobClientMock = new Mock<IBackgroundJobClient>();
        _userServiceMock = new Mock<IUserService>();
        _financialTxRepoMock = new Mock<IFinancialTransactionRepository>();
        _notificationServiceMock = new Mock<INotificationService>();
        _disputeRepoMock = new Mock<IDisputeRepository>();
        _loggerMock = new Mock<Microsoft.Extensions.Logging.ILogger<OrderService>>();

        _options = new OrderOptions
        {
            SellerConfirmWindowHours = 12,
            BuyerCancelWindowMinutes = 30,
            AutoCancelPollIntervalSeconds = 60
        };

        var optionsMock = new Mock<IOptions<OrderOptions>>();
        optionsMock.Setup(o => o.Value).Returns(_options);

        _sut = new OrderService(
            _orderRepoMock.Object,
            _listingRepoMock.Object,
            _userRepoMock.Object,
            _uowMock.Object,
            optionsMock.Object,
            _steamGatewayClientMock.Object,
            _userServiceMock.Object,
            _backgroundJobClientMock.Object,
            _financialTxRepoMock.Object,
            _notificationServiceMock.Object,
            _disputeRepoMock.Object,
            _loggerMock.Object);
    }

    private Order CreateTestOrder(Guid buyerId, Guid sellerId, DateTime createdAt, OrderStatus status = OrderStatus.Pending)
    {
        return new Order
        {
            Id = Guid.NewGuid(),
            BuyerId = buyerId,
            SellerId = sellerId,
            ListingId = Guid.NewGuid(),
            Status = status,
            CreatedAt = createdAt,
            ConfirmDeadline = createdAt.AddHours(_options.SellerConfirmWindowHours),
            LockPrice = 100,
            Listing = new Listing { Item = new Item { MarketHashName = "Test Item", BaseName = "", Category = "", Rarity = "", Color = "", ImageHash = "" } },
            Buyer = new User { Id = buyerId, Username = "Buyer" },
            Seller = new User { Id = sellerId, Username = "Seller" }
        };
    }

    [Fact]
    public async Task ProcessTlsnTradeStatusProofAsync_Completion_RecordsSaleTransaction()
    {
        var buyerId = Guid.NewGuid();
        var sellerId = Guid.NewGuid();
        const string steamTradeId = "trade-1";

        var order = CreateTestOrder(buyerId, sellerId, DateTime.UtcNow.AddDays(-9), OrderStatus.InEscrow);
        order.AcceptedAt = DateTime.UtcNow.AddDays(-8); // escrow (7d + buffer) has elapsed
        order.Buyer.SteamId = "buyerSteam";
        order.Listing.SteamAssetId = 123;
        order.SteamTrades.Add(new SteamTrade
        {
            Id = Guid.NewGuid(), OrderId = order.Id, TradeOfferId = "offer-1",
            TradeId = steamTradeId, OfferState = SteamOfferState.Accepted, UpdatedAt = DateTime.UtcNow.AddDays(-8)
        });

        _orderRepoMock.Setup(r => r.GetBySteamTradeIdWithDetailsAsync(steamTradeId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(order);
        _uowMock.Setup(u => u.BeginTransactionAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(Mock.Of<Microsoft.EntityFrameworkCore.Storage.IDbContextTransaction>());

        var settlementUnix = DateTimeOffset.UtcNow.AddHours(-1).ToUnixTimeSeconds();

        await _sut.ProcessTlsnTradeStatusProofAsync(
            steamTradeId, SteamTradeStatus.Complete, "buyerSteam", new[] { "123" },
            settlementUnix, DateTimeOffset.UtcNow, CancellationToken.None);

        order.Status.Should().Be(OrderStatus.Completed);

        // The buyer's Purchase entry is posted at purchase time; completion only settles the seller's Sale.
        _financialTxRepoMock.Verify(r => r.Add(It.Is<FinancialTransaction>(t =>
            t.UserId == sellerId && t.Type == FinancialTransactionType.Sale && t.ReferenceId == order.Id)),
            Times.Once);
        _financialTxRepoMock.Verify(r => r.Add(It.Is<FinancialTransaction>(t =>
            t.Type == FinancialTransactionType.Purchase)),
            Times.Never);
    }

    [Fact]
    public async Task ConfirmOrderAsync_Success_ChangesStatusToConfirmed()
    {
        var sellerId = Guid.NewGuid();
        var order = CreateTestOrder(Guid.NewGuid(), sellerId, DateTime.UtcNow);

        _orderRepoMock.Setup(r => r.GetByIdAsync(order.Id, It.IsAny<CancellationToken>()))
            .ReturnsAsync(order);

        _orderRepoMock.Setup(r => r.ExecuteConfirmAsync(order.Id, It.IsAny<DateTime>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(1); // 1 row updated

        var result = await _sut.ConfirmOrderAsync(order.Id, sellerId);

        result.Status.Should().Be(OrderStatus.Confirmed);
        order.Status.Should().Be(OrderStatus.Confirmed); // Verify in-memory updated
        order.ConfirmedAt.Should().NotBeNull();
    }

    [Fact]
    public async Task ConfirmOrderAsync_AfterDeadline_AutoCancelsAndThrowsExceeded()
    {
        var sellerId = Guid.NewGuid();
        // Created 13 hours ago, deadline is 12 hours -> expired
        var order = CreateTestOrder(Guid.NewGuid(), sellerId, DateTime.UtcNow.AddHours(-13)); 

        _orderRepoMock.Setup(r => r.GetByIdAsync(order.Id, It.IsAny<CancellationToken>()))
            .ReturnsAsync(order);
            
        _uowMock.Setup(u => u.BeginTransactionAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(Mock.Of<Microsoft.EntityFrameworkCore.Storage.IDbContextTransaction>());

        _orderRepoMock.Setup(r => r.ExecuteCancelAsync(order.Id, CancelledBy.System, It.IsAny<string>(), It.IsAny<DateTime>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(1); // Auto-cancel succeeds

        var act = async () => await _sut.ConfirmOrderAsync(order.Id, sellerId);

        var ex = await act.Should().ThrowAsync<BusinessException>();
        ex.Which.ErrorCode.Should().Be(BusinessErrorCodes.ConfirmDeadlineExceeded);
        ex.Which.Data["order"].Should().NotBeNull();
        order.Status.Should().Be(OrderStatus.Cancelled);
        order.CancelledBy.Should().Be(CancelledBy.System);
    }

    [Fact]
    public async Task CancelOrderAsync_BySeller_PendingOrder_NoPenalty_FullRefund()
    {
        // A Pending order was never confirmed — cancelling it carries NO penalty for anyone,
        // even when the seller cancels. Buyer is refunded in full, seller is not charged.
        var buyerId = Guid.NewGuid();
        var sellerId = Guid.NewGuid();
        var order = CreateTestOrder(buyerId, sellerId, DateTime.UtcNow); // default status = Pending
        var buyer = new User { Id = buyerId, FrozenBalance = 0, Balance = 50 };
        var seller = new User { Id = sellerId, FrozenBalance = 100, Balance = 10 };
        var listing = new Listing { Id = order.ListingId, Status = ListingStatus.TradePending };

        _orderRepoMock.Setup(r => r.GetByIdAsync(order.Id, It.IsAny<CancellationToken>())).ReturnsAsync(order);
        _uowMock.Setup(u => u.BeginTransactionAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(Mock.Of<Microsoft.EntityFrameworkCore.Storage.IDbContextTransaction>());
        _orderRepoMock.Setup(r => r.ExecuteCancelAsync(order.Id, CancelledBy.Seller, It.IsAny<string>(), It.IsAny<DateTime>(), It.IsAny<CancellationToken>())).ReturnsAsync(1);
        _userRepoMock.Setup(r => r.GetByIdAsync(buyerId, It.IsAny<CancellationToken>())).ReturnsAsync(buyer);
        _userRepoMock.Setup(r => r.GetByIdAsync(sellerId, It.IsAny<CancellationToken>())).ReturnsAsync(seller);
        _listingRepoMock.Setup(r => r.GetByIdAsync(listing.Id, It.IsAny<CancellationToken>())).ReturnsAsync(listing);

        var result = await _sut.CancelOrderAsync(order.Id, sellerId, "reason", null);

        result.Status.Should().Be(OrderStatus.Cancelled);

        buyer.Balance.Should().Be(150);        // full refund (50 + 100), no compensation
        seller.Balance.Should().Be(10);        // NOT charged
        buyer.FrozenBalance.Should().Be(0);
        seller.FrozenBalance.Should().Be(0);   // hold released
        listing.Status.Should().Be(ListingStatus.Active);

        _financialTxRepoMock.Verify(r => r.Add(It.Is<FinancialTransaction>(t =>
            t.UserId == buyerId && t.Type == FinancialTransactionType.Refund && t.Amount == 100m && t.ReferenceId == order.Id)), Times.Once);
        _financialTxRepoMock.Verify(r => r.Add(It.Is<FinancialTransaction>(t =>
            t.Type == FinancialTransactionType.Penalty)), Times.Never);
    }

    [Fact]
    public async Task CancelOrderAsync_ByBuyer_PendingOrder_NoPenalty_FullRefund()
    {
        // Reported bug: buyer cancels a not-yet-confirmed purchase after 30 min — there must be
        // NO penalty (previously latestTrade == null wrongly blamed the seller and paid the buyer 0.05).
        var buyerId = Guid.NewGuid();
        var sellerId = Guid.NewGuid();
        var order = CreateTestOrder(buyerId, sellerId, DateTime.UtcNow.AddMinutes(-35)); // Pending, past 30-min window
        var buyer = new User { Id = buyerId, FrozenBalance = 0, Balance = 0 };
        var seller = new User { Id = sellerId, FrozenBalance = 100, Balance = 10 };
        var listing = new Listing { Id = order.ListingId, Status = ListingStatus.TradePending };

        _orderRepoMock.Setup(r => r.GetByIdAsync(order.Id, It.IsAny<CancellationToken>())).ReturnsAsync(order);
        _uowMock.Setup(u => u.BeginTransactionAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(Mock.Of<Microsoft.EntityFrameworkCore.Storage.IDbContextTransaction>());
        _orderRepoMock.Setup(r => r.ExecuteCancelAsync(order.Id, CancelledBy.Buyer, It.IsAny<string>(), It.IsAny<DateTime>(), It.IsAny<CancellationToken>())).ReturnsAsync(1);
        _userRepoMock.Setup(r => r.GetByIdAsync(buyerId, It.IsAny<CancellationToken>())).ReturnsAsync(buyer);
        _userRepoMock.Setup(r => r.GetByIdAsync(sellerId, It.IsAny<CancellationToken>())).ReturnsAsync(seller);
        _listingRepoMock.Setup(r => r.GetByIdAsync(listing.Id, It.IsAny<CancellationToken>())).ReturnsAsync(listing);

        await _sut.CancelOrderAsync(order.Id, buyerId, "changed my mind", null);

        buyer.Balance.Should().Be(100);        // full refund
        seller.Balance.Should().Be(10);        // seller not touched
        seller.FrozenBalance.Should().Be(0);   // hold released
        _financialTxRepoMock.Verify(r => r.Add(It.Is<FinancialTransaction>(t =>
            t.Type == FinancialTransactionType.Penalty)), Times.Never);
    }

    [Fact]
    public async Task CancelOrderAsync_ByBuyer_TooEarly_Throws()
    {
        var buyerId = Guid.NewGuid();
        var order = CreateTestOrder(buyerId, Guid.NewGuid(), DateTime.UtcNow.AddMinutes(-10)); // Only 10 mins passed

        _orderRepoMock.Setup(r => r.GetByIdAsync(order.Id, It.IsAny<CancellationToken>())).ReturnsAsync(order);

        var act = async () => await _sut.CancelOrderAsync(order.Id, buyerId, "reason", null);

        var ex = await act.Should().ThrowAsync<BusinessException>();
        ex.Which.ErrorCode.Should().Be(BusinessErrorCodes.TooEarlyToCancel);
        ex.Which.Data["remainingSeconds"].Should().NotBeNull();
    }
    
    [Fact]
    public async Task CancelOrderAsync_ByBuyer_After30Min_Success()
    {
        var buyerId = Guid.NewGuid();
        var order = CreateTestOrder(buyerId, Guid.NewGuid(), DateTime.UtcNow.AddMinutes(-35)); // 35 mins passed

        _orderRepoMock.Setup(r => r.GetByIdAsync(order.Id, It.IsAny<CancellationToken>())).ReturnsAsync(order);
        _uowMock.Setup(u => u.BeginTransactionAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(Mock.Of<Microsoft.EntityFrameworkCore.Storage.IDbContextTransaction>());
        _orderRepoMock.Setup(r => r.ExecuteCancelAsync(order.Id, CancelledBy.Buyer, It.IsAny<string>(), It.IsAny<DateTime>(), It.IsAny<CancellationToken>())).ReturnsAsync(1);

        var result = await _sut.CancelOrderAsync(order.Id, buyerId, "reason", null);

        result.Status.Should().Be(OrderStatus.Cancelled);
        result.CancelledBy.Should().Be("Buyer");
    }

    [Fact]
    public async Task CancelOrderAsync_Worker_System_Success()
    {
        var order = CreateTestOrder(Guid.NewGuid(), Guid.NewGuid(), DateTime.UtcNow.AddHours(-13));

        _orderRepoMock.Setup(r => r.GetByIdAsync(order.Id, It.IsAny<CancellationToken>())).ReturnsAsync(order);
        _uowMock.Setup(u => u.BeginTransactionAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(Mock.Of<Microsoft.EntityFrameworkCore.Storage.IDbContextTransaction>());
        _orderRepoMock.Setup(r => r.ExecuteCancelAsync(order.Id, CancelledBy.System, It.IsAny<string>(), It.IsAny<DateTime>(), It.IsAny<CancellationToken>())).ReturnsAsync(1);

        var result = await _sut.CancelOrderAsync(order.Id, null, "timeout", CancelledBy.System);

        result.Status.Should().Be(OrderStatus.Cancelled);
        result.CancelledBy.Should().Be("System");
    }

    [Fact]
    public async Task CancelOrderAsync_RaceCondition_ExecuteCancelReturns0_ThrowsOrderNotPending()
    {
        var buyerId = Guid.NewGuid();
        var order = CreateTestOrder(buyerId, Guid.NewGuid(), DateTime.UtcNow.AddMinutes(-35));

        _orderRepoMock.Setup(r => r.GetByIdAsync(order.Id, It.IsAny<CancellationToken>())).ReturnsAsync(order);
        _uowMock.Setup(u => u.BeginTransactionAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(Mock.Of<Microsoft.EntityFrameworkCore.Storage.IDbContextTransaction>());
            
        // Return 0 means no rows affected (status was no longer Pending)
        _orderRepoMock.Setup(r => r.ExecuteCancelAsync(order.Id, It.IsAny<CancelledBy>(), It.IsAny<string>(), It.IsAny<DateTime>(), It.IsAny<CancellationToken>())).ReturnsAsync(0);

        var act = async () => await _sut.CancelOrderAsync(order.Id, buyerId, "reason", null);

        var ex = await act.Should().ThrowAsync<BusinessException>();
        ex.Which.ErrorCode.Should().Be(BusinessErrorCodes.OrderNotPending);
    }

    [Fact]
    public void DetermineFault_NullTrade_ReturnsSeller()
    {
        var fault = _sut.DetermineFault(null, null, null, DateTime.UtcNow, null);
        fault.Should().Be(FaultParty.Seller);
    }

    [Fact]
    public void DetermineFault_RollbackBuyerReason_ReturnsBuyer()
    {
        var trade = new SteamTrade { OfferState = SteamOfferState.Active };
        var fault = _sut.DetermineFault(trade, null, null, DateTime.UtcNow, "Trade rolled back by buyer in Steam");
        fault.Should().Be(FaultParty.Buyer);
    }

    [Fact]
    public void DetermineFault_RollbackSellerReason_ReturnsSeller()
    {
        var trade = new SteamTrade { OfferState = SteamOfferState.Active };
        var fault = _sut.DetermineFault(trade, null, null, DateTime.UtcNow, "Trade rolled back by seller in Steam");
        fault.Should().Be(FaultParty.Seller);
    }

    [Fact]
    public void DetermineFault_TradeStatusRolledBackNoReason_LogsWarningAndReturnsNone()
    {
        var trade = new SteamTrade { TradeStatus = SteamTradeStatus.TradeProtectionRollback, TradeId = "123", OrderId = Guid.NewGuid() };
        var fault = _sut.DetermineFault(trade, null, null, DateTime.UtcNow, null);

        fault.Should().Be(FaultParty.None);
        _loggerMock.Verify(
            x => x.Log(
                LogLevel.Warning,
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((v, t) => true),
                It.IsAny<Exception>(),
                It.Is<Func<It.IsAnyType, Exception?, string>>((v, t) => true)),
            Times.Once);
    }

    [Fact]
    public void DetermineFault_OfferStateDeclined_ReturnsBuyer()
    {
        var trade = new SteamTrade { OfferState = SteamOfferState.Declined };
        var fault = _sut.DetermineFault(trade, null, null, DateTime.UtcNow, null);
        fault.Should().Be(FaultParty.Buyer);
    }

    [Fact]
    public void DetermineFault_OfferStateCanceled_AfterDeadline_ReturnsBuyer()
    {
        var trade = new SteamTrade { OfferState = SteamOfferState.Canceled };
        var sentAt = DateTime.UtcNow.AddHours(-25);
        var acceptDeadline = sentAt.AddHours(24);
        var cancelledAt = DateTime.UtcNow; // cancelled after 25h

        var fault = _sut.DetermineFault(trade, sentAt, acceptDeadline, cancelledAt, null);
        fault.Should().Be(FaultParty.Buyer);
    }

    [Fact]
    public void DetermineFault_OfferStateCanceled_BeforeDeadline_ReturnsSeller()
    {
        var trade = new SteamTrade { OfferState = SteamOfferState.Canceled };
        var sentAt = DateTime.UtcNow.AddHours(-10);
        var acceptDeadline = sentAt.AddHours(24);
        var cancelledAt = DateTime.UtcNow; // cancelled prematurely (after 10h)

        var fault = _sut.DetermineFault(trade, sentAt, acceptDeadline, cancelledAt, null);
        fault.Should().Be(FaultParty.Seller);
    }

    [Fact]
    public void DetermineFault_SellerCanceledEarly_ReturnsSeller_EvenIfHeuristicWouldSayBuyer()
    {
        // Repro of the reported bug: the offer is Canceled and >24h have passed since it was
        // sent, so the time-based heuristic alone would blame the BUYER. But the explicit
        // "seller canceled early" reason must win → SELLER fault (no buyer penalty, no dispute).
        var trade = new SteamTrade { OfferState = SteamOfferState.Canceled };
        var sentAt = DateTime.UtcNow.AddHours(-30);
        var deadline = sentAt.AddHours(24);

        var fault = _sut.DetermineFault(trade, sentAt, deadline, DateTime.UtcNow, "Seller canceled trade early in Steam");

        fault.Should().Be(FaultParty.Seller);
    }

    [Fact]
    public void DetermineFault_BuyerDeclined_ReturnsBuyer()
    {
        var trade = new SteamTrade { OfferState = SteamOfferState.Declined };
        var fault = _sut.DetermineFault(trade, DateTime.UtcNow.AddHours(-1), DateTime.UtcNow.AddHours(23), DateTime.UtcNow, "Buyer declined trade in Steam");
        fault.Should().Be(FaultParty.Buyer);
    }

    [Fact]
    public void DetermineFault_UnhandledCombination_LogsWarningAndReturnsNone()
    {
        var trade = new SteamTrade { OfferState = SteamOfferState.Invalid };
        var sentAt = DateTime.UtcNow;
        // Missing deadline will bypass the deadline check
        var fault = _sut.DetermineFault(trade, sentAt, null, DateTime.UtcNow, null);

        fault.Should().Be(FaultParty.None);
        _loggerMock.Verify(
            x => x.Log(
                LogLevel.Warning,
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((v, t) => true),
                It.IsAny<Exception>(),
                It.Is<Func<It.IsAnyType, Exception?, string>>((v, t) => true)),
            Times.Once);
    }

    private (Order order, User buyer, User seller) SetupBuyerTimeoutCancelScenario()
    {
        var buyerId = Guid.NewGuid();
        var sellerId = Guid.NewGuid();
        var order = CreateTestOrder(buyerId, sellerId, DateTime.UtcNow.AddHours(-25), OrderStatus.TradeSent);
        order.TradeSentAt = DateTime.UtcNow.AddHours(-25);
        order.TradeAcceptDeadline = order.TradeSentAt.Value.AddHours(24);
        order.LockPrice = 100m;

        // Trade was canceled (e.g. expired or buyer just ignored it) AFTER the accept deadline
        order.SteamTrades.Add(new SteamTrade
        {
            OrderId = order.Id,
            OfferState = SteamOfferState.Canceled,
            TradeStatus = SteamTradeStatus.Invalid,
            UpdatedAt = DateTime.UtcNow
        });

        var buyer = new User { Id = buyerId, FrozenBalance = 0m, Balance = 0m };
        var seller = new User { Id = sellerId, FrozenBalance = 100m, Balance = 0m };

        _userRepoMock.Setup(r => r.GetByIdAsync(buyerId, It.IsAny<CancellationToken>())).ReturnsAsync(buyer);
        _userRepoMock.Setup(r => r.GetByIdAsync(sellerId, It.IsAny<CancellationToken>())).ReturnsAsync(seller);
        _orderRepoMock.Setup(r => r.GetByIdAsync(order.Id, It.IsAny<CancellationToken>())).ReturnsAsync(order);
        _uowMock.Setup(u => u.BeginTransactionAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(Mock.Of<Microsoft.EntityFrameworkCore.Storage.IDbContextTransaction>());
        _orderRepoMock.Setup(r => r.ExecuteCancelAsync(order.Id, It.IsAny<CancelledBy>(), It.IsAny<string>(), It.IsAny<DateTime>(), It.IsAny<CancellationToken>())).ReturnsAsync(1);

        return (order, buyer, seller);
    }

    [Fact]
    public async Task ApplyPenalties_BuyerTimeout_WithBuyerConfirmation_AppliesBuyerPenalty()
    {
        var (order, buyer, seller) = SetupBuyerTimeoutCancelScenario();

        // The buyer's extension confirmed the offer really reached them with the right item.
        var trade = order.SteamTrades.First();
        trade.BuyerReportedOfferState = SteamOfferState.Active;
        trade.BuyerAssetMatchesListing = true;

        await _sut.CancelOrderAsync(order.Id, null, "timeout", CancelledBy.System);

        // Penalty is Max(100 * 0.02, 0.05) = 2.0 — charged immediately, corroboration exists.
        buyer.Balance.Should().Be(98m);
        seller.Balance.Should().Be(2m);
        buyer.FrozenBalance.Should().Be(0m);
        seller.FrozenBalance.Should().Be(0m);

        _disputeRepoMock.Verify(r => r.Add(It.IsAny<OrderDispute>()), Times.Never);
    }

    [Fact]
    public async Task ApplyPenalties_BuyerTimeout_WithoutBuyerConfirmation_AppliesPenaltyImmediately_NoDispute()
    {
        var (order, buyer, seller) = SetupBuyerTimeoutCancelScenario();

        await _sut.CancelOrderAsync(order.Id, null, "timeout", CancelledBy.System);

        // Policy: buyer-fault penalties apply immediately (money keeps moving, no admin friction).
        // A false report is the buyer's to contest via a PenaltyAppeal dispute — nothing is frozen
        // and no dispute is auto-opened here.
        buyer.Balance.Should().Be(98m);
        seller.Balance.Should().Be(2m);
        buyer.FrozenBalance.Should().Be(0m);
        seller.FrozenBalance.Should().Be(0m);

        _financialTxRepoMock.Verify(r => r.Add(It.Is<FinancialTransaction>(t =>
            t.UserId == buyer.Id && t.Type == FinancialTransactionType.Penalty && t.Amount == -2m)), Times.Once);
        _financialTxRepoMock.Verify(r => r.Add(It.Is<FinancialTransaction>(t =>
            t.UserId == seller.Id && t.Type == FinancialTransactionType.Penalty && t.Amount == 2m)), Times.Once);

        _disputeRepoMock.Verify(r => r.Add(It.IsAny<OrderDispute>()), Times.Never);
    }

    [Fact]
    public async Task CancelOrderAsync_WithOpenDispute_Throws()
    {
        var buyerId = Guid.NewGuid();
        var order = CreateTestOrder(buyerId, Guid.NewGuid(), DateTime.UtcNow.AddMinutes(-35));

        _disputeRepoMock.Setup(r => r.HasOpenDisputeAsync(order.Id, It.IsAny<CancellationToken>()))
            .ReturnsAsync(true);
        _orderRepoMock.Setup(r => r.GetByIdAsync(order.Id, It.IsAny<CancellationToken>())).ReturnsAsync(order);

        var act = async () => await _sut.CancelOrderAsync(order.Id, buyerId, "reason", null);

        var ex = await act.Should().ThrowAsync<BusinessException>();
        ex.Which.ErrorCode.Should().Be(BusinessErrorCodes.OrderDisputed);
    }

    [Fact]
    public async Task UpdateTradeAttemptAsync_WithOpenDispute_FreezesOrder_NoCancelNoPenalty()
    {
        // Repro of the reported bug: seller cancels the Steam offer while a dispute is open.
        // The trade state must be recorded, but the order must NOT auto-cancel (which would
        // apply a default penalty and override the pending support resolution).
        var buyerId = Guid.NewGuid();
        var sellerId = Guid.NewGuid();
        var order = CreateTestOrder(buyerId, sellerId, DateTime.UtcNow.AddHours(-26), OrderStatus.TradeSent);
        order.TradeSentAt = DateTime.UtcNow.AddHours(-26);
        order.TradeAcceptDeadline = order.TradeSentAt.Value.AddHours(24);
        order.SteamTrades.Add(new SteamTrade
        {
            Id = Guid.NewGuid(), OrderId = order.Id, TradeOfferId = "offer-1",
            OfferState = SteamOfferState.Active, UpdatedAt = DateTime.UtcNow.AddHours(-26)
        });

        _orderRepoMock.Setup(r => r.GetByIdWithDetailsAsync(order.Id, It.IsAny<CancellationToken>())).ReturnsAsync(order);
        _uowMock.Setup(u => u.BeginTransactionAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(Mock.Of<Microsoft.EntityFrameworkCore.Storage.IDbContextTransaction>());
        _disputeRepoMock.Setup(r => r.HasOpenDisputeAsync(order.Id, It.IsAny<CancellationToken>())).ReturnsAsync(true);

        // Seller "canceled after 24h" — the branch that would normally cancel with a buyer penalty.
        var canceledAtUnix = new DateTimeOffset(order.TradeSentAt.Value.AddHours(25)).ToUnixTimeSeconds();
        await _sut.UpdateTradeAttemptAsync(order.Id, sellerId, "offer-1", SteamOfferState.Canceled, null, null, canceledAtUnix);

        // Order stays put — frozen for the admin.
        order.Status.Should().Be(OrderStatus.TradeSent);
        _orderRepoMock.Verify(r => r.ExecuteCancelAsync(It.IsAny<Guid>(), It.IsAny<CancelledBy>(), It.IsAny<string>(), It.IsAny<DateTime>(), It.IsAny<CancellationToken>()), Times.Never);
        _financialTxRepoMock.Verify(r => r.Add(It.Is<FinancialTransaction>(t => t.Type == FinancialTransactionType.Penalty)), Times.Never);
    }
}
