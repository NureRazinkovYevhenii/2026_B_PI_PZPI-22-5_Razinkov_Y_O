using Microsoft.EntityFrameworkCore;
using SkinHex.Core.Entities;
using SkinHex.Core.Interfaces.Repositories;

namespace SkinHex.Infrastructure.Repositories;

public sealed class DisputeRepository(SkinHexDbContext context) : IDisputeRepository
{
    private static readonly DisputeStatus[] OpenStatuses = [DisputeStatus.Open, DisputeStatus.UnderReview];

    public void Add(OrderDispute dispute) => context.OrderDisputes.Add(dispute);

    public Task<bool> HasOpenDisputeAsync(Guid orderId, CancellationToken ct = default) =>
        context.OrderDisputes.AnyAsync(d => d.OrderId == orderId && OpenStatuses.Contains(d.Status), ct);

    public Task<OrderDispute?> GetOpenByOrderIdAsync(Guid orderId, CancellationToken ct = default) =>
        context.OrderDisputes
            .FirstOrDefaultAsync(d => d.OrderId == orderId && OpenStatuses.Contains(d.Status), ct);

    public Task<OrderDispute?> GetByIdAsync(Guid id, CancellationToken ct = default) =>
        context.OrderDisputes
            .Include(d => d.Order)
            .FirstOrDefaultAsync(d => d.Id == id, ct);

    public Task<OrderDispute?> GetByIdWithOrderDetailsAsync(Guid id, CancellationToken ct = default) =>
        context.OrderDisputes
            .Include(d => d.Order).ThenInclude(o => o.Buyer)
            .Include(d => d.Order).ThenInclude(o => o.Seller)
            .Include(d => d.Order).ThenInclude(o => o.Listing)
            .FirstOrDefaultAsync(d => d.Id == id, ct);

    public Task<List<OrderDispute>> GetByParticipantAsync(Guid userId, CancellationToken ct = default) =>
        context.OrderDisputes
            .AsNoTracking()
            .Where(d => d.Order.BuyerId == userId || d.Order.SellerId == userId)
            .OrderByDescending(d => d.UpdatedAt)
            .ToListAsync(ct);
}
