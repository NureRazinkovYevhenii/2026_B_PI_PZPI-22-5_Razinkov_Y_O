import { useTranslation } from 'react-i18next';

type VerificationBannerProps = {
  isUnverified: boolean;
  onVerify: () => void;
};

export function VerificationBanner({ isUnverified, onVerify }: VerificationBannerProps) {
  const { t } = useTranslation();
  
  const title = isUnverified ? t('banner.emailTitle') : t('banner.tradeTitle');
  const desc = isUnverified 
    ? t('banner.emailDesc')
    : t('banner.tradeDesc');
  const btn = isUnverified ? t('banner.verifyBtn') : t('banner.tradeBtn');

  return (
    <section className="verification-banner glass-panel" aria-live="polite" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '16px 24px', borderRadius: '12px', marginBottom: '24px', border: '1px solid var(--accent)' }}>
      <div>
        <strong style={{ display: 'block', fontSize: '16px', color: 'var(--text-h)', marginBottom: '4px' }}>{title}</strong>
        <p style={{ margin: 0, color: 'var(--text-muted)', fontSize: '14px' }}>{desc}</p>
      </div>
      <button className="primary-button" onClick={onVerify} type="button" style={{ whiteSpace: 'nowrap' }}>
        {btn}
      </button>
    </section>
  );
}

