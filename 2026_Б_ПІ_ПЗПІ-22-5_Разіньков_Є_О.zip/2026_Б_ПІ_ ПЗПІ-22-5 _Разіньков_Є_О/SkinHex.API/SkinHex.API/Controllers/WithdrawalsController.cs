using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using SkinHex.Core.Entities;
using SkinHex.Core.Models;
using SkinHex.Core.Models.Withdrawals;
using SkinHex.Core.Options;
using SkinHex.Infrastructure;

namespace SkinHex.API.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public sealed class WithdrawalsController : ControllerBase
{
    private readonly SkinHexDbContext _dbContext;
    private readonly NowPaymentsOptions _options;
    private readonly ILogger<WithdrawalsController> _logger;

    public WithdrawalsController(
        SkinHexDbContext dbContext,
        IOptions<NowPaymentsOptions> options,
        ILogger<WithdrawalsController> logger)
    {
        _dbContext = dbContext;
        _options = options.Value;
        _logger = logger;
    }

    /// <summary>Stablecoins the user can withdraw to, plus the platform minimum and fee.</summary>
    [AllowAnonymous]
    [HttpGet("currencies")]
    public IActionResult GetCurrencies()
    {
        return Ok(new
        {
            minWithdrawalUsd = _options.MinWithdrawalUsd,
            withdrawalFeePercent = _options.WithdrawalFeePercent,
            currencies = SupportedDepositCurrencies.All
                .Where(c => c.Group == SupportedDepositCurrencies.GroupStablecoin)
        });
    }

    /// <summary>Live breakdown of platform fee, estimated network fee, and the amount the user will receive.</summary>
    [AllowAnonymous]
    [HttpGet("estimate")]
    public IActionResult GetEstimate([FromQuery] decimal amountUsd, [FromQuery] string payCurrency)
    {
        if (amountUsd <= 0)
            return BadRequest(new { message = "Amount must be greater than zero." });
        if (!IsSupportedStablecoin(payCurrency))
            return BadRequest(new { message = "Unsupported currency." });

        var platformFee = decimal.Round(amountUsd * _options.WithdrawalFeePercent, 2, MidpointRounding.ToPositiveInfinity);
        var estNetworkFee = GetNetworkFeeEstimate(payCurrency);
        var estimatedReceive = Math.Max(0m, amountUsd - platformFee - (estNetworkFee ?? 0m));

        return Ok(new WithdrawalEstimateDto(
            amountUsd,
            _options.WithdrawalFeePercent,
            platformFee,
            estNetworkFee,
            decimal.Round(estimatedReceive, 2, MidpointRounding.ToNegativeInfinity),
            payCurrency));
    }

    [HttpPost]
    public async Task<IActionResult> CreateWithdrawal([FromBody] CreateWithdrawalRequest request, CancellationToken ct)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
            return Unauthorized();

        if (request.AmountUsd <= 0)
            return BadRequest(new { message = "Amount must be greater than zero." });
        if (!IsSupportedStablecoin(request.PayCurrency))
            return BadRequest(new { message = "Unsupported currency." });
        if (string.IsNullOrWhiteSpace(request.Address))
            return BadRequest(new { message = "Payout address is required." });
        if (request.AmountUsd < _options.MinWithdrawalUsd)
            return BadRequest(new { message = $"Minimum withdrawal is ${_options.MinWithdrawalUsd}." });

        var user = await _dbContext.Users.FirstOrDefaultAsync(u => u.Id == userId, ct);
        if (user is null)
            return Unauthorized();
        if (user.Role == UserRole.Banned)
            return StatusCode(StatusCodes.Status403Forbidden, new { message = "Account is banned." });
        if (user.Balance < request.AmountUsd)
            return BadRequest(new { message = "Insufficient balance." });

        var platformFee = decimal.Round(request.AmountUsd * _options.WithdrawalFeePercent, 2, MidpointRounding.ToPositiveInfinity);
        var payoutAmount = request.AmountUsd - platformFee;

        var now = DateTime.UtcNow;
        var transaction = new FinancialTransaction
        {
            Id = Guid.NewGuid(),
            UserId = user.Id,
            Amount = request.AmountUsd,
            Type = FinancialTransactionType.Withdrawal,
            Status = FinancialTransactionStatus.Pending,
            CreatedAt = now
        };

        var withdrawal = new Withdrawal
        {
            Id = Guid.NewGuid(),
            UserId = user.Id,
            TransactionId = transaction.Id,
            AmountUsd = request.AmountUsd,
            PlatformFeeUsd = platformFee,
            PayoutAmountUsd = payoutAmount,
            PayCurrency = request.PayCurrency.Trim().ToLowerInvariant(),
            PayoutAddress = request.Address.Trim(),
            PayoutExtraId = string.IsNullOrWhiteSpace(request.ExtraId) ? null : request.ExtraId.Trim(),
            Status = WithdrawalStatus.Pending,
            CreatedAt = now,
            UpdatedAt = now
        };
        transaction.ReferenceId = withdrawal.Id;

        // Debit the main balance immediately (no freeze).
        user.Balance -= request.AmountUsd;
        user.UpdatedAt = now;

        _dbContext.FinancialTransactions.Add(transaction);
        _dbContext.Withdrawals.Add(withdrawal);

        var useTransaction = _dbContext.Database.ProviderName != "Microsoft.EntityFrameworkCore.InMemory";
        var dbTransaction = useTransaction ? await _dbContext.Database.BeginTransactionAsync(ct) : null;
        try
        {
            await _dbContext.SaveChangesAsync(ct);
            if (dbTransaction != null)
                await dbTransaction.CommitAsync(ct);
        }
        finally
        {
            if (dbTransaction != null)
                await dbTransaction.DisposeAsync();
        }

        _logger.LogInformation("User {UserId} requested withdrawal {WithdrawalId} for {Amount} USD", user.Id, withdrawal.Id, request.AmountUsd);

        return Ok(ToDto(withdrawal));
    }

    [HttpGet("my")]
    public async Task<IActionResult> GetMyWithdrawals(CancellationToken ct)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
            return Unauthorized();

        var rows = await _dbContext.Withdrawals
            .AsNoTracking()
            .Where(w => w.UserId == userId)
            .OrderByDescending(w => w.CreatedAt)
            .ToListAsync(ct);

        return Ok(rows.Select(ToDto).ToList());
    }

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> GetWithdrawal(Guid id, CancellationToken ct)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
            return Unauthorized();

        var withdrawal = await _dbContext.Withdrawals.AsNoTracking().FirstOrDefaultAsync(w => w.Id == id, ct);
        if (withdrawal is null)
            return NotFound();
        if (withdrawal.UserId != userId)
            return Forbid();

        return Ok(ToDto(withdrawal));
    }

    private static WithdrawalDto ToDto(Withdrawal w) => new(
        w.Id, w.AmountUsd, w.PlatformFeeUsd, w.PayoutAmountUsd, w.PayCurrency, w.PayoutAddress,
        w.Status.ToString(), w.RejectionReason, w.CreatedAt, w.ProcessedAt);

    private decimal? GetNetworkFeeEstimate(string payCurrency)
    {
        foreach (var kvp in _options.NetworkFeeEstimateUsd)
        {
            if (string.Equals(kvp.Key, payCurrency, StringComparison.OrdinalIgnoreCase))
                return kvp.Value;
        }
        return null;
    }

    private static bool IsSupportedStablecoin(string? code) =>
        !string.IsNullOrWhiteSpace(code) &&
        SupportedDepositCurrencies.All.Any(c =>
            c.Group == SupportedDepositCurrencies.GroupStablecoin &&
            string.Equals(c.Code, code, StringComparison.OrdinalIgnoreCase));

    private Guid? GetCurrentUserId()
    {
        var value = User.FindFirstValue(ClaimTypes.NameIdentifier);
        return Guid.TryParse(value, out var id) ? id : null;
    }
}
