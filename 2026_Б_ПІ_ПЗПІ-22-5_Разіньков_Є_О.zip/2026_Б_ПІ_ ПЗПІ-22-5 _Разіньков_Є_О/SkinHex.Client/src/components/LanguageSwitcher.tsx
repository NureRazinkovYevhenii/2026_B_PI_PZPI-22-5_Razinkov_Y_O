import { useState, useRef, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { ChevronDown } from 'lucide-react';

const LANGUAGES = [
  { code: 'en', name: 'English', flagUrl: 'https://flagcdn.com/w20/gb.png' },
  { code: 'uk', name: 'Українська', flagUrl: 'https://flagcdn.com/w20/ua.png' }
];

export function LanguageSwitcher() {
  const { i18n } = useTranslation();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const currentLang = LANGUAGES.find(l => l.code === (i18n.language || '').split('-')[0]) || LANGUAGES[0];

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const changeLanguage = (code: string) => {
    i18n.changeLanguage(code);
    localStorage.setItem('skinhex_lang', code);
    setIsOpen(false);
  };

  return (
    <div className="language-switcher" ref={dropdownRef} style={{ position: 'relative' }}>
      <button 
        onClick={() => setIsOpen(!isOpen)}
        style={{ 
          padding: '8px 12px', 
          display: 'flex', 
          alignItems: 'center', 
          gap: '8px', 
          border: '1px solid var(--border)', 
          background: 'var(--bg-glass)',
          borderRadius: '8px',
          cursor: 'pointer',
          color: 'var(--text-h)'
        }}
      >
        <img src={currentLang.flagUrl} alt={currentLang.code} style={{ width: '20px', height: '15px', objectFit: 'cover', borderRadius: '2px' }} />
        <span style={{ fontSize: '14px', fontWeight: 500 }}>{currentLang.code.toUpperCase()}</span>
        <ChevronDown size={14} style={{ color: 'var(--text-muted)' }} />
      </button>

      {isOpen && (
        <div 
          className="glass-panel" 
          style={{ 
            position: 'absolute', 
            top: 'calc(100% + 8px)', 
            right: 0, 
            width: '140px', 
            padding: '8px',
            borderRadius: '12px',
            zIndex: 100,
            display: 'flex',
            flexDirection: 'column',
            gap: '4px',
            border: '1px solid var(--border)'
          }}
        >
          {LANGUAGES.map((lang) => {
            const isActive = (i18n.language || '').startsWith(lang.code);
            return (
              <button
                key={lang.code}
                onClick={() => changeLanguage(lang.code)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  width: '100%',
                  padding: '8px 12px',
                  background: isActive ? 'var(--bg)' : 'transparent',
                  border: 'none',
                  borderRadius: '8px',
                  cursor: 'pointer',
                  color: isActive ? 'var(--text-h)' : 'var(--text)',
                  textAlign: 'left',
                  transition: 'background 0.2s ease'
                }}
                onMouseOver={(e) => e.currentTarget.style.background = 'var(--bg)'}
                onMouseOut={(e) => e.currentTarget.style.background = isActive ? 'var(--bg)' : 'transparent'}
              >
                <img src={lang.flagUrl} alt={lang.code} style={{ width: '20px', height: '15px', objectFit: 'cover', borderRadius: '2px' }} />
                <span style={{ fontSize: '14px', fontWeight: 500 }}>{lang.name}</span>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
