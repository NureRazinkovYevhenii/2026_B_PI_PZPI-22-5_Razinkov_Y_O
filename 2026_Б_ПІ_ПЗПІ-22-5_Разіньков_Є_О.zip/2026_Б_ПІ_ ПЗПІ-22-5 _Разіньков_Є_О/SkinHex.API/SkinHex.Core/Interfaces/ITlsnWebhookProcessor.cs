using System.Threading.Tasks;
using SkinHex.Core.Models.Tlsn;

namespace SkinHex.Core.Interfaces
{
    public interface ITlsnWebhookProcessor
    {
        Task ProcessWebhookAsync(WebhookPayload payload);
    }
}
