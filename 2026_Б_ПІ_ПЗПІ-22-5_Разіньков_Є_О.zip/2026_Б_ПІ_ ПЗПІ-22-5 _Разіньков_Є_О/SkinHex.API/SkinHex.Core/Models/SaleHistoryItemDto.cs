namespace SkinHex.Core.Models;

/// <summary>One sale record — same shape as a catalog listing plus the date it was sold.</summary>
public sealed class SaleHistoryItemDto
{
    public Guid Id { get; set; }
    public decimal Price { get; set; }

    public Guid SellerId { get; set; }
    public string SellerSteamId { get; set; } = string.Empty;

    public int ItemId { get; set; }
    public string MarketHashName { get; set; } = null!;

    [System.Text.Json.Serialization.JsonIgnore(Condition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull)]
    public double? FloatValue { get; set; }

    [System.Text.Json.Serialization.JsonIgnore(Condition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull)]
    public int? PaintSeed { get; set; }

    public DateTimeOffset CreatedAt { get; set; }

    [System.Text.Json.Serialization.JsonIgnore(Condition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull)]
    public string? InspectHex { get; set; }

    [System.Text.Json.Serialization.JsonIgnore(Condition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull)]
    public string? ScreenshotFrontUrl { get; set; }

    [System.Text.Json.Serialization.JsonIgnore(Condition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull)]
    public string? ScreenshotBackUrl { get; set; }

    /// <summary>When the sale was confirmed (AcceptedAt ?? TradeSentAt ?? ConfirmedAt ?? Order.CreatedAt).</summary>
    public DateTime SoldAt { get; set; }
}
