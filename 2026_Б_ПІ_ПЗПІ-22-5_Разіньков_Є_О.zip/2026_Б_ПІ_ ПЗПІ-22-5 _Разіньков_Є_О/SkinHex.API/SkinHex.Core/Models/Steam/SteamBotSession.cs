namespace SkinHex.Core.Models.Steam;

public sealed record SteamBotSession
{
    public required string Username { get; init; }
    public required string SessionId { get; init; }
    public required string SteamLoginSecure { get; init; }
    public required DateTimeOffset RefreshedAtUtc { get; init; }
}
