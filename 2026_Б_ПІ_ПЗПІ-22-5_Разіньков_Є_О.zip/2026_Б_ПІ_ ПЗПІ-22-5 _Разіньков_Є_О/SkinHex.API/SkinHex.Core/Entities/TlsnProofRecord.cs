using System.ComponentModel.DataAnnotations;

namespace SkinHex.Core.Entities;

public enum TlsnProofOutcome
{
    /// <summary>Proof validated and the order was (or already had been) finalized.</summary>
    Accepted = 0,

    /// <summary>Proof parsed correctly but a business guard refused it (mismatch, timing, wrong state).</summary>
    Rejected = 1,

    /// <summary>Payload could not be parsed or came from an unexpected server — nothing was processed.</summary>
    Ignored = 2
}

/// <summary>
/// Evidence log: every TLSN webhook is persisted verbatim together with the validation outcome,
/// so disputes always have a cryptographically-backed record of who proved what and when.
/// </summary>
public class TlsnProofRecord
{
    [Key]
    public Guid Id { get; set; }

    /// <summary>Order resolved from the Steam trade id; null when the trade is unknown to us.</summary>
    public Guid? OrderId { get; set; }

    [MaxLength(100)]
    public string? SteamTradeId { get; set; }

    [MaxLength(100)]
    public string? SessionId { get; set; }

    [MaxLength(200)]
    public string ServerName { get; set; } = string.Empty;

    /// <summary>Raw Steam trade status number extracted from the proven response.</summary>
    public int? TradeStatus { get; set; }

    [MaxLength(50)]
    public string? SteamIdOther { get; set; }

    /// <summary>Comma-separated asset ids from assets_given in the proven response.</summary>
    [MaxLength(2000)]
    public string? TransferredAssetIds { get; set; }

    public long? TimeSettlementUnix { get; set; }

    public TlsnProofOutcome Outcome { get; set; }

    [MaxLength(100)]
    public string? FailureCode { get; set; }

    [MaxLength(1000)]
    public string? FailureReason { get; set; }

    /// <summary>Full webhook payload as received (jsonb).</summary>
    public string PayloadJson { get; set; } = string.Empty;

    public DateTime ReceivedAt { get; set; } = DateTime.UtcNow;

    public Order? Order { get; set; }
}
