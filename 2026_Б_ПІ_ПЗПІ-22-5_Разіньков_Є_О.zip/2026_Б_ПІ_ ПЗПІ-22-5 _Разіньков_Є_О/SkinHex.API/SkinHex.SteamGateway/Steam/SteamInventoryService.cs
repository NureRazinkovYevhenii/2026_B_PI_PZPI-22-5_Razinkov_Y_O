using SkinHex.Core.Models;

namespace SkinHex.SteamGateway.Steam;

public sealed class SteamInventoryService(ISteamInventoryClient inventoryClient) : ISteamInventoryService
{
    public Task<IReadOnlyList<InventoryItemDto>> GetInventoryAsync(
        SteamInventoryRequest request,
        CancellationToken cancellationToken = default)
    {
        return inventoryClient.FetchInventoryAsync(request, cancellationToken);
    }

    public Task ValidateTradeLinkAsync(
        SteamInventoryRequest request,
        CancellationToken cancellationToken = default)
    {
        return inventoryClient.ValidateTradeLinkAsync(request, cancellationToken);
    }
}
