using SkinHex.Core.Entities;

namespace SkinHex.Core.Interfaces;

public interface IRefreshTokenRepository
{
    Task<RefreshToken?> GetByTokenWithUserAsync(string token, CancellationToken ct);
    Task<List<RefreshToken>> GetByUserIdAsync(Guid id, CancellationToken ct);
    Task AddAsync(RefreshToken refreshToken, CancellationToken ct);
}
