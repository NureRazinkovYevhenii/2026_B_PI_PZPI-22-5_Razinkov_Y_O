namespace SkinHex.Core.Entities;

public enum FaultParty
{
    None = 0,
    Buyer = 1,
    Seller = 2
}
