namespace SkinHex.SteamGateway.Options;

public sealed class SteamGatewayOptions
{
    public const string SectionName = "SteamGateway";

    public string BaseAddress { get; init; } = "https://steamcommunity.com/";
    public int RequestTimeoutSeconds { get; init; } = 20;
    public int RetryCount { get; init; } = 1;

    /// <summary>
    /// Browser User-Agent sent with every Steam request. Steam's edge/WAF rate-limits (429)
    /// requests that lack a realistic browser User-Agent, regardless of IP or bot account.
    /// </summary>
    public string UserAgent { get; init; } =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

    /// <summary>How long a bot account stays quarantined after Steam rate-limits/bans it.</summary>
    public int BotQuarantineMinutes { get; init; } = 10;
}
