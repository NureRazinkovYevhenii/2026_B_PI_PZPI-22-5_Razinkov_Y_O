namespace SkinHex.Core.Entities;

public class CartItem
{
    public Guid Id { get; set; }
    
    public Guid UserId { get; set; }
    public User User { get; set; } = null!;
    
    public Guid ListingId { get; set; }
    public Listing Listing { get; set; } = null!;
    
    public DateTimeOffset AddedAt { get; set; } = DateTimeOffset.UtcNow;
}
