import type { FetchSteamUserResponse } from "../bridge/types";
import { TokenManager } from "./tokenManager"; 

export async function getSteamStatus(expectedSteamID?: string): Promise<FetchSteamUserResponse> {
    const loginCookie = await chrome.cookies.get({ url: 'https://steamcommunity.com', name: 'steamLoginSecure' });
    const sessionCookie = await chrome.cookies.get({ url: 'https://steamcommunity.com', name: 'sessionid' });

    if (!loginCookie || !sessionCookie) {
        return { isLoggedIn: false };
    }

    const currentSteamID = loginCookie.value.match(/^(\d+)/)?.[1] || null;

    if (expectedSteamID && currentSteamID !== expectedSteamID) {
        return { 
            isLoggedIn: false, 
            error: 'The Steam account does not match the SkinHex account'
        };
    }

    let token: string | undefined;
    try {
        token = await TokenManager.getInstance().getToken();
    } catch (e) {
        console.error("Failed to obtain Steam Web API token", e);
    }

    return {
        isLoggedIn: true,
        steamID: currentSteamID,
        sessionID: sessionCookie.value,
        token: token
    };
}