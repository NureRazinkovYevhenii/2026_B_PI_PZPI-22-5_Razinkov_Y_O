using System.Security.Cryptography;

namespace SkinHex.Infrastructure.Services;

/// <summary>
/// Minimal RFC 6238 (TOTP) generator used to produce the 2FA verification code required
/// to auto-confirm NOWPayments payouts. HMAC-SHA1, 6 digits, 30-second time step.
/// </summary>
public static class Totp
{
    private const int Digits = 6;
    private const int PeriodSeconds = 30;

    /// <summary>Generates the current TOTP code for a Base32-encoded secret.</summary>
    public static string Generate(string base32Secret, DateTimeOffset? now = null)
    {
        var key = Base32Decode(base32Secret);
        var timestamp = (now ?? DateTimeOffset.UtcNow).ToUnixTimeSeconds();
        var counter = timestamp / PeriodSeconds;

        var counterBytes = BitConverter.GetBytes(counter);
        if (BitConverter.IsLittleEndian)
            Array.Reverse(counterBytes); // big-endian per RFC 4226

        using var hmac = new HMACSHA1(key);
        var hash = hmac.ComputeHash(counterBytes);

        var offset = hash[^1] & 0x0F;
        var binary =
            ((hash[offset] & 0x7F) << 24) |
            ((hash[offset + 1] & 0xFF) << 16) |
            ((hash[offset + 2] & 0xFF) << 8) |
            (hash[offset + 3] & 0xFF);

        var code = binary % (int)Math.Pow(10, Digits);
        return code.ToString().PadLeft(Digits, '0');
    }

    private static byte[] Base32Decode(string input)
    {
        const string alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
        input = input.TrimEnd('=').Replace(" ", "").ToUpperInvariant();

        var bits = 0;
        var value = 0;
        var output = new List<byte>(input.Length * 5 / 8);

        foreach (var c in input)
        {
            var idx = alphabet.IndexOf(c);
            if (idx < 0)
                throw new ArgumentException($"Invalid Base32 character '{c}' in TOTP secret.", nameof(input));

            value = (value << 5) | idx;
            bits += 5;

            if (bits >= 8)
            {
                output.Add((byte)((value >> (bits - 8)) & 0xFF));
                bits -= 8;
            }
        }

        return output.ToArray();
    }
}
