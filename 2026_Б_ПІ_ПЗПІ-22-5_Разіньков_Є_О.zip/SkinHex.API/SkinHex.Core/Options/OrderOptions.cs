namespace SkinHex.Core.Options;

public class OrderOptions
{
    public int SellerConfirmWindowHours { get; set; } = 12;
    public int BuyerCancelWindowMinutes { get; set; } = 30;
    public int AutoCancelPollIntervalSeconds { get; set; } = 60;

    /// <summary>
    /// Platform commission taken from the seller's proceeds on a completed sale,
    /// as a fraction of the sale price (e.g. 0.05 = 5%). The buyer pays the full
    /// LockPrice; the seller receives LockPrice minus this commission.
    /// </summary>
    public decimal SaleCommissionPercent { get; set; } = 0.02m;
}
