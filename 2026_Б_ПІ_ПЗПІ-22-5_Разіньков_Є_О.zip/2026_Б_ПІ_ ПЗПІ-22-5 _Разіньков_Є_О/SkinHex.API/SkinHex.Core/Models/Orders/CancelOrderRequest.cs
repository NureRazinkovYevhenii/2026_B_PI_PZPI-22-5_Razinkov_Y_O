namespace SkinHex.Core.Models.Orders;

public record CancelOrderRequest(string? Reason);
