using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Moq;
using SkinHex.API.Controllers;
using SkinHex.Core.Entities;
using SkinHex.Core.Interfaces.Services;
using SkinHex.Infrastructure;
using Xunit;

namespace SkinHex.Core.Tests.Withdrawals;

public class PayoutIpnTests
{
    private readonly SkinHexDbContext _dbContext;
    private readonly Mock<INowPaymentsService> _nowPaymentsServiceMock = new();
    private readonly WebhooksController _controller;

    public PayoutIpnTests()
    {
        var dbOptions = new DbContextOptionsBuilder<SkinHexDbContext>()
            .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
            .Options;
        _dbContext = new SkinHexDbContext(dbOptions);

        _nowPaymentsServiceMock
            .Setup(s => s.VerifyIpnSignature(It.IsAny<string>(), It.IsAny<string>()))
            .Returns(true);

        _controller = new WebhooksController(_dbContext, _nowPaymentsServiceMock.Object, Mock.Of<INotificationService>(), Mock.Of<ILogger<WebhooksController>>());
        _controller.ControllerContext = new ControllerContext { HttpContext = new DefaultHttpContext() };
    }

    private Withdrawal Seed(decimal balance)
    {
        var user = new User { Id = Guid.NewGuid(), SteamId = "s", Username = "u", Balance = balance };
        var tx = new FinancialTransaction
        {
            Id = Guid.NewGuid(), UserId = user.Id, Amount = 5m,
            Type = FinancialTransactionType.Withdrawal, Status = FinancialTransactionStatus.Pending
        };
        var withdrawal = new Withdrawal
        {
            Id = Guid.NewGuid(), UserId = user.Id, TransactionId = tx.Id,
            AmountUsd = 5m, PayoutAmountUsd = 5m, PayCurrency = "usdttrc20", PayoutAddress = "TAddr",
            Status = WithdrawalStatus.Processing, NowPaymentsPayoutId = "payout1"
        };
        _dbContext.Users.Add(user);
        _dbContext.FinancialTransactions.Add(tx);
        _dbContext.Withdrawals.Add(withdrawal);
        _dbContext.SaveChanges();
        return withdrawal;
    }

    private void SetBody(object payload)
    {
        _controller.Request.Headers["x-nowpayments-sig"] = "sig";
        _controller.Request.Body = new MemoryStream(Encoding.UTF8.GetBytes(JsonSerializer.Serialize(payload)));
    }

    [Fact]
    public async Task Finished_CompletesWithdrawal_WithoutTouchingBalance()
    {
        var withdrawal = Seed(balance: 5m);
        SetBody(new { id = "payout1", status = "finished" });

        await _controller.HandlePayoutIpn();

        var updated = await _dbContext.Withdrawals.Include(w => w.User).Include(w => w.Transaction).FirstAsync();
        Assert.Equal(WithdrawalStatus.Completed, updated.Status);
        Assert.Equal(FinancialTransactionStatus.Completed, updated.Transaction.Status);
        Assert.Equal(5m, updated.User.Balance); // already debited at request time; unchanged
    }

    [Fact]
    public async Task Finished_WithHashInPayload_StoresPayoutTxHash()
    {
        var withdrawal = Seed(balance: 5m);
        SetBody(new { id = "payout1", status = "finished", hash = "0xoutgoinghash" });

        await _controller.HandlePayoutIpn();

        var updated = await _dbContext.Withdrawals.FirstAsync();
        Assert.Equal("0xoutgoinghash", updated.PayoutTxHash);
    }

    [Fact]
    public async Task NonTerminalStatus_WithHash_StoresHashEarly()
    {
        var withdrawal = Seed(balance: 5m);
        SetBody(new { id = "payout1", status = "sending", hash = "0xearlyhash" });

        await _controller.HandlePayoutIpn();

        var updated = await _dbContext.Withdrawals.FirstAsync();
        Assert.Equal(WithdrawalStatus.Processing, updated.Status);
        Assert.Equal("0xearlyhash", updated.PayoutTxHash);
    }

    [Fact]
    public async Task Failed_RefundsBalance()
    {
        var withdrawal = Seed(balance: 5m);
        SetBody(new { id = "payout1", status = "failed" });

        await _controller.HandlePayoutIpn();

        var updated = await _dbContext.Withdrawals.Include(w => w.User).Include(w => w.Transaction).FirstAsync();
        Assert.Equal(WithdrawalStatus.Failed, updated.Status);
        Assert.Equal(FinancialTransactionStatus.Failed, updated.Transaction.Status);
        Assert.Equal(10m, updated.User.Balance); // 5 refunded
    }
}
