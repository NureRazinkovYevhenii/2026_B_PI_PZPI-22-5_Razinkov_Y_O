using SkinHex.Core.Models;
using Xunit;

namespace SkinHex.Core.Tests;

public class BlockchainExplorerTests
{
    [Theory]
    [InlineData("usdttrc20", "abc123", "https://tronscan.org/#/transaction/abc123")]
    [InlineData("usdtbsc", "0xdead", "https://bscscan.com/tx/0xdead")]
    [InlineData("usdterc20", "0xbeef", "https://etherscan.io/tx/0xbeef")]
    [InlineData("USDTTRC20", "abc123", "https://tronscan.org/#/transaction/abc123")] // case-insensitive
    public void BuildTxUrl_KnownCurrency_ReturnsExpectedUrl(string payCurrency, string hash, string expected)
    {
        Assert.Equal(expected, BlockchainExplorer.BuildTxUrl(payCurrency, hash));
    }

    [Fact]
    public void BuildTxUrl_NullOrEmptyHash_ReturnsNull()
    {
        Assert.Null(BlockchainExplorer.BuildTxUrl("usdttrc20", null));
        Assert.Null(BlockchainExplorer.BuildTxUrl("usdttrc20", ""));
    }

    [Fact]
    public void BuildTxUrl_UnknownCurrency_ReturnsNull()
    {
        Assert.Null(BlockchainExplorer.BuildTxUrl("unknowncoin", "abc123"));
    }
}
