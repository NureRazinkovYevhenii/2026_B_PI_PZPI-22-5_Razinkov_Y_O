import { ArrowRight, ShieldCheck, Zap, Coins } from 'lucide-react';
import type { AuthState, PageKey } from '../types';
import { useTranslation } from 'react-i18next';

type HomePageProps = {
  auth: AuthState | null;
  isUnverified: boolean;
  onNavigate: (page: PageKey) => void;
};

export function HomePage({ auth, onNavigate }: HomePageProps) {
  const { t } = useTranslation();

  return (
    <div className="animate-fade-in" style={{ display: 'flex', flexDirection: 'column', gap: '64px', paddingBottom: '64px' }}>
      {/* Hero Section */}
      <section className="glass-panel" style={{ 
        position: 'relative', overflow: 'hidden', borderRadius: '24px', 
        textAlign: 'center', padding: '96px 24px',
        background: 'radial-gradient(circle at 50% -20%, rgba(14, 165, 233, 0.15), transparent 70%), var(--surface-glass)'
      }}>
        <h1 className="hero-title" style={{ fontSize: 'clamp(42px, 5vw, 72px)', fontWeight: 800, marginBottom: '24px', letterSpacing: '-0.03em', lineHeight: 1.1 }}>
          {t('home.title')}
        </h1>
        <p className="hero-subtitle" style={{ fontSize: '20px', color: 'var(--text-muted)', maxWidth: '600px', margin: '0 auto 40px auto', lineHeight: 1.6 }}>
          {t('home.subtitle')}
        </p>
        
        <div style={{ display: 'flex', gap: '16px', justifyContent: 'center' }}>
          {auth ? (
            <button className="primary-button" onClick={() => onNavigate('catalog')} type="button" style={{ padding: '12px 32px', fontSize: '16px', background: 'var(--brand)', color: '#fff', borderRadius: '12px', border: 'none', fontWeight: 800, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '8px' }}>
              {t('home.startTrading')} <ArrowRight size={20} />
            </button>
          ) : (
            <button className="primary-button" onClick={() => onNavigate('profile')} type="button" style={{ padding: '12px 32px', fontSize: '16px', background: 'var(--brand)', color: '#fff', borderRadius: '12px', border: 'none', fontWeight: 800, cursor: 'pointer' }}>
              {t('home.signIn')}
            </button>
          )}
        </div>
      </section>

      {/* Features Section */}
      <section>
        <div style={{ textAlign: 'center', marginBottom: '48px' }}>
          <h2 style={{ fontSize: '32px', marginBottom: '16px', color: 'var(--text-h)' }}>{t('home.whyChoose')}</h2>
          <p style={{ color: 'var(--text-muted)', marginBottom: '48px', fontSize: '18px' }}>{t('home.whyDesc')}</p>
        </div>
        
        <div className="features-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '32px', textAlign: 'left' }}>
          {[
            { icon: <ShieldCheck size={32} color="#10b981" />, title: t('home.features.escrowTitle'), desc: t('home.features.escrowDesc') },
            { icon: <Coins size={32} color="#f59e0b" />, title: t('home.features.feesTitle'), desc: t('home.features.feesDesc') },
            { icon: <Zap size={32} color="#3b82f6" />, title: t('home.features.supportTitle'), desc: t('home.features.supportDesc') },
          ].map((feature, i) => (
            <div key={i} className="glass-panel" style={{ padding: '32px 24px', borderRadius: '16px', textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '16px' }}>
              <div style={{ background: 'var(--surface)', padding: '16px', borderRadius: '50%', boxShadow: 'var(--shadow-sm)' }}>
                {feature.icon}
              </div>
              <h3 style={{ fontSize: '20px', color: 'var(--text-h)', margin: 0 }}>{feature.title}</h3>
              <p style={{ color: 'var(--text-muted)', margin: 0, fontSize: '15px' }}>{feature.desc}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
