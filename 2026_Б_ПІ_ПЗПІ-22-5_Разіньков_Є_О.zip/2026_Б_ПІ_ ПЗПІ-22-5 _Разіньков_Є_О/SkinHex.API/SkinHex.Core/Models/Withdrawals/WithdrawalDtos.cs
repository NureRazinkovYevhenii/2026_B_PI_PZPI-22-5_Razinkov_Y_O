namespace SkinHex.Core.Models.Withdrawals;

public record CreateWithdrawalRequest(decimal AmountUsd, string PayCurrency, string Address, string? ExtraId);

/// <summary>Live breakdown shown to the user before confirming a withdrawal.</summary>
public record WithdrawalEstimateDto(
    decimal AmountUsd,
    decimal PlatformFeePercent,
    decimal PlatformFeeUsd,
    decimal? EstNetworkFeeUsd,   // display-only estimate; real network fee is taken by NOWPayments
    decimal EstimatedReceiveUsd,
    string PayCurrency);

/// <summary>User-facing view of a withdrawal.</summary>
public record WithdrawalDto(
    Guid Id,
    decimal AmountUsd,
    decimal PlatformFeeUsd,
    decimal PayoutAmountUsd,
    string PayCurrency,
    string PayoutAddress,
    string Status,
    string? RejectionReason,
    DateTime CreatedAt,
    DateTime? ProcessedAt);
