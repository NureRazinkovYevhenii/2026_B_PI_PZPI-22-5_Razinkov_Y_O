using Hangfire;
using Microsoft.Extensions.Logging;
using SkinHex.Core.Entities;
using SkinHex.Core.Errors;
using SkinHex.Core.Interfaces.Repositories;
using SkinHex.Core.Interfaces.Services;
using SkinHex.Core.Models.Disputes;
using SkinHex.Core.Models.Notifications;

namespace SkinHex.Core.Services;

public class DisputeService(
    IDisputeRepository disputeRepository,
    IOrderRepository orderRepository,
    IFinancialTransactionRepository financialTransactionRepository,
    IUnitOfWork unitOfWork,
    INotificationService notificationService,
    IBackgroundJobClient backgroundJobClient,
    ILogger<DisputeService> logger) : IDisputeService
{
    /// <summary>How long after cancellation a participant can still contest the outcome (penalty appeal etc.).</summary>
    private static readonly TimeSpan CancelledAppealWindow = TimeSpan.FromDays(7);

    private const int MaxDescriptionLength = 2000;

    public async Task<DisputeDto> OpenDisputeAsync(Guid orderId, Guid userId, DisputeReason reason, string description, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(description))
            throw new BusinessException(BusinessErrorCodes.DisputeNotAllowed, "Describe the problem — a description is required.", 400);

        if (!Enum.IsDefined(reason) || reason == DisputeReason.UnverifiedBuyerFault)
            throw new BusinessException(BusinessErrorCodes.DisputeNotAllowed, "Invalid dispute reason.", 400);

        var order = await orderRepository.GetByIdAsync(orderId, ct)
            ?? throw new BusinessException(BusinessErrorCodes.OrderNotFound, "Order not found.", 404);

        if (order.BuyerId != userId && order.SellerId != userId)
            throw new BusinessException(BusinessErrorCodes.Forbidden, "Insufficient permissions.", 403);

        var now = DateTime.UtcNow;
        // Confirmed included on purpose: even before a trade exists the flow can wedge
        // (seller confirmed but nothing moves), and the dispute button must still work.
        var isActive = order.Status is OrderStatus.Confirmed or OrderStatus.TradeSent or OrderStatus.InEscrow;
        var isAppealableCancel = order.Status == OrderStatus.Cancelled
            && order.CancelledAt.HasValue
            && now - order.CancelledAt.Value <= CancelledAppealWindow;

        if (!isActive && !isAppealableCancel)
            throw new BusinessException(BusinessErrorCodes.DisputeNotAllowed,
                "A dispute can be opened for a confirmed order (Confirmed/TradeSent/InEscrow) or for a cancelled one within 7 days.", 409);

        if (await disputeRepository.HasOpenDisputeAsync(orderId, ct))
            throw new BusinessException(BusinessErrorCodes.DisputeAlreadyOpen, "A dispute is already open for this order.", 409);

        var dispute = new OrderDispute
        {
            Id = Guid.NewGuid(),
            OrderId = orderId,
            OpenedByUserId = userId,
            Reason = reason,
            Status = DisputeStatus.Open,
            Description = Truncate(description.Trim(), MaxDescriptionLength),
            CreatedAt = now,
            UpdatedAt = now
        };

        disputeRepository.Add(dispute);
        await unitOfWork.SaveChangesAsync(ct);

        var openedBy = userId == order.BuyerId ? "buyer" : "seller";
        var counterpartyId = userId == order.BuyerId ? order.SellerId : order.BuyerId;
        await notificationService.NotifyAsync(counterpartyId, NotificationType.DisputeOpened,
            new DisputeOpenedPayload(dispute.Id, orderId, reason.ToString(), openedBy), ct);

        logger.LogInformation("Dispute {DisputeId} ({Reason}) opened by {OpenedBy} on order {OrderId}.",
            dispute.Id, reason, openedBy, orderId);

        return MapToDto(dispute);
    }

    public async Task<OrderDispute?> OpenSystemDisputeAsync(Guid orderId, DisputeReason reason, string description, decimal? frozenPenaltyAmount = null, CancellationToken ct = default)
    {
        if (await disputeRepository.HasOpenDisputeAsync(orderId, ct))
        {
            logger.LogInformation("System dispute ({Reason}) for order {OrderId} skipped — an open dispute already exists.", reason, orderId);
            return null;
        }

        var order = await orderRepository.GetByIdAsync(orderId, ct);
        if (order is null)
        {
            logger.LogWarning("System dispute ({Reason}) skipped — order {OrderId} not found.", reason, orderId);
            return null;
        }

        var now = DateTime.UtcNow;
        var dispute = new OrderDispute
        {
            Id = Guid.NewGuid(),
            OrderId = orderId,
            OpenedByUserId = null,
            Reason = reason,
            Status = DisputeStatus.Open,
            Description = Truncate(description, MaxDescriptionLength),
            FrozenPenaltyAmount = frozenPenaltyAmount,
            CreatedAt = now,
            UpdatedAt = now
        };

        disputeRepository.Add(dispute);
        await unitOfWork.SaveChangesAsync(ct);

        var payload = new DisputeOpenedPayload(dispute.Id, orderId, reason.ToString(), "system");
        await notificationService.NotifyAsync(order.BuyerId, NotificationType.DisputeOpened, payload, ct);
        await notificationService.NotifyAsync(order.SellerId, NotificationType.DisputeOpened, payload, ct);

        logger.LogInformation("System dispute {DisputeId} ({Reason}) opened on order {OrderId}.", dispute.Id, reason, orderId);
        return dispute;
    }

    public async Task<IReadOnlyCollection<DisputeDto>> GetMyDisputesAsync(Guid userId, CancellationToken ct = default)
    {
        var disputes = await disputeRepository.GetByParticipantAsync(userId, ct);
        return disputes.Select(MapToDto).ToList();
    }

    public async Task<DisputeDto> GetDisputeAsync(Guid disputeId, Guid userId, CancellationToken ct = default)
    {
        var dispute = await disputeRepository.GetByIdAsync(disputeId, ct)
            ?? throw new BusinessException(BusinessErrorCodes.DisputeNotFound, "Dispute not found.", 404);

        if (dispute.Order.BuyerId != userId && dispute.Order.SellerId != userId)
            throw new BusinessException(BusinessErrorCodes.Forbidden, "Insufficient permissions.", 403);

        return MapToDto(dispute);
    }

    public async Task<DisputeDto> TakeUnderReviewAsync(Guid disputeId, Guid adminId, CancellationToken ct = default)
    {
        var dispute = await disputeRepository.GetByIdAsync(disputeId, ct)
            ?? throw new BusinessException(BusinessErrorCodes.DisputeNotFound, "Dispute not found.", 404);

        if (dispute.Status is not (DisputeStatus.Open or DisputeStatus.UnderReview))
            throw new BusinessException(BusinessErrorCodes.InvalidDisputeResolution, "Dispute is already closed.", 409);

        dispute.Status = DisputeStatus.UnderReview;
        dispute.ResolvedByAdminId = adminId;
        dispute.UpdatedAt = DateTime.UtcNow;
        await unitOfWork.SaveChangesAsync(ct);

        return MapToDto(dispute);
    }

    public async Task<DisputeDto> ResolveDisputeAsync(Guid disputeId, Guid adminId, DisputeResolution resolution, string? note, CancellationToken ct = default)
    {
        var dispute = await disputeRepository.GetByIdWithOrderDetailsAsync(disputeId, ct)
            ?? throw new BusinessException(BusinessErrorCodes.DisputeNotFound, "Dispute not found.", 404);

        if (dispute.Status is not (DisputeStatus.Open or DisputeStatus.UnderReview))
            throw new BusinessException(BusinessErrorCodes.InvalidDisputeResolution, "Dispute is already closed.", 409);

        var order = dispute.Order;
        var buyer = order.Buyer;
        var seller = order.Seller;
        var now = DateTime.UtcNow;

        using var transaction = await unitOfWork.BeginTransactionAsync(ct);

        switch (resolution)
        {
            case DisputeResolution.RefundBuyer:
                ResolveRefundBuyer(dispute, order, buyer, seller, note, now);
                break;

            case DisputeResolution.CompleteOrder:
                ResolveCompleteOrder(order, seller, now);
                break;

            case DisputeResolution.ApplyBuyerPenalty:
                ResolveApplyBuyerPenalty(dispute, order, buyer, seller, now);
                break;

            case DisputeResolution.ReverseBuyerPenalty:
                await ResolveReverseBuyerPenaltyAsync(dispute, order, buyer, seller, now, ct);
                break;

            case DisputeResolution.NoAction:
                // A withheld penalty is a pending money decision — the admin must apply or reverse it.
                if (dispute.FrozenPenaltyAmount is > 0)
                    throw new BusinessException(BusinessErrorCodes.InvalidDisputeResolution,
                        "A penalty is withheld on this dispute — choose ApplyBuyerPenalty or ReverseBuyerPenalty.", 409);
                break;

            default:
                throw new BusinessException(BusinessErrorCodes.InvalidDisputeResolution, "Invalid resolution.", 400);
        }

        dispute.Status = resolution == DisputeResolution.NoAction ? DisputeStatus.Rejected : DisputeStatus.Resolved;
        dispute.Resolution = resolution;
        dispute.ResolutionNote = note is null ? null : Truncate(note.Trim(), MaxDescriptionLength);
        dispute.ResolvedByAdminId = adminId;
        dispute.ResolvedAt = now;
        dispute.UpdatedAt = now;

        await unitOfWork.SaveChangesAsync(ct);
        await transaction.CommitAsync(ct);

        var payload = new DisputeResolvedPayload(dispute.Id, order.Id, resolution.ToString(), dispute.ResolutionNote);
        await notificationService.NotifyAsync(order.BuyerId, NotificationType.DisputeResolved, payload, ct);
        await notificationService.NotifyAsync(order.SellerId, NotificationType.DisputeResolved, payload, ct);

        if (resolution is DisputeResolution.RefundBuyer or DisputeResolution.ApplyBuyerPenalty or DisputeResolution.ReverseBuyerPenalty)
            await notificationService.PushBalanceUpdateAsync(buyer, 0, "dispute_resolution", ct);
        if (resolution is DisputeResolution.RefundBuyer or DisputeResolution.CompleteOrder or DisputeResolution.ApplyBuyerPenalty or DisputeResolution.ReverseBuyerPenalty)
            await notificationService.PushBalanceUpdateAsync(seller, 0, "dispute_resolution", ct);

        // NoAction on a still-active order: automation was frozen by the open dispute,
        // so re-arm the timeout pipeline to let the normal lifecycle resume.
        if (resolution == DisputeResolution.NoAction &&
            order.Status is OrderStatus.Pending or OrderStatus.Confirmed or OrderStatus.TradeSent)
        {
            backgroundJobClient.Enqueue<IOrderTimeoutJobs>(x => x.ExecuteTimeoutCheckAsync(order.Id, CancellationToken.None));
        }

        logger.LogInformation("Dispute {DisputeId} resolved by admin {AdminId}: {Resolution}.", disputeId, adminId, resolution);
        return MapToDto(dispute);
    }

    private void ResolveRefundBuyer(OrderDispute dispute, Order order, User buyer, User seller, string? note, DateTime now)
    {
        if (order.Status is not (OrderStatus.TradeSent or OrderStatus.InEscrow))
            throw new BusinessException(BusinessErrorCodes.InvalidDisputeResolution,
                "A full refund is only available for an active order (TradeSent/InEscrow).", 409);

        var statusBefore = order.Status;
        order.CancelledAtStatus = statusBefore;
        order.Status = OrderStatus.Cancelled;
        order.CancelledBy = CancelledBy.System;
        order.CancelReason = $"Support resolution: {note ?? dispute.Reason.ToString()}";
        order.CancelledAt = now;
        order.UpdatedAt = now;

        // TradeSent: the item never left the seller — relist it. InEscrow: the item is already
        // with the buyer, the listing is spent even though the seller got no money.
        if (order.Listing is not null)
            order.Listing.Status = statusBefore == OrderStatus.TradeSent ? ListingStatus.Active : ListingStatus.Sold;

        seller.FrozenBalance -= order.LockPrice;
        buyer.Balance += order.LockPrice;
        AddLedgerEntry(buyer.Id, order.LockPrice, FinancialTransactionType.Refund, order.Id, now);
    }

    private void ResolveCompleteOrder(Order order, User seller, DateTime now)
    {
        if (order.Status != OrderStatus.InEscrow)
            throw new BusinessException(BusinessErrorCodes.InvalidDisputeResolution,
                "Manual completion is only available for an order in escrow.", 409);

        order.Status = OrderStatus.Completed;
        order.HoldEndsAt = now;
        order.UpdatedAt = now;

        if (order.Listing is not null)
            order.Listing.Status = ListingStatus.Sold;

        seller.FrozenBalance -= order.LockPrice;
        seller.Balance += order.LockPrice;
        AddLedgerEntry(seller.Id, order.LockPrice, FinancialTransactionType.Sale, order.Id, now);
    }

    private void ResolveApplyBuyerPenalty(OrderDispute dispute, Order order, User buyer, User seller, DateTime now)
    {
        if (dispute.FrozenPenaltyAmount is not > 0)
            throw new BusinessException(BusinessErrorCodes.InvalidDisputeResolution,
                "There is no withheld penalty on this dispute.", 409);
        if (order.Status != OrderStatus.Cancelled)
            throw new BusinessException(BusinessErrorCodes.InvalidDisputeResolution,
                "A penalty can only be applied to a cancelled order.", 409);

        var amount = dispute.FrozenPenaltyAmount.Value;
        buyer.FrozenBalance -= amount;
        seller.Balance += amount;
        AddLedgerEntry(buyer.Id, -amount, FinancialTransactionType.Penalty, order.Id, now);
        AddLedgerEntry(seller.Id, amount, FinancialTransactionType.Penalty, order.Id, now);
    }

    private async Task ResolveReverseBuyerPenaltyAsync(OrderDispute dispute, Order order, User buyer, User seller, DateTime now, CancellationToken ct)
    {
        if (dispute.FrozenPenaltyAmount is > 0)
        {
            // Withheld-but-never-applied penalty: just release the freeze back to the buyer.
            // The full Refund ledger entry was already posted at cancellation time.
            var amount = dispute.FrozenPenaltyAmount.Value;
            buyer.FrozenBalance -= amount;
            buyer.Balance += amount;
            return;
        }

        // Penalty appeal: the penalty was actually charged earlier — reverse the ledger.
        var penalties = await financialTransactionRepository.GetCompletedByReferenceAsync(order.Id, FinancialTransactionType.Penalty, ct);
        var buyerNet = penalties.Where(t => t.UserId == buyer.Id).Sum(t => t.Amount);
        if (buyerNet >= 0)
            throw new BusinessException(BusinessErrorCodes.InvalidDisputeResolution,
                "The buyer has no applied penalty on this order.", 409);

        var amountToReverse = -buyerNet;
        buyer.Balance += amountToReverse;
        seller.Balance -= amountToReverse;
        AddLedgerEntry(buyer.Id, amountToReverse, FinancialTransactionType.Penalty, order.Id, now);
        AddLedgerEntry(seller.Id, -amountToReverse, FinancialTransactionType.Penalty, order.Id, now);
    }

    private void AddLedgerEntry(Guid userId, decimal amount, FinancialTransactionType type, Guid orderId, DateTime at)
    {
        financialTransactionRepository.Add(new FinancialTransaction
        {
            Id = Guid.NewGuid(),
            UserId = userId,
            Amount = amount,
            Type = type,
            Status = FinancialTransactionStatus.Completed,
            ReferenceId = orderId,
            CreatedAt = at
        });
    }

    internal static DisputeDto MapToDto(OrderDispute d) => new(
        d.Id, d.OrderId, d.OpenedByUserId,
        d.Reason.ToString(), d.Status.ToString(), d.Resolution.ToString(),
        d.Description, d.ResolutionNote, d.FrozenPenaltyAmount,
        d.CreatedAt, d.UpdatedAt, d.ResolvedAt);

    private static string Truncate(string value, int maxLength) =>
        value.Length <= maxLength ? value : value[..maxLength];
}
