namespace SkinHex.Core.Entities;

public enum ScreenshotStatus
{
    Pending = 0,    // Рендер запитано, чекаємо результат
    Ready = 1,      // Файли завантажені та збережені локально
    Failed = 2      // Рендер не вдався після всіх спроб
}

// Скріншоти предмета "в грі" (front/back), отримані за inspect-посиланням.
// Ключ дедуплікації — InspectHex: той самий екземпляр скіна (float/seed/стікери)
// при повторному виставленні перевикористовує вже завантажені файли.
public class ItemScreenshot
{
    public Guid Id { get; set; }

    public string InspectHex { get; set; } = null!;   // hex-пейлоад inspect-посилання (Listing.Metadata)
    public ScreenshotStatus Status { get; set; }

    public string? ExternalGuid { get; set; }         // guid рендера у провайдера скріншотів
    public string? FrontImagePath { get; set; }       // шлях відносно кореня сховища, напр. "{Id}/front.png"
    public string? BackImagePath { get; set; }

    public int Attempts { get; set; }
    public string? LastError { get; set; }

    public DateTimeOffset CreatedAt { get; set; }
    public DateTimeOffset? CompletedAt { get; set; }
}
