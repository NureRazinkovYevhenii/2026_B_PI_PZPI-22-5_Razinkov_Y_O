namespace SkinHex.Core.Interfaces.Jobs;

public interface ISteamTradeChecker
{
    void VerifyBuyerAcceptedTrade(Guid orderId);
}
