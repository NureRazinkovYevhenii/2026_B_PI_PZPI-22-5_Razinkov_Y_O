﻿namespace SkinHex.Core.Entities;
public enum ListingStatus
{
    Active = 0,         // Виставлений на продаж, видно в каталозі
    TradePending = 1,   // Покупець оплатив, чекаємо поки продавець передасть предмет у Steam
    Sold = 2,           // Трейд успішний, гроші зараховані продавцю
    Cancelled = 3       // Продавець зняв з продажу або скасував трейд
}

public class Listing
{
    public Guid Id { get; set; }

    // --- КОМЕРЦІЙНА ЧАСТИНА (Оферта) ---
    public decimal Price { get; set; }
    public ListingStatus Status { get; set; }
    public DateTimeOffset CreatedAt { get; set; }

    public Guid SellerId { get; set; }
    public User Seller { get; set; } = null!;

    // --- ФІЗИЧНА ЧАСТИНА (Сам скін) ---
    public int ItemId { get; set; }            // Посилання на довідник (MarketHashName, картинка)
    public Item Item { get; set; } = null!;

    public long SteamAssetId { get; set; }     // ID скіна у Steam (потрібен для трейд-бота)
    public double? FloatValue { get; set; }    // Знос
    public int? PaintSeed { get; set; }        // Патерн
    public string? Metadata { get; set; }      // Hex-пейлоад inspect-посилання (rgAssetProperties, propertyid 6)

    public Guid? ScreenshotId { get; set; }    // Скріншоти front/back за inspect-посиланням
    public ItemScreenshot? Screenshot { get; set; }
}