namespace SkinHex.Core.Models;

public sealed class CreateListingsResponse
{
    public IReadOnlyList<Guid> ListingIds { get; init; } = Array.Empty<Guid>();
}
