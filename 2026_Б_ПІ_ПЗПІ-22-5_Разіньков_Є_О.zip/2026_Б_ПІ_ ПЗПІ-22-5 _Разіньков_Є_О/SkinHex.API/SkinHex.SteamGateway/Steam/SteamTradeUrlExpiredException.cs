namespace SkinHex.SteamGateway.Steam;

public sealed class SteamTradeUrlExpiredException : Exception
{
    public const string ErrorCode = "TRADE_URL_EXPIRED";

    public SteamTradeUrlExpiredException()
        : base("Steam trade URL is expired or invalid.")
    {
    }
}
