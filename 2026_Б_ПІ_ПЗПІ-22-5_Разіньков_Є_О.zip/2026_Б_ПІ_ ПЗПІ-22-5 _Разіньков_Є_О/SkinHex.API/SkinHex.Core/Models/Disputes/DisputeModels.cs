using SkinHex.Core.Entities;

namespace SkinHex.Core.Models.Disputes;

public class OpenDisputeRequest
{
    public DisputeReason Reason { get; set; }
    public string Description { get; set; } = string.Empty;
}

public class ResolveDisputeRequest
{
    public DisputeResolution Resolution { get; set; }
    public string? Note { get; set; }
}

public record DisputeDto(
    Guid Id,
    Guid OrderId,
    Guid? OpenedByUserId,
    string Reason,
    string Status,
    string Resolution,
    string Description,
    string? ResolutionNote,
    decimal? FrozenPenaltyAmount,
    DateTime CreatedAt,
    DateTime UpdatedAt,
    DateTime? ResolvedAt);

public record AdminDisputeListItemDto(
    Guid Id,
    Guid OrderId,
    Guid? OpenedByUserId,
    string? OpenedByUsername,
    string Reason,
    string Status,
    string Resolution,
    string OrderStatus,
    decimal OrderPrice,
    decimal? FrozenPenaltyAmount,
    DateTime CreatedAt,
    DateTime UpdatedAt);

public record AdminDisputeTradeDto(
    string TradeOfferId,
    string? SteamTradeId,
    string OfferState,
    string? TradeStatus,
    string? BuyerReportedOfferState,
    DateTime? BuyerReportedAt,
    string? BuyerSeenAssetIds,
    bool? BuyerAssetMatchesListing,
    DateTime CreatedAt,
    DateTime UpdatedAt);

public record AdminDisputeProofDto(
    Guid Id,
    string? SteamTradeId,
    int? TradeStatus,
    string? SteamIdOther,
    string? TransferredAssetIds,
    string Outcome,
    string? FailureCode,
    string? FailureReason,
    DateTime ReceivedAt);

public record AdminDisputeOrderDto(
    Guid OrderId,
    string Status,
    decimal LockPrice,
    Guid BuyerId,
    string BuyerUsername,
    Guid SellerId,
    string SellerUsername,
    string? MarketHashName,
    long ListingAssetId,
    string? CancelledBy,
    string? CancelReason,
    DateTime CreatedAt);

public record AdminDisputeDetailDto(
    DisputeDto Dispute,
    AdminDisputeOrderDto Order,
    IReadOnlyCollection<AdminDisputeTradeDto> Trades,
    IReadOnlyCollection<AdminDisputeProofDto> Proofs);
