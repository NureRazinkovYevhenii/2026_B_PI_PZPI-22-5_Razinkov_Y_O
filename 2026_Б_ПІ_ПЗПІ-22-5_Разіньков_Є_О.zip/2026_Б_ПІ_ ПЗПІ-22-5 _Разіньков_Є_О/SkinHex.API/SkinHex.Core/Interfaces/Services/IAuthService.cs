using FluentResults;
using SkinHex.Core.Models.Auth;

namespace SkinHex.Core.Interfaces;

public interface IAuthService
{
    Task<Result<AuthResult>> AuthenticateWithSteamAsync(SteamUserInfo steamUserInfo, CancellationToken cancellationToken);
    Task<Result<TokenResult>> RefreshTokensAsync(string refreshToken, CancellationToken cancellationToken);
    Task<Result> SendVerificationCodeAsync(Guid userId, string email, CancellationToken cancellationToken);
    Task<Result<TokenResult>> VerifyEmailAsync(Guid userId, string email, int code, CancellationToken cancellationToken);
}
