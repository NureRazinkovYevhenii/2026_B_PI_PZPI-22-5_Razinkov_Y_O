import { useState, useRef, useEffect } from 'react';
import { ArrowUpDown, ChevronDown } from 'lucide-react';
import type { CatalogSortOption } from '../types';

type CatalogSortBarProps = {
  sortBy: CatalogSortOption;
  onSortChange: (sort: CatalogSortOption) => void;
};

const SORT_OPTIONS: { value: CatalogSortOption; label: string }[] = [
  { value: 0, label: 'Price: Low → High' },
  { value: 1, label: 'Price: High → Low' },
  { value: 2, label: 'Newest' },
  { value: 3, label: 'Float: Low → High' },
  { value: 4, label: 'Float: High → Low' },
];

export function CatalogSortBar({ sortBy, onSortChange }: CatalogSortBarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const wrapRef = useRef<HTMLDivElement>(null);

  const currentLabel = SORT_OPTIONS.find((o) => o.value === sortBy)?.label ?? 'Sort';

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="cat-sort-bar">
      <div className="cat-sort-wrap" ref={wrapRef}>
        <button
          className="cat-sort-trigger"
          type="button"
          onClick={() => setIsOpen(!isOpen)}
        >
          <ArrowUpDown size={14} />
          <span>{currentLabel}</span>
          <ChevronDown size={14} className={`cat-chevron ${isOpen ? 'open' : ''}`} />
        </button>
        {isOpen && (
          <div className="cat-sort-dropdown glass-panel">
            {SORT_OPTIONS.map((opt) => (
              <button
                key={opt.value}
                type="button"
                className={`cat-sort-option ${sortBy === opt.value ? 'active' : ''}`}
                onClick={() => {
                  onSortChange(opt.value);
                  setIsOpen(false);
                }}
              >
                {opt.label}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
