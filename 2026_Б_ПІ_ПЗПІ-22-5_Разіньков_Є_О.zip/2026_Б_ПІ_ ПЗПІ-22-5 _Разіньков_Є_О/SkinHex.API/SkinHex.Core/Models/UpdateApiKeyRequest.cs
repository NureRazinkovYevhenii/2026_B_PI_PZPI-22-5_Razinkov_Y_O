﻿namespace SkinHex.Core.Models;

public class UpdateApiKeyRequest
{
    public string ApiKey { get; set; } = null!;
}