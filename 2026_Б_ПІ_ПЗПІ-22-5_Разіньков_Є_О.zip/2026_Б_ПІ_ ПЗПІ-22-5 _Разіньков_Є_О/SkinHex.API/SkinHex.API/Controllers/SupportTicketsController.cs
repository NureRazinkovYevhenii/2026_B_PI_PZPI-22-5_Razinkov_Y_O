using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SkinHex.Core.Entities;
using SkinHex.Core.Models.Admin;
using SkinHex.Infrastructure;

namespace SkinHex.API.Controllers;

[ApiController]
[Route("api/support/tickets")]
[Authorize]
public sealed class SupportTicketsController : ControllerBase
{
    private const int MaxSubjectLength = 200;
    private const int MaxBodyLength = 4000;

    private readonly SkinHexDbContext _dbContext;

    public SupportTicketsController(SkinHexDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    [HttpPost]
    public async Task<IActionResult> CreateTicket([FromBody] CreateTicketRequest request, CancellationToken ct)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
            return Unauthorized();

        if (string.IsNullOrWhiteSpace(request.Subject))
            return BadRequest(new { message = "Subject is required." });
        if (string.IsNullOrWhiteSpace(request.Message))
            return BadRequest(new { message = "Message is required." });
        if (!Enum.IsDefined(request.Category))
            return BadRequest(new { message = "Invalid category." });

        // A ticket "about an order" must reference an order the user actually participates in.
        if (request.OrderId is { } orderId)
        {
            var belongsToUser = await _dbContext.Orders
                .AnyAsync(o => o.Id == orderId && (o.BuyerId == userId || o.SellerId == userId), ct);
            if (!belongsToUser)
                return BadRequest(new { message = "Order not found or does not belong to you." });
        }

        var now = DateTime.UtcNow;
        var ticketId = Guid.NewGuid();

        var ticket = new SupportTicket
        {
            Id = ticketId,
            UserId = userId.Value,
            OrderId = request.OrderId,
            Subject = Truncate(request.Subject.Trim(), MaxSubjectLength),
            Category = request.Category,
            Status = TicketStatus.Open,
            CreatedAt = now,
            UpdatedAt = now,
            Messages =
            {
                new TicketMessage
                {
                    Id = Guid.NewGuid(),
                    SenderId = userId.Value,
                    IsFromSupport = false,
                    Body = Truncate(request.Message.Trim(), MaxBodyLength),
                    CreatedAt = now
                }
            }
        };

        _dbContext.SupportTickets.Add(ticket);
        await _dbContext.SaveChangesAsync(ct);

        var detail = await LoadOwnedTicketDetailAsync(ticketId, userId.Value, ct);
        return Ok(detail);
    }

    [HttpGet("my")]
    public async Task<IActionResult> GetMyTickets(CancellationToken ct)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
            return Unauthorized();

        var rows = await _dbContext.SupportTickets
            .AsNoTracking()
            .Where(t => t.UserId == userId)
            .OrderByDescending(t => t.UpdatedAt)
            .Select(t => new
            {
                t.Id,
                t.Subject,
                t.Category,
                t.Status,
                t.UserId,
                Username = t.User.Username,
                t.OrderId,
                t.AssignedAdminId,
                MessagesCount = t.Messages.Count,
                t.CreatedAt,
                t.UpdatedAt
            })
            .ToListAsync(ct);

        var items = rows
            .Select(t => new TicketListItemDto(
                t.Id, t.Subject, t.Category.ToString(), t.Status.ToString(),
                t.UserId, t.Username, t.OrderId, t.AssignedAdminId, t.MessagesCount, t.CreatedAt, t.UpdatedAt))
            .ToList();

        return Ok(items);
    }

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> GetTicket(Guid id, CancellationToken ct)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
            return Unauthorized();

        var detail = await LoadOwnedTicketDetailAsync(id, userId.Value, ct);
        return detail is null ? NotFound() : Ok(detail);
    }

    [HttpPost("{id:guid}/reply")]
    public async Task<IActionResult> Reply(Guid id, [FromBody] TicketReplyRequest request, CancellationToken ct)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
            return Unauthorized();

        if (string.IsNullOrWhiteSpace(request.Body))
            return BadRequest(new { message = "Message body is required." });

        var ticket = await _dbContext.SupportTickets.FirstOrDefaultAsync(t => t.Id == id, ct);
        if (ticket is null)
            return NotFound();
        if (ticket.UserId != userId)
            return Forbid();
        if (ticket.Status == TicketStatus.Closed)
            return BadRequest(new { message = "Ticket is closed." });

        _dbContext.TicketMessages.Add(new TicketMessage
        {
            Id = Guid.NewGuid(),
            TicketId = id,
            SenderId = userId.Value,
            IsFromSupport = false,
            Body = Truncate(request.Body.Trim(), MaxBodyLength),
            CreatedAt = DateTime.UtcNow
        });

        ticket.Status = TicketStatus.PendingSupport;
        ticket.UpdatedAt = DateTime.UtcNow;

        await _dbContext.SaveChangesAsync(ct);

        var detail = await LoadOwnedTicketDetailAsync(id, userId.Value, ct);
        return Ok(detail);
    }

    private async Task<TicketDetailDto?> LoadOwnedTicketDetailAsync(Guid id, Guid userId, CancellationToken ct)
    {
        var row = await _dbContext.SupportTickets
            .AsNoTracking()
            .Where(t => t.Id == id && t.UserId == userId)
            .Select(t => new
            {
                t.Id,
                t.Subject,
                t.Category,
                t.Status,
                t.UserId,
                Username = t.User.Username,
                t.OrderId,
                t.AssignedAdminId,
                t.CreatedAt,
                t.UpdatedAt,
                t.ClosedAt,
                Messages = t.Messages
                    .OrderBy(m => m.CreatedAt)
                    .Select(m => new { m.Id, m.SenderId, m.IsFromSupport, m.Body, m.CreatedAt })
                    .ToList()
            })
            .FirstOrDefaultAsync(ct);

        if (row is null)
            return null;

        var messages = row.Messages
            .Select(m => new TicketMessageDto(m.Id, m.SenderId, m.IsFromSupport, m.Body, m.CreatedAt))
            .ToList();

        return new TicketDetailDto(
            row.Id, row.Subject, row.Category.ToString(), row.Status.ToString(),
            row.UserId, row.Username, row.OrderId, row.AssignedAdminId,
            row.CreatedAt, row.UpdatedAt, row.ClosedAt, messages);
    }

    private Guid? GetCurrentUserId()
    {
        var value = User.FindFirstValue(ClaimTypes.NameIdentifier);
        return Guid.TryParse(value, out var id) ? id : null;
    }

    private static string Truncate(string value, int maxLength) =>
        value.Length <= maxLength ? value : value[..maxLength];
}
