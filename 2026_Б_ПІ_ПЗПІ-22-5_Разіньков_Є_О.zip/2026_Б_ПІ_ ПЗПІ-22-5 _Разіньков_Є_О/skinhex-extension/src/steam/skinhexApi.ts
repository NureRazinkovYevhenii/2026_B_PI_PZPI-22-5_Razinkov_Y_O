/**
 * Утиліта для звернення розширення до SkinHex API.
 */

export interface TradeInfo {
    buyerSteamId: string;
    buyerTradeToken: string;
    buyerPartnerId: string;
    assetId: number;
}

export interface PendingTradeSyncItem {
    orderId: string;
    tradeOfferId: string;
    tradeId?: string | null;
    offerState: number;
    tradeStatus?: number | null;
    timeUpdated?: number | null;
    /** Asset id листинга — покупецька сторона звіряє вміст вхідного офера. */
    expectedAssetId?: number | null;
    /** SteamID64 контрагента. */
    partnerSteamId?: string | null;
    /** Сторона користувача в цьому замовленні. */
    role?: 'buyer' | 'seller' | null;
    /** Коли ескроу завершився і продавцю час запускати completion proof (unix, UTC). */
    escrowEndsAtUnix?: number | null;
    /** Останній стан, підтверджений покупцем — щоб не слати повторні репорти. */
    buyerReportedOfferState?: number | null;
}

export interface PendingTradeSyncResponse {
    actorRole: string;
    trades: PendingTradeSyncItem[];
}

export interface BatchTradeSyncUpdateItem {
    orderId: string;
    tradeOfferId: string;
    offerState: number;
    tradeId?: string | null;
    tradeStatus?: number | null;
    timeUpdated?: number | null;
    /** Тільки для покупецьких репортів: asset id, які видно в items_to_receive офера. */
    assetIds?: string[] | null;
}

export interface BatchTradeSyncUpdateResponse {
    actorRole: string;
    received: number;
    updated: number;
    failed: number;
}

export async function fetchTradeInfo(
    apiBaseUrl: string,
    orderId: string,
    authToken: string
): Promise<TradeInfo> {
    const url = `${apiBaseUrl}/orders/${orderId}/trade-info`;

    const resp = await fetch(url, {
        method: 'GET',
        headers: {
            'Authorization': `Bearer ${authToken}`,
            'Content-Type': 'application/json',
        },
    });

    if (!resp.ok) {
        if (resp.status === 401) throw new Error("AUTH_EXPIRED");
        let errorMsg = `API error: ${resp.status}`;
        try {
            const body = await resp.json();
            errorMsg = body.message || body.error || errorMsg;
        } catch {}
        throw new Error(errorMsg);
    }

    return (await resp.json()) as TradeInfo;
}

export async function createTradeAttempt(
    apiBaseUrl: string,
    orderId: string,
    tradeOfferId: string,
    offerState: number,
    authToken: string
): Promise<any> {
    const url = `${apiBaseUrl}/orders/${orderId}/trade`;

    const resp = await fetch(url, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${authToken}`,
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            tradeOfferId,
            offerState
        })
    });

    if (!resp.ok) {
        if (resp.status === 401) throw new Error("AUTH_EXPIRED");
        let errorMsg = `API error: ${resp.status}`;
        try {
            const body = await resp.json();
            errorMsg = body.message || body.error || errorMsg;
        } catch {}
        throw new Error(errorMsg);
    }

    return await resp.json();
}

export async function updateTradeAttempt(
    apiBaseUrl: string,
    orderId: string,
    tradeOfferId: string,
    offerState: number,
    tradeId: string | null,
    tradeStatus: number | null,
    timeUpdated: number | null,
    authToken: string
): Promise<any> {
    const url = `${apiBaseUrl}/orders/${orderId}/trade`;

    const resp = await fetch(url, {
        method: 'PUT',
        headers: {
            'Authorization': `Bearer ${authToken}`,
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            tradeOfferId,
            offerState,
            tradeId,
            tradeStatus,
            timeUpdated
        })
    });

    if (!resp.ok) {
        if (resp.status === 401) throw new Error("AUTH_EXPIRED");
        let errorMsg = `API error: ${resp.status}`;
        try {
            const body = await resp.json();
            errorMsg = body.message || body.error || errorMsg;
        } catch {}
        throw new Error(errorMsg);
    }

    return await resp.json();
}

export async function fetchPendingTradeSyncItems(
    apiBaseUrl: string,
    authToken: string,
    actorRole: 'seller' | 'buyer' | 'all' = 'all'
): Promise<PendingTradeSyncResponse> {
    // 'all' — єдиний sync: бекенд поверне і покупки, і продажі з полем role у кожного трейду.
    const url = `${apiBaseUrl}/orders/trade-sync/pending?actorRole=${encodeURIComponent(actorRole)}`;

    const resp = await fetch(url, {
        method: 'GET',
        headers: {
            'Authorization': `Bearer ${authToken}`,
            'Content-Type': 'application/json',
        },
    });

    if (!resp.ok) {
        if (resp.status === 401) throw new Error("AUTH_EXPIRED");
        let errorMsg = `API error: ${resp.status}`;
        try {
            const body = await resp.json();
            errorMsg = body.message || body.error || errorMsg;
        } catch {}
        throw new Error(errorMsg);
    }

    return (await resp.json()) as PendingTradeSyncResponse;
}

export async function reportBatchTradeSync(
    apiBaseUrl: string,
    authToken: string,
    updates: BatchTradeSyncUpdateItem[],
    actorRole: 'seller' | 'buyer' | 'all' = 'all'
): Promise<BatchTradeSyncUpdateResponse> {
    const url = `${apiBaseUrl}/orders/trade-sync/batch`;

    const resp = await fetch(url, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${authToken}`,
            'Content-Type': 'application/json',
        },
        // actorRole 'all' — бекенд сам визначає роль по кожному замовленню.
        body: JSON.stringify({ actorRole, updates }),
    });

    if (!resp.ok) {
        if (resp.status === 401) throw new Error("AUTH_EXPIRED");
        let errorMsg = `API error: ${resp.status}`;
        try {
            const body = await resp.json();
            errorMsg = body.message || body.error || errorMsg;
        } catch {}
        throw new Error(errorMsg);
    }

    return (await resp.json()) as BatchTradeSyncUpdateResponse;
}
