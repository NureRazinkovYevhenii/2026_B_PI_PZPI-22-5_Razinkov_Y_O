namespace SkinHex.Core.Models;

/// <summary>Посилання на конкретну якість цього скіна (для перемикання між сторінками якостей).</summary>
public sealed class WearLinkDto
{
    public string Wear { get; set; } = null!;
    public string MarketHashName { get; set; } = null!;
    public decimal? MinPrice { get; set; }
    public bool IsActive { get; set; }
}

/// <summary>Посилання на варіант предмета: звичайний / StatTrak™ / сувенірний.</summary>
public sealed class VariantLinkDto
{
    public string Kind { get; set; } = null!; // "normal" | "stattrak" | "souvenir"
    public string MarketHashName { get; set; } = null!;
    public bool IsActive { get; set; }
}

public sealed class MarketItemPageDto
{
    public string MarketHashName { get; set; } = null!;
    public string BaseName { get; set; } = null!;
    public string SkinName { get; set; } = null!;
    public string? Weapon { get; set; }
    public string Category { get; set; } = null!;
    public string Rarity { get; set; } = null!;

    public string? Wear { get; set; }
    public bool IsStatTrak { get; set; }
    public bool IsSouvenir { get; set; }

    public int ItemId { get; set; }

    // Сусідні якості того самого варіанта (для табів якості) — з каталогу, не з листингів.
    public IReadOnlyList<WearLinkDto> Wears { get; set; } = Array.Empty<WearLinkDto>();

    // Доступні варіанти (звичайний / StatTrak / сувенір) — для кнопок-перемикачів.
    public IReadOnlyList<VariantLinkDto> Variants { get; set; } = Array.Empty<VariantLinkDto>();

    public string ImageUrl { get; set; } = null!;
    public string RarityColor { get; set; } = null!;

    // Орієнтовна ціна саме цього предмета (ця якість + варіант).
    public decimal? MinPrice { get; set; }
    public decimal? AvgPrice { get; set; }

    public PagedResult<ListingCatalogItemDto> Listings { get; set; } = new();
}
