import { useCallback, useEffect, useRef, useState } from 'react';
import { Loader2 } from 'lucide-react';
import { CatalogMarketCard } from '../components/CatalogMarketCard';
import { CatalogSidebar } from '../components/CatalogSidebar';
import { CatalogSortBar } from '../components/CatalogSortBar';
import { CardSkeletonGrid } from '../components/CardSkeletonGrid';
import { ItemDetailModal } from '../components/ItemDetailModal';
import type { AuthState, AuthorizedFetch, CatalogFilters, CatalogSortOption, ItemDictionaryEntry, ListingCatalogItem } from '../types';
import { readApiError } from '../utils/api';
import { buildCatalogParams, DEFAULT_FILTERS } from '../utils/catalogHelpers';
import { getItemStatic, loadItemDictionary } from '../utils/itemDictionary';

type MyListingsPageProps = {
  auth: AuthState | null;
  authorizedFetch: AuthorizedFetch;
  onRequireLogin: () => void;
};

export function MyListingsPage({ auth, authorizedFetch, onRequireLogin }: MyListingsPageProps) {
  const [filters, setFilters] = useState<CatalogFilters>({ ...DEFAULT_FILTERS });
  const [items, setItems] = useState<ListingCatalogItem[]>([]);
  const [itemDictionary, setItemDictionary] = useState<Record<string, ItemDictionaryEntry>>({});
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [detailItem, setDetailItem] = useState<ListingCatalogItem | null>(null);

  // Refs for debounce & infinite scroll
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const sentinelRef = useRef<HTMLDivElement>(null);
  const filtersRef = useRef(filters);
  filtersRef.current = filters;

  // Track whether it's first load vs filter-triggered reload
  const isFirstLoad = useRef(true);

  // ── Fetch my listings data ──
  const fetchMyListings = useCallback(
    async (currentFilters: CatalogFilters, pageNum: number, append: boolean) => {
      if (append) {
        setIsLoadingMore(true);
      } else {
        setIsLoading(true);
      }
      setError(null);

      try {
        const params = buildCatalogParams(currentFilters, pageNum);
        const [response, dictionary] = await Promise.all([
          authorizedFetch(`/market/my?${params}`),
          loadItemDictionary(),
        ]);

        if (!response.ok) {
          throw new Error(await readApiError(response));
        }

        const data = (await response.json()) as {
          items: ListingCatalogItem[];
          totalPages: number;
          page: number;
        };

        setItemDictionary(dictionary);
        setTotalPages(data.totalPages || 1);

        if (append) {
          setItems((prev) => [...prev, ...data.items]);
        } else {
          setItems(data.items);
        }
        setPage(data.page || pageNum);
      } catch (loadError) {
        if (!append) setItems([]);
        setError(loadError instanceof Error ? loadError.message : 'Failed to load your listings.');
      } finally {
        setIsLoading(false);
        setIsLoadingMore(false);
      }
    },
    [authorizedFetch],
  );

  // ── Initial load ──
  useEffect(() => {
    if (isFirstLoad.current) {
      isFirstLoad.current = false;
      void fetchMyListings(filters, 1, false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ── Debounced filter change → refetch from page 1 ──
  const handleFiltersChange = useCallback(
    (next: CatalogFilters) => {
      setFilters(next);

      if (debounceRef.current) {
        clearTimeout(debounceRef.current);
      }

      debounceRef.current = setTimeout(() => {
        setPage(1);
        void fetchMyListings(next, 1, false);
      }, 500);
    },
    [fetchMyListings],
  );

  // ── Sort change → immediate refetch ──
  const handleSortChange = useCallback(
    (sort: CatalogSortOption) => {
      const next = { ...filtersRef.current, sortBy: sort };
      setFilters(next);
      setPage(1);
      void fetchMyListings(next, 1, false);
    },
    [fetchMyListings],
  );

  // ── Reset ──
  const handleReset = useCallback(() => {
    const next = { ...DEFAULT_FILTERS };
    setFilters(next);
    setPage(1);
    void fetchMyListings(next, 1, false);
  }, [fetchMyListings]);

  // ── Load next page callback ──
  const loadNextPage = useCallback(() => {
    if (isLoading || isLoadingMore || page >= totalPages) return;
    const nextPage = page + 1;
    void fetchMyListings(filtersRef.current, nextPage, true);
  }, [isLoading, isLoadingMore, page, totalPages, fetchMyListings]);

  // ── Infinite scroll via IntersectionObserver ──
  useEffect(() => {
    const sentinel = sentinelRef.current;
    if (!sentinel) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          loadNextPage();
        }
      },
      { rootMargin: '400px' },
    );

    observer.observe(sentinel);
    return () => observer.disconnect();
  }, [loadNextPage]);

  // ── Reload catalog (after purchase etc.) ──
  const reloadMyListings = useCallback(() => {
    setPage(1);
    void fetchMyListings(filtersRef.current, 1, false);
  }, [fetchMyListings]);

  if (!auth) {
    return (
      <div className="inventory-state">
        <strong>Authentication Required</strong>
        <p>Please sign in to view your listings.</p>
      </div>
    );
  }

  return (
    <section className="cat-page">
      <CatalogSidebar
        filters={filters}
        onChange={handleFiltersChange}
        onReset={handleReset}
        itemDictionary={itemDictionary}
      />

      <div className="cat-main">
        <div style={{ padding: '0 24px', marginBottom: '16px' }}>
          <h2>My Listings</h2>
        </div>
        <CatalogSortBar sortBy={filters.sortBy} onSortChange={handleSortChange} />

        {error ? (
          <div className="inventory-state inventory-error" role="alert">
            <strong>Error</strong>
            <p>{error}</p>
          </div>
        ) : isLoading ? (
          <CardSkeletonGrid />
        ) : items.length > 0 ? (
          <>
            <div className="cat-grid">
              {items.map((item) => (
                <CatalogMarketCard
                  key={item.id}
                  auth={auth}
                  authorizedFetch={authorizedFetch}
                  item={item}
                  itemStatic={getItemStatic(itemDictionary, item.marketHashName)}
                  isOwnListing={true}
                  onPurchaseCreated={reloadMyListings}
                  onRequireLogin={onRequireLogin}
                  onOpenDetails={() => setDetailItem(item)}
                />
              ))}
            </div>

            {/* Infinite scroll sentinel */}
            <div ref={sentinelRef} className="cat-sentinel">
              {isLoadingMore && (
                <div className="cat-loading-more">
                  <Loader2 size={20} className="spin-animation" />
                  <span>Loading more...</span>
                </div>
              )}
              {page >= totalPages && items.length > 0 && (
                <div className="cat-end-message">
                  No more items
                </div>
              )}
            </div>
          </>
        ) : (
          <div className="inventory-state">
            <strong>No listings found</strong>
            <p>You don't have any active listings matching these filters.</p>
          </div>
        )}
      </div>

      {detailItem && (
        <ItemDetailModal
          source={{ kind: 'listing', listing: detailItem }}
          itemStatic={getItemStatic(itemDictionary, detailItem.marketHashName)}
          onClose={() => setDetailItem(null)}
          market={{
            auth,
            authorizedFetch,
            isOwnListing: true,
            onChanged: reloadMyListings,
            onRequireLogin,
          }}
        />
      )}
    </section>
  );
}
