import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import type { AuthState, AuthorizedFetch, ItemDictionaryEntry, Order, OrderStatus } from '../types';
import { getItemImageUrl } from '../utils/itemDictionary';
import { confirmOrder, cancelOrder } from '../utils/orders';
import { ApiError } from '../utils/api';
import {
  checkSteamAuthViaExtension,
  sendTradeViaExtension,
  checkTradeOfferStatusViaExtension,
  cancelTradeOfferViaExtension,
  proveTradeStatusViaExtension
} from '../utils/extensionBridge';
import { API_BASE_URL } from '../config';
import {
  isDisputeOpen,
  openDispute,
  USER_DISPUTE_REASONS,
  type Dispute,
  type DisputeReason,
} from '../api/disputesApi';

type OrderCardProps = {
  order: Order;
  itemStatic: ItemDictionaryEntry | null;
  auth: AuthState | null;
  authorizedFetch: AuthorizedFetch;
  onOrderUpdate: (updatedOrder: Order) => void;
  dispute?: Dispute | null;
  onDisputeChanged?: (dispute: Dispute) => void;
};

const TRADE_STEPS = [
  { key: 'sellerAccepts', statusThreshold: 0 },
  { key: 'sellerSendsTrade', statusThreshold: 1 },
  { key: 'buyerAcceptsTrade', statusThreshold: 2 },
  { key: 'tradeVerified', statusThreshold: 3 },
] as const;

/** After sending a dispute TLSN proof, the button is disabled for this long (anti-spam),
 *  then re-enabled so a second proof can still be requested if support needs one. */
const TLSN_PROOF_COOLDOWN_MS = 3 * 60 * 1000;

const STATUS_MAP: Record<string, { index: number; color: string }> = {
  pending:   { index: 0, color: '#60a5fa' },
  confirmed: { index: 1, color: '#818cf8' },
  tradesent: { index: 2, color: '#a78bfa' },
  inescrow:  { index: 3, color: '#fbbf24' },
  completed: { index: 4, color: '#34d399' },
  cancelled: { index: -1, color: '#f87171' },
};

function normalizeStatus(status: OrderStatus): string {
  if (typeof status === 'number') {
    return (['pending', 'confirmed', 'tradesent', 'inescrow', 'completed', 'cancelled'][status]) ?? 'pending';
  }
  return status.toLowerCase().replace(/\s/g, '');
}

function isRecoverableOfferState(offerState: number): boolean {
  return [4, 5, 6, 7, 8, 10].includes(offerState);
}

function mapOrderStatusFromTrade(offerState: number, currentStatusKey: string): OrderStatus {
  if (offerState === 2) return 'TradeSent';
  if (offerState === 3 || offerState === 11) return 'InEscrow';
  if (offerState === 9 || isRecoverableOfferState(offerState)) return 'Confirmed';
  if (currentStatusKey === 'tradesent') return 'Confirmed';
  switch (currentStatusKey) {
    case 'pending': return 'Pending';
    case 'confirmed': return 'Confirmed';
    case 'tradesent': return 'TradeSent';
    case 'inescrow': return 'InEscrow';
    case 'completed': return 'Completed';
    case 'cancelled': return 'Cancelled';
    default: return 'Confirmed';
  }
}

function getRelativeTime(dateStr: string) {
  const diff = Date.now() - new Date(dateStr).getTime();
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (minutes < 1) return 'Just now';
  if (minutes < 60) return `${minutes}m ago`;
  if (hours < 24) return `${hours}h ago`;
  if (days === 1) return 'Yesterday';
  return `${days}d ago`;
}

function formatDuration(seconds: number): string {
  if (seconds <= 0) return '00:00';
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h >= 24) {
    const d = Math.floor(h / 24);
    const rh = h % 24;
    return `${d}d ${rh.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  }
  if (h > 0) {
    return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  }
  return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
}

/* SVG icons for step states */
function CheckIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
      <path d="M3 7.5L5.5 10L11 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function CrossIcon() {
  return (
    <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
      <path d="M2 2L10 10M10 2L2 10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

export function OrderCard({ order, itemStatic, auth, authorizedFetch, onOrderUpdate, dispute = null, onDisputeChanged }: OrderCardProps) {
  const { t } = useTranslation();

  const [now, setNow] = useState(Date.now());
  const [isConfirming, setIsConfirming] = useState(false);
  const [isCancelling, setIsCancelling] = useState(false);
  const [isSendingTrade, setIsSendingTrade] = useState(false);
  const [isVerifyingTrade, setIsVerifyingTrade] = useState(false);
  const [isProvingTradeStatus, setIsProvingTradeStatus] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);
  const [isWaitingMobileConfirm, setIsWaitingMobileConfirm] = useState(false);
  const [showCancelConfirm, setShowCancelConfirm] = useState(false);
  const [showDisputeModal, setShowDisputeModal] = useState(false);
  const [disputeReason, setDisputeReason] = useState<DisputeReason>('OfferNotReceived');
  const [disputeDescription, setDisputeDescription] = useState('');
  const [isSubmittingDispute, setIsSubmittingDispute] = useState(false);
  const [disputeError, setDisputeError] = useState<string | null>(null);

  const statusKey = normalizeStatus(order.status);
  const isPending = statusKey === 'pending';
  const isConfirmed = statusKey === 'confirmed';
  const isTradeSent = statusKey === 'tradesent';
  const isCancelled = statusKey === 'cancelled';
  const isCompleted = statusKey === 'completed';
  const isBuyer = order.role === 'Buyer';
  const sellerCanResend = !isBuyer && (
    !order.activeTrade ||
    isConfirmed ||
    isRecoverableOfferState(order.activeTrade.offerState)
  );

  // Mobile confirmation modal is now triggered only by "Send Trade" action.

  useEffect(() => {
    if (isCompleted || isCancelled) return;
    const interval = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(interval);
  }, [isCompleted, isCancelled]);

  const confirmDeadlineMs = order.confirmDeadline ? new Date(order.confirmDeadline).getTime() : 0;
  const sendTradeDeadlineMs = order.sendTradeDeadline ? new Date(order.sendTradeDeadline).getTime() : 0;
  const buyerCancelableMs = order.buyerCancelableAt ? new Date(order.buyerCancelableAt).getTime() : 0;
  const tradeAcceptDeadlineMs = order.tradeAcceptDeadline ? new Date(order.tradeAcceptDeadline).getTime() : 0;
  const escrowEndsAtMs = order.escrowEndsAt ? new Date(order.escrowEndsAt).getTime() : 0;

  const timeToConfirm = Math.max(0, Math.floor((confirmDeadlineMs - now) / 1000));
  const timeToSendTrade = Math.max(0, Math.floor((sendTradeDeadlineMs - now) / 1000));
  const timeToBuyerCancel = Math.max(0, Math.floor((buyerCancelableMs - now) / 1000));
  const timeToTradeAccept = Math.max(0, Math.floor((tradeAcceptDeadlineMs - now) / 1000));
  const timeToEscrowEnd = Math.max(0, Math.floor((escrowEndsAtMs - now) / 1000));
  
  const buyerCanCancel = timeToBuyerCancel === 0;
  const sellerCanCancelTrade = !isBuyer && isTradeSent && order.tradeAcceptDeadline != null && timeToTradeAccept === 0;

  // Disputes: available to both parties from the moment the seller confirms, and on
  // cancelled orders (penalty appeal — the backend enforces the 7-day appeal window).
  // All reasons are always offered: a wedged status must not block opening a dispute.
  const hasOpenDispute = isDisputeOpen(dispute);
  const canOpenDispute =
    !hasOpenDispute &&
    (isConfirmed || isTradeSent || statusKey === 'inescrow' || isCancelled);

  // Seconds left on the TLSN-proof cooldown for this order (0 = ready). Stored in localStorage so
  // it survives the reload the proof triggers; `now` ticks each second while the order is active.
  const proofCooldownLeft = (() => {
    const raw = localStorage.getItem(`skinhex_tlsn_proof_at_${order.orderId}`);
    const at = raw ? Number(raw) : NaN;
    if (!Number.isFinite(at)) return 0;
    return Math.max(0, Math.ceil((at + TLSN_PROOF_COOLDOWN_MS - now) / 1000));
  })();

  const handleOpenDispute = async () => {
    if (!disputeDescription.trim()) return;
    setIsSubmittingDispute(true);
    setDisputeError(null);
    try {
      const created = await openDispute(authorizedFetch, order.orderId, disputeReason, disputeDescription.trim());
      onDisputeChanged?.(created);
      setShowDisputeModal(false);
      setDisputeDescription('');
    } catch (err) {
      setDisputeError(err instanceof Error ? err.message : 'Failed to open dispute');
    } finally {
      setIsSubmittingDispute(false);
    }
  };

  const handleConfirm = async () => {
    setIsConfirming(true);
    try {
      const updated = await confirmOrder(authorizedFetch, order.orderId);
      onOrderUpdate(updated);
    } catch (err) {
      if (err instanceof ApiError && err.status === 409 && err.payload?.order) {
        onOrderUpdate(err.payload.order as Order);
      } else {
        alert(err instanceof Error ? err.message : 'Error confirming order');
      }
    } finally {
      setIsConfirming(false);
    }
  };

  const handleCancel = async () => {
    setIsCancelling(true);
    try {
      if (sellerCanCancelTrade && order.activeTrade) {
         const cancelRes = await cancelTradeOfferViaExtension(order.activeTrade.tradeOfferId);
         if (cancelRes.error) throw new Error(cancelRes.error);
         
         const tradeDto = await checkTradeOfferStatusViaExtension(order.activeTrade.tradeOfferId, API_BASE_URL, order.orderId);
         if (tradeDto.error) throw new Error(tradeDto.error);
         
         window.location.reload();
         return;
      }
      
      const updated = await cancelOrder(authorizedFetch, order.orderId, null);
      onOrderUpdate(updated);
    } catch (err) {
      if (err instanceof ApiError && err.status === 409 && err.payload?.remainingSeconds) {
        alert(t('orders.actions.cancelIn', { time: formatDuration(err.payload.remainingSeconds) }));
      } else if (err instanceof ApiError && err.status === 409 && err.payload?.order) {
        onOrderUpdate(err.payload.order as Order);
      } else {
        alert(err instanceof Error ? err.message : 'Error cancelling order');
      }
    } finally {
      setIsCancelling(false);
    }
  };

  const handleSendTrade = async () => {
    if (!auth?.accessToken) return;

    setActionError(null);
    setIsSendingTrade(true);
    try {
      const steamAuth = await checkSteamAuthViaExtension(auth.steamId ?? undefined);
      
      if (!steamAuth.isLoggedIn) {
        setActionError('You are not logged into Steam! Please log in on steamcommunity.com first.');
        return;
      }
      if (steamAuth.error) {
        setActionError(`Steam Auth Error: ${steamAuth.error}`);
        return;
      }

      let needsNewTrade = true;

      // 1. If we already have a trade, check its status first!
      if (order.activeTrade) {
        const tradeDto = await checkTradeOfferStatusViaExtension(order.activeTrade.tradeOfferId, API_BASE_URL, order.orderId);
        
        if (!tradeDto.error && tradeDto.offerState !== undefined) {
          const offerState = tradeDto.offerState;
          
          if (!isRecoverableOfferState(offerState)) {
             // It's still active (2), in escrow (3), or needs confirmation (9)
             needsNewTrade = false;
             
             const updatedOrder = {
               ...order,
               activeTrade: tradeDto,
               status: mapOrderStatusFromTrade(tradeDto.offerState, statusKey)
             };
             onOrderUpdate(updatedOrder as any);

             if (offerState === 9) {
               setIsWaitingMobileConfirm(true);
             }
          }
          // If it IS a recoverable state (like 7 - Canceled), needsNewTrade remains true!
        }
      }

      // 2. Create a new trade only if we need to
      if (needsNewTrade) {
        const tradeDto = await sendTradeViaExtension(
          order.orderId,
          API_BASE_URL
        );

        if (tradeDto.error) {
          setActionError(tradeDto.error);
        } else if (tradeDto.tradeOfferId) {
          const updatedOrder = {
            ...order,
            activeTrade: tradeDto,
            status: mapOrderStatusFromTrade(tradeDto.offerState, statusKey)
          };
          onOrderUpdate(updatedOrder as any);

          if (tradeDto.needsConfirmation || tradeDto.offerState === 9) {
            setIsWaitingMobileConfirm(true);
          }
        }
      }
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Error communicating with extension');
    } finally {
      setIsSendingTrade(false);
    }
  };

  const handleProveTradeStatus = async () => {
    if (!auth?.steamId) {
      setActionError('Steam ID is missing in your profile. Please re-login and try again.');
      return;
    }
    if (!order.activeTrade) {
      setActionError('No trade to prove yet.');
      return;
    }

    setActionError(null);
    setIsProvingTradeStatus(true);
    try {
      const steamAuth = await checkSteamAuthViaExtension(auth.steamId);
      if (!steamAuth.isLoggedIn) {
        throw new Error('You are not logged into Steam.');
      }

      // The Steam trade id (needed for the GetTradeStatus proof) is populated by the periodic
      // sync. If it hasn't landed yet, fetch it on demand so the button works immediately
      // instead of making the seller wait for the next sync tick.
      let steamTradeId = order.activeTrade.steamTradeId ?? null;
      if (!steamTradeId) {
        const status = await checkTradeOfferStatusViaExtension(order.activeTrade.tradeOfferId, API_BASE_URL, order.orderId);
        steamTradeId = status.tradeId ?? null;
      }
      if (!steamTradeId) {
        throw new Error('Steam has not assigned a trade id yet (the buyer may not have accepted). Try again shortly.');
      }

      const result = await proveTradeStatusViaExtension(
        steamTradeId,
        auth.steamId,
        order.orderId,
      );

      if (result.error) {
        throw new Error(result.error);
      }

      // Start the anti-spam cooldown; persists across the reload below.
      localStorage.setItem(`skinhex_tlsn_proof_at_${order.orderId}`, String(Date.now()));

      // Webhook processing is asynchronous on the backend after notary submission.
      setTimeout(() => {
        window.location.reload();
      }, 1500);
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Failed to generate TLSN proof');
    } finally {
      setIsProvingTradeStatus(false);
    }
  };

  const handleVerifyTrade = async () => {
    if (!order.activeTrade) return;

    setActionError(null);
    setIsVerifyingTrade(true);
    try {
        const tradeDto = await checkTradeOfferStatusViaExtension(order.activeTrade.tradeOfferId, API_BASE_URL, order.orderId);
        if (tradeDto.error) {
            setActionError(tradeDto.error);
            return;
        }

        const newOfferState = tradeDto.offerState ?? order.activeTrade.offerState;
        
        // If the state hasn't changed, just return locally
        if (newOfferState === order.activeTrade.offerState && newOfferState === 9) {
            setActionError('Трейд усе ще очікує підтвердження в мобільному застосунку Steam.');
            return;
        }
        
        const updatedOrder = {
          ...order,
          activeTrade: tradeDto,
          status: mapOrderStatusFromTrade(tradeDto.offerState, statusKey)
        };
        onOrderUpdate(updatedOrder as any);

        if (newOfferState === 2 || newOfferState === 3) {
            setIsWaitingMobileConfirm(false);
        } else if (newOfferState === 9) {
            setActionError('Трейд усе ще очікує підтвердження в мобільному застосунку Steam.');
        }
    } catch(err) {
        setActionError(err instanceof Error ? err.message : 'Error communicating with extension');
    } finally {
        setIsVerifyingTrade(false);
    }
  };

  const statusInfo = STATUS_MAP[statusKey] ?? STATUS_MAP.pending;
  const cancelledAtStatusKey = order.cancelledAtStatus != null
    ? normalizeStatus(order.cancelledAtStatus)
    : null;
  const cancelledAtStatusInfo = cancelledAtStatusKey
    ? (STATUS_MAP[cancelledAtStatusKey] ?? STATUS_MAP.pending)
    : null;
  const progressIndex = isCancelled
    ? Math.max(0, cancelledAtStatusInfo?.index ?? 0)
    : statusInfo.index;
  const colorHex = itemStatic?.color ? `#${itemStatic.color}` : 'transparent';
  const imageUrl = getItemImageUrl(itemStatic);
  const wearStr = order.item.wear
    ? `${order.item.wear}${order.item.float != null ? ` · ${order.item.float.toFixed(4)}` : ''}`
    : (itemStatic?.rarity || '');

  function getContextMessage() {
    if (isCompleted) return t('orders.context.completed');
    if (isCancelled) {
      const by = order.cancelledBy ? t(`orders.cancelBy.${order.cancelledBy.toLowerCase()}`) : t('orders.context.cancelled');
      const reason = order.cancelReason ? ` - ${order.cancelReason}` : '';
      return `${by}${reason}`;
    }

    if (isBuyer) {
      switch (statusKey) {
        case 'pending': return t('orders.context.sellerPending');
        case 'confirmed': return t('orders.context.sellerConfirmed');
        case 'tradesent': return t('orders.context.tradeSentBuyer');
        case 'inescrow': return t('orders.context.inEscrow');
        default: return '';
      }
    } else {
      switch (statusKey) {
        case 'pending': return t('orders.context.buyerPending');
        case 'confirmed': return t('orders.context.buyerConfirmed');
        case 'tradesent': return t('orders.context.tradeSentSeller');
        case 'inescrow': return t('orders.context.inEscrow');
        default: return '';
      }
    }
  }

  const contextMessage = getContextMessage();

  // Determine avatar info for seller/buyer sides
  const selfAvatar = auth?.avatarUrl ?? null;
  const selfName = auth?.name ?? t('orders.you');
  const partnerAvatar = order.partner.avatarUrl;
  const partnerName = order.partner.username;

  const sellerAvatar = isBuyer ? partnerAvatar : selfAvatar;
  const sellerName = isBuyer ? partnerName : selfName;
  const buyerAvatar = isBuyer ? selfAvatar : partnerAvatar;
  const buyerName = isBuyer ? selfName : partnerName;

  return (
    <article className={`trade-card ${isCancelled ? 'trade-card--cancelled' : ''} ${isCompleted ? 'trade-card--completed' : ''}`}>
      {/* ═══ Item Header ═══ */}
      <div className="trade-card__header">
        <div
          className="trade-card__item-img"
          style={{
            borderColor: colorHex !== 'transparent' ? colorHex : '#27272a',
            background: itemStatic?.color
              ? `radial-gradient(circle, ${colorHex}22 0%, transparent 70%)`
              : '#111115',
          }}
        >
          {imageUrl ? <img src={imageUrl} alt="" /> : <div className="trade-card__img-empty" />}
        </div>

        <div className="trade-card__item-info">
          <h3 className="trade-card__item-name">{order.item.marketHashName}</h3>
          {wearStr && <span className="trade-card__item-wear">{wearStr}</span>}
        </div>

        <div className="trade-card__meta">
          <span className="trade-card__price">${order.price.toFixed(2)}</span>
          <span className={`trade-card__status trade-card__status--${statusKey}`}>
            {isCompleted && <CheckIcon />}
            {isCancelled && <CrossIcon />}
            {t(`orders.statusLabel.${statusKey}`)}
          </span>
          {isPending && timeToConfirm > 0 && (
            <span className="trade-card__time">
              ⏱ {formatDuration(timeToConfirm)}
            </span>
          )}
          {isConfirmed && timeToSendTrade > 0 && (
            <span className="trade-card__time" style={{ color: timeToSendTrade < 900 ? '#ef4444' : '#fb923c' }}>
              ⏱ {formatDuration(timeToSendTrade)}
            </span>
          )}
          {isTradeSent && timeToTradeAccept > 0 && (
            <span className="trade-card__time" style={{ color: timeToTradeAccept < 3600 ? '#ef4444' : '#fb923c' }}>
              ⏱ {formatDuration(timeToTradeAccept)}
            </span>
          )}
          {statusKey === 'inescrow' && timeToEscrowEnd > 0 && (
            <span className="trade-card__time" style={{ color: timeToEscrowEnd < 86400 ? '#ef4444' : '#fb923c' }}>
              ⏱ {formatDuration(timeToEscrowEnd)}
            </span>
          )}
          <span className="trade-card__time" title={new Date(order.createdAt).toLocaleString()}>
            {getRelativeTime(order.createdAt)}
          </span>
        </div>
      </div>

      {/* ═══ Trade Stepper ═══ */}
      <div className="trade-stepper">
        {/* Seller anchor */}
        <div className="trade-stepper__anchor">
          <div className={`trade-stepper__avatar ${!isBuyer ? 'trade-stepper__avatar--you' : ''}`}>
            {sellerAvatar
              ? <img src={sellerAvatar} alt="" />
              : <div className="trade-stepper__avatar-placeholder" />
            }
          </div>
          <span className="trade-stepper__anchor-label">
            {!isBuyer ? t('orders.you') : sellerName}
          </span>
        </div>

        {/* Steps rail */}
        <div className="trade-stepper__rail">
          {/* Connector line (background) */}
          <div className="trade-stepper__connector">
            <div
              className="trade-stepper__connector-fill"
              style={{
                width: isCancelled
                  ? `${Math.min(100, (progressIndex / TRADE_STEPS.length) * 100)}%`
                  : `${Math.min(100, (progressIndex / TRADE_STEPS.length) * 100)}%`,
                background: isCancelled
                  ? '#f87171'
                  : `linear-gradient(90deg, ${statusInfo.color}cc, ${statusInfo.color}88)`,
              }}
            />
          </div>

          {/* Step pills */}
          <div className="trade-stepper__steps">
            {TRADE_STEPS.map((step, idx) => {
              const isFilled = progressIndex > idx;
              const isActive = !isCancelled && progressIndex === idx;
              const isFuture = progressIndex < idx;

              return (
                <div
                  key={step.key}
                  className={[
                    'trade-step',
                    isFilled ? 'trade-step--done' : '',
                    isActive ? 'trade-step--active' : '',
                    isFuture ? 'trade-step--future' : '',
                    isCancelled ? 'trade-step--cancelled' : '',
                  ].filter(Boolean).join(' ')}
                  style={
                    (isFilled || isActive)
                      ? { '--step-color': statusInfo.color } as React.CSSProperties
                      : undefined
                  }
                >
                  <div className="trade-step__circle">
                    {isFilled ? (
                      <CheckIcon />
                    ) : isActive ? (
                      <span className="trade-step__pulse" />
                    ) : isCancelled ? (
                      <CrossIcon />
                    ) : (
                      <span className="trade-step__number">{idx + 1}</span>
                    )}
                  </div>
                  <span className="trade-step__label">
                    {t(`orders.steps.${step.key}`)}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Buyer anchor */}
        <div className="trade-stepper__anchor">
          <div className={`trade-stepper__avatar ${isBuyer ? 'trade-stepper__avatar--you' : ''}`}>
            {buyerAvatar
              ? <img src={buyerAvatar} alt="" />
              : <div className="trade-stepper__avatar-placeholder" />
            }
          </div>
          <span className="trade-stepper__anchor-label">
            {isBuyer ? t('orders.you') : buyerName}
          </span>
        </div>
      </div>

      {/* ═══ Context message ═══ */}
      {contextMessage && (
        <div className={`trade-card__context ${isCompleted ? 'trade-card__context--success' : ''} ${isCancelled ? 'trade-card__context--error' : ''}`}>
          <p>{contextMessage}</p>
        </div>
      )}

      {/* ═══ Action Bar ═══ */}
      {(actionError || isPending || (isConfirmed && !isBuyer) || (order.activeTrade != null && !isBuyer && !isCancelled) || (isTradeSent && isBuyer && order.activeTrade) || sellerCanCancelTrade) && (
        <div className="trade-card__actions-container" style={{ display: 'flex', flexDirection: 'column', borderTop: '1px solid #27272a' }}>
          {actionError && (
            <div style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)', color: '#fca5a5', padding: '12px 16px', fontSize: '13px', display: 'flex', alignItems: 'flex-start', gap: '8px', borderBottom: '1px solid rgba(239, 68, 68, 0.2)' }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0, marginTop: '1px' }}>
                <circle cx="12" cy="12" r="10"></circle>
                <line x1="12" y1="8" x2="12" y2="12"></line>
                <line x1="12" y1="16" x2="12.01" y2="16"></line>
              </svg>
              <span>{actionError}</span>
            </div>
          )}
          
          {/* Mobile confirmation modal is now rendered globally at the end of the component */}
          {/* An open dispute freezes the order — hide confirm/send/cancel actions; the dispute
              strip below shows the "under review" banner (and TLSN proof button when applicable). */}
          { !hasOpenDispute && (isPending || (isConfirmed && !isBuyer) || (order.activeTrade != null && !isBuyer && !isCancelled) || (isTradeSent && isBuyer && order.activeTrade) || sellerCanCancelTrade) && (
              <div className="trade-card__actions" style={{ display: 'flex', gap: '8px', padding: '16px' }}>
                {isPending && !isBuyer && (
                  <button 
                    className="primary-button" 
                    onClick={handleConfirm} 
                    disabled={isConfirming || isCancelling}
                    style={{ flex: 1 }}
                  >
                    {isConfirming ? t('orders.actions.confirming') : t('orders.actions.confirmSale')}
                  </button>
                )}
                
                {(isConfirmed || isTradeSent) && sellerCanResend && (
                  <button 
                    className="primary-button" 
                    onClick={handleSendTrade} 
                    disabled={isSendingTrade}
                    style={{ flex: 1 }}
                  >
                    {isSendingTrade ? t('orders.actions.sending') : t('orders.actions.sendTrade')}
                  </button>
                )}


                {statusKey === 'inescrow' && !isBuyer && timeToEscrowEnd === 0 && (
                  <button 
                    className="primary-button" 
                    onClick={handleProveTradeStatus}
                    disabled={isProvingTradeStatus}
                    style={{ flex: 1, backgroundColor: '#10b981', color: '#fff' }}
                  >
                    {isProvingTradeStatus ? 'Generating TLSN Proof...' : 'Proof Trade Status to Get Credited'}
                  </button>
                )}

                {isTradeSent && isBuyer && order.activeTrade && (
                  <a 
                    className="primary-button" 
                    href={`https://steamcommunity.com/tradeoffer/${order.activeTrade.tradeOfferId}/`}
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{ flex: 1, textDecoration: 'none', textAlign: 'center', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '0 16px', fontSize: '14px', fontWeight: 600, borderRadius: '4px', height: '40px' }}
                  >
                    Accept Trade
                  </a>
                )}

                {(isPending || sellerCanCancelTrade) && !showCancelConfirm && (
                  <button 
                    className="secondary-button" 
                    onClick={() => setShowCancelConfirm(true)} 
                    disabled={isCancelling || isConfirming || (isBuyer && !buyerCanCancel)}
                    style={{ flex: 1, borderColor: '#3f3f46', background: 'transparent', color: sellerCanCancelTrade ? '#f87171' : undefined }}
                  >
                    {isCancelling 
                      ? t('orders.actions.cancelling') 
                      : (isBuyer && !buyerCanCancel 
                          ? t('orders.actions.cancelIn', { time: formatDuration(timeToBuyerCancel) }) 
                          : t('orders.actions.cancelOrder'))
                    }
                  </button>
                )}
                
                {showCancelConfirm && (
                  <div style={{ display: 'flex', gap: '8px', flex: 1 }}>
                    <button 
                      className="secondary-button" 
                      onClick={() => setShowCancelConfirm(false)} 
                      disabled={isCancelling}
                      style={{ flex: 1, borderColor: '#3f3f46', background: 'transparent' }}
                    >
                      Back
                    </button>
                    <button 
                      className="primary-button" 
                      onClick={handleCancel} 
                      disabled={isCancelling}
                      style={{ flex: 1, backgroundColor: '#ef4444', color: 'white' }}
                    >
                      {isCancelling ? 'Cancelling...' : 'Confirm Cancel'}
                    </button>
                  </div>
                )}
              </div>
            )
          }
        </div>
      )}

      {/* ═══ Dispute strip ═══ */}
      {(dispute || canOpenDispute) && (
        <div style={{ borderTop: '1px solid #27272a', padding: '12px 16px', display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' }}>
          {dispute && hasOpenDispute ? (
            <>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: '8px', color: '#fbbf24', fontSize: '13px', fontWeight: 600 }}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
                  <line x1="12" y1="9" x2="12" y2="13" />
                  <line x1="12" y1="17" x2="12.01" y2="17" />
                </svg>
                {t('orders.dispute.openBanner', { reason: t(`orders.dispute.reasons.${dispute.reason}`) })}
              </span>
              {/* Seller can prove the trade status once the buyer has accepted (InEscrow) — the
                  Steam trade id is fetched on click if the periodic sync hasn't cached it yet. */}
              {!isBuyer && statusKey === 'inescrow' && order.activeTrade && (
                <button
                  className="secondary-button"
                  type="button"
                  onClick={handleProveTradeStatus}
                  disabled={isProvingTradeStatus || proofCooldownLeft > 0}
                  style={{ marginLeft: 'auto', borderColor: '#10b981', color: proofCooldownLeft > 0 ? 'var(--text-muted)' : '#34d399', fontSize: '13px' }}
                >
                  {isProvingTradeStatus
                    ? t('orders.dispute.provingTlsn')
                    : proofCooldownLeft > 0
                      ? t('orders.dispute.tlsnCooldown', { time: formatDuration(proofCooldownLeft) })
                      : t('orders.dispute.sendTlsn')}
                </button>
              )}
            </>
          ) : dispute ? (
            <>
              <span style={{ color: 'var(--text-muted)', fontSize: '13px' }}>
                {t('orders.dispute.resolvedBanner', {
                  status: t(`orders.dispute.statuses.${dispute.status}`),
                  resolution: t(`orders.dispute.resolutions.${dispute.resolution}`),
                })}
              </span>
              {/* A resolved dispute doesn't block a new one — if something else went wrong,
                  the user can open another dispute on this order. */}
              {canOpenDispute && (
                <button
                  className="secondary-button"
                  type="button"
                  onClick={() => { setDisputeError(null); setShowDisputeModal(true); }}
                  style={{ marginLeft: 'auto', borderColor: '#3f3f46', background: 'transparent', color: '#fbbf24', fontSize: '13px' }}
                >
                  {t('orders.dispute.openAnother')}
                </button>
              )}
            </>
          ) : (
            <button
              className="secondary-button"
              type="button"
              onClick={() => { setDisputeError(null); setShowDisputeModal(true); }}
              style={{ marginLeft: 'auto', borderColor: '#3f3f46', background: 'transparent', color: '#fbbf24', fontSize: '13px', display: 'inline-flex', alignItems: 'center', gap: '8px' }}
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z" />
                <line x1="4" y1="22" x2="4" y2="15" />
              </svg>
              {t('orders.dispute.openButton')}
            </button>
          )}
        </div>
      )}

      {/* ═══ Dispute Modal ═══ */}
      {showDisputeModal && (
        <div className="mobile-confirm-modal-overlay" style={{
          position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.85)', zIndex: 99999,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          backdropFilter: 'blur(4px)'
        }}>
          <div className="mobile-confirm-modal" style={{
            backgroundColor: '#18181b', borderRadius: '12px', width: '100%', maxWidth: '560px',
            boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)', overflow: 'hidden', margin: '20px'
          }}>
            <div style={{ padding: '24px', borderBottom: '1px solid #27272a' }}>
              <h2 style={{ margin: 0, fontSize: '20px', fontWeight: 600, color: 'white' }}>{t('orders.dispute.modalTitle')}</h2>
              <p style={{ margin: '8px 0 0 0', color: '#a1a1aa', fontSize: '14px' }}>
                {t('orders.dispute.modalDescription')}
              </p>
            </div>

            <div style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <label style={{ display: 'flex', flexDirection: 'column', gap: '6px', fontSize: '13px', color: '#a1a1aa' }}>
                {t('orders.dispute.reasonLabel')}
                <select
                  className="admin-select"
                  value={disputeReason}
                  onChange={(e) => setDisputeReason(e.target.value as DisputeReason)}
                >
                  {USER_DISPUTE_REASONS.map((reason) => (
                    <option key={reason} value={reason}>{t(`orders.dispute.reasons.${reason}`)}</option>
                  ))}
                </select>
              </label>

              <label style={{ display: 'flex', flexDirection: 'column', gap: '6px', fontSize: '13px', color: '#a1a1aa' }}>
                {t('orders.dispute.descriptionLabel')}
                <textarea
                  className="admin-textarea"
                  maxLength={2000}
                  rows={5}
                  placeholder={t('orders.dispute.descriptionPlaceholder')}
                  value={disputeDescription}
                  onChange={(e) => setDisputeDescription(e.target.value)}
                />
              </label>

              {disputeError && (
                <div style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)', color: '#fca5a5', padding: '12px', borderRadius: '6px', fontSize: '14px' }}>
                  {disputeError}
                </div>
              )}

              <div style={{ display: 'flex', gap: '8px' }}>
                <button
                  className="secondary-button"
                  type="button"
                  onClick={() => setShowDisputeModal(false)}
                  disabled={isSubmittingDispute}
                  style={{ flex: 1, borderColor: '#3f3f46', background: 'transparent' }}
                >
                  {t('orders.dispute.cancel')}
                </button>
                <button
                  className="primary-button"
                  type="button"
                  onClick={handleOpenDispute}
                  disabled={isSubmittingDispute || !disputeDescription.trim()}
                  style={{ flex: 1, backgroundColor: '#f59e0b', color: '#18181b' }}
                >
                  {isSubmittingDispute ? t('orders.dispute.submitting') : t('orders.dispute.submit')}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ═══ Mobile Confirmation Modal ═══ */}
      {isWaitingMobileConfirm && (
        <div className="mobile-confirm-modal-overlay" style={{
          position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.85)', zIndex: 99999,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          backdropFilter: 'blur(4px)'
        }}>
          <div className="mobile-confirm-modal" style={{
            backgroundColor: '#18181b', borderRadius: '12px', width: '100%', maxWidth: '600px',
            boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)', overflow: 'hidden', margin: '20px'
          }}>
            <div style={{ padding: '24px', borderBottom: '1px solid #27272a', display: 'flex', alignItems: 'center', gap: '16px' }}>
              <div style={{ backgroundColor: '#2563eb', padding: '12px', borderRadius: '8px' }}>
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="5" y="2" width="14" height="20" rx="2" ry="2"></rect>
                  <line x1="12" y1="18" x2="12.01" y2="18"></line>
                </svg>
              </div>
              <div>
                <h2 style={{ margin: 0, fontSize: '22px', fontWeight: 600, color: 'white' }}>Confirm Trade on Steam Mobile App</h2>
                <p style={{ margin: '4px 0 0 0', color: '#a1a1aa', fontSize: '15px' }}>We've started the trade offer, you need to confirm it on your Steam mobile app.</p>
              </div>
            </div>

            <div style={{ padding: '24px' }}>
              <div style={{ backgroundColor: '#dc2626', borderRadius: '8px', padding: '16px', display: 'flex', gap: '14px', marginBottom: '24px' }}>
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0, marginTop: '2px' }}>
                  <circle cx="12" cy="12" r="10"></circle>
                  <line x1="12" y1="8" x2="12" y2="12"></line>
                  <line x1="12" y1="16" x2="12.01" y2="16"></line>
                </svg>
                <div style={{ color: 'white', fontSize: '15px', lineHeight: 1.5 }}>
                  <p style={{ margin: '0 0 12px 0', fontWeight: 600 }}>
                    When confirming the trade offer on your Steam mobile authenticator, please <span style={{ textDecoration: 'underline' }}>make sure that the badges and name of the buyer matches the following on your phone.</span>
                  </p>
                  <p style={{ margin: 0, fontWeight: 600 }}>
                    If the badges or name does not match, your Steam account may have been hijacked and you should cancel the trade offer!
                  </p>
                </div>
              </div>

              <div style={{ backgroundColor: '#27272a', borderRadius: '8px', padding: '16px', display: 'flex', alignItems: 'center', gap: '16px', marginBottom: '24px' }}>
                <img src={partnerAvatar || ''} alt="" style={{ width: '64px', height: '64px', borderRadius: '8px', objectFit: 'cover' }} />
                <div>
                  <div style={{ color: '#a1a1aa', fontSize: '14px', marginBottom: '6px' }}>You offered a trade to</div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <span style={{ color: 'white', fontSize: '20px', fontWeight: 600 }}>{partnerName}</span>
                    <span style={{ display: 'flex', alignItems: 'center', backgroundColor: '#3f3f46', color: '#e4e4e7', fontSize: '12px', padding: '2px 6px', borderRadius: '4px', fontWeight: 600 }}>
                      Level <span style={{ marginLeft: '4px', color: '#60a5fa' }}>?</span>
                    </span>
                  </div>
                </div>
              </div>

              {actionError && (
                <div style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)', color: '#fca5a5', padding: '12px', borderRadius: '6px', fontSize: '14px', textAlign: 'center', marginBottom: '24px' }}>
                  {actionError}
                </div>
              )}

              <button 
                className="primary-button"
                onClick={handleVerifyTrade}
                disabled={isVerifyingTrade}
                style={{ width: '100%', padding: '16px', fontSize: '16px', fontWeight: 600, backgroundColor: '#2563eb', color: 'white', border: 'none', borderRadius: '8px', cursor: 'pointer', opacity: isVerifyingTrade ? 0.7 : 1 }}
              >
                {isVerifyingTrade ? 'Verifying...' : "I've Confirmed the Trade"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ═══ TLSN Proof Progress Modal ═══ */}
      {isProvingTradeStatus && (
        <div className="mobile-confirm-modal-overlay" style={{
          position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.85)', zIndex: 99999,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          backdropFilter: 'blur(4px)'
        }}>
          <div className="mobile-confirm-modal" style={{
            backgroundColor: '#18181b', borderRadius: '12px', width: '100%', maxWidth: '560px',
            boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)', overflow: 'hidden', margin: '20px'
          }}>
            <div style={{ padding: '24px', borderBottom: '1px solid #27272a' }}>
              <h2 style={{ margin: 0, fontSize: '22px', fontWeight: 600, color: 'white' }}>Generating TLSN Proof</h2>
              <p style={{ margin: '8px 0 0 0', color: '#a1a1aa', fontSize: '15px' }}>
                Securely proving Steam trade status to notary and forwarding result to SkinHex webhook.
              </p>
            </div>

            <div style={{ padding: '24px', display: 'flex', alignItems: 'center', gap: '16px' }}>
              <div style={{ width: '28px', height: '28px', border: '3px solid #3f3f46', borderTopColor: '#10b981', borderRadius: '50%', animation: 'spin 1s linear infinite' }} />
              <div style={{ color: '#e4e4e7', fontSize: '14px', lineHeight: 1.5 }}>
                This can take up to 10-20 seconds. Keep this tab open until proof is submitted.
              </div>
            </div>
          </div>
        </div>
      )}
    </article>
  );
}
