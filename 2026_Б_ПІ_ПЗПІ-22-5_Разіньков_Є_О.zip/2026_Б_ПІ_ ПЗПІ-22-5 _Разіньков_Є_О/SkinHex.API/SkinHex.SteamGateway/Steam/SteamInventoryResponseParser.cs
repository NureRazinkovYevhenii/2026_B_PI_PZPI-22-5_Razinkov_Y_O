using System.Globalization;
using System.Text.Json;
using SkinHex.Core.Models;

namespace SkinHex.SteamGateway.Steam;

internal static class SteamInventoryResponseParser
{
    private const string RussianExpiredTradeUrlText = "Эта ссылка для отправки предложения обмена";
    private const string EnglishInvalidTradeUrlText = "Trade partner's trade URL is invalid";
    private const string EnglishTradeUnavailableText = "not available to trade";
    private const string EnglishCannotTradeText = "cannot trade";
    private const string EnglishCantTradeText = "can't trade";
    private const string EnglishFindOutWhyText = "can find out why";
    private const string RussianTradeUnavailableText = "не может обмениваться";

    private static readonly Dictionary<int, string> DopplerPhases = new()
    {
        // Classic Knives Doppler
        { 415, "Phase 1" }, { 416, "Phase 2" }, { 417, "Phase 3" }, { 418, "Phase 4" },
        { 419, "Ruby" }, { 420, "Sapphire" }, { 421, "Black Pearl" },

        // Classic Knives Gamma Doppler
        { 568, "Phase 1" }, { 569, "Phase 2" }, { 570, "Phase 3" }, { 571, "Phase 4" }, { 572, "Emerald" },

        // Second Gen Knives Doppler (Talon, Ursus, Navaja, Stiletto)
        { 852, "Phase 1" }, { 853, "Phase 2" }, { 854, "Phase 3" }, { 855, "Phase 4" },
        { 856, "Ruby" }, { 857, "Sapphire" }, { 858, "Black Pearl" },

        // Second Gen Knives Gamma Doppler
        { 1119, "Phase 1" }, { 1120, "Phase 2" }, { 1121, "Phase 3" }, { 1122, "Phase 4" }, { 1123, "Emerald" }
    };

    public static IReadOnlyList<InventoryItemDto> Parse(string rawJson)
    {
        try
        {
            using var document = JsonDocument.Parse(rawJson);
            var root = document.RootElement;

            if (root.TryGetProperty("success", out var successProperty) &&
                successProperty.ValueKind == JsonValueKind.False)
            {
                string? message = null;
                if (root.TryGetProperty("Error", out var errorProp) && errorProp.ValueKind == JsonValueKind.String)
                    message = errorProp.GetString();
                else if (root.TryGetProperty("error", out var errProp2) && errProp2.ValueKind == JsonValueKind.String)
                    message = errProp2.GetString();
                else if (root.TryGetProperty("message", out var msgProp) && msgProp.ValueKind == JsonValueKind.String)
                    message = msgProp.GetString();

                throw new SteamIntegrationException(message ?? "Steam inventory request was rejected.");
            }
        }
        catch (JsonException)
        {
            throw new SteamIntegrationException("Steam returned malformed inventory payload.");
        }

        SteamInventoryResponse? response;
        try
        {
            var options = new JsonSerializerOptions
            {
                Converters = 
                { 
                    new SteamDictionaryConverter<RgInventoryItem>(),
                    new SteamDictionaryConverter<RgDescription>(),
                    new SteamDictionaryConverter<List<RgAssetProperty>>()
                }
            };
            response = JsonSerializer.Deserialize<SteamInventoryResponse>(rawJson, options);
        }
        catch (JsonException)
        {
            throw new SteamIntegrationException("Steam returned unsupported inventory payload shape.");
        }

        if (response?.Success != true ||
            response.RgInventory is null ||
            response.RgDescriptions is null)
        {
            return Array.Empty<InventoryItemDto>();
        }

        var result = new List<InventoryItemDto>(response.RgInventory.Count);

        foreach (var (assetId, inventoryItem) in response.RgInventory)
        {
            var descriptionKey = $"{inventoryItem.ClassId}_{inventoryItem.InstanceId}";
            if (!response.RgDescriptions.TryGetValue(descriptionKey, out var description) ||
                description.Tradable != 1)
            {
                continue;
            }

            var item = new InventoryItemDto
            {
                AssetId = assetId,
                MarketHashName = description.MarketHashName
            };

            ApplyAssetProperties(response, assetId, item);
            ApplyDopplerPhase(item);
            result.Add(item);
        }

        return result;
    }

    public static bool IsTradeUrlExpired(string rawJson)
    {
        if (rawJson.Contains(RussianExpiredTradeUrlText, StringComparison.OrdinalIgnoreCase) ||
            rawJson.Contains(EnglishInvalidTradeUrlText, StringComparison.OrdinalIgnoreCase))
        {
            return true;
        }

        try
        {
            var response = JsonSerializer.Deserialize<SteamInventoryResponse>(rawJson);
            return response is { Success: false, EResult: 15 };
        }
        catch (JsonException)
        {
            return false;
        }
    }

    public static bool IsTradePartnerUnavailable(string rawJson)
    {
        return rawJson.Contains(EnglishTradeUnavailableText, StringComparison.OrdinalIgnoreCase) ||
               rawJson.Contains(EnglishCannotTradeText, StringComparison.OrdinalIgnoreCase) ||
               rawJson.Contains(EnglishCantTradeText, StringComparison.OrdinalIgnoreCase) ||
               rawJson.Contains(EnglishFindOutWhyText, StringComparison.OrdinalIgnoreCase) ||
               rawJson.Contains(RussianTradeUnavailableText, StringComparison.OrdinalIgnoreCase);
    }

    private static void ApplyAssetProperties(
        SteamInventoryResponse response,
        string assetId,
        InventoryItemDto item)
    {
        if (response.RgAssetProperties is null ||
            !response.RgAssetProperties.TryGetValue(assetId, out var properties))
        {
            return;
        }

        foreach (var property in properties)
        {
            switch (property.PropertyId)
            {
                case 1 when int.TryParse(property.IntValue, out var paintSeed):
                    item.PaintSeed = paintSeed;
                    break;
                case 2 when double.TryParse(
                    property.FloatValue,
                    NumberStyles.Any,
                    CultureInfo.InvariantCulture,
                    out var floatValue):
                    item.FloatValue = floatValue;
                    break;
                case 6:
                    item.MetadataHex = property.StringValue;
                    break;
                case 7 when int.TryParse(property.IntValue, out var paintIndex):
                    item.PaintIndex = paintIndex;
                    break;
            }
        }
    }

    private static void ApplyDopplerPhase(InventoryItemDto item)
    {
        if (item.PaintIndex is not { } paintIndex ||
            !DopplerPhases.TryGetValue(paintIndex, out var phase) ||
            !IsDoppler(item.MarketHashName) ||
            item.MarketHashName.EndsWith($"({phase})", StringComparison.Ordinal))
        {
            return;
        }

        item.MarketHashName = $"{item.MarketHashName} ({phase})";
    }

    private static bool IsDoppler(string marketHashName)
    {
        return marketHashName.Contains("Doppler", StringComparison.OrdinalIgnoreCase);
    }
}
