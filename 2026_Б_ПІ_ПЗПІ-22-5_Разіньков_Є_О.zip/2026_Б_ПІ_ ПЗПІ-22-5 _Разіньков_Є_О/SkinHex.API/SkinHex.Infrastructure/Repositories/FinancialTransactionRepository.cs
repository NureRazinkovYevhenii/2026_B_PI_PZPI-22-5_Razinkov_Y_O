using Microsoft.EntityFrameworkCore;
using SkinHex.Core.Entities;
using SkinHex.Core.Interfaces.Repositories;

namespace SkinHex.Infrastructure.Repositories;

public sealed class FinancialTransactionRepository(SkinHexDbContext context) : IFinancialTransactionRepository
{
    public void Add(FinancialTransaction transaction) => context.FinancialTransactions.Add(transaction);

    public void AddRange(IEnumerable<FinancialTransaction> transactions) => context.FinancialTransactions.AddRange(transactions);

    public Task<List<FinancialTransaction>> GetCompletedByReferenceAsync(Guid referenceId, FinancialTransactionType type, CancellationToken ct = default) =>
        context.FinancialTransactions
            .AsNoTracking()
            .Where(t => t.ReferenceId == referenceId && t.Type == type && t.Status == FinancialTransactionStatus.Completed)
            .ToListAsync(ct);
}
