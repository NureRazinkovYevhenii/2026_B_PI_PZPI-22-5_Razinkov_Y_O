using SkinHex.Core.Entities;
using SkinHex.Core.Models.Notifications;

namespace SkinHex.Core.Interfaces.Services;

public interface INotificationService
{
    /// <summary>
    /// Persists a notification and pushes it to the user over the realtime channel.
    /// The push is best-effort: a delivery failure is logged but never fails the calling business operation.
    /// Call this after the surrounding business transaction has committed.
    /// </summary>
    Task<NotificationDto> NotifyAsync(Guid userId, NotificationType type, object payload, CancellationToken ct = default);

    // --- Typed convenience wrappers over NotifyAsync ---

    Task<NotificationDto> NotifyItemSoldAsync(Order order, Listing listing, User buyer, CancellationToken ct = default);

    /// <summary>
    /// Persisted notification + ephemeral "OrderUpdated" push for the given order participant.
    /// <paramref name="status"/> is passed explicitly (not read from <paramref name="order"/>.Status) so the
    /// event stays deterministic even if the order advanced further before an async dispatch ran.
    /// </summary>
    Task<NotificationDto> NotifyOrderStatusChangedAsync(Guid recipientId, Order order, OrderStatus status, CancellationToken ct = default);

    Task<NotificationDto> NotifyDepositCompletedAsync(Guid userId, Guid depositId, decimal amount, string? payCurrency, CancellationToken ct = default);

    Task<NotificationDto> NotifyWithdrawalStatusAsync(Guid userId, Withdrawal withdrawal, CancellationToken ct = default);

    // --- Ephemeral events (realtime only, not persisted) ---

    /// <summary>Pushes the user's current balance snapshot. <paramref name="reason"/> is a short machine-readable tag (e.g. "purchase_hold", "deposit", "sale_settled").</summary>
    Task PushBalanceUpdateAsync(User user, decimal delta, string reason, CancellationToken ct = default);

    /// <summary>Tells every user holding the listing in their cart that it is no longer available.</summary>
    Task InvalidateCartListingAsync(Guid listingId, Guid? excludeUserId = null, CancellationToken ct = default);

    // --- History / read state (used by the API controller) ---

    Task<NotificationsPageResponse> GetNotificationsAsync(Guid userId, int limit, DateTime? before, CancellationToken ct = default);
    Task<int> GetUnreadCountAsync(Guid userId, CancellationToken ct = default);
    Task<int> MarkReadAsync(Guid userId, IReadOnlyCollection<Guid> ids, CancellationToken ct = default);
    Task<int> MarkAllReadAsync(Guid userId, CancellationToken ct = default);
}
