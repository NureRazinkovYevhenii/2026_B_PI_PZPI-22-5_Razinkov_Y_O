import { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import type { AuthorizedFetch } from '../../types';
import {
  fetchOrder,
  fetchOrders,
  type AdminOrderDetail,
  type AdminOrderListItem,
} from '../../api/adminApi';
import { formatDateTime, formatMoney, IdCell, Pager, shortId, StateBlock, StatusBadge } from './adminShared';

type Props = { authorizedFetch: AuthorizedFetch };

const PAGE_SIZE = 20;
const STATUS_OPTIONS = ['', 'Pending', 'Confirmed', 'TradeSent', 'InEscrow', 'Completed', 'Cancelled'];

export function AdminOrders({ authorizedFetch }: Props) {
  const { t } = useTranslation();
  const [status, setStatus] = useState('');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [items, setItems] = useState<AdminOrderListItem[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await fetchOrders(authorizedFetch, { status, search: search.trim(), page, pageSize: PAGE_SIZE });
      setItems(result.items);
      setTotalCount(result.totalCount);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load orders');
    } finally {
      setLoading(false);
    }
  }, [authorizedFetch, status, search, page]);

  useEffect(() => {
    void load();
  }, [load]);

  const onSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1);
    void load();
  };

  return (
    <div>
      <form className="admin-toolbar" onSubmit={onSearchSubmit}>
        <input
          className="admin-input"
          placeholder={t('admin.orders.searchPlaceholder')}
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <select className="admin-select" value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }}>
          {STATUS_OPTIONS.map((s) => (
            <option key={s} value={s}>{s === '' ? t('admin.orders.allStatuses') : s}</option>
          ))}
        </select>
        <button className="primary-button" type="submit">{t('admin.search')}</button>
      </form>

      {error ? (
        <StateBlock><strong>{t('admin.error')}</strong><p>{error}</p></StateBlock>
      ) : loading ? (
        <StateBlock><strong>{t('admin.loading')}</strong></StateBlock>
      ) : items.length === 0 ? (
        <StateBlock><strong>{t('admin.orders.none')}</strong></StateBlock>
      ) : (
        <div className="admin-table-wrap">
          <table className="admin-table">
            <thead>
              <tr>
                <th>{t('admin.id')}</th>
                <th>{t('admin.orders.item')}</th>
                <th>{t('admin.orders.buyer')}</th>
                <th>{t('admin.orders.seller')}</th>
                <th>{t('admin.orders.status')}</th>
                <th style={{ textAlign: 'right' }}>{t('admin.orders.price')}</th>
                <th>{t('admin.orders.created')}</th>
              </tr>
            </thead>
            <tbody>
              {items.map((o) => (
                <tr key={o.orderId} className="admin-row" onClick={() => setSelectedId(o.orderId)}>
                  <td><IdCell id={o.orderId} /></td>
                  <td style={{ fontWeight: 600, color: 'var(--text-h)' }}>{o.marketHashName}</td>
                  <td>{o.buyer.username}</td>
                  <td>{o.seller.username}</td>
                  <td><StatusBadge status={o.status} /></td>
                  <td style={{ textAlign: 'right', fontWeight: 600 }}>{formatMoney(o.price)}</td>
                  <td style={{ color: 'var(--text-muted)', fontSize: 13 }}>{formatDateTime(o.createdAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Pager page={page} pageSize={PAGE_SIZE} totalCount={totalCount} onPage={setPage} />

      {selectedId && (
        <OrderDetailModal authorizedFetch={authorizedFetch} orderId={selectedId} onClose={() => setSelectedId(null)} />
      )}
    </div>
  );
}

function OrderDetailModal({ authorizedFetch, orderId, onClose }: { authorizedFetch: AuthorizedFetch; orderId: string; onClose: () => void }) {
  const { t } = useTranslation();
  const [detail, setDetail] = useState<AdminOrderDetail | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    fetchOrder(authorizedFetch, orderId)
      .then((d) => active && setDetail(d))
      .catch((e) => active && setError(e instanceof Error ? e.message : 'Failed to load order'));
    return () => {
      active = false;
    };
  }, [authorizedFetch, orderId]);

  return (
    <div className="admin-modal-overlay" onClick={onClose}>
      <div className="admin-modal glass-panel" onClick={(e) => e.stopPropagation()}>
        <div className="admin-modal-head">
          <div>
            <h3>{t('admin.orders.detailTitle')}</h3>
            <IdCell id={orderId} />
          </div>
          <button className="admin-modal-close" onClick={onClose} aria-label="Close">✕</button>
        </div>

        {error ? (
          <StateBlock><strong>{error}</strong></StateBlock>
        ) : !detail ? (
          <StateBlock><strong>{t('admin.loading')}</strong></StateBlock>
        ) : (
          <div className="admin-modal-body">
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
              <span style={{ fontWeight: 700, fontSize: 16, color: 'var(--text-h)' }}>{detail.marketHashName}</span>
              <StatusBadge status={detail.status} />
            </div>

            <div className="admin-kv-grid">
              <div><span>{t('admin.orders.price')}</span><strong>{formatMoney(detail.price)}</strong></div>
              <div><span>{t('admin.orders.wear')}</span><strong>{detail.wear ?? '—'}</strong></div>
              <div><span>Float</span><strong>{detail.float ?? '—'}</strong></div>
              <div><span>{t('admin.orders.buyer')}</span><strong>{detail.buyer.username}</strong></div>
              <div><span>{t('admin.orders.seller')}</span><strong>{detail.seller.username}</strong></div>
              <div><span>{t('admin.orders.created')}</span><strong>{formatDateTime(detail.createdAt)}</strong></div>
              <div><span>{t('admin.orders.confirmedAt')}</span><strong>{formatDateTime(detail.confirmedAt)}</strong></div>
              <div><span>{t('admin.orders.tradeSentAt')}</span><strong>{formatDateTime(detail.tradeSentAt)}</strong></div>
              {detail.cancelledBy && <div><span>{t('admin.orders.cancelledBy')}</span><strong>{detail.cancelledBy}</strong></div>}
            </div>

            {detail.cancelReason && (
              <p className="admin-hint" style={{ marginTop: 8 }}>{t('admin.orders.cancelReason')}: {detail.cancelReason}</p>
            )}

            <h4 style={{ marginTop: 20 }}>{t('admin.orders.trades')}</h4>
            {detail.trades.length === 0 ? (
              <p className="admin-hint">{t('admin.orders.noTrades')}</p>
            ) : (
              <div className="admin-table-wrap">
                <table className="admin-table">
                  <thead>
                    <tr>
                      <th>{t('admin.orders.offerId')}</th>
                      <th>{t('admin.orders.offerState')}</th>
                      <th>{t('admin.orders.tradeStatus')}</th>
                      <th>{t('admin.orders.updated')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {detail.trades.map((tr) => (
                      <tr key={tr.id}>
                        <td>{shortId(tr.tradeOfferId)}</td>
                        <td><StatusBadge status={tr.offerState} /></td>
                        <td>{tr.tradeStatus ?? '—'}</td>
                        <td style={{ color: 'var(--text-muted)', fontSize: 13 }}>{formatDateTime(tr.updatedAt)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
