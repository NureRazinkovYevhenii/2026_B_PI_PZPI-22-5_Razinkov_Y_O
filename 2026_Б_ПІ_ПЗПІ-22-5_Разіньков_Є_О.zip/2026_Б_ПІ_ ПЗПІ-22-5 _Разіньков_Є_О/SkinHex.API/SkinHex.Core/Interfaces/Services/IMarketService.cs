using FluentResults;
using SkinHex.Core.Models;

namespace SkinHex.Core.Interfaces.Services;

public interface IMarketService
{
    // Повертає ID створеного лота (або Result.Fail у разі помилки)
    Task<Result<Guid>> CreateListingAsync(Guid sellerId, CreateListingRequest request, CancellationToken ct);
    Task<Result<CreateListingsResponse>> CreateListingsAsync(Guid sellerId, CreateListingsRequest request, CancellationToken ct);
    Task<Result> UpdateListingAsync(Guid sellerId, Guid listingId, UpdateListingRequest request, CancellationToken ct);
    Task<Result> RemoveListingAsync(Guid sellerId, Guid listingId, CancellationToken ct);
    Task<PagedResult<ListingCatalogItemDto>> GetCatalogAsync(GetListingsRequest request, CancellationToken ct);
    Task<Result<MarketItemPageDto>> GetItemPageAsync(MarketItemPageRequest request, CancellationToken ct);
    Task<Result<IReadOnlyList<MarketSearchTipDto>>> SearchTipsAsync(MarketSearchTipRequest request, CancellationToken ct);
    Task<Result<IReadOnlyList<MarketItemSearchResultDto>>> SearchItemsAsync(MarketSearchTipRequest request, CancellationToken ct);
    Task<PagedResult<SaleHistoryItemDto>> GetSaleHistoryAsync(int itemId, int page, int pageSize, CancellationToken ct);
}
