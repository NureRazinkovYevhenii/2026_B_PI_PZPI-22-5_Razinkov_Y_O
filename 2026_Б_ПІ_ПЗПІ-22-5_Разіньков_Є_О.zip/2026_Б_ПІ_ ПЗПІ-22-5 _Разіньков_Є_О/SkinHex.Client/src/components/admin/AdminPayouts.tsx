import { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import type { AuthorizedFetch } from '../../types';
import {
  approveWithdrawal,
  fetchWithdrawals,
  rejectWithdrawal,
  type AdminWithdrawalListItem,
} from '../../api/adminApi';
import { formatDateTime, formatMoney, IdCell, Pager, shortId, StateBlock, StatusBadge } from './adminShared';

type Props = { authorizedFetch: AuthorizedFetch };

const PAGE_SIZE = 20;
const STATUS_OPTIONS = ['', 'Pending', 'Processing', 'Completed', 'Rejected', 'Failed'];

export function AdminPayouts({ authorizedFetch }: Props) {
  const { t } = useTranslation();
  const [status, setStatus] = useState('');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [items, setItems] = useState<AdminWithdrawalListItem[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<AdminWithdrawalListItem | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await fetchWithdrawals(authorizedFetch, { status, search: search.trim(), page, pageSize: PAGE_SIZE });
      setItems(result.items);
      setTotalCount(result.totalCount);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load withdrawals');
    } finally {
      setLoading(false);
    }
  }, [authorizedFetch, status, search, page]);

  useEffect(() => {
    void load();
  }, [load]);

  const onSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1);
    void load();
  };

  return (
    <div>
      <form className="admin-toolbar" onSubmit={onSearchSubmit}>
        <input
          className="admin-input"
          placeholder={t('admin.payouts.searchPlaceholder')}
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <select className="admin-select" value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }}>
          {STATUS_OPTIONS.map((s) => (
            <option key={s} value={s}>{s === '' ? t('admin.payouts.allStatuses') : s}</option>
          ))}
        </select>
        <button className="primary-button" type="submit">{t('admin.search')}</button>
      </form>

      {error ? (
        <StateBlock><strong>{t('admin.error')}</strong><p>{error}</p></StateBlock>
      ) : loading ? (
        <StateBlock><strong>{t('admin.loading')}</strong></StateBlock>
      ) : items.length === 0 ? (
        <StateBlock><strong>{t('admin.payouts.none')}</strong></StateBlock>
      ) : (
        <div className="admin-table-wrap">
          <table className="admin-table">
            <thead>
              <tr>
                <th>{t('admin.id')}</th>
                <th>{t('admin.payouts.user')}</th>
                <th style={{ textAlign: 'right' }}>{t('admin.payouts.amount')}</th>
                <th>{t('admin.payouts.currency')}</th>
                <th>{t('admin.payouts.address')}</th>
                <th>{t('admin.payouts.status')}</th>
                <th>{t('admin.payouts.created')}</th>
              </tr>
            </thead>
            <tbody>
              {items.map((w) => (
                <tr key={w.id} className="admin-row" onClick={() => setSelected(w)}>
                  <td><IdCell id={w.id} /></td>
                  <td style={{ fontWeight: 600, color: 'var(--text-h)' }}>{w.username}</td>
                  <td style={{ textAlign: 'right', fontWeight: 600 }}>{formatMoney(w.amountUsd)}</td>
                  <td>{w.payCurrency.toUpperCase()}</td>
                  <td style={{ fontFamily: 'monospace', fontSize: 12 }}>{shortId(w.payoutAddress)}</td>
                  <td><StatusBadge status={w.status} /></td>
                  <td style={{ color: 'var(--text-muted)', fontSize: 13 }}>{formatDateTime(w.createdAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Pager page={page} pageSize={PAGE_SIZE} totalCount={totalCount} onPage={setPage} />

      {selected && (
        <PayoutDetailModal
          authorizedFetch={authorizedFetch}
          withdrawal={selected}
          onClose={() => setSelected(null)}
          onChanged={() => { setSelected(null); void load(); }}
        />
      )}
    </div>
  );
}

type ModalProps = {
  authorizedFetch: AuthorizedFetch;
  withdrawal: AdminWithdrawalListItem;
  onClose: () => void;
  onChanged: () => void;
};

function PayoutDetailModal({ authorizedFetch, withdrawal, onClose, onChanged }: ModalProps) {
  const { t } = useTranslation();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [rejecting, setRejecting] = useState(false);
  const [reason, setReason] = useState('');

  const isPending = withdrawal.status === 'Pending';

  const approve = async () => {
    setBusy(true);
    setError(null);
    try {
      await approveWithdrawal(authorizedFetch, withdrawal.id);
      onChanged();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Approve failed');
    } finally {
      setBusy(false);
    }
  };

  const reject = async () => {
    setBusy(true);
    setError(null);
    try {
      await rejectWithdrawal(authorizedFetch, withdrawal.id, reason.trim() || 'Rejected by admin.');
      onChanged();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Reject failed');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="admin-modal-overlay" onClick={onClose}>
      <div className="admin-modal glass-panel" onClick={(e) => e.stopPropagation()}>
        <div className="admin-modal-head">
          <div>
            <h3>{t('admin.payouts.detailTitle')}</h3>
            <IdCell id={withdrawal.id} />
          </div>
          <button className="admin-modal-close" onClick={onClose} aria-label="Close">✕</button>
        </div>

        <div className="admin-modal-body">
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
            <span style={{ fontWeight: 700, fontSize: 18, color: 'var(--text-h)' }}>{formatMoney(withdrawal.amountUsd)}</span>
            <StatusBadge status={withdrawal.status} />
          </div>

          <div className="admin-kv-grid">
            <div><span>{t('admin.payouts.user')}</span><strong>{withdrawal.username}</strong></div>
            <div><span>{t('admin.payouts.currency')}</span><strong>{withdrawal.payCurrency.toUpperCase()}</strong></div>
            <div><span>{t('admin.payouts.platformFee')}</span><strong>{formatMoney(withdrawal.platformFeeUsd)}</strong></div>
            <div><span>{t('admin.payouts.payoutAmount')}</span><strong>{formatMoney(withdrawal.payoutAmountUsd)}</strong></div>
            <div><span>{t('admin.payouts.created')}</span><strong>{formatDateTime(withdrawal.createdAt)}</strong></div>
            {withdrawal.processedAt && <div><span>{t('admin.payouts.processed')}</span><strong>{formatDateTime(withdrawal.processedAt)}</strong></div>}
          </div>

          <div style={{ marginTop: 12 }}>
            <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>{t('admin.payouts.address')}</span>
            <div style={{ fontFamily: 'monospace', fontSize: 13, wordBreak: 'break-all', color: 'var(--text-h)' }}>{withdrawal.payoutAddress}</div>
            {withdrawal.payoutExtraId && (
              <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 4 }}>memo: {withdrawal.payoutExtraId}</div>
            )}
          </div>

          {withdrawal.nowPaymentsPayoutId && (
            <p className="admin-hint" style={{ marginTop: 8 }}>payout id: {withdrawal.nowPaymentsPayoutId}</p>
          )}
          {withdrawal.rejectionReason && (
            <p className="admin-hint" style={{ marginTop: 8 }}>{t('admin.payouts.reason')}: {withdrawal.rejectionReason}</p>
          )}

          {error && <div className="admin-inline-error">{error}</div>}

          {isPending && !rejecting && (
            <div className="admin-action-row">
              <button className="primary-button" disabled={busy} onClick={() => void approve()}>{t('admin.payouts.approve')}</button>
              <button className="admin-btn-danger" disabled={busy} onClick={() => setRejecting(true)}>{t('admin.payouts.reject')}</button>
            </div>
          )}

          {isPending && rejecting && (
            <div style={{ marginTop: 16 }}>
              <textarea
                className="admin-textarea"
                rows={2}
                placeholder={t('admin.payouts.reasonPlaceholder')}
                value={reason}
                onChange={(e) => setReason(e.target.value)}
              />
              <div className="admin-action-row" style={{ marginTop: 8 }}>
                <button className="admin-btn-danger" disabled={busy} onClick={() => void reject()}>{t('admin.payouts.confirmReject')}</button>
                <button className="admin-btn-ghost" disabled={busy} onClick={() => setRejecting(false)}>{t('admin.payouts.cancel')}</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
