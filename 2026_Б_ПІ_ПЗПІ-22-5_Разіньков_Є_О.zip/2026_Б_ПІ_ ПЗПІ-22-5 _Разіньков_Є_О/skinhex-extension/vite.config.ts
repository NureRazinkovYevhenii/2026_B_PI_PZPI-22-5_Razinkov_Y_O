import { defineConfig } from "vite";

/**
 * Patches tlsn-wasm's spawn.js (bundled inside worker.js) so that
 * `startSpawnerWorker` creates workers from our `spawner.js` instead of
 * the original relative `./spawn.js` (which doesn't exist in the extension).
 *
 * `self.__SPAWNER_URL__` is injected by worker.ts at runtime.
 */
const patchTlsnSpawnPlugin = {
    name: 'patch-tlsn-spawn',
    transform(code: string, id: string) {
        if (!id.includes('tlsn-wasm') || !id.includes('spawn.js')) return null;

        // Replace `new URL('./spawn.js', import.meta.url)` → use runtime URL
        return code.replace(
            /new URL\(['"]\.\/spawn\.js['"],\s*import\.meta\.url\)/g,
            `new URL(self.__SPAWNER_URL__ || 'spawner.js', self.location.href)`
        );
    }
};

export default defineConfig({
    plugins: [patchTlsnSpawnPlugin],
    worker: {
        format: 'es',
    },
    build: {
        outDir: 'dist',
        rollupOptions: {
            input: {
                background: 'src/background.ts',
                offscreen: 'offscreen.html',
                worker: 'src/offscreen/worker.ts',
                spawner: 'src/offscreen/spawner.ts',
            },
            output: {
                entryFileNames: '[name].js',
                chunkFileNames: 'assets/[name]-[hash].js',
            },
        },
    },
});