using Microsoft.Extensions.Caching.Memory;
using SkinHex.Core.Interfaces.Services;

namespace SkinHex.Infrastructure.Services;

public sealed class MemoryEmailVerificationCodeStore(IMemoryCache cache)
    : IEmailVerificationCodeStore
{
    public Task StoreAsync(
        Guid userId,
        EmailVerificationCode verificationCode,
        TimeSpan timeToLive,
        CancellationToken cancellationToken = default)
    {
        cache.Set(GetKey(userId), verificationCode, timeToLive);
        return Task.CompletedTask;
    }

    public Task<EmailVerificationCode?> GetAsync(
        Guid userId,
        CancellationToken cancellationToken = default)
    {
        cache.TryGetValue(GetKey(userId), out EmailVerificationCode? verificationCode);
        return Task.FromResult(verificationCode);
    }

    public Task RemoveAsync(Guid userId, CancellationToken cancellationToken = default)
    {
        cache.Remove(GetKey(userId));
        return Task.CompletedTask;
    }

    private static string GetKey(Guid userId) => $"email-verification:{userId:N}";
}
