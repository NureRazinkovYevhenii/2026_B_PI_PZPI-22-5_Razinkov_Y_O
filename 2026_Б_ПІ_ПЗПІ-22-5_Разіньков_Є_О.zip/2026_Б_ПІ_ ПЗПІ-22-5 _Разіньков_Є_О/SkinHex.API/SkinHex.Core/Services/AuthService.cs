using FluentResults;
using System.Security.Cryptography;
using SkinHex.Core.Entities;
using SkinHex.Core.Interfaces;
using SkinHex.Core.Interfaces.Repositories;
using SkinHex.Core.Interfaces.Services;
using SkinHex.Core.Models.Auth;

namespace SkinHex.Core.Services;

public sealed class AuthService(
    IUserRepository _userRepository,
    IRefreshTokenRepository _refreshTokenRepository,
    ITokenService _tokenService,
    IEmailVerificationCodeStore _verificationCodeStore,
    IEmailService _emailService,
    IUnitOfWork _unitOfWork) : IAuthService
{
    public async Task<Result<AuthResult>> AuthenticateWithSteamAsync(SteamUserInfo steamUserInfo, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(steamUserInfo.SteamId))
        {
            return Result.Fail<AuthResult>("SteamId is required.");
        }

        var username = string.IsNullOrWhiteSpace(steamUserInfo.Username)
            ? steamUserInfo.SteamId
            : steamUserInfo.Username;

        var user = await _userRepository.GetBySteamIdAsync(steamUserInfo.SteamId, ct);
        if (user is null)
        {
            user = new User
            {
                Id = Guid.NewGuid(),
                SteamId = steamUserInfo.SteamId,
                Username = username,
                AvatarUrl = steamUserInfo.AvatarUrl,
                Role = UserRole.Unverified,
                CreatedAt = DateTime.UtcNow
            };

            await _userRepository.AddAsync(user, ct);
        }
        else
        {
            user.Username = username;
            user.AvatarUrl = steamUserInfo.AvatarUrl;
            user.UpdatedAt = DateTime.UtcNow;
        }

        var tokens = _tokenService.GenerateTokens(user);
        if (tokens.IsFailed)
        {
            return Result.Fail<AuthResult>(tokens.Errors);
        }

        await _refreshTokenRepository.AddAsync(new RefreshToken
        {
            Id = Guid.NewGuid(),
            Token = tokens.Value.RefreshToken,
            UserId = user.Id,
            ExpiresAt = DateTime.UtcNow.AddDays(30),
            CreatedAt = DateTime.UtcNow
        }, ct);

        await _unitOfWork.SaveChangesAsync(ct);

        return Result.Ok(new AuthResult(user, tokens.Value));
    }

    public async Task<Result<TokenResult>> RefreshTokensAsync(string refreshToken, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(refreshToken))
        {
            return Result.Fail<TokenResult>("Refresh token is required.");
        }

        var storedRefreshToken = await _refreshTokenRepository.GetByTokenWithUserAsync(
            refreshToken,
            ct);

        if (storedRefreshToken is null || !storedRefreshToken.IsActive)
        {
            return Result.Fail<TokenResult>("Refresh token is invalid or expired.");
        }

        var accessToken = _tokenService.GenerateAccessToken(storedRefreshToken.User);
        if (accessToken.IsFailed)
        {
            return Result.Fail<TokenResult>(accessToken.Errors);
        }

        return Result.Ok(new TokenResult
        {
            AccessToken = accessToken.Value,
            RefreshToken = storedRefreshToken.Token
        });
    }

    public async Task<Result> SendVerificationCodeAsync(Guid userId, string email, CancellationToken ct)
    {
        if (userId == Guid.Empty)
        {
            return Result.Fail("UserId is required.");
        }

        if (string.IsNullOrWhiteSpace(email))
        {
            return Result.Fail("Email is required.");
        }

        var existingCode = await _verificationCodeStore.GetAsync(userId, ct);
        if (existingCode is not null)
        {
            var timeSinceLastRequest = DateTimeOffset.UtcNow - existingCode.CreatedAt;
            if (timeSinceLastRequest < TimeSpan.FromMinutes(1))
            {
                var waitSeconds = (int)(60 - timeSinceLastRequest.TotalSeconds);
                return Result.Fail($"Please wait {waitSeconds} seconds before requesting again.");
            }
        }

        var code = RandomNumberGenerator.GetInt32(100000, 1_000_000);
        await _verificationCodeStore.StoreAsync(
            userId,
            new EmailVerificationCode(email, code, DateTimeOffset.UtcNow),
            TimeSpan.FromMinutes(10),
            ct);

        var sendResult = await _emailService.SendOtpAsync(email, code, ct);
        if (sendResult.IsFailed)
        {
            return sendResult;
        }

        return Result.Ok();
    }

    public async Task<Result<TokenResult>> VerifyEmailAsync(Guid userId, string email, int code, CancellationToken ct)
    {
        var cachedData = await _verificationCodeStore.GetAsync(userId, ct);
        if (cachedData is null)
        {
            return Result.Fail("The verification code has expired or was not requested.");
        }

        if (!string.Equals(cachedData.Email, email, StringComparison.OrdinalIgnoreCase))
        {
            return Result.Fail("The email does not match the one to which the code was requested.");
        }

        if (cachedData.Code != code)
        {
            return Result.Fail("Invalid confirmation code.");
        }

        await _verificationCodeStore.RemoveAsync(userId, ct);

        var user = await _userRepository.GetByIdAsync(userId, ct);
        if (user is null)
        {
            return Result.Fail("User was not found.");
        }

        user.Email = email;
        user.Role = UserRole.User;

        var oldTokens = await _refreshTokenRepository.GetByUserIdAsync(userId, ct);
        foreach (var token in oldTokens)
        {
            token.IsRevoked = true;
        }

        var newTokens = _tokenService.GenerateTokens(user);
        if (newTokens.IsFailed)
        {
            return Result.Fail<TokenResult>(newTokens.Errors);
        }

        await _refreshTokenRepository.AddAsync(new RefreshToken
        {
            Id = Guid.NewGuid(),
            Token = newTokens.Value.RefreshToken,
            UserId = user.Id,
            ExpiresAt = DateTime.UtcNow.AddDays(30),
            CreatedAt = DateTime.UtcNow
        }, ct);

        await _unitOfWork.SaveChangesAsync(ct);

        return newTokens;
    }
}
