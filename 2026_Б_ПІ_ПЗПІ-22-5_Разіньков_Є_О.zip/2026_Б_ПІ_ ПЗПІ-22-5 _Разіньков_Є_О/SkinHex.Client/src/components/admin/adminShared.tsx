import { useState, type ReactNode } from 'react';
import { Check, Copy } from 'lucide-react';

export function formatMoney(value: number): string {
  return `$${value.toFixed(2)}`;
}

export function formatDateTime(value: string | null | undefined): string {
  if (!value) return '—';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return date.toLocaleString();
}

export function shortId(id: string | null | undefined): string {
  if (!id) return '—';
  return id.length > 8 ? `${id.slice(0, 8)}…` : id;
}

/** Compact, clickable ID display: shows a truncated id, copies the full id on click. */
export function IdCell({ id }: { id: string }) {
  const [copied, setCopied] = useState(false);

  const onCopy = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard
      .writeText(id)
      .then(() => {
        setCopied(true);
        window.setTimeout(() => setCopied(false), 1200);
      })
      .catch(() => { /* clipboard may be unavailable (insecure context, permissions) */ });
  };

  return (
    <button type="button" className="admin-id-cell" title={id} onClick={onCopy}>
      {shortId(id)}
      {copied ? <Check size={12} /> : <Copy size={12} />}
    </button>
  );
}

type Tone = 'green' | 'amber' | 'red' | 'gray';

const toneColors: Record<Tone, { bg: string; fg: string }> = {
  green: { bg: 'rgba(16, 185, 129, 0.12)', fg: '#34d399' },
  amber: { bg: 'rgba(245, 158, 11, 0.12)', fg: '#fbbf24' },
  red: { bg: 'rgba(239, 68, 68, 0.12)', fg: '#f87171' },
  gray: { bg: 'var(--surface-hover)', fg: 'var(--text-muted)' },
};

function toneFor(status: string): Tone {
  const s = status.toLowerCase();
  if (['completed', 'resolved', 'finished', 'active', 'user', 'accepted', 'complete'].includes(s)) return 'green';
  if (['pending', 'pendingsupport', 'pendinguser', 'open', 'confirming', 'confirmed', 'inescrow', 'tradesent', 'waiting'].includes(s))
    return 'amber';
  if (['cancelled', 'canceled', 'failed', 'banned', 'closed', 'expired', 'invalid', 'declined'].includes(s)) return 'red';
  return 'gray';
}

export function StatusBadge({ status }: { status: string }) {
  const { bg, fg } = toneColors[toneFor(status)];
  return (
    <span
      style={{
        display: 'inline-block',
        padding: '2px 10px',
        borderRadius: '999px',
        fontSize: '12px',
        fontWeight: 700,
        background: bg,
        color: fg,
        whiteSpace: 'nowrap',
      }}
    >
      {status}
    </span>
  );
}

export function StateBlock({ children }: { children: ReactNode }) {
  return (
    <div className="inventory-state" role="status">
      {children}
    </div>
  );
}

type PagerProps = {
  page: number;
  pageSize: number;
  totalCount: number;
  onPage: (page: number) => void;
};

export function Pager({ page, pageSize, totalCount, onPage }: PagerProps) {
  const totalPages = Math.max(1, Math.ceil(totalCount / pageSize));
  if (totalPages <= 1) return null;

  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: '12px', marginTop: '16px' }}>
      <button
        className="admin-page-btn"
        type="button"
        disabled={page <= 1}
        onClick={() => onPage(page - 1)}
      >
        ‹ Prev
      </button>
      <span style={{ fontSize: '13px', color: 'var(--text-muted)' }}>
        {page} / {totalPages}
      </span>
      <button
        className="admin-page-btn"
        type="button"
        disabled={page >= totalPages}
        onClick={() => onPage(page + 1)}
      >
        Next ›
      </button>
    </div>
  );
}
