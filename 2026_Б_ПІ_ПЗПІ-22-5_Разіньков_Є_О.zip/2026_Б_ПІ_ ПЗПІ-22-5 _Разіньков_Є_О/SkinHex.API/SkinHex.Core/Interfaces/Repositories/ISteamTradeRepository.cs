using SkinHex.Core.Entities;

namespace SkinHex.Core.Interfaces.Repositories;

public interface ISteamTradeRepository
{
    Task AddAsync(SteamTrade steamTrade, CancellationToken ct = default);
}
