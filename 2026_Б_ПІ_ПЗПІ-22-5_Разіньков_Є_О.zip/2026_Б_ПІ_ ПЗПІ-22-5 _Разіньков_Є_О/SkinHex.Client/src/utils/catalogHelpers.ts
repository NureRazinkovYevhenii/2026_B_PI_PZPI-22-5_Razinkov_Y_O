import type { CatalogFilters } from '../types';

/**
 * Hardcoded category → weapon[] mapping.
 * Extracted from items_dict.json. Categories without weapons have an empty array.
 */
export const WEAPON_CATEGORIES: Record<string, string[]> = {
  'Rifles': ['AK-47', 'AUG', 'AWP', 'FAMAS', 'G3SG1', 'Galil AR', 'M4A1-S', 'M4A4', 'SCAR-20', 'SG 553', 'SSG 08'],
  'Pistols': ['CZ75-Auto', 'Desert Eagle', 'Dual Berettas', 'Five-SeveN', 'Glock-18', 'P2000', 'P250', 'R8 Revolver', 'Tec-9', 'USP-S'],
  'SMGs': ['MAC-10', 'MP5-SD', 'MP7', 'MP9', 'P90', 'PP-Bizon', 'UMP-45'],
  'Heavy': ['M249', 'MAG-7', 'Negev', 'Nova', 'Sawed-Off', 'XM1014'],
  'Knives': ['Bayonet', 'Bowie Knife', 'Butterfly Knife', 'Classic Knife', 'Falchion Knife', 'Flip Knife', 'Gut Knife', 'Huntsman Knife', 'Karambit', 'Kukri Knife', 'M9 Bayonet', 'Navaja Knife', 'Nomad Knife', 'Paracord Knife', 'Shadow Daggers', 'Skeleton Knife', 'Stiletto Knife', 'Survival Knife', 'Talon Knife', 'Ursus Knife'],
  'Gloves': ['Bloodhound Gloves', 'Broken Fang Gloves', 'Driver Gloves', 'Hand Wraps', 'Hydra Gloves', 'Moto Gloves', 'Specialist Gloves', 'Sport Gloves'],
  'Equipment': ['Zeus x27'],
  'Case': [],
  'Sticker Capsule': [],
  'Patch Capsule': [],
  'Music Kit Box': [],
  'Graffiti': [],
  'Pin': [],
  'Pins': [],
  'Other': [],
  'Autograph Capsule': [],
  'Autograph': [],
  'Event': [],
  'Fantasy Trophy': [],
  'Map Contributor Coin': [],
  'Old Pick\'Em Trophy': [],
  'Operation Coin': [],
  'Operation Pass': [],
  'Pick\'Em Coin': [],
  'Premier Season Coin': [],
  'Service Medal': [],
  'Souvenir Highlight': [],
  'Souvenir Token': [],
  'Souvenir': [],
  'Stars for Operation': [],
  'Team': [],
  'Tournament Finalist Trophy': [],
  'Tournament Pass': [],
};

export const ALL_CATEGORIES = Object.keys(WEAPON_CATEGORIES);

export function getWeaponsForCategory(category: string): string[] {
  return WEAPON_CATEGORIES[category] ?? [];
}

/**
 * Converts CatalogFilters into URLSearchParams suitable for the API.
 */
export function buildCatalogParams(filters: CatalogFilters, page: number): URLSearchParams {
  const params = new URLSearchParams();
  params.set('page', String(page));
  params.set('pageSize', '24');
  params.set('sortBy', String(filters.sortBy));

  if (filters.searchTerm.trim()) {
    params.set('searchTerm', filters.searchTerm.trim());
  }
  if (filters.category) {
    params.set('category', filters.category);
  }
  if (filters.weapon) {
    params.set('weapon', filters.weapon);
  }
  if (filters.minPrice && Number(filters.minPrice) > 0) {
    params.set('minPrice', filters.minPrice);
  }
  if (filters.maxPrice && Number(filters.maxPrice) > 0) {
    params.set('maxPrice', filters.maxPrice);
  }
  if (filters.minFloat && Number(filters.minFloat) > 0) {
    params.set('minFloat', filters.minFloat);
  }
  if (filters.maxFloat && Number(filters.maxFloat) > 0 && Number(filters.maxFloat) < 1) {
    params.set('maxFloat', filters.maxFloat);
  }
  if (filters.paintSeed && Number(filters.paintSeed) > 0) {
    params.set('paintSeed', filters.paintSeed);
  }
  if (filters.wear) {
    params.set('wear', filters.wear);
  }

  return params;
}

/**
 * Formats an ISO date string into a human-readable "time ago" string.
 */
export function formatTimeAgo(isoDate: string): string {
  const now = Date.now();
  const then = new Date(isoDate).getTime();
  const diffMs = now - then;

  if (diffMs < 0) return 'just now';

  const seconds = Math.floor(diffMs / 1000);
  if (seconds < 60) return `${seconds}s`;

  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m`;

  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h`;

  const days = Math.floor(hours / 24);
  if (days < 30) return `${days}d`;

  const months = Math.floor(days / 30);
  return `${months}mo`;
}

export const DEFAULT_FILTERS: CatalogFilters = {
  searchTerm: '',
  category: null,
  weapon: null,
  minPrice: '',
  maxPrice: '',
  minFloat: '',
  maxFloat: '',
  paintSeed: '',
  wear: null,
  sortBy: 0,
};

/** Wear preset ranges for the float slider */
export const WEAR_PRESETS: { label: string; short: string; min: number; max: number; color: string }[] = [
  { label: 'Factory New', short: 'FN', min: 0, max: 0.07, color: '#15803d' },
  { label: 'Minimal Wear', short: 'MW', min: 0.07, max: 0.15, color: '#84cc16' },
  { label: 'Field-Tested', short: 'FT', min: 0.15, max: 0.38, color: '#ca8a04' },
  { label: 'Well-Worn', short: 'WW', min: 0.38, max: 0.45, color: '#ea580c' },
  { label: 'Battle-Scarred', short: 'BS', min: 0.45, max: 1.0, color: '#b91c1c' },
];
