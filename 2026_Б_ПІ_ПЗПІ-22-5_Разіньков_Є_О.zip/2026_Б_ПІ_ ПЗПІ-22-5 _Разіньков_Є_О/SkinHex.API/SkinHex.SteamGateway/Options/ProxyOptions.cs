namespace SkinHex.SteamGateway.Options;

public sealed class ProxyOptions
{
    public const string SectionName = "Proxy";

    public IReadOnlyList<string> Endpoints { get; init; } = Array.Empty<string>();
    public int QuarantineMinutes { get; init; } = 10;
}
