import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { X, Loader2, ArrowRightLeft, ShieldCheck } from 'lucide-react';
import {
  createDeposit,
  getEstimate,
  getMinAmount,
  getSupportedCurrencies,
  type DepositCurrency,
  type MinAmountResponse,
} from '../api/depositApi';

type DepositModalProps = {
  isOpen: boolean;
  onClose: () => void;
};

const DEFAULT_CODE = 'usdtbsc';
const FALLBACK_MIN_USD = 3;
const DEFAULT_FEE = 0.01;

/** Trims a crypto amount to a sensible number of significant digits for display. */
function formatCrypto(value: number): string {
  if (!Number.isFinite(value) || value <= 0) return '';
  if (value >= 1) return value.toFixed(6).replace(/\.?0+$/, '');
  return value.toFixed(8).replace(/\.?0+$/, '');
}

const CoinIcon: React.FC<{ currency: DepositCurrency }> = ({ currency }) => {
  const [failed, setFailed] = useState(false);

  if (failed) {
    // Fallback to a colored letter chip if the icon asset is missing.
    return (
      <span className="dep-coin-icon" style={{ background: currency.color }}>
        {currency.ticker.slice(0, 3)}
      </span>
    );
  }

  return (
    <img
      className="dep-coin-img"
      src={`/coins/${currency.code}.svg`}
      alt={`${currency.ticker}${currency.network ? ` ${currency.network}` : ''}`}
      onError={() => setFailed(true)}
    />
  );
};

export const DepositModal: React.FC<DepositModalProps> = ({ isOpen, onClose }) => {
  const [currencies, setCurrencies] = useState<DepositCurrency[]>([]);
  const [platformMinUsd, setPlatformMinUsd] = useState<number>(FALLBACK_MIN_USD);
  const [feePercent, setFeePercent] = useState<number>(DEFAULT_FEE);
  const [selectedCode, setSelectedCode] = useState<string>(DEFAULT_CODE);

  // amountUsd = NET amount credited to balance. amountCrypto = GROSS the user actually sends (net × (1+fee)).
  const [amountUsd, setAmountUsd] = useState<string>('10');
  const [amountCrypto, setAmountCrypto] = useState<string>('');
  const [rate, setRate] = useState<number>(0); // crypto per 1 USD

  const [minInfo, setMinInfo] = useState<MinAmountResponse | null>(null);
  const [loadingRate, setLoadingRate] = useState(false);
  const [loadingCurrencies, setLoadingCurrencies] = useState(false);

  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const selected = useMemo(
    () => currencies.find((c) => c.code === selectedCode) ?? null,
    [currencies, selectedCode],
  );

  // ── Load the curated currency list once when the modal opens ──
  useEffect(() => {
    if (!isOpen || currencies.length > 0) return;

    let cancelled = false;
    setLoadingCurrencies(true);
    getSupportedCurrencies()
      .then((data) => {
        if (cancelled) return;
        setCurrencies(data.currencies);
        setPlatformMinUsd(data.platformMinUsd);
        setFeePercent(data.depositFeePercent ?? DEFAULT_FEE);
        if (!data.currencies.some((c) => c.code === DEFAULT_CODE) && data.currencies[0]) {
          setSelectedCode(data.currencies[0].code);
        }
      })
      .catch((err) => !cancelled && setError(err.message || 'Failed to load currencies'))
      .finally(() => !cancelled && setLoadingCurrencies(false));

    return () => {
      cancelled = true;
    };
  }, [isOpen, currencies.length]);

  // ── When currency changes: fetch its minimum and a conversion rate ──
  useEffect(() => {
    if (!isOpen || !selected) return;

    const controller = new AbortController();
    setError('');
    setMinInfo(null);
    setRate(0);
    setLoadingRate(true);

    // Rate is derived from a $100 estimate (accurate and independent of the typed amount).
    Promise.all([
      getMinAmount(selected.code, controller.signal),
      getEstimate(100, selected.code, controller.signal),
    ])
      .then(([min, est]) => {
        if (controller.signal.aborted) return;
        setMinInfo(min);
        const derivedRate = est.estimatedCrypto > 0 ? est.estimatedCrypto / est.amountUsd : 0;
        setRate(derivedRate);
        const usd = parseFloat(amountUsd);
        if (derivedRate > 0 && Number.isFinite(usd) && usd > 0) {
          setAmountCrypto(formatCrypto(usd * (1 + feePercent) * derivedRate));
        }
      })
      .catch((err) => {
        if (controller.signal.aborted) return;
        setError(err.message || 'Failed to load currency info');
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoadingRate(false);
      });

    return () => controller.abort();
    // amountUsd intentionally excluded: we only refetch on currency change.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen, selected]);

  const handleUsdChange = useCallback(
    (value: string) => {
      setAmountUsd(value);
      const usd = parseFloat(value);
      if (rate > 0 && Number.isFinite(usd) && usd > 0) {
        setAmountCrypto(formatCrypto(usd * (1 + feePercent) * rate));
      } else if (!value) {
        setAmountCrypto('');
      }
    },
    [rate, feePercent],
  );

  const handleCryptoChange = useCallback(
    (value: string) => {
      setAmountCrypto(value);
      const crypto = parseFloat(value);
      if (rate > 0 && Number.isFinite(crypto) && crypto > 0) {
        setAmountUsd((crypto / rate / (1 + feePercent)).toFixed(2));
      } else if (!value) {
        setAmountUsd('');
      }
    },
    [rate, feePercent],
  );

  const effectiveMinUsd = minInfo?.minUsd ?? platformMinUsd;
  const amountUsdNum = parseFloat(amountUsd);
  const belowMin = Number.isFinite(amountUsdNum) && amountUsdNum < effectiveMinUsd;
  const canSubmit =
    !!selected && !submitting && !loadingRate && rate > 0 && Number.isFinite(amountUsdNum) && amountUsdNum > 0 && !belowMin;

  const modalRef = useRef<HTMLDivElement>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selected) return;

    setError('');

    const usd = parseFloat(amountUsd);
    if (!Number.isFinite(usd) || usd <= 0) {
      setError('Please enter a valid amount');
      return;
    }
    if (usd < effectiveMinUsd) {
      setError(`Minimum deposit for ${selected.ticker} (${selected.network ?? 'native'}) is $${effectiveMinUsd.toFixed(2)}`);
      return;
    }

    setSubmitting(true);
    try {
      const response = await createDeposit({ amountUsd: usd, payCurrency: selected.code });
      localStorage.setItem('last_deposit_id', response.depositId);
      window.location.href = response.invoiceUrl;
    } catch (err: any) {
      setError(err.message || 'Something went wrong');
      setSubmitting(false);
    }
  };

  const popular = currencies.filter((c) => c.group === 'popular');
  const stablecoins = currencies.filter((c) => c.group === 'stablecoin');

  const renderCoin = (currency: DepositCurrency) => (
    <button
      key={currency.code}
      type="button"
      className={`dep-coin ${selectedCode === currency.code ? 'selected' : ''}`}
      onClick={() => setSelectedCode(currency.code)}
    >
      <CoinIcon currency={currency} />
      <span className="dep-coin-text">
        <span className="dep-coin-ticker">
          {currency.ticker}
          {currency.network && <span className="dep-coin-network">{currency.network}</span>}
        </span>
        <span className="dep-coin-name">{currency.name}</span>
      </span>
    </button>
  );

  return (
    <div className="dep-overlay" onClick={onClose}>
      <div className="dep-modal glass-panel" ref={modalRef} onClick={(e) => e.stopPropagation()}>
        <button className="dep-close" onClick={onClose} aria-label="Close">
          <X size={20} />
        </button>

        <header className="dep-header">
          <h2 className="dep-title">Deposit Funds</h2>
          <p className="dep-subtitle">Choose a coin and top up your balance instantly.</p>
        </header>

        {loadingCurrencies ? (
          <div className="dep-loading">
            <Loader2 size={24} className="spin-animation" />
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="dep-form">
            {/* ── Currency picker ── */}
            <div className="dep-section">
              <div className="dep-section-head">
                <span className="dep-dot dep-dot-blue" />
                <span className="dep-section-label">Popular Coins</span>
              </div>
              <div className="dep-coin-grid">{popular.map(renderCoin)}</div>
            </div>

            <div className="dep-section">
              <div className="dep-section-head">
                <span className="dep-dot dep-dot-green" />
                <span className="dep-section-label">Stablecoins</span>
              </div>
              <div className="dep-coin-grid">{stablecoins.map(renderCoin)}</div>
            </div>

            {/* ── Amount (USD ⇆ crypto) ── */}
            <div className="dep-amounts">
              <div className="dep-field">
                <label className="dep-field-label">Deposit amount (USD)</label>
                <div className="dep-input-wrap">
                  <span className="dep-input-prefix">$</span>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    inputMode="decimal"
                    value={amountUsd}
                    onChange={(e) => handleUsdChange(e.target.value)}
                    className="dep-input"
                    placeholder="0.00"
                  />
                </div>
              </div>

              <div className="dep-swap">
                <ArrowRightLeft size={16} />
              </div>

              <div className="dep-field">
                <label className="dep-field-label">You send {selected ? `(${selected.ticker})` : ''}</label>
                <div className="dep-input-wrap">
                  {selected && <CoinIcon currency={selected} />}
                  <input
                    type="number"
                    min="0"
                    step="any"
                    inputMode="decimal"
                    value={amountCrypto}
                    onChange={(e) => handleCryptoChange(e.target.value)}
                    className="dep-input dep-input-crypto"
                    placeholder="0.00"
                    disabled={loadingRate || rate <= 0}
                  />
                  {loadingRate && <Loader2 size={16} className="spin-animation dep-input-spinner" />}
                </div>
              </div>
            </div>

            {/* ── Fee breakdown ── */}
            {feePercent > 0 && Number.isFinite(amountUsdNum) && amountUsdNum > 0 ? (
              <div className="dep-fee">
                <div className="dep-fee-row">
                  <span>You pay</span>
                  <span>${(amountUsdNum * (1 + feePercent)).toFixed(2)}</span>
                </div>
                <div className="dep-fee-row dep-fee-muted">
                  <span>Fee ({(feePercent * 100).toFixed(feePercent * 100 % 1 === 0 ? 0 : 2)}%)</span>
                  <span>${(amountUsdNum * feePercent).toFixed(2)}</span>
                </div>
                <div className="dep-fee-row dep-fee-total">
                  <span>Credited to balance</span>
                  <span>${amountUsdNum.toFixed(2)}</span>
                </div>
              </div>
            ) : null}

            {/* ── Min hint ── */}
            <div className={`dep-min ${belowMin ? 'dep-min-warn' : ''}`}>
              {loadingRate ? (
                <span>Fetching minimum…</span>
              ) : minInfo ? (
                <span>
                  Minimum: <strong>${effectiveMinUsd.toFixed(2)}</strong>
                  {rate > 0 && selected
                    ? ` (≈ ${formatCrypto(effectiveMinUsd * rate)} ${selected.ticker})`
                    : ''}
                </span>
              ) : (
                <span>Minimum deposit: ${platformMinUsd.toFixed(2)}</span>
              )}
            </div>

            {error && <div className="dep-error">{error}</div>}

            <button type="submit" className="dep-submit" disabled={!canSubmit}>
              {submitting ? (
                <>
                  <Loader2 size={18} className="spin-animation" /> Processing…
                </>
              ) : (
                'Proceed to Payment'
              )}
            </button>

            <p className="dep-secure">
              <ShieldCheck size={14} /> Secured by NOWPayments
            </p>
          </form>
        )}
      </div>
    </div>
  );
};
