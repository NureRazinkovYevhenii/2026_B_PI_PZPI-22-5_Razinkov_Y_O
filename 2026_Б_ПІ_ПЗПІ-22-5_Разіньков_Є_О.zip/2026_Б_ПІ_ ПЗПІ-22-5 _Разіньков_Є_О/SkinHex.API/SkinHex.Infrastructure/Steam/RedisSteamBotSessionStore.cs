using System.Text.Json;
using Microsoft.Extensions.Options;
using SkinHex.Core.Interfaces.Steam;
using SkinHex.Core.Models.Steam;
using SkinHex.Infrastructure.Options;
using StackExchange.Redis;

namespace SkinHex.Infrastructure.Steam;

public sealed class RedisSteamBotSessionStore : ISteamBotSessionStore
{
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

    private readonly IDatabase _database;
    private readonly RedisOptions _options;
    private readonly RedisKey _sessionIndexKey;

    public RedisSteamBotSessionStore(
        IConnectionMultiplexer connectionMultiplexer,
        IOptions<RedisOptions> options)
    {
        _database = connectionMultiplexer.GetDatabase();
        _options = options.Value;
        _sessionIndexKey = $"{_options.SteamSessionsKey}:bots";
    }

    public async Task StoreAsync(
        SteamBotSession session,
        CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(session.Username);

        var value = JsonSerializer.Serialize(session, JsonOptions);
        var ttl = TimeSpan.FromMinutes(_options.SessionTtlMinutes);

        await _database.StringSetAsync(GetSessionKey(session.Username), value, ttl)
            .WaitAsync(cancellationToken);
        await _database.SetAddAsync(_sessionIndexKey, session.Username)
            .WaitAsync(cancellationToken);
    }

    public async Task<SteamBotSession> GetAnyReadySessionAsync(
        CancellationToken cancellationToken = default)
    {
        var usernames = await _database.SetMembersAsync(_sessionIndexKey)
            .WaitAsync(cancellationToken);

        if (usernames.Length == 0)
        {
            throw new InvalidOperationException("There are no active Steam bot sessions in Redis.");
        }

        Random.Shared.Shuffle(usernames);

        foreach (var usernameValue in usernames)
        {
            var username = usernameValue.ToString();
            var session = await TryGetAsync(username, cancellationToken);
            if (session is not null)
            {
                return session;
            }

            await _database.SetRemoveAsync(_sessionIndexKey, usernameValue)
                .WaitAsync(cancellationToken);
        }

        throw new InvalidOperationException("All Steam bot sessions in Redis have expired.");
    }

    public async Task<SteamBotSession> GetSessionByBotAsync(
        string username,
        CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(username);

        return await TryGetAsync(username, cancellationToken)
            ?? throw new KeyNotFoundException($"Active Steam bot session '{username}' was not found.");
    }

    private async Task<SteamBotSession?> TryGetAsync(
        string username,
        CancellationToken cancellationToken)
    {
        var value = await _database.StringGetAsync(GetSessionKey(username))
            .WaitAsync(cancellationToken);

        return value.IsNullOrEmpty
            ? null
            : JsonSerializer.Deserialize<SteamBotSession>(value.ToString(), JsonOptions);
    }

    private RedisKey GetSessionKey(string username) => $"{_options.SteamSessionsKey}:bot:{username}";
}
