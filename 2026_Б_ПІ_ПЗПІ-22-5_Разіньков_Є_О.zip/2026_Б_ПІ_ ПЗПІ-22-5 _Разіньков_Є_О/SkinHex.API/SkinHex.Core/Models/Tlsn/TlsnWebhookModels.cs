using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace SkinHex.Core.Models.Tlsn
{
    public class WebhookPayload
    {
        [JsonPropertyName("server_name")]
        public string ServerName { get; set; } = string.Empty;

        [JsonPropertyName("results")]
        public List<HandlerResult> Results { get; set; } = new();

        [JsonPropertyName("config")]
        public RevealConfigForWebhook Config { get; set; } = new();

        [JsonPropertyName("session")]
        public SessionInfo Session { get; set; } = new();

        [JsonPropertyName("transcript")]
        public RedactedTranscript Transcript { get; set; } = new();
    }

    public class HandlerResult
    {
        [JsonPropertyName("type")]
        public string Type { get; set; } = string.Empty;

        [JsonPropertyName("part")]
        public string Part { get; set; } = string.Empty;

        [JsonPropertyName("action")]
        public HandlerAction? Action { get; set; }

        [JsonPropertyName("value")]
        public string Value { get; set; } = string.Empty;
    }

    public class HandlerAction
    {
        [JsonPropertyName("kind")]
        public string Kind { get; set; } = string.Empty;
    }

    public class RevealConfigForWebhook
    {
        [JsonPropertyName("sent")]
        public List<RangeWithHandler> Sent { get; set; } = new();

        [JsonPropertyName("recv")]
        public List<RangeWithHandler> Recv { get; set; } = new();
    }

    public class RangeWithHandler
    {
        [JsonPropertyName("start")]
        public int Start { get; set; }

        [JsonPropertyName("end")]
        public int End { get; set; }

        // Omitting handler details here as they are not strictly needed for basic verification
    }

    public class SessionInfo
    {
        [JsonPropertyName("id")]
        public string Id { get; set; } = string.Empty;
        
        // Dynamic session data can be captured here if needed, e.g. using JsonExtensionData
        [JsonExtensionData]
        public Dictionary<string, System.Text.Json.JsonElement>? ExtensionData { get; set; }
    }

    public class RedactedTranscript
    {
        [JsonPropertyName("sent")]
        public string Sent { get; set; } = string.Empty;

        [JsonPropertyName("recv")]
        public string Recv { get; set; } = string.Empty;

        [JsonPropertyName("sent_length")]
        public int SentLength { get; set; }

        [JsonPropertyName("recv_length")]
        public int RecvLength { get; set; }
    }
}
