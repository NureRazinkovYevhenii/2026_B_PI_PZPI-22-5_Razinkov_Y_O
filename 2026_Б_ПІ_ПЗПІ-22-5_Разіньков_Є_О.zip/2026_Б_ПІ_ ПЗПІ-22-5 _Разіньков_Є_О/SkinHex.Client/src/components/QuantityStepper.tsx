import { useState, useCallback, useRef } from 'react';
import { Minus, Plus } from 'lucide-react';

type QuantityStepperProps = {
  value: number;
  min: number;
  max: number;
  onChange: (value: number) => void;
};

export function QuantityStepper({ value, min, max, onChange }: QuantityStepperProps) {
  const [animClass, setAnimClass] = useState('');
  const timeoutRef = useRef<number | null>(null);

  const triggerAnim = useCallback((direction: 'up' | 'down') => {
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    setAnimClass('');
    // Force reflow to restart animation
    requestAnimationFrame(() => {
      setAnimClass(direction === 'up' ? 'bump-up' : 'bump-down');
      timeoutRef.current = window.setTimeout(() => setAnimClass(''), 250);
    });
  }, []);

  const decrement = () => {
    if (value > min) {
      onChange(value - 1);
      triggerAnim('down');
    }
  };

  const increment = () => {
    if (value < max) {
      onChange(value + 1);
      triggerAnim('up');
    }
  };

  return (
    <div className="qty-stepper">
      <button
        className="qty-stepper-btn"
        onClick={decrement}
        disabled={value <= min}
        type="button"
        aria-label="Decrease quantity"
      >
        <Minus size={14} strokeWidth={2.5} />
      </button>
      <div className="qty-stepper-value">
        <span className={`qty-stepper-num ${animClass}`}>{value}</span>
      </div>
      <button
        className="qty-stepper-btn"
        onClick={increment}
        disabled={value >= max}
        type="button"
        aria-label="Increase quantity"
      >
        <Plus size={14} strokeWidth={2.5} />
      </button>
    </div>
  );
}
