namespace SkinHex.Core.Models;

public sealed record CurrentUserDto(
    string SteamId,
    string Username,
    string? AvatarUrl,
    decimal Balance,
    decimal FrozenBalance);
