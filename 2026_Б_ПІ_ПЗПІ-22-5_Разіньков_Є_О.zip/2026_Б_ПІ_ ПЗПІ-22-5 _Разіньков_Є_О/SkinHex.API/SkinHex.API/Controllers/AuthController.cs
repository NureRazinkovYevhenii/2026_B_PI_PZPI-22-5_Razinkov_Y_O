using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebUtilities;
using SkinHex.API.Errors;
using SkinHex.Core.Interfaces;
using SkinHex.Core.Models.Auth;
using System.Security.Claims;

namespace SkinHex.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public sealed class AuthController(IAuthService _authService, IConfiguration _configuration) : ControllerBase
{
    private const string ExternalCookieScheme = "External";
    private const string SteamAuthenticationScheme = "Steam";

    [HttpGet("login")]
    public IActionResult Login()
    {
        var redirectUri = Url.Action(nameof(Callback), "Auth", values: null, protocol: Request.Scheme);

        var properties = new AuthenticationProperties
        {
            RedirectUri = redirectUri
        };

        return Challenge(properties, SteamAuthenticationScheme);
    }

    [HttpGet("callback")]
    public async Task<IActionResult> Callback(CancellationToken ct)
    {
        var externalAuthResult = await HttpContext.AuthenticateAsync(ExternalCookieScheme);
        if (!externalAuthResult.Succeeded || externalAuthResult.Principal is null)
        {
            return Problem(statusCode: StatusCodes.Status401Unauthorized, title: "Steam authentication failed");
        }

        var principal = externalAuthResult.Principal;
        var steamId = ExtractSteamId(principal);
        if (string.IsNullOrWhiteSpace(steamId))
        {
            return Problem(statusCode: StatusCodes.Status401Unauthorized, title: "Steam identity was not provided");
        }

        var username = GetClaimValue(principal, ClaimTypes.Name, "urn:steam:personaname") ?? steamId;
        var avatarUrl = GetClaimValue(principal, "urn:steam:avatarfull");

        var authResult = await _authService.AuthenticateWithSteamAsync(new SteamUserInfo(steamId, username, avatarUrl),ct);

        if (authResult.IsFailed)
        {
            return this.ToProblemDetails(authResult.Errors);
        }

        await HttpContext.SignOutAsync(ExternalCookieScheme);

        var frontendUrl = _configuration["FrontendUrl"];
        if (string.IsNullOrWhiteSpace(frontendUrl))
        {
            // Віддаємо саме посилання (або null) для Swagger/Postman
            return Ok(new
            {
                authResult.Value.Tokens,
                TradeUrl = authResult.Value.User.TradeUrl,
            });
        }

        // Дістаємо саме посилання (якщо null, робимо порожній рядок для URL)
        var tradeUrl = authResult.Value.User.TradeUrl ?? string.Empty;

        // Додаємо в параметри
        var redirectFragment = QueryHelpers.AddQueryString(string.Empty, new Dictionary<string, string?>
        {
            ["accessToken"] = authResult.Value.Tokens.AccessToken,
            ["refreshToken"] = authResult.Value.Tokens.RefreshToken,
            ["tradeUrl"] = tradeUrl, // <-- Передаємо сам рядок
        }).TrimStart('?');

        // The URL fragment is not sent to proxies or as an HTTP referrer.
        return Redirect($"{frontendUrl.TrimEnd('#')}#{redirectFragment}");
    }
    

    [HttpPost("refresh")]
    public async Task<IActionResult> Refresh(RefreshTokenRequest request, CancellationToken ct)
    {
        var tokens = await _authService.RefreshTokensAsync(request.RefreshToken, ct);
        if (tokens.IsFailed)
        {
            return this.ToProblemDetails(
                tokens.Errors,
                StatusCodes.Status401Unauthorized,
                "Refresh token was rejected");
        }

        return Ok(tokens.Value);
    }

    [Authorize(Roles = "Unverified")]
    [HttpPost("send-otp")]
    public async Task<IActionResult> SendOtp(SendOtpRequest request, CancellationToken ct)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _authService.SendVerificationCodeAsync(userId.Value, request.Email, ct);

        if (result.IsFailed)
        {
            return this.ToProblemDetails(result.Errors);
        }

        return NoContent();
    }

    [Authorize(Roles = "Unverified")]
    [HttpPost("verify-email")]
    public async Task<IActionResult> VerifyEmail(VerifyEmailRequest request, CancellationToken ct)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _authService.VerifyEmailAsync(
            userId.Value,
            request.Email,
            request.Code,
            ct);

        if (result.IsFailed)
        {
            return this.ToProblemDetails(result.Errors);
        }

        return Ok(result.Value);
    }

    private static string? ExtractSteamId(ClaimsPrincipal principal)
    {
        var nameIdentifier = principal.FindFirstValue(ClaimTypes.NameIdentifier);
        if (string.IsNullOrWhiteSpace(nameIdentifier))
        {
            return null;
        }

        const string steamOpenIdPrefix = "https://steamcommunity.com/openid/id/";
        return nameIdentifier.StartsWith(steamOpenIdPrefix, StringComparison.OrdinalIgnoreCase)
            ? nameIdentifier[steamOpenIdPrefix.Length..]
            : nameIdentifier;
    }

    private static string? GetClaimValue(ClaimsPrincipal principal, params string[] claimTypes)
    {
        foreach (var claimType in claimTypes)
        {
            var value = principal.FindFirstValue(claimType);
            if (!string.IsNullOrWhiteSpace(value))
            {
                return value;
            }
        }

        return null;
    }

    private Guid? GetCurrentUserId()
    {
        var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
        return Guid.TryParse(userId, out var parsedUserId)
            ? parsedUserId
            : null;
    }

}
