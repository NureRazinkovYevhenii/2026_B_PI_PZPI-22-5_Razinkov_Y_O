import { API_BASE_URL } from '../config';

export interface CreateDepositRequest {
  amountUsd: number;
  payCurrency: string;
}

export interface CreateDepositResponse {
  depositId: string;
  invoiceUrl: string;
}

export interface DepositStatusResponse {
  status: string;
  fiatAmount: number;
}

export interface DepositCurrency {
  code: string;
  ticker: string;
  name: string;
  network: string | null;
  color: string;
  group: 'popular' | 'stablecoin';
}

export interface CurrenciesResponse {
  platformMinUsd: number;
  depositFeePercent: number;
  currencies: DepositCurrency[];
}

export interface MinAmountResponse {
  payCurrency: string;
  coinMinCrypto: number | null;
  coinMinUsd: number | null;
  platformMinUsd: number;
  minUsd: number;
}

export interface EstimateResponse {
  payCurrency: string;
  amountUsd: number;
  estimatedCrypto: number;
}

const authHeaders = (): Record<string, string> => {
  const token = localStorage.getItem('jwt_token');
  return {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
};

async function readError(response: Response, fallback: string): Promise<string> {
  try {
    const text = await response.text();
    if (!text) return fallback;
    try {
      const json = JSON.parse(text);
      return json.detail ?? json.message ?? json.title ?? text;
    } catch {
      return text;
    }
  } catch {
    return fallback;
  }
}

export const getSupportedCurrencies = async (): Promise<CurrenciesResponse> => {
  const response = await fetch(`${API_BASE_URL}/deposits/currencies`, { headers: authHeaders() });
  if (!response.ok) {
    throw new Error(await readError(response, 'Failed to load currencies'));
  }
  return response.json();
};

export const getMinAmount = async (payCurrency: string, signal?: AbortSignal): Promise<MinAmountResponse> => {
  const response = await fetch(
    `${API_BASE_URL}/deposits/min-amount?payCurrency=${encodeURIComponent(payCurrency)}`,
    { headers: authHeaders(), signal },
  );
  if (!response.ok) {
    throw new Error(await readError(response, 'Failed to load minimum amount'));
  }
  return response.json();
};

export const getEstimate = async (
  amountUsd: number,
  payCurrency: string,
  signal?: AbortSignal,
): Promise<EstimateResponse> => {
  const params = new URLSearchParams({ amountUsd: String(amountUsd), payCurrency });
  const response = await fetch(`${API_BASE_URL}/deposits/estimate?${params}`, {
    headers: authHeaders(),
    signal,
  });
  if (!response.ok) {
    throw new Error(await readError(response, 'Failed to fetch conversion rate'));
  }
  return response.json();
};

export const createDeposit = async (request: CreateDepositRequest): Promise<CreateDepositResponse> => {
  const response = await fetch(`${API_BASE_URL}/deposits`, {
    method: 'POST',
    headers: authHeaders(),
    body: JSON.stringify(request),
  });

  if (!response.ok) {
    throw new Error(await readError(response, 'Failed to create deposit'));
  }

  return response.json();
};

export const getDepositStatus = async (id: string): Promise<DepositStatusResponse> => {
  const response = await fetch(`${API_BASE_URL}/deposits/${id}`, { headers: authHeaders() });

  if (!response.ok) {
    throw new Error(await readError(response, 'Failed to get deposit status'));
  }

  return response.json();
};
