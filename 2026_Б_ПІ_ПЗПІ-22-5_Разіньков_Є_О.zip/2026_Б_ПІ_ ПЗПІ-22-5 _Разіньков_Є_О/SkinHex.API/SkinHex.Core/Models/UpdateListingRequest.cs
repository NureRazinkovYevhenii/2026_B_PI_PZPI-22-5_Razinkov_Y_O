namespace SkinHex.Core.Models;

public sealed class UpdateListingRequest
{
    public decimal Price { get; set; }
}
