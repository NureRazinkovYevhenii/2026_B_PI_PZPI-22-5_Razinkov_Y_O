using System.Text.Json;
using System.Text.Json.Serialization;

namespace SkinHex.SteamGateway.Steam;

internal sealed class SteamDictionaryConverter<TValue> : JsonConverter<Dictionary<string, TValue>>
{
    public override Dictionary<string, TValue>? Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
    {
        if (reader.TokenType == JsonTokenType.StartArray)
        {
            // Steam returns an empty array `[]` when the inventory is empty or private,
            // instead of returning an empty object `{}`.
            reader.Skip();
            return new Dictionary<string, TValue>();
        }

        if (reader.TokenType == JsonTokenType.StartObject)
        {
            var dict = new Dictionary<string, TValue>();
            using var doc = JsonDocument.ParseValue(ref reader);
            
            foreach (var prop in doc.RootElement.EnumerateObject())
            {
                var val = prop.Value.Deserialize<TValue>(options);
                if (val != null)
                {
                    dict[prop.Name] = val;
                }
            }

            return dict;
        }

        throw new JsonException($"Expected StartObject or StartArray but got {reader.TokenType}");
    }

    public override void Write(Utf8JsonWriter writer, Dictionary<string, TValue> value, JsonSerializerOptions options)
    {
        JsonSerializer.Serialize(writer, value, options);
    }
}
