namespace SkinHex.Core.Entities;

public enum SteamOfferState
{
    Invalid = 1,
    Active = 2,
    Accepted = 3,
    Countered = 4,
    Expired = 5,
    Canceled = 6,
    Declined = 7,
    InvalidItems = 8,
    CreatedNeedsConfirmation = 9,
    CanceledBySecondFactor = 10,
    InEscrow = 11,
}

public enum SteamTradeStatus
{
    Invalid = 0,
    Complete = 3,
    FullSupportRollback = 6,
    EscrowRollback = 11,
    TradeProtectionRollback = 12,
}
