namespace SkinHex.Core.Interfaces.Services;

public sealed record EmailVerificationCode(string Email, int Code, DateTimeOffset CreatedAt);

public interface IEmailVerificationCodeStore
{
    Task StoreAsync(
        Guid userId,
        EmailVerificationCode verificationCode,
        TimeSpan timeToLive,
        CancellationToken cancellationToken = default);

    Task<EmailVerificationCode?> GetAsync(
        Guid userId,
        CancellationToken cancellationToken = default);

    Task RemoveAsync(Guid userId, CancellationToken cancellationToken = default);
}
