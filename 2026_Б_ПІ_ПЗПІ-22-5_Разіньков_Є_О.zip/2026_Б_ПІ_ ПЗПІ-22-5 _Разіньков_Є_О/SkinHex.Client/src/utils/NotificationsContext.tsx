import { createContext, useContext, useCallback, useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { HubConnectionBuilder, LogLevel } from '@microsoft/signalr';
import type { HubConnection } from '@microsoft/signalr';
import { API_BASE_URL } from '../config';
import type { AuthorizedFetch } from '../types';
import { useCart } from './CartContext';
import {
  getNotifications,
  markAllNotificationsRead,
  markNotificationsRead,
} from '../api/notificationsApi';
import type {
  AppNotification,
  BalanceChangedPayload,
  CartItemUnavailablePayload,
  OrderStatusChangedPayload,
} from '../api/notificationsApi';

// API_BASE_URL ends with `/api`; the hub is mapped on the host root.
const HUB_URL = `${API_BASE_URL.replace(/\/api$/, '')}/hubs/notifications`;

const PAGE_SIZE = 20;

export const ORDER_UPDATED_EVENT = 'skinhex:order-updated';

interface NotificationsContextType {
  notifications: AppNotification[];
  unreadCount: number;
  hasMore: boolean;
  isLoading: boolean;
  isConnected: boolean;
  loadMore: () => Promise<void>;
  markAsRead: (ids: string[]) => Promise<void>;
  markAllAsRead: () => Promise<void>;
}

const NotificationsContext = createContext<NotificationsContextType | undefined>(undefined);

export function NotificationsProvider({
  children,
  authorizedFetch,
  isAuthenticated,
  onBalanceUpdate,
}: {
  children: ReactNode;
  authorizedFetch: AuthorizedFetch;
  isAuthenticated: boolean;
  onBalanceUpdate: (payload: BalanceChangedPayload) => void;
}) {
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [hasMore, setHasMore] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isConnected, setIsConnected] = useState(false);

  const { refreshCart } = useCart();

  // The SignalR connection must outlive re-renders, so handlers reach the
  // latest callbacks through refs instead of being re-subscribed.
  const onBalanceUpdateRef = useRef(onBalanceUpdate);
  onBalanceUpdateRef.current = onBalanceUpdate;
  const refreshCartRef = useRef(refreshCart);
  refreshCartRef.current = refreshCart;
  const authorizedFetchRef = useRef(authorizedFetch);
  authorizedFetchRef.current = authorizedFetch;

  // Initial history load.
  useEffect(() => {
    if (!isAuthenticated) {
      setNotifications([]);
      setUnreadCount(0);
      setHasMore(false);
      return;
    }

    let cancelled = false;
    setIsLoading(true);
    getNotifications(authorizedFetchRef.current, PAGE_SIZE)
      .then((page) => {
        if (cancelled) return;
        setNotifications(page.items);
        setUnreadCount(page.unreadCount);
        setHasMore(page.hasMore);
      })
      .catch((error) => console.error('Failed to load notifications', error))
      .finally(() => {
        if (!cancelled) setIsLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [isAuthenticated]);

  // Realtime connection lifecycle.
  useEffect(() => {
    if (!isAuthenticated) {
      return;
    }

    const connection: HubConnection = new HubConnectionBuilder()
      .withUrl(HUB_URL, {
        // persistAuth keeps this key fresh across token refreshes, so reconnects
        // always negotiate with a current JWT.
        accessTokenFactory: () => localStorage.getItem('jwt_token') ?? '',
      })
      .withAutomaticReconnect()
      .configureLogging(LogLevel.Warning)
      .build();

    connection.on('Notification', (notification: AppNotification) => {
      setNotifications((prev) => [notification, ...prev]);
      setUnreadCount((count) => count + 1);
    });

    connection.on('BalanceUpdated', (payload: BalanceChangedPayload) => {
      onBalanceUpdateRef.current(payload);
    });

    connection.on('CartItemUnavailable', (_payload: CartItemUnavailablePayload) => {
      // The server recomputes availability, so a refresh reflects the lost item.
      void refreshCartRef.current();
    });

    connection.on('OrderUpdated', (payload: OrderStatusChangedPayload) => {
      window.dispatchEvent(new CustomEvent(ORDER_UPDATED_EVENT, { detail: payload }));
    });

    connection.onreconnected(() => setIsConnected(true));
    connection.onreconnecting(() => setIsConnected(false));
    connection.onclose(() => setIsConnected(false));

    // withAutomaticReconnect only covers drops of an established connection;
    // the initial start must retry on its own (e.g. the API is still booting).
    let disposed = false;
    let retryTimer: number | undefined;

    const start = () => {
      connection
        .start()
        .then(() => {
          if (!disposed) setIsConnected(true);
        })
        .catch(() => {
          if (!disposed) {
            retryTimer = window.setTimeout(start, 10_000);
          }
        });
    };

    start();

    return () => {
      disposed = true;
      if (retryTimer !== undefined) window.clearTimeout(retryTimer);
      setIsConnected(false);
      void connection.stop();
    };
  }, [isAuthenticated]);

  const loadMore = useCallback(async () => {
    const oldest = notifications[notifications.length - 1];
    if (!oldest || isLoading) return;

    setIsLoading(true);
    try {
      const page = await getNotifications(authorizedFetchRef.current, PAGE_SIZE, oldest.createdAt);
      setNotifications((prev) => {
        const known = new Set(prev.map((n) => n.id));
        return [...prev, ...page.items.filter((n) => !known.has(n.id))];
      });
      setUnreadCount(page.unreadCount);
      setHasMore(page.hasMore);
    } catch (error) {
      console.error('Failed to load more notifications', error);
    } finally {
      setIsLoading(false);
    }
  }, [notifications, isLoading]);

  const markAsRead = useCallback(async (ids: string[]) => {
    if (ids.length === 0) return;
    const idSet = new Set(ids);

    // Optimistic update; the server call only confirms it.
    let affected = 0;
    setNotifications((prev) =>
      prev.map((n) => {
        if (!idSet.has(n.id) || n.isRead) return n;
        affected += 1;
        return { ...n, isRead: true, readAt: new Date().toISOString() };
      }),
    );
    setUnreadCount((count) => Math.max(0, count - affected));

    try {
      await markNotificationsRead(authorizedFetchRef.current, ids);
    } catch (error) {
      console.error('Failed to mark notifications as read', error);
    }
  }, []);

  const markAllAsRead = useCallback(async () => {
    setNotifications((prev) =>
      prev.map((n) => (n.isRead ? n : { ...n, isRead: true, readAt: new Date().toISOString() })),
    );
    setUnreadCount(0);

    try {
      await markAllNotificationsRead(authorizedFetchRef.current);
    } catch (error) {
      console.error('Failed to mark all notifications as read', error);
    }
  }, []);

  return (
    <NotificationsContext.Provider
      value={{ notifications, unreadCount, hasMore, isLoading, isConnected, loadMore, markAsRead, markAllAsRead }}
    >
      {children}
    </NotificationsContext.Provider>
  );
}

export function useNotifications() {
  const context = useContext(NotificationsContext);
  if (context === undefined) {
    throw new Error('useNotifications must be used within a NotificationsProvider');
  }
  return context;
}
