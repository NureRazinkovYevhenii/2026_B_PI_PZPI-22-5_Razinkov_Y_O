using SkinHex.Core.Entities;

namespace SkinHex.Core.Models.Orders;

public record CreateOrderResponse(
    Guid Id,
    Guid ListingId,
    OrderStatus Status,
    decimal LockPrice,
    DateTime CreatedAt,
    DateTime ConfirmDeadline,
    OrderParticipantDto Buyer,
    OrderParticipantDto Seller);

public record OrderParticipantDto(
    Guid Id,
    string Username,
    string? AvatarUrl);
