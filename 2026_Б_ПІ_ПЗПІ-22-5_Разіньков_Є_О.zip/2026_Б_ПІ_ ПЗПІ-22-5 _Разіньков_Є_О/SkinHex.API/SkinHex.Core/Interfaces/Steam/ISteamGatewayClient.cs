using SkinHex.Core.Models;
using SkinHex.Core.Models.Steam;

namespace SkinHex.Core.Interfaces.Steam;

public interface ISteamGatewayClient
{
    Task<IReadOnlyList<InventoryItemDto>> GetInventoryAsync(
        SteamTradeLink tradeLink,
        bool forceReload = false,
        CancellationToken cancellationToken = default);

    Task ValidateTradeLinkAsync(
        SteamTradeLink tradeLink,
        CancellationToken cancellationToken = default);
}
