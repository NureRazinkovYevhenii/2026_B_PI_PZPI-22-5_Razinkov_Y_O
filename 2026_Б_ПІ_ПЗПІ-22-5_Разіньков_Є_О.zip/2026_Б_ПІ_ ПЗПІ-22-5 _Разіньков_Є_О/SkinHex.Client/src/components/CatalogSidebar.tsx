import React, { useCallback, useState, useRef, useEffect } from 'react';
import { Search, ChevronDown, RotateCcw } from 'lucide-react';
import type { CatalogFilters, ItemDictionaryEntry, MarketSearchTipDto } from '../types';
import { API_BASE_URL } from '../config';
import { getItemImageUrl } from '../utils/itemDictionary';
import { ALL_CATEGORIES, getWeaponsForCategory, WEAR_PRESETS } from '../utils/catalogHelpers';
import { DualRangeSlider } from './DualRangeSlider';

const WEAR_PRIORITY = [
  'Factory New',
  'Minimal Wear',
  'Field-Tested',
  'Well-Worn',
  'Battle-Scarred',
];

function findBestItemEntry(
  dictionary: Record<string, ItemDictionaryEntry>,
  baseName: string,
): ItemDictionaryEntry | null {
  // Try with each wear, best quality first
  for (const wear of WEAR_PRIORITY) {
    const key = `${baseName} (${wear})`;
    if (dictionary[key]) return dictionary[key];
  }
  // Try without wear (e.g. for items like stickers, cases)
  if (dictionary[baseName]) return dictionary[baseName];
  // Try StatTrak variants
  for (const wear of WEAR_PRIORITY) {
    const key = `StatTrak\u2122 ${baseName} (${wear})`;
    if (dictionary[key]) return dictionary[key];
  }
  return null;
}

type CatalogSidebarProps = {
  filters: CatalogFilters;
  onChange: (next: CatalogFilters) => void;
  onReset: () => void;
  itemDictionary: Record<string, ItemDictionaryEntry>;
};

const PRICE_MIN = 0;
const PRICE_MAX = 10000;
const FLOAT_MIN = 0;
const FLOAT_MAX = 1;

const PRICE_QUICK = [
  { label: '<$10', min: '0', max: '10' },
  { label: '$10–$50', min: '10', max: '50' },
  { label: '$50–$250', min: '50', max: '250' },
  { label: '>$250', min: '250', max: '' },
];

const FLOAT_SEGMENTS = WEAR_PRESETS.map((p) => ({
  color: p.color,
  start: p.min,
  end: p.max,
}));

export function CatalogSidebar({ filters, onChange, onReset, itemDictionary }: CatalogSidebarProps) {
  const [openSections, setOpenSections] = useState<Record<string, boolean>>({
    price: true,
    float: true,
    seed: true,
    weapon: true,
  });

  const toggle = (key: string) =>
    setOpenSections((prev) => ({ ...prev, [key]: !prev[key] }));

  const update = useCallback(
    (patch: Partial<CatalogFilters>) => onChange({ ...filters, ...patch }),
    [filters, onChange],
  );

  const [localSearch, setLocalSearch] = useState(filters.searchTerm || '');

  useEffect(() => {
    setLocalSearch(filters.searchTerm || '');
  }, [filters.searchTerm]);

  const [tips, setTips] = useState<MarketSearchTipDto[]>([]);
  const [showTips, setShowTips] = useState(false);
  const tipsDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const executeSearch = (term: string) => {
    if (term !== filters.searchTerm) {
      update({ searchTerm: term });
    }
    setShowTips(false);
  };

  useEffect(() => {
    const term = localSearch.trim();
    if (term.length < 2) {
      setTips([]);
      setShowTips(false);
      return;
    }

    if (term === (filters.searchTerm || '').trim()) {
      return;
    }

    if (tipsDebounceRef.current) {
      clearTimeout(tipsDebounceRef.current);
    }

    tipsDebounceRef.current = setTimeout(async () => {
      try {
        const res = await fetch(`${API_BASE_URL}/market/search-tips?query=${encodeURIComponent(term)}&limit=15`);
        if (res.ok) {
          const data = await res.json();
          setTips(data);
          setShowTips(true);
        }
      } catch (err) {
        console.error('Failed to fetch search tips', err);
      }
    }, 300);

  }, [localSearch, filters.searchTerm]);

  const searchRef = useRef(localSearch);
  useEffect(() => {
    searchRef.current = localSearch;
  }, [localSearch]);

  const handleTipClick = (baseName: string) => {
    setLocalSearch(baseName);
    searchRef.current = baseName;
    executeSearch(baseName);
  };

  const handleInputKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      executeSearch(localSearch);
    }
  };

  const handleInputBlur = () => {
    setTimeout(() => {
      executeSearch(searchRef.current);
    }, 200);
  };

  const weapons = filters.category ? getWeaponsForCategory(filters.category) : [];

  const priceMin = filters.minPrice ? Number(filters.minPrice) : PRICE_MIN;
  const priceMax = filters.maxPrice ? Number(filters.maxPrice) : PRICE_MAX;
  const floatMin = filters.minFloat ? Number(filters.minFloat) : FLOAT_MIN;
  const floatMax = filters.maxFloat ? Number(filters.maxFloat) : FLOAT_MAX;

  const activeWear = WEAR_PRESETS.find(
    (p) =>
      Number(filters.minFloat) === p.min && Number(filters.maxFloat) === p.max,
  );

  return (
    <aside className="cat-sidebar">
      {/* ── Search ── */}
      <div className="cat-filter-search" style={{ position: 'relative' }}>
        <Search size={16} className="cat-search-icon" />
        <input
          type="text"
          placeholder="Search skins..."
          value={localSearch}
          onChange={(e) => setLocalSearch(e.target.value)}
          onKeyDown={handleInputKeyDown}
          onFocus={() => { if (tips.length > 0) setShowTips(true); }}
          onBlur={handleInputBlur}
          className="cat-search-input"
        />
        
        {showTips && tips.length > 0 && (
          <div className="custom-scrollbar" style={{ position: 'absolute', top: '100%', left: 0, right: 0, marginTop: '8px', backgroundColor: '#18181b', border: '1px solid #27272a', borderRadius: '8px', zIndex: 50, maxHeight: '320px', overflowY: 'auto', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.5)' }}>
            {tips.map((tip, idx) => {
              const itemEntry = findBestItemEntry(itemDictionary, tip.baseName);
              const imageUrl = getItemImageUrl(itemEntry);
              const colorHex = itemEntry?.color ? `#${itemEntry.color}` : null;
              return (
                <div 
                  key={`${tip.baseName}-${idx}`}
                  onMouseDown={(e) => {
                    e.preventDefault(); // Prevents input from losing focus immediately
                    handleTipClick(tip.baseName);
                  }}
                  style={{ display: 'flex', alignItems: 'center', padding: '8px 12px', cursor: 'pointer', gap: '12px', borderBottom: '1px solid #27272a', transition: 'background-color 0.15s' }}
                  onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#27272a'}
                  onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                >
                  <div style={{ width: '48px', height: '36px', flexShrink: 0, borderRadius: '4px', backgroundColor: colorHex ? `${colorHex}22` : '#3f3f46', border: `1px solid ${colorHex ? `${colorHex}66` : '#52525b'}`, display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
                    {imageUrl ? <img src={imageUrl} alt="" style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }} /> : <div style={{ width: '100%', height: '100%' }} />}
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', overflow: 'hidden', justifyContent: 'center' }}>
                    <span style={{ fontSize: '13px', fontWeight: 600, color: '#f4f4f5', whiteSpace: 'nowrap', textOverflow: 'ellipsis', overflow: 'hidden' }}>{tip.baseName}</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* ── Price ── */}
      <section className="cat-filter-section">
        <button
          className="cat-filter-heading"
          onClick={() => toggle('price')}
          type="button"
        >
          <span>Price</span>
          <ChevronDown
            size={16}
            className={`cat-chevron ${openSections.price ? 'open' : ''}`}
          />
        </button>
        {openSections.price && (
          <div className="cat-filter-body">
            <DualRangeSlider
              min={PRICE_MIN}
              max={PRICE_MAX}
              step={1}
              valueMin={priceMin}
              valueMax={priceMax}
              onChange={(lo, hi) =>
                update({
                  minPrice: lo > PRICE_MIN ? String(lo) : '',
                  maxPrice: hi < PRICE_MAX ? String(hi) : '',
                })
              }
            />
            <div className="cat-minmax-row">
              <div className="cat-minmax-field">
                <label>Min</label>
                <div className="cat-price-input-wrap">
                  <span className="cat-currency">$</span>
                  <input
                    type="number"
                    min={0}
                    placeholder="0"
                    value={filters.minPrice}
                    onChange={(e) => update({ minPrice: e.target.value })}
                  />
                </div>
              </div>
              <span className="cat-minmax-dash">–</span>
              <div className="cat-minmax-field">
                <label>Max</label>
                <div className="cat-price-input-wrap">
                  <span className="cat-currency">$</span>
                  <input
                    type="number"
                    min={0}
                    placeholder="∞"
                    value={filters.maxPrice}
                    onChange={(e) => update({ maxPrice: e.target.value })}
                  />
                </div>
              </div>
            </div>
            <div className="cat-quick-filters">
              {PRICE_QUICK.map((q) => (
                <button
                  key={q.label}
                  type="button"
                  className={`cat-quick-btn ${
                    filters.minPrice === q.min && filters.maxPrice === q.max
                      ? 'active'
                      : ''
                  }`}
                  onClick={() => update({ minPrice: q.min, maxPrice: q.max })}
                >
                  {q.label}
                </button>
              ))}
            </div>
          </div>
        )}
      </section>

      {/* ── Float ── */}
      <section className="cat-filter-section">
        <button
          className="cat-filter-heading"
          onClick={() => toggle('float')}
          type="button"
        >
          <span>Float</span>
          <ChevronDown
            size={16}
            className={`cat-chevron ${openSections.float ? 'open' : ''}`}
          />
        </button>
        {openSections.float && (
          <div className="cat-filter-body">
            <DualRangeSlider
              min={FLOAT_MIN}
              max={FLOAT_MAX}
              step={0.001}
              valueMin={floatMin}
              valueMax={floatMax}
              onChange={(lo, hi) =>
                update({
                  minFloat: lo > FLOAT_MIN ? lo.toFixed(3) : '',
                  maxFloat: hi < FLOAT_MAX ? hi.toFixed(3) : '',
                  wear: null,
                })
              }
              trackSegments={FLOAT_SEGMENTS}
            />
            <div className="cat-minmax-row">
              <div className="cat-minmax-field">
                <label>Min</label>
                <input
                  type="number"
                  min={0}
                  max={1}
                  step={0.001}
                  placeholder="0.000"
                  value={filters.minFloat}
                  onChange={(e) => update({ minFloat: e.target.value, wear: null })}
                />
              </div>
              <span className="cat-minmax-dash">–</span>
              <div className="cat-minmax-field">
                <label>Max</label>
                <input
                  type="number"
                  min={0}
                  max={1}
                  step={0.001}
                  placeholder="1.000"
                  value={filters.maxFloat}
                  onChange={(e) => update({ maxFloat: e.target.value, wear: null })}
                />
              </div>
            </div>
            <div className="cat-wear-presets">
              {WEAR_PRESETS.map((p) => (
                <button
                  key={p.short}
                  type="button"
                  className={`cat-wear-btn ${activeWear?.short === p.short ? 'active' : ''}`}
                  style={{ '--wear-color': p.color } as React.CSSProperties}
                  onClick={() =>
                    update({
                      minFloat: String(p.min),
                      maxFloat: String(p.max),
                      wear: null,
                    })
                  }
                >
                  {p.short}
                </button>
              ))}
            </div>
          </div>
        )}
      </section>

      {/* ── Paint Seed ── */}
      <section className="cat-filter-section">
        <button
          className="cat-filter-heading"
          onClick={() => toggle('seed')}
          type="button"
        >
          <span>Paint Seed</span>
          <ChevronDown
            size={16}
            className={`cat-chevron ${openSections.seed ? 'open' : ''}`}
          />
        </button>
        {openSections.seed && (
          <div className="cat-filter-body">
            <input
              type="number"
              min={0}
              max={1000}
              placeholder="Enter seed..."
              className="cat-seed-input"
              value={filters.paintSeed}
              onChange={(e) => update({ paintSeed: e.target.value })}
            />
          </div>
        )}
      </section>

      {/* ── Weapon / Category ── */}
      <section className="cat-filter-section">
        <button
          className="cat-filter-heading"
          onClick={() => toggle('weapon')}
          type="button"
        >
          <span>Weapon</span>
          <ChevronDown
            size={16}
            className={`cat-chevron ${openSections.weapon ? 'open' : ''}`}
          />
        </button>
        {openSections.weapon && (
          <div className="cat-filter-body">
            <div className="cat-select-wrap">
              <select
                className="cat-select"
                value={filters.category ?? ''}
                onChange={(e) =>
                  update({
                    category: e.target.value || null,
                    weapon: null,
                  })
                }
              >
                <option value="">All Categories</option>
                {ALL_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
              <ChevronDown size={14} className="cat-select-icon" />
            </div>

            {weapons.length > 0 && (
              <div className="cat-select-wrap" style={{ marginTop: 8 }}>
                <select
                  className="cat-select"
                  value={filters.weapon ?? ''}
                  onChange={(e) => update({ weapon: e.target.value || null })}
                >
                  <option value="">All {filters.category}</option>
                  {weapons.map((w) => (
                    <option key={w} value={w}>
                      {w}
                    </option>
                  ))}
                </select>
                <ChevronDown size={14} className="cat-select-icon" />
              </div>
            )}
          </div>
        )}
      </section>

      {/* ── Reset ── */}
      <button className="cat-reset-btn" type="button" onClick={() => {
        setLocalSearch('');
        setTips([]);
        setShowTips(false);
        onReset();
      }}>
        <RotateCcw size={14} />
        Reset Filters
      </button>
    </aside>
  );
}
