namespace SkinHex.Core.Models;

public sealed record UserBalanceDto(
    decimal Balance,
    decimal FrozenBalance);
