using SkinHex.Core.Entities;

namespace SkinHex.Core.Models.Auth;

public sealed record AuthResult(
    User User,
    TokenResult Tokens);
