using Microsoft.EntityFrameworkCore;
using SkinHex.Core.Entities;

namespace SkinHex.Infrastructure;

public class SkinHexDbContext : DbContext
{
    public SkinHexDbContext(DbContextOptions<SkinHexDbContext> options) : base(options) { }

    public DbSet<User> Users => Set<User>();
    public DbSet<RefreshToken> RefreshTokens => Set<RefreshToken>();
    public DbSet<Item> Items => Set<Item>();
    public DbSet<Listing> Listings => Set<Listing>();
    public DbSet<Order> Orders => Set<Order>();
    public DbSet<SteamTrade> SteamTrades => Set<SteamTrade>();
    public DbSet<CartItem> CartItems => Set<CartItem>();
    public DbSet<FinancialTransaction> FinancialTransactions => Set<FinancialTransaction>();
    public DbSet<Deposit> Deposits => Set<Deposit>();
    public DbSet<SupportTicket> SupportTickets => Set<SupportTicket>();
    public DbSet<TicketMessage> TicketMessages => Set<TicketMessage>();
    public DbSet<Withdrawal> Withdrawals => Set<Withdrawal>();
    public DbSet<Notification> Notifications => Set<Notification>();
    public DbSet<ItemScreenshot> ItemScreenshots => Set<ItemScreenshot>();
    public DbSet<OrderDispute> OrderDisputes => Set<OrderDispute>();
    public DbSet<TlsnProofRecord> TlsnProofRecords => Set<TlsnProofRecord>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => e.SteamId).IsUnique();

            entity.Property(e => e.Balance).HasPrecision(18, 2);
            entity.Property(e => e.FrozenBalance).HasPrecision(18, 2);
        });

        modelBuilder.Entity<RefreshToken>(entity =>
        {
            entity.HasKey(e => e.Id);

            entity.HasIndex(e => e.Token).IsUnique();

            entity.HasOne(rt => rt.User)
                .WithMany(u => u.RefreshTokens)
                .HasForeignKey(rt => rt.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });


        modelBuilder.Entity<Item>(entity =>
        {
            entity.HasKey(e => e.Id);

            entity.HasIndex(e => e.MarketHashName).IsUnique();

            entity.HasIndex(e => new { e.Weapon, e.IsStatTrak });

            entity.Property(e => e.MarketHashName).HasMaxLength(300);
            entity.Property(e => e.BaseName).HasMaxLength(200);
            entity.Property(e => e.Category).HasMaxLength(50);
            entity.Property(e => e.Weapon).HasMaxLength(50);
            entity.Property(e => e.Rarity).HasMaxLength(50);
            entity.Property(e => e.Wear).HasMaxLength(50);
            entity.Property(e => e.Color).HasMaxLength(10);
            entity.Property(e => e.ImageHash).HasMaxLength(255);
        });

        modelBuilder.Entity<Listing>(entity =>
        {
            entity.HasKey(e => e.Id);

            // Optimistic concurrency via PostgreSQL xmin system column.
            // Prevents two buyers from purchasing the same listing simultaneously.
            if (Database.ProviderName == "Npgsql.EntityFrameworkCore.PostgreSQL")
            {
                entity.UseXminAsConcurrencyToken();
            }

            entity.Property(e => e.Price).HasPrecision(18, 2);

            // Індекс для каталогу: швидкий пошук активних лотів + сортування за ціною
            entity.HasIndex(e => new { e.Status, e.Price });

            // НОВИЙ ІНДЕКС: Твій трейд-бот скаже тобі дякую.
            // Коли бот парситиме інвентар для передачі, він шукатиме лот саме за SteamAssetId
            entity.HasIndex(e => e.SteamAssetId);

            // Зв'язок з фізичним користувачем (Продавцем)
            entity.HasOne(e => e.Seller)
                .WithMany(u => u.Listings) // Тепер посилаємося на нову колекцію в User
                .HasForeignKey(e => e.SellerId)
                .OnDelete(DeleteBehavior.Cascade); // Якщо видаляємо користувача - видаляються всі його лоти

            // Зв'язок із довідником предметів (Items/Skins).
            // Інверсія зобов'язана вказувати на Item.Listings: інакше EF створює для колекції
            // другий зв'язок за конвенцією з shadow-колонкою ItemId1.
            entity.HasOne(e => e.Item)
                .WithMany(i => i.Listings)
                .HasForeignKey(e => e.ItemId)
                .OnDelete(DeleteBehavior.Restrict); // Restrict: захист від випадкового видалення предмета з бази, якщо він виставлений на продаж

            // Скріншоти шаряться між листингами одного екземпляра скіна,
            // тому видалення скріншота лише обнуляє посилання.
            entity.HasOne(e => e.Screenshot)
                .WithMany()
                .HasForeignKey(e => e.ScreenshotId)
                .OnDelete(DeleteBehavior.SetNull);
        });

        modelBuilder.Entity<Order>(entity =>
        {
            entity.HasKey(e => e.Id);

            entity.Property(e => e.LockPrice).HasPrecision(18, 2);
            entity.Property(e => e.CancelReason).HasMaxLength(500);

            entity.HasIndex(e => e.ListingId);
            entity.HasIndex(e => e.BuyerId);
            entity.HasIndex(e => e.SellerId);
            entity.HasIndex(e => e.Status);

            entity.HasOne(e => e.Listing)
                .WithMany()
                .HasForeignKey(e => e.ListingId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(e => e.Buyer)
                .WithMany()
                .HasForeignKey(e => e.BuyerId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(e => e.Seller)
                .WithMany()
                .HasForeignKey(e => e.SellerId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<SteamTrade>(entity =>
        {
            entity.HasKey(e => e.Id);

            entity.Property(e => e.TradeOfferId).HasMaxLength(100);

            entity.HasIndex(e => e.OrderId);
            entity.HasIndex(e => e.TradeOfferId).IsUnique();

            entity.HasOne(e => e.Order)
                .WithMany(e => e.SteamTrades)
                .HasForeignKey(e => e.OrderId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<CartItem>(entity =>
        {
            entity.HasKey(e => e.Id);

            entity.HasIndex(e => e.UserId);
            entity.HasIndex(e => e.ListingId);
            
            // Захист від дублів: один і той самий лот не можна додати двічі
            entity.HasIndex(e => new { e.UserId, e.ListingId }).IsUnique();

            entity.HasOne(e => e.User)
                .WithMany(u => u.CartItems)
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            entity.HasOne(e => e.Listing)
                .WithMany()
                .HasForeignKey(e => e.ListingId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<FinancialTransaction>(entity =>
        {
            entity.HasKey(e => e.Id);
            
            entity.Property(e => e.Amount).HasPrecision(18, 2);
            
            entity.HasIndex(e => e.UserId);
            entity.HasIndex(e => e.ReferenceId);
            entity.HasIndex(e => e.Type);
            entity.HasIndex(e => e.Status);

            entity.HasOne(e => e.User)
                .WithMany(u => u.FinancialTransactions)
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<Deposit>(entity =>
        {
            entity.HasKey(e => e.Id);
            
            entity.Property(e => e.NowPaymentsPaymentId).HasMaxLength(100);
            entity.Property(e => e.PayCurrency).HasMaxLength(20);

            entity.Property(e => e.FiatAmount).HasPrecision(18, 2);
            entity.Property(e => e.PayAmount).HasPrecision(28, 8); // High precision for crypto
            entity.Property(e => e.PayinHash).HasMaxLength(128);

            entity.HasIndex(e => e.UserId);
            entity.HasIndex(e => e.NowPaymentsPaymentId).IsUnique(); // Quick lookup for webhooks
            entity.HasIndex(e => e.TransactionId).IsUnique(); // One-to-one with FinancialTransaction
            entity.HasIndex(e => e.Status);

            entity.HasOne(e => e.User)
                .WithMany(u => u.Deposits)
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            entity.HasOne(e => e.Transaction)
                .WithMany() // No collection in FinancialTransaction for Deposit
                .HasForeignKey(e => e.TransactionId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<SupportTicket>(entity =>
        {
            entity.HasKey(e => e.Id);

            entity.Property(e => e.Subject).HasMaxLength(200);

            entity.HasIndex(e => e.Status);
            entity.HasIndex(e => e.Category);
            entity.HasIndex(e => e.UserId);
            entity.HasIndex(e => e.OrderId);

            // Restrict on both relationships: Postgres rejects multiple cascade paths,
            // and we never want deleting a user/order to silently wipe support history.
            entity.HasOne(e => e.User)
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(e => e.Order)
                .WithMany()
                .HasForeignKey(e => e.OrderId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<TicketMessage>(entity =>
        {
            entity.HasKey(e => e.Id);

            entity.Property(e => e.Body).HasMaxLength(4000);

            entity.HasIndex(e => e.TicketId);

            entity.HasOne(e => e.Ticket)
                .WithMany(t => t.Messages)
                .HasForeignKey(e => e.TicketId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<Withdrawal>(entity =>
        {
            entity.HasKey(e => e.Id);

            entity.Property(e => e.AmountUsd).HasPrecision(18, 2);
            entity.Property(e => e.PlatformFeeUsd).HasPrecision(18, 2);
            entity.Property(e => e.PayoutAmountUsd).HasPrecision(18, 2);
            entity.Property(e => e.PayCurrency).HasMaxLength(20);
            entity.Property(e => e.PayoutAddress).HasMaxLength(255);
            entity.Property(e => e.PayoutExtraId).HasMaxLength(255);
            entity.Property(e => e.NowPaymentsPayoutId).HasMaxLength(100);
            entity.Property(e => e.NowPaymentsBatchId).HasMaxLength(100);
            entity.Property(e => e.PayoutTxHash).HasMaxLength(128);
            entity.Property(e => e.RejectionReason).HasMaxLength(500);

            entity.HasIndex(e => e.UserId);
            entity.HasIndex(e => e.Status);
            entity.HasIndex(e => e.NowPaymentsPayoutId);
            entity.HasIndex(e => e.TransactionId).IsUnique(); // one-to-one with FinancialTransaction

            entity.HasOne(e => e.User)
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(e => e.Transaction)
                .WithMany()
                .HasForeignKey(e => e.TransactionId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<ItemScreenshot>(entity =>
        {
            entity.HasKey(e => e.Id);

            // Дедуплікація рендерів: один екземпляр скіна — один набір скріншотів.
            entity.HasIndex(e => e.InspectHex).IsUnique();

            // Hex росте зі стікерами/брелоками, залишаємо запас.
            entity.Property(e => e.InspectHex).HasMaxLength(2048);
            entity.Property(e => e.ExternalGuid).HasMaxLength(64);
            entity.Property(e => e.FrontImagePath).HasMaxLength(300);
            entity.Property(e => e.BackImagePath).HasMaxLength(300);
            entity.Property(e => e.LastError).HasMaxLength(1000);
        });

        modelBuilder.Entity<OrderDispute>(entity =>
        {
            entity.HasKey(e => e.Id);

            entity.Property(e => e.FrozenPenaltyAmount).HasPrecision(18, 2);

            entity.HasIndex(e => e.Status);
            entity.HasIndex(e => e.Reason);
            entity.HasIndex(e => e.OrderId);

            // Business rule "one open dispute per order" enforced at the DB level:
            // partial unique index over the open statuses (Open=0, UnderReview=1).
            entity.HasIndex(e => e.OrderId)
                .IsUnique()
                .HasFilter("\"Status\" IN (0, 1)")
                .HasDatabaseName("IX_OrderDisputes_OrderId_OpenUnique");

            // Restrict: dispute history must survive order/user housekeeping.
            entity.HasOne(e => e.Order)
                .WithMany()
                .HasForeignKey(e => e.OrderId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<TlsnProofRecord>(entity =>
        {
            entity.HasKey(e => e.Id);

            // Stored as text, not jsonb: the raw TLSN transcript can contain unicode null escapes
            // that Postgres jsonb rejects (error 22P05). Opaque evidence blob, never queried into.
            entity.Property(e => e.PayloadJson).HasColumnType("text");

            entity.HasIndex(e => e.SteamTradeId);
            entity.HasIndex(e => e.OrderId);
            entity.HasIndex(e => e.Outcome);

            // SetNull: proofs are evidence and must outlive the order row itself.
            entity.HasOne(e => e.Order)
                .WithMany()
                .HasForeignKey(e => e.OrderId)
                .OnDelete(DeleteBehavior.SetNull);
        });

        modelBuilder.Entity<Notification>(entity =>
        {
            entity.HasKey(e => e.Id);

            entity.Property(e => e.Payload).HasColumnType("jsonb");

            // Feed query: latest notifications per user, newest first.
            entity.HasIndex(e => new { e.UserId, e.CreatedAt }).IsDescending(false, true);

            // Badge counter: unread rows only, kept small via partial index.
            entity.HasIndex(e => new { e.UserId, e.IsRead }).HasFilter("\"IsRead\" = false");

            entity.HasOne(e => e.User)
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });
    }
}
