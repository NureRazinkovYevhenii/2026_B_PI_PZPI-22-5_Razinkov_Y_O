namespace SkinHex.Core.Models;

public sealed class CreateListingsRequest
{
    public IReadOnlyList<CreateListingItemRequest> Items { get; init; } = Array.Empty<CreateListingItemRequest>();
}

public sealed class CreateListingItemRequest
{
    public string AssetId { get; init; } = null!;
    public decimal Price { get; init; }
}
