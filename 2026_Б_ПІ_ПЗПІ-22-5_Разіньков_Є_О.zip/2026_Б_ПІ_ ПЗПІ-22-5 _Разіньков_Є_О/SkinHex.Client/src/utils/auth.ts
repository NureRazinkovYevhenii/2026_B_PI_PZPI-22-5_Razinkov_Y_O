import type { AuthState, JwtPayload, TokenPair } from '../types';

const AUTH_STORAGE_KEY = 'skinhex.auth';
export const PROMPT_SEEN_KEY = 'skinhex.emailPromptSeen';

const roleClaimKeys = [
  'role',
  'roles',
  'http://schemas.microsoft.com/ws/2008/06/identity/claims/role',
  'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/role',
];

const nameClaimKeys = [
  'name',
  'unique_name',
  'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name',
];

function decodeJwtPayload(token: string): JwtPayload | null {
  const [, payload] = token.split('.');

  if (!payload) {
    return null;
  }

  try {
    const normalized = payload.replace(/-/g, '+').replace(/_/g, '/');
    const padded = normalized.padEnd(normalized.length + ((4 - (normalized.length % 4)) % 4), '=');

    return JSON.parse(atob(padded)) as JwtPayload;
  } catch {
    return null;
  }
}

function getStringClaim(payload: JwtPayload | null, keys: string[]) {
  if (!payload) {
    return null;
  }

  for (const key of keys) {
    const value = payload[key];

    if (typeof value === 'string' && value.trim()) {
      return value;
    }
  }

  return null;
}

function getRoles(payload: JwtPayload | null) {
  if (!payload) {
    return [];
  }

  return roleClaimKeys.flatMap((key) => {
    const value = payload[key];

    if (Array.isArray(value)) {
      return value.filter((item): item is string => typeof item === 'string');
    }

    if (typeof value === 'string') {
      return [value];
    }

    return [];
  });
}

function getUserId(payload: JwtPayload | null): string | null {
  if (!payload) {
    return null;
  }

  const userIdKeys = [
    'sub',
    'user_id',
    'userid',
    'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier',
  ];

  for (const key of userIdKeys) {
    const value = payload[key];
    if (typeof value === 'string' && value.trim()) {
      return value;
    }
  }

  return null;
}

export function buildAuthState(
  accessToken: string,
  refreshToken: string | null,
  tradeUrl: string | null = null,
  balance = 0,
  frozenBalance = 0,
  avatarUrl: string | null = null,
): AuthState {
  const payload = decodeJwtPayload(accessToken);
  const roles = getRoles(payload);

  return {
    accessToken,
    refreshToken,
    expiresAt: typeof payload?.exp === 'number' ? payload.exp * 1000 : null,
    name: getStringClaim(payload, nameClaimKeys),
    role: roles[0] ?? null,
    roles,
    tradeUrl,
    userId: getUserId(payload),
    steamId: typeof payload?.steam_id === 'string' ? payload.steam_id : null,
    balance,
    frozenBalance,
    avatarUrl,
  };
}

export function isUnverified(auth: AuthState | null) {
  return auth?.roles.some((role) => role.toLowerCase() === 'unverified') ?? false;
}

export function isAdmin(auth: AuthState | null) {
  return auth?.roles.some((role) => role.toLowerCase() === 'admin') ?? false;
}

export function setCookie(name: string, value: string, expiresMs?: number) {
  let expiresStr = '';
  if (expiresMs) {
    const date = new Date(expiresMs);
    expiresStr = `; expires=${date.toUTCString()}`;
  }
  document.cookie = `${name}=${value || ''}${expiresStr}; path=/; SameSite=Lax; Secure`;
}

export function deleteCookie(name: string) {
  document.cookie = `${name}=; path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT; SameSite=Lax; Secure`;
}

export function persistAuth(auth: AuthState) {
  localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(auth));
  localStorage.setItem('jwt_token', auth.accessToken);
  localStorage.setItem('refresh_token', auth.refreshToken ?? '');
  localStorage.setItem('auth_role', auth.role ?? '');
  localStorage.setItem('trade_url', auth.tradeUrl ?? '');
  localStorage.setItem('user_id', auth.userId ?? '');
  localStorage.setItem('steam_id', auth.steamId ?? '');
  
  // Set cookies for the extension to read
  setCookie('skinhex_jwt', auth.accessToken, auth.expiresAt ?? undefined);
  if (auth.refreshToken) {
    setCookie('skinhex_refresh_jwt', auth.refreshToken, auth.expiresAt ? auth.expiresAt + 7 * 24 * 60 * 60 * 1000 : undefined);
  }
}

export function clearPersistedAuth() {
  localStorage.removeItem(AUTH_STORAGE_KEY);
  localStorage.removeItem('jwt_token');
  localStorage.removeItem('refresh_token');
  localStorage.removeItem('auth_role');
  localStorage.removeItem('trade_url');
  localStorage.removeItem('user_id');
  localStorage.removeItem('steam_id');
  sessionStorage.removeItem(PROMPT_SEEN_KEY);

  // Clear cookies
  deleteCookie('skinhex_jwt');
  deleteCookie('skinhex_refresh_jwt');
}

function readStoredAuth(): AuthState | null {
  const stored = localStorage.getItem(AUTH_STORAGE_KEY);

  if (stored) {
    try {
      const parsed = JSON.parse(stored) as AuthState;

      if (parsed.accessToken) {
        return {
          ...parsed,
          balance: parsed.balance ?? 0,
          frozenBalance: parsed.frozenBalance ?? 0,
          avatarUrl: parsed.avatarUrl ?? null,
        };
      }
    } catch {
      clearPersistedAuth();
    }
  }

  const legacyToken = localStorage.getItem('jwt_token');

  if (!legacyToken) {
    return null;
  }

  const tradeUrl = localStorage.getItem('trade_url');

  return buildAuthState(legacyToken, localStorage.getItem('refresh_token'), tradeUrl);
}

function getTokensFromUrl() {
  let params = new URLSearchParams();

  if (window.location.search) {
    params = new URLSearchParams(window.location.search);
  } else if (window.location.hash.length > 1) {
    const hashContent = window.location.hash.startsWith('#?') 
      ? window.location.hash.slice(2) 
      : window.location.hash.slice(1);
    
    let queryPart = hashContent;
    const qIndex = hashContent.indexOf('?');
    if (qIndex !== -1) {
      queryPart = hashContent.slice(qIndex + 1);
    }
    
    params = new URLSearchParams(queryPart);
  }

  const accessToken = params.get('accessToken') ?? params.get('jwtToken') ?? params.get('token');
  const refreshToken = params.get('refreshToken');
  const tradeUrl = params.get('tradeUrl');

  return accessToken ? { accessToken, refreshToken, tradeUrl } : null;
}

export function cleanAuthParamsFromUrl() {
  const url = new URL(window.location.href);
  const keysToRemove = ['accessToken', 'jwtToken', 'token', 'refreshToken', 'tradeUrl'];

  keysToRemove.forEach((key) => url.searchParams.delete(key));

  let newHash = url.hash;
  if (newHash.length > 1) {
    const isQueryHash = newHash.startsWith('#?');
    const hashContent = isQueryHash ? newHash.slice(2) : newHash.slice(1);
    
    let pathPart = '';
    let queryPart = hashContent;

    const qIndex = hashContent.indexOf('?');
    if (qIndex !== -1) {
      pathPart = hashContent.slice(0, qIndex);
      queryPart = hashContent.slice(qIndex + 1);
    } else if (!hashContent.includes('=')) {
      queryPart = '';
      pathPart = hashContent;
    }

    if (queryPart) {
      const hashParams = new URLSearchParams(queryPart);
      let removedAny = false;
      keysToRemove.forEach((key) => {
        if (hashParams.has(key)) {
          hashParams.delete(key);
          removedAny = true;
        }
      });

      if (removedAny) {
        const newQueryString = hashParams.toString();
        
        if (pathPart) {
          newHash = newQueryString ? `#${isQueryHash ? '?' : ''}${pathPart}?${newQueryString}` : `#${isQueryHash ? '?' : ''}${pathPart}`;
        } else {
          newHash = newQueryString ? `#${isQueryHash ? '?' : ''}${newQueryString}` : '';
        }
      }
    }
  }

  window.history.replaceState({}, document.title, `${url.pathname}${url.search}${newHash}`);
}

export function readInitialAuth() {
  const tokenPair = getTokensFromUrl();

  if (tokenPair) {
    const auth = buildAuthState(tokenPair.accessToken, tokenPair.refreshToken, tokenPair.tradeUrl);
    persistAuth(auth);

    return { auth, fromUrl: true };
  }

  return { auth: readStoredAuth(), fromUrl: false };
}

export function extractTokenPair(value: unknown): TokenPair | null {
  if (!value || typeof value !== 'object') {
    return null;
  }

  const record = value as Record<string, unknown>;
  const directAccessToken = record.accessToken ?? record.jwtToken ?? record.token;

  if (typeof directAccessToken === 'string') {
    return {
      accessToken: directAccessToken,
      refreshToken: typeof record.refreshToken === 'string' ? record.refreshToken : null,
    };
  }

  return extractTokenPair(record.tokens ?? record.value);
}

